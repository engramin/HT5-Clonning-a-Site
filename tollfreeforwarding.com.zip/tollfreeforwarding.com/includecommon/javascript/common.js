//	This function trims all leading and trailing whitespace from a string
function trim(str) {
    return str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
}

//	This function returns the code of the key that was pressed on the user's keyboard
function checkKey(event) {
    var code;
    if (!event)
        var event = window.event;
    if (event.keyCode)
        code = event.keyCode;
    else
    if (event.which)
        code = event.which;
    return code;
}

// Function to find the index in an array of the first entry with a specific value.
// Returns -1 if no matching entry is found.
// It can be used, among other things, to get the index of a column in the column list of a JSON query result set.
Array.prototype.findIdx = function(value) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] == value)
            return i;
    }
    return -1;
}

//	This function finds the index of a form's <select> object, based on the option's value
function findSelectIndexByValue(selObj, value) {
    for (var i = 0; i < selObj.length; i++)
        if (selObj[i].value == value)
            return i;
    return -1;
}

function setCookie(cookieName, value, expireDays) {
    var expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + expireDays);
    document.cookie = cookieName + "=" + escape(value) + ((expireDays == null) ? "" : ";expires=" + expirationDate.toUTCString());
}

function getCookie(cookieName) {
    if (document.cookie.length > 0) {
        startIdx = document.cookie.indexOf(cookieName + "=");
        if (startIdx != -1) {
            startIdx = startIdx + cookieName.length + 1;
            endIdx = document.cookie.indexOf(";", startIdx);
            if (endIdx == -1)
                endIdx = document.cookie.length;
            return unescape(document.cookie.substring(startIdx, endIdx));
        }
    }
    return null;
}

/*  This function formats a number so that there are at least as many digits after the decimal point as minDecimalPlaces
 *  dictates (pads with zeros if there are less digits than minDecimalPlaces).  After minDecimalPlaces has been satisfied,
 *  removes any trailing zeros after the last significant non-zero digit is reached.
 */
function floatFormat(number, minDecimalPlaces) {
    var formattedNumber = number.toString().split(".")[0];
    var trailingDigits = number.toString().split(".")[1];
    if (trailingDigits == undefined)
        trailingDigits = "0";
    var newTrailingDigits = "";
    var nonZeroFound = false;
    if (isNaN(number))
        return number;
    if (parseInt(trailingDigits) != 0) {
        for (var i = trailingDigits.length - 1; i >= 0; i--) {
            if (trailingDigits.charAt(i) != "0" || nonZeroFound) {
                newTrailingDigits = trailingDigits.charAt(i).toString() + newTrailingDigits.toString();
            }
            if (trailingDigits.charAt(i) != "0")
                nonZeroFound = true;
        }
        trailingDigits = newTrailingDigits;
    }
    if (minDecimalPlaces < 0)
        minDecimalPlaces = 0;
    if (minDecimalPlaces > 0) {
        formattedNumber = formattedNumber + ".";
        if (trailingDigits.length < minDecimalPlaces) {
            newTrailingDigits = trailingDigits;
            for (var i = 0; i < minDecimalPlaces - trailingDigits.length; i++) {
                newTrailingDigits = newTrailingDigits + "0";
            }
            trailingDigits = newTrailingDigits;
        }
        formattedNumber = formattedNumber + trailingDigits;
    }
    return formattedNumber;
}

function loaddivcontent(div, url) {
    $(div).load(url);
}

function switchcontent(content_id) {
    document.getElementById('banner_content').innerHTML = document.getElementById('banner_content_' + content_id).innerHTML;
    document.getElementById('banner_image').className = 'hp_g_' + content_id;

    document.getElementById('banner_btn_1').className = 'hp_btn_1';
    document.getElementById('banner_btn_2').className = 'hp_btn_2';
    document.getElementById('banner_btn_3').className = 'hp_btn_3';

    document.getElementById('banner_btn_' + content_id).className = 'hp_btn_' + content_id + '_o';

}



function pausescroller(content, divId, divClass, delay) {
    this.content = content //message array content
    this.tickerid = divId //ID of ticker div to display information
    this.delay = delay //Delay between msg change, in miliseconds.
    this.mouseoverBol = 0 //Boolean to indicate whether mouse is currently over scroller (and pause it if it is)
    this.hiddendivpointer = 1 //index of message array for hidden div
    document.write('<div id="' + divId + '" class="' + divClass + '" style="position: relative; overflow: hidden"><div class="innerDiv" style="position: absolute; width: 100%" id="' + divId + '1">' + content[0] + '</div><div class="innerDiv" style="position: absolute; width: 100%; visibility: hidden" id="' + divId + '2">' + content[1] + '</div></div>')
    var scrollerinstance = this
    if (window.addEventListener) //run onload in DOM2 browsers
        window.addEventListener("load", function() {
            scrollerinstance.initialize()
        }, false)
    else if (window.attachEvent) //run onload in IE5.5+
        window.attachEvent("onload", function() {
            scrollerinstance.initialize()
        })
    else if (document.getElementById) //if legacy DOM browsers, just start scroller after 0.5 sec
        setTimeout(function() {
            scrollerinstance.initialize()
        }, 500)
}

function showcontent(id) {

    if (document.getElementById('pullquote' + id).style.display == "none") {
        document.getElementById('pullquote' + id).style.display = "";
    } else {
        document.getElementById('pullquote' + id).style.display = "none";
    }
}

function setpage(pagename, selectedcontent) {
    if (typeof rootdir == "undefined")
        rootdir = window.location.protocol + "//" + window.location.hostname + (window.location.port ? (":" + window.location.port) : "");
    switch (pagename) {
        case 'home':
            url = rootdir + '/';
            break;
        case 'features':
            url = rootdir + '/features/';
            break;
        case 'rates':
            url = rootdir + '/rates/';
            break;
        case 'enterprise':
            url = rootdir + '/rates/?selectplan=ENTPLUS';
            break;
        case 'howitworks':
            url = rootdir + '/content/how-it-works/';
            break;
        case 'howitworksmovie':
            url = rootdir + '/content/how-it-works-movie/';
            break;
        case 'faq':
            url = rootdir + '/faq/';
            break;
        case 'aboutus':
            url = rootdir + '/content/about-us/';
            break;
        case 'testimonials':
            url = rootdir + '/testimonials/';
            break;
        case 'contactus':
            url = rootdir + '/contact/';
            break;
        case 'gettingstarted':
            url = rootdir + '/content/getting-started/';
            break;
        case 'callrecording':
            url = rootdir + '/content/call_recording/';
            break;
        case 'whitepaper':
            url = rootdir + '/content/whitepaper/';
            break;
        case 'quotebuilder':
            url = rootdir + '/content/quotebuilder/';
            break;
        default:
            url = rootdir + "/content/" + pagename + "/";
    }

    if (selectedcontent == undefined)
        document.location = url;
    else
        document.location = url + "?selectedcontent=" + selectedcontent;
}