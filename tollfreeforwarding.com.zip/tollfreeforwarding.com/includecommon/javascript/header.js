/*	This library contains code that is shared by both the standard header and the checkout header	*/

//	The following function allows the popovers to stay visible while hovering over them (useful if, for example, we have links in the popover content that we want the user to be able to click)
(function($) {
    var oldHide = $.fn.popover.Constructor.prototype.hide;

    $.fn.popover.Constructor.prototype.hide = function() {
        if (this.options.trigger === "hover" && this.tip().is(":hover")) {
            var that = this;
            // try again after what would have been the delay
            setTimeout(function() {
                return that.hide.call(that, arguments);
            }, that.options.delay.hide);
            return;
        }
        oldHide.call(this, arguments);
    };
})(jQuery);

//	The following function creates a popover for a particular element, using our standard desired popover options (and also applies some kluges for IE and Chrome)
function fixed_popover(sel, content, position, top_offset, center, no_padding, template, container) {
    if (template == null)
        template = '<div class="popover NO_PADDING" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content NO_PADDING"></div></div>';
    var opts = {
        //container: "body",
        content: $(content).html(),
        html: true,
        placement: position,
        trigger: 'hover',
        delay: {
            show: 100,
            hide: 100
        },
        //template: '<div class="popover NO_PADDING" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content NO_PADDING"></div></div>'.replace(
        template: template.replace(
            /NO_PADDING/g, no_padding ? 'no_padding' : '')
    };
    if (container)
        opts.container = container;

    var popover = $(sel).popover(opts);
    if (center) {
        $(sel).on('shown.bs.popover', function() {
            var p = '#' + popover.attr('aria-describedby');
            if (/Chrome\//.test(navigator.userAgent)) {
                $(p).css({
                    'margin-left': '155px'
                });
            }
            $(p).find('.close').on('click', function() {
                $(p).remove();
            });
            /*.find('.popover-content').css({
            				padding: '0px'
            				}); /*.find('> *').css({
            				padding: '10px'
            				})*/
            ;
        });
    }
    var is_ie = /(MSIE)|(Trident)/.test(navigator.userAgent);
    if (position == 'top' && is_ie) {
        $(sel).hover(function() {
                // Disable pointer events so that the tooltip doesn't hide
                // itself, then show the popover.
                popover.css('pointer-events', 'none').popover('show');
                // Get the popover's id.
                var p = '#' + popover.attr('aria-describedby');
                // Move the popover as necessary
                var top = parseInt($(p).css('top'));
                $(p).css({
                    top: (top - top_offset) + 'px'
                });
                popover.css('pointer-events', 'auto');
            },
            function() {
                popover.popover('hide');
            });
    }
    return popover;
}

//	The following function makes sure that the footer is always positioned at the bottom of the viewport/window
$(function() {
    var wait = false;

    function fix() {
        $('#footer').css('position', $(document).height() > $(window).height() ? 'absolute' : 'fixed');
        wait = false;
    }
    fix();
    $(window).resize(function() {
        if (wait) {
            clearTimeout(wait);
            wait = false;
        }
        wait = setTimeout(fix, 10);
    });
});

//	The following function shows and hides our "faux" placeholders for input elements
$(function() {
    $("input[required='required'] + label, label#details-label").click(function(evt) {
        var elt = evt.target.previousElementSibling;
        elt.focus();
    });

    function check_overlay(evt) {
        var next = evt.target.nextElementSibling;
        if ($(evt.target).val())
            $(next).hide();
        else
            $(next).show();
    }
    $("#details, input[required='required']").keyup(check_overlay).keydown(check_overlay);
})

//	Activates the tool tips
$(function() {
    $("[data-toggle='tooltip']").tooltip();
})

//	Special "helper" function to show modals when they otherwise would show uncentered vertically (it happens sometimes with some of the modals; especially the ones that are shown via JavaScript)
function showModal(modalID, explicitClose) {
    if (explicitClose == null)
        explicitClose = true;
    $("#" + modalID).on("shown.bs.modal", function(e) {

        var marginTop = (window.innerHeight / 2) - ($("#" + modalID + " div.modal-content").height() / 2);

        // Prevents modal from having negative margin
        // Fix for some mobile modals that get pushed up under the top of the viewport
        if (marginTop <= 0) {
            marginTop = 0;
        }

        $("#" + modalID).animate({
            "margin-top": marginTop
        }, 500);
    });
    var options = explicitClose ? {
        backdrop: "static"
    } : {};
    $("#" + modalID).modal(options);
}