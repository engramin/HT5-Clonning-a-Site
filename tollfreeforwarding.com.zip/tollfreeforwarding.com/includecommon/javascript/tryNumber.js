var tnProxy = new tryNumberProxy();
tnProxy.setErrorHandler(proxyErrorHandler);

if (rootDir == null)
    var rootDir = window.location.protocol + "//" + window.location.host;

if (languageCode == null)
    var languageCode = "en";

var _tnbTranslations = {
    outOfStock: "We are currently out of stock of",
    numbers: "numbers",
    contactUsToOrder: "Please contact us to order, or choose a new number type.",
    difficultyProcessingRequest: "We are having difficulty processing your request.",
    checkYourInput: "Please check your input and try again.",
    ifProblemPersistsContactSupport: "If the problem persists, please contact customer support.",
    phoneNumberInvalid: "The phone number you entered above is invalid",
    pleaseCorrectTheFollowing: "Please correct the following"
};

//	This function is only used when attributes.obfuscateSelectOptions is true in the trynumber.cfm custom tag (which it should never be as of this writing, 12/01/2014), but keeping the logic just in case we ever decide to use it again)
function initializeSelectOptions(formName, selectedValues, webDisplayOnly) {
    if (webDisplayOnly == null)
        webDisplayOnly = true;
    var url = document.location.href.split("/").slice(0, 3).join("/") + "/content/ajax_actions.cfm";
    $("#selDNISGroup_" + formName).load(url + "?tnbajaxaction=getDNISGroupOptions&tnbselectval=" + selectedValues.dnisGroup);
    //$("#selDNISType_" + formName).load(url + "?tnbajaxaction=getDNISTypeOptions&dnisgroup=" + selectedValues.dnisGroup + "&tnbselectval=" + selectedValues.dnisType);
    $("#selDNISType_" + formName).load(url, {
        tnbajaxaction: "getDNISTypeOptions",
        dnis_group: selectedValues.dnisGroup,
        tnbselectval: selectedValues.dnisType,
        web_display_only: webDisplayOnly,
        languageCode: languageCode
    });
    $("#selDNIS_" + formName).load(url + "?tnbajaxaction=getDNISOptions&dnistype=" + selectedValues.dnisType + "&tnbselectval=" + selectedValues.dnis);
    // We don't want to use load() for selDestination since the callbackfunction for that executes once per element in the results,and we only want it to fire once at the end instead.
    $.get(url, {
        tnbajaxaction: "getDestinationOptions",
        tnbselectval: selectedValues.destE164 + "|" + selectedValues.destISO
    }, function(data) {
        $("#selDestination_" + formName).html(data);
        this("initializeRingTo_" + formName)();
    });
}

//	This function is called from the Try Number Bar whenever the user selects a new DNIS group (i.e., country)
function changeDNISGroup(groupObj, formName, webDisplayOnly) {
    if (webDisplayOnly == null)
        webDisplayOnly = true;
    // 11/09/2021 (LL): no longer needed
    /*
    if (typeof criteoPush == "function") {
    	if (formName == "tnbRatesSignup")
    		var criteoEvent = [{event: "viewBasket", item: [{id: $(groupObj).val(), price: 1, quantity: 1}]}];
    	else
    		var criteoEvent = [{event: "viewItem", item: $(groupObj).val()}];
    	criteoPush(criteoEvent);  
    	}
    else
    	console.log("criteoPush not defined");
    */

    if (groupObj.options[groupObj.selectedIndex].value == "")
        groupObj.selectedIndex = 0;
    tnProxy.setCallbackHandler(function(results) {
        loadDNISTypes(results, formName);
    });
    tnProxy.getDNISTypes(groupObj.options[groupObj.selectedIndex].value, true, webDisplayOnly, false, languageCode);
}

//	This function is called from the Try Number Bar whenever the user selects a new DNIS type
function changeDNISType(dnisTypeObj, formName) {
    //tnProxy.setCallbackHandler(loadDNISes);
    var dnisType = $(dnisTypeObj).val();
    loadToolTipContent(formName, dnisType);
    $("#dnisTypeWebDisplay_" + formName).html($("#" + $(dnisTypeObj).attr("id") + " option:selected").attr("data-webdisplay") == 0 ? "NOT DISPLAYED ON WEB SITE" : "");
    tnProxy.setCallbackHandler(function(results) {
        loadDNISes(results, formName);
    });
    tnProxy.getDNISByType(dnisType, "DNIS");
    setTrialOptions($("#selDNISType_" + formName + " option:selected").attr("data-istrialallowed"));
}

//	This function is called from the Try Number Bar whenever the user selects a new destination country
function changeDestination(destinationObj, formName) {
    var prefix = destinationObj.value.split("|")[0];
    $("#hidDestination_" + formName).val(prefix);
    if (prefix == "") {
        prefix = "1-";
        destinationObj.selectedIndex = 0;
    } else
    if (prefix == 1)
        prefix = "1-";
    else
    if (prefix == 999)
        prefix = "device@sip.yourdomain.com";
    else {
        prefix = "+" + prefix;
        prefix = prefix + "-";
    }
    document.getElementById("ringToValidate_" + formName).focus();
    document.getElementById("ringToValidate_" + formName).value = prefix;
    saveUserSelections(formName, formName.search(/signup/i) < 0);
}

var loadDNISTypes = function(results, formName) {
    var selIndex = -1;
    document.getElementById("selDNISType_" + formName).options.length = 0;
    for (i = 0; i < results.DATA.length; i++) {
        var option = new Option();
        option.text = results.DATA[i][results.COLUMNS.findIdx("SHORTNAME")];
        option.value = results.DATA[i][results.COLUMNS.findIdx("DNISTYPE")];
        option.title = option.text;
        var trueShortName = option.text;
        var isTrialAllowed = results.DATA[i][results.COLUMNS.findIdx("ISTRIALALLOWED")];
        var webDisplay = results.DATA[i][results.COLUMNS.findIdx("WEBDISPLAY")];
        if (results.COLUMNS.findIdx("TRUESHORTNAME") > -1)
            trueShortName = results.DATA[i][results.COLUMNS.findIdx("TRUESHORTNAME")];
        option.setAttribute("data-shortname", trueShortName);
        option.setAttribute("data-istrialallowed", isTrialAllowed == true || isTrialAllowed == 1 ? 1 : 0);
        option.setAttribute("data-webdisplay", webDisplay);
        document.getElementById("selDNISType_" + formName).options[i] = option;
        if ((results.DATA[i][results.COLUMNS.findIdx("DNISAVAILABLE")] > 0) && (selIndex == -1))
            selIndex = i;
    }
    if (selIndex == -1)
        selIndex = 0;
    document.getElementById("selDNISType_" + formName).selectedIndex = selIndex;
    changeDNISType(document.getElementById("selDNISType_" + formName), formName);
}

var loadDNISes = function(results, formName) {
    document.getElementById("selDNIS_" + formName).options.length = 0;
    for (i = 0; i < results.DATA.length; i++) {
        var option = new Option();
        option.text = results.DATA[i][results.COLUMNS.findIdx("APPEAR")];
        option.value = results.DATA[i][results.COLUMNS.findIdx("DNIS")];
        option.value = option.value.replace(/DNIS/i, "");
        option.title = option.text;
        document.getElementById("selDNIS_" + formName).options[i] = option;
    }
    document.getElementById("selDNIS_" + formName).selectedIndex = Math.floor(Math.random() * (results.DATA.length - 1));
    //	With our current skin (implemented in late 2014), you really only need to show/hide the wrapper and not the select element in the below conditional, but in case we change skins and the new skin doesn't have a wrapper,
    //	I'm including the show/hide of the actual select element, as well, just to be safe.
    if (document.getElementById("selDNIS_" + formName).options.length == 1 && document.getElementById("selDNIS_" + formName).options[0].value.split("_")[0] == 0) {
        $("#selDNIS_" + formName).hide();
        $("#selectWrap_DNIS_" + formName).hide();
    } else {
        $("#selDNIS_" + formName).show();
        $("#selectWrap_DNIS_" + formName).show();
    }
    saveUserSelections(formName, formName.search(/signup/i) < 0);
    if (typeof tnb_LoadDNISesCallback == "function")
        tnb_LoadDNISesCallback();
}

//	This function is fired every time the user clicks in the Ring To text box; if by default we pre-populate
//	that field with "device@sip.yourdomain.com" when SIP is chosen as the destination "country," but we don't
//	want that domain going into the cart, since it's meant simply for an example and not actual real data.
function checkRingTo(ringToObj) {
    if (ringToObj.value.toLowerCase().indexOf("yourdomain.com") >= 0)
        ringToObj.value = "";
}

//  refreshRates is a boolean value that indicates whether the Rates page should be refreshed
//	after the user's Try Number Bar selections are saved (assuming we're actually on the Rates page)
function saveUserSelections(formName, refreshRates) {
    // The ring-to validation object (among other things) calls this function, but we don't always have the fields available that would
    // necessitate executing this function (for example, when chowing the cart in step 3 of the checkout process) - if that's the case,
    // just exit the function without executing any of its code.
    if ($("#selDNISGroup_" + formName).length == 0)
        return;

    refreshRatesFlag = refreshRates;
    //	If we're going to refresh the rates content, let's keep track of the currently selected tab, so we can make sure that tab is again selected when the rates/tabs are refreshed
    if (refreshRatesFlag) {
        var tabIndex = 0;
        if (document.getElementById("pricingTabs") != null) {
            var tabID = $("#pricingTabs li.active a").attr("id").replace(/[^a-z]/gi, "").toLowerCase();
            switch (tabID) {
                case "enterprise":
                    tabIndex = 2;
                    break;
                case "business":
                    tabIndex = 1;
                    break;
            };
            tabIndex++; // (because tabs are 0-indexed)
        }
    }
    var dnisGroup = document.getElementById("selDNISGroup_" + formName).value;
    var type = document.getElementById("selDNISType_" + formName).value;
    var number = document.getElementById("selDNIS_" + formName).value;
    if (document.getElementById("selDestination_" + formName) == null) {
        var toCountry = "null";
        var toCountryCodeISO = "";
    } else {
        var toCountry = document.getElementById("selDestination_" + formName).value.split("|")[0];
        var toCountryCodeISO = $("#selDestination_" + formName).val().match(/|/) ? $("#selDestination_" + formName).val().split("|")[1] : "";
    }
    if (typeof toCountryCodeISO == "undefined")
        toCountryCodeISO = "";
    if (document.getElementById("ringToValidate_" + formName) == null)
        var ringTo = "null";
    else
        var ringTo = $.trim(document.getElementById("ringToValidate_" + formName).value);
    tnProxy.setCallbackHandler();

    if (isRatesPage && refreshRatesFlag) {
        $("#loading_message").show();
        $("#countryrates").load(ratesPageURL + "&tocountry=" + toCountry + "&tocountrycodeiso=" + toCountryCodeISO + "&type=" + type + "&seltab=" + tabIndex, function() {
            $("#loading_message").hide();
        });
    }
    tnProxy.saveTryNumber(dnisGroup, type, number, toCountry, ringTo, toCountryCodeISO);
}

function handleTryNumberFormSubmit(formName, tryOrBuy, bypassFreeEmailCheck, planID, minutesRequested, languageCode) {
    if (typeof tnbTranslations == "object")
        $.extend(_tnbTranslations, tnbTranslations);
    //toggleWaitMsg("");
    $("#btnSubmitSignupForm").hide();
    $("#signupWaitMsg").show();
    if (bypassFreeEmailCheck == null)
        bypassFreeEmailCheck = false;
    if (planID == null)
        planID = "";
    if (minutesRequested == null)
        minutesRequested = "";
    if (languageCode == null)
        languageCode = "en";
    var formData = getFormData(formName);
    $("#hidFirstName").text(formData.txtFirstName);
    $("#hidLastName").text(formData.txtLastName);
    $("#hidPhone").text(formData.txtPhone);
    $("#hidCompanyName").text(formData.txtCompanyName);
    $("#hidWebAddress").text(formData.txtWebAddress);
    if (!allowUnavailableDNISesInCart) {
        if (formData.selDNIS.split("_")[0] == 0) {
            alert(_tnbTranslations.outOfStock + "\n" + document.getElementById("selDNISType_" + formName).options[document.getElementById("selDNISType_" + formName).selectedIndex].text + " " + _tnbTranslations.numbers + ".\n" + _tnbTranslations.contactUsToOrder);
            return;
        }
    }
    if (formData.rdoUsageType != null && formData.rdoUsageType.toLowerCase() == "personal")
        bypassFreeEmailCheck = true;
    formData.tryOrBuy = tryOrBuy;
    formData.planID = planID;
    formData.minutesRequested = minutesRequested;
    formData = $.param(formData);
    var fieldNameList = "txtFirstName,txtLastName,txtEmail,txtConfirmEmail,rdoUsageType,chkAcceptTC,txtWebAddress,txtPhone";
    var isFreeEmail;
    var isUsernameUnique;
    var isRingToInvalid = false;
    //	Validate form
    $.post(
        window.location.protocol + "//" + window.location.host + "/content/checkout/ajax_actions.cfm", {
            action: "validateTryNumberForm",
            languageCode: languageCode,
            data: formData
        },
        function(results) {
            //toggleWaitMsg("none");
            if (typeof results == "undefined") {
                //toggleWaitMsg("none");
                $("#signupWaitMsg").hide();
                $("#btnSubmitSignupForm").show();
                alert(_tnbTranslations.difficultyProcessingRequest + "\n" + _tnbTranslations.checkYourInput + "\n" + _tnbTranslations.ifProblemPersistsContactSupport);
            } else {
                var errCount = 0;
                document.getElementById("errorMsg_" + formName).style.display = "none";
                $.each(fieldNameList.split(","), function(index, value) {
                    $("#" + value + "_errMsg").hide();
                });
                if (results.length > 0) {
                    //toggleWaitMsg("none");
                    $.each(results, function(index, value) {
                        var resultType = value.split("^")[0];
                        var fieldName = value.split("^")[1];
                        var fieldValue = value.split("^")[2];
                        if (resultType.toLowerCase() == "err") {
                            errCount++;
                            if (fieldName == "txtRingTo")
                                isRingToInvalid = true;
                            if (!(fieldName == "txtRingTo" && $("#resultID_" + formName).html().indexOf(fieldValue) >= 0)) {
                                $("#" + fieldName + "_errMsg").html(fieldValue).show();
                            }
                        } else
                        if (resultType.toLowerCase() == "info")
                            eval(fieldName + " = " + fieldValue);
                    });
                    if (errCount == 0) {
                        if (isFreeEmail != null && isFreeEmail == 1 && !bypassFreeEmailCheck) {
                            errCount++;
                            if (formName == "custom_mobile") { //	Does this even get executed?  I'm not 100% sure, but I strongly believe that the mobile layout logic flows to the last 'else' statement in this conditional, and not to this first conditional
                                $("#hidRingToValidate_" + formName).val($("#ringToValidate_" + formName).val());
                                $("#" + formName).attr("action", window.location.protocol + "//" + window.location.host + "/content/checkout/anonymous_email.cfm");
                                $("#" + formName).submit();
                            } else
                            if (formName == "tnbRatesSignup") {
                                $("#emailLabel").html($.trim($("#txtEmail_" + formName).val()));
                                $("#step1").modal("hide");
                                $("#businessEmailWaitMsg").hide();
                                $("#submitBusinessEmailWrapper").show();
                                $("#continueWithFreeEmail").show();
                                $("#business_email").modal({
                                    backdrop: "static"
                                });
                            } else
                                //	Is this where the mobile layout logic flows to?
                                showFancyBox(window.location.protocol + "//" + window.location.host + "/content/checkout/anonymous_email.cfm?" + formData);
                        } else
                        if (!isUsernameUnique && $("#txtEmail_" + formName).val() != (sessionCustomerUserName != null && sessionCustomerUserName != "" ? sessionCustomerUserName : null)) {
                            if ($("input[name='skin']").length != 0 && document.tryNumberForm.skin.value == "custom_mobile") {
                                //	Mobile layout (legacy) logic
                                errCount++;
                                showFancyBox(window.location.protocol + "//" + window.location.host + "/content/checkout/duplicate_username.cfm?" + formData);
                            } else {
                                errCount++;
                                $("#step1").modal("hide");
                                $("#txtEmail3").val($.trim($("#txtEmail_" + formName).val()));
                                $("label[for='txtEmail3']").hide();
                                $("#duplicate_username").modal({
                                    backdrop: "static"
                                });
                            }
                        }
                    } else {
                        if (errCount == 1 && isRingToInvalid)
                            var errMsg = _tnbTranslations.phoneNumberInvalid;
                        else
                            var errMsg = _tnbTranslations.pleaseCorrectTheFollowing + ":";
                        $("#signupWaitMsg").hide();
                        $("#btnSubmitSignupForm").show();
                        $("#errorMsg_" + formName).html(errMsg).show();
                    }
                }
                if (errCount == 0) {
                    //document.getElementById("tryOrBuy_" + formName).value = tryOrBuy;
                    addToCart(formName, tryOrBuy, planID, minutesRequested, function() {
                        submitTNBForm(formName, formData);
                    });
                }
            }
        },
        "json"
    );
}

function getFormData(formName) {
    var formData = {
        formName: formName,
        txtFirstName: $("#txtFirstName_" + formName).val(),
        txtLastName: $("#txtLastName_" + formName).val(),
        txtEmail: $("#txtEmail_" + formName).val(),
        rdoUsageType: $("input[type='radio'][id^='rdoUsageType_" + formName + "'" + "]:checked").val(),
        chkAcceptTC: $("#chkAcceptTC_" + formName).is(":checked"),
        hidUserName: $("#hidUserName_" + formName).val(),
        selDNIS: $("#selDNIS_" + formName).val(),
        selDestination: $("#selDestination_" + formName).val(),
        ringToValidate: $("#ringToValidate_" + formName).val(),
        txtRingTo: $("#ringToValidate_" + formName).val()
    };
    if (document.getElementById("txtConfirmEmail_" + formName))
        formData.txtConfirmEmail = $("#txtConfirmEmail_" + formName).val();
    if (document.getElementById("selPhoneCountry_" + formName))
        formData.selPhoneCountry = $("#selPhoneCountry_" + formName).val();
    if (document.getElementById("txtPhone_" + formName))
        formData.txtPhone = $("#txtPhone_" + formName).val();
    if (document.getElementById("txtCompanyName_" + formName))
        formData.txtCompanyName = $("#txtCompanyName_" + formName).val();
    if (document.getElementById("txtWebAddress_" + formName))
        formData.txtWebAddress = $("#txtWebAddress_" + formName).val();
    if (allowUnavailableDNISesInCart)
        formData.selDNISType = $("#selDNISType_" + formName).val();
    if (typeof $("input[name='skin']") != "undefined")
        formData.skin = $("input[name='skin']").val();
    return formData;
}

function submitTNBForm(formName, formData) {
    window.location.href = secureRootDir + "/checkout/step1/?deserialize&" + formData;
};

function addToCart(formName, tryOrBuy, ratePlan, minutesRequested, callbackHandler) {
    var dnis = document.getElementById("selDNIS_" + formName).value;
    if (document.getElementById("selDestination_" + formName) == null) {
        var destinationCountryCode = "null";
        var destinationCountryCodeISO = "";
    } else {
        var destinationCountryCode = document.getElementById("selDestination_" + formName).value.split("|")[0];
        var destinationCountryCodeISO = $("#selDestination_" + formName).val().match(/|/) ? $("#selDestination_" + formName).val().split("|")[1] : "";
    }
    if (document.getElementById("ringToValidate_" + formName) == null)
        var ringTo = "null";
    else
        var ringTo = $.trim(document.getElementById("ringToValidate_" + formName).value);
    if (ratePlan == null)
        ratePlan = "";
    if (callbackHandler == null)
        callbackHandler = goToCheckout;
    tnProxy.setCallbackHandler(callbackHandler);
    tnProxy.addToCart(dnis, destinationCountryCode, ringTo, ratePlan, tryOrBuy, minutesRequested, destinationCountryCodeISO);
}

function deleteFromCart(dnis, callbackHandler) {
    tnProxy.setCallbackHandler(callbackHandler);
    tnProxy.deleteFromCart(dnis);
}

function loadToolTipContent(formName, selDNISType, accountID) {
    if (accountID == null)
        accountID = _localAccountID != null ? _localAccountID : 0;
    var index = document.getElementById("selDNISType_" + formName).selectedIndex;
    region_name_html = document.getElementById("selDNISType_" + formName).options[index].text;
    region_name_html = $("#selDNISType_" + formName + " option:selected").attr("data-shortname");
    dnisgroup = document.getElementById("selDNISGroup_" + formName).value;
    $("#region_name_" + formName).html(region_name_html);
    var url = window.location.protocol + "//" + window.location.host + "/content/notespopup.cfm?selDNISType=" + selDNISType + "&dnisgroup=" + dnisgroup + "&localAccountID=" + accountID + "&setLanguage=" + languageCode;
    //var url = rootDir + "/content/notespopup.cfm?selDNISType=" + selDNISType + "&dnisgroup=" + dnisgroup + "&localAccountID=" + accountID;
    $.get(
        url,
        function(data) {
            var myPopover = $("#dnisNotes_" + formName).data("bs.popover");
            //	Check to make sure myPopover is defined, since we don't use popovers for things like the mobile skin
            if (myPopover != null) {
                //myPopover.options.html = true;
                myPopover.options.content = data;
                //$("#dnisNotes_" + formName).popover("show");
            }
        }
    );
}

function setTrialOptions(isTrialAllowed) {
    var bIsTrialAllowed = isTrialAllowed == true || isTrialAllowed == 1;
    $(".tnbaction_buy")[bIsTrialAllowed ? "show" : "hide"]();
    $(".tnbaction_try").each(function(idx, val) {
        var linkHref = $(this).attr("href");
        var linkHtml = $(this).html();
        if (linkHref) {
            if (bIsTrialAllowed) {
                linkHref = linkHref.replace(/'buy'/i, "'try'");
                linkHtml = linkHtml.replace($(this).attr("data-label-buy"), $(this).attr("data-label-try"));
            } else {
                linkHref = linkHref.replace(/'try'/i, "'buy'");
                linkHtml = linkHtml.replace($(this).attr("data-label-try"), $(this).attr("data-label-buy"));
            }
            $(this).attr("href", linkHref).html(linkHtml);
        }
    });
}

/*
var reLoadStep1 = function() {
	window.location.href ='index.cfm';
	}
*/

var goToCheckout = function() {
    window.location.href = secureRootDir + "/checkout/step2/";
}

// Error handler for the asynchronous functions
var proxyErrorHandler = function(statusCode, statusMsg) {
    /*
    if (document.getElementById("ajaxLoaderMsg1"))
    	document.getElementById("ajaxLoaderMsg1").style.display = "none";
    */
    alert('Status: ' + statusCode + ', ' + statusMsg);
    //alert("We could not process your request");
}