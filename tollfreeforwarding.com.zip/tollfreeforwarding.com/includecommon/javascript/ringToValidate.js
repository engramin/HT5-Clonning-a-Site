//added to indent validation text
if (!window.adjustValidationTextLeft) {
    adjustValidationTextLeft = "0px";
}
if (!window.ValidationTextColor) {
    ValidationTextColor = "#000";
}

if (typeof $ != "undefined") /* The following block of JS REQUIRES jQuery!!!  The following code was tested with jQuery version 1.3.2. */ {
    /* Ring To Validation Object ==================================================================================================== */
    var ringToValidation = {
        minRingToLength: 4,
        /* Minimum ringTo length for processing. */
        top: 0,
        /* Result box "top" position in pixel. */
        left: 0,
        /* Result box "left" position in pixel. */
        width: 0,
        /* Result box "width" in pixel. */
        height: 0,
        /* Result box "height" in pixel. */
        xhr: new Array(),
        /* Array storing XMLHttpRequest objects to refer back later if needed. */
        jqObj: "",
        /* RingTo input jQuery object. */
        jqSel: "",
        /* Country select jQuery object (set only if available). */
        resultID: "",
        /* Result box "id". */
        destPrefixChoice: "",
        /* Result box destination selected by the user. */
        prefixLookUpOpt: "",
        /* Result box link "class"/ */
        jqObjResult: "",
        /* Result box jQuery object. */
        isRingTo: true,
        /* Indicates that this validation is on a ring-to (as opposed to, for example, a regular contact number, etc.) */
        allowOverrideOn: "",
        /* Allows user to continue on error if the number matches this value. */
        restrictedDestinations: "",
        /* Comma-delimited list of country code ISOs that are not allowed as ring-to countries, which override any global restrictions. */
        allowedRestrictedDestinations: "",
        /* Comma-delimited list of country code ISOs that are allowed as ring-to countries, which override any global restrictions. */
        isSubmitOnEnd: false,
        /* Submit on successful ajax check. */
        isQtipSuppressed: false,
        /* Suppress qTip flag. */
        isValid: false,
        /* Ring to validation produce valid result. */
        isOverride: false,
        /* Allow submit even if result is invalid. */
        rootDir: "",
        /* Default root directory if one is not passed to the init function. */
        functionToCallAfterInitialization: "",
        /* Name of a JavaScript function to execute after the init function completes */
        functionToCallAfterValidation: "",
        /* Name of a JavaScript function to execute after the runRingToValidation function completes */
        functionToCallAfterCountryChange: "",
        /* Name of a JavaScript function to execute after the destination country is changed */
        resultCSS: {},
        /* Object of CSS styling for result box */
        tryNumberFormName: "tryNumberForm",
        /* Name of the try number form */
        refreshRates: false,
        /* If true, refreshes the rates on the rates page when destination country is changed */
        /* Main Init ================================================================================================================ */
        /*
         * 	arguments[0] = RingTo input field id
         * 	arguments[1] = County select field name
         */
        init: function() {
            var rtvObj = this;
            /* Required ring to input id */
            rtvObj.jqObj = $("#" + arguments[0]);
            this.width = rtvObj.jqObj.width() - 2;

            /* Optional Country Select Option name */
            if (typeof arguments[1] != "undefined" && arguments[1].length > 0) {
                rtvObj.jqSel = $("select[name=" + arguments[1] + "]");
                rtvObj.destPrefixChoice = rtvObj.jqSel.val().replace(/\.0$/ig, "").replace(/\D/ig, "");

                /* Set Country select events. */
                rtvObj.jqSel.change(function() {
                    rtvObj.destPrefixChoice = $(this).val().replace(/\.0$/ig, "").replace(/\D/ig, "");
                    rtvObj.jqObjResult.html("&nbsp;");
                }).focus(function() {
                    rtvObj.clearQTip();
                    rtvObj.isQtipSuppressed = true;
                });
            }

            /* Generate random id/class (unless resultID was explicitly passed) */
            if (rtvObj.resultID != "")
                rtvObj.resultID = "resultID_" + rtvObj.resultID;
            else
                rtvObj.resultID = "resultID_" + Math.floor(Math.random() * 1000001);
            rtvObj.prefixLookUpOpt = "prefixLookUpOpt_" + Math.floor(Math.random() * 1000001);
            rtvObj.closeQTip = "closeQTip_" + Math.floor(Math.random() * 1000001);

            /* Result box */
            rtvObj.initResultBox();
            rtvObj.initMessage();

            /* Set RingTo Validate Events */
            rtvObj.jqObj.keydown(function(event) {
                if (rtvObj.verifyKeycode(parseInt(event.keyCode, 10))) {
                    //rtvObj.abortRequests();
                }

                if (parseInt(event.keyCode, 10) == 13) {
                    rtvObj.isSubmitOnEnd = true;
                    $(this).blur();
                }
            }).focus(function() {
                rtvObj.clearQTip();
                //rtvObj.isQtipSuppressed = false;
            }).blur(function() {
                var origRingTo = $.trim($(this).val());
                var currRingTo = origRingTo.replace(/\D*/gi, "");

                if ((origRingTo.match(/^\+?\d{1,4}\-?$/ig) && currRingTo.length > rtvObj.minRingToLength) ||
                    (!origRingTo.match(/^\+?\d{1,4}\-?$/ig) && origRingTo.length > rtvObj.minRingToLength)) {
                    if (rtvObj.jqSel.length != 0 && rtvObj.jqSel.val().replace(/\.0$/ig, "").replace(/\D/ig, "").length > rtvObj.minRingToLength) {
                        rtvObj.destPrefixChoice = rtvObj.jqSel.val().replace(/\.0$/ig, "").replace(/\D/ig, "");
                        var tmpRegX = "/^1?" + rtvObj.destPrefixChoice.replace(/^1/ig, "") + "/i";
                        if (rtvObj.destPrefixChoice.match(/^1/i) && currRingTo.match(eval(tmpRegX))) {
                            rtvObj.updRingToInput(currRingTo, true);
                        }
                    }
                    rtvObj.runRingToValidation(origRingTo);
                } else {
                    rtvObj.jqObjResult.html("&nbsp;"); /* Enter your existing phone number above. */
                    rtvObj.destPrefixChoice = "";
                }
            }).change(function() {
                rtvObj.isQtipSuppressed = false;
            });

            /* Set Result box link events. */
            //$("a." + rtvObj.prefixLookUpOpt).on("mousedown", function(){
            $(document).on("mousedown", "a." + rtvObj.prefixLookUpOpt, function(e) {
                //e.preventDefault();
                if (typeof $(this).attr("data-destination") != "undefined")
                    var destTxt = $(this).attr("data-destination");
                else
                    var destTxt = $(this).html();
                var tmpRingTo = rtvObj.jqObj.val();
                rtvObj.destPrefixChoice = destTxt.replace(/\D/ig, "");

                /* Add "1" for NANPA links */
                if (rtvObj.destPrefixChoice.match(/^1/i) && !destTxt.match(/^SIP\/VoIP$/i)) {
                    rtvObj.updRingToInput(tmpRingTo, true);
                }
            }).on("click", "a." + rtvObj.prefixLookUpOpt, function(e) {
                //e.preventDefault();
                if (typeof $(this).attr("data-destination") != "undefined")
                    var destTxt = $(this).attr("data-destination");
                else
                    var destTxt = $(this).html();
                var origRingTo = rtvObj.jqObj.val();
                var tmpRingTo = origRingTo;
                var isNANPA = destTxt.replace(/\D/ig, "").match(/^1/i);

                tmpRingTo = tmpRingTo.replace(/\D/ig, "");
                tmpRingTo = tmpRingTo.replace(/^1/ig, ""); /* Remove leading one since it will be added later. */

                /* Special case for GB */
                if (!isNANPA && tmpRingTo.match(/^44/i) && tmpRingTo.length > 2 && !destTxt.match(/^SIP\/VoIP$/i)) {
                    tmpRingTo = tmpRingTo.replace(/^(\d{2})0(\d*)$/ig, "$1$2");
                }

                /* Special case for SIP/VoIP */
                if (destTxt.match(/^SIP\/VoIP$/i)) {
                    rtvObj.updRingToSelect(destTxt);
                    rtvObj.updRingToInput(origRingTo, false, true);
                } else {
                    rtvObj.updRingToSelect(destTxt);
                    rtvObj.updRingToInput(tmpRingTo, isNANPA);
                }

                rtvObj.clearQTip();
                rtvObj.jqObj.focus();
                rtvObj.runRingToValidation(rtvObj.jqObj.val());
                return false;
            }).on("click", "a." + rtvObj.closeQTip, function(e) {
                //$("a." + rtvObj.closeQTip).on("click", function () {
                //e.preventDefault();
                rtvObj.clearQTip();
                rtvObj.jqObj.focus();
                return false;
            });

            /* Modify Submit Buttons */
            $("a[href*='javascript:addToCart(']").click(function() {
                $(this).attr("href", "#");
                rtvObj.isSubmitOnEnd = true;
                rtvObj.runRingToValidation(rtvObj.jqObj.val());
            });

            rtvObj.jqObj.focus().blur();

            if (rtvObj.functionToCallAfterInitialization != "") {
                if (typeof rtvObj.functionToCallAfterInitialization == "function")
                    rtvObj.functionToCallAfterInitialization();
                else
                    window[rtvObj.functionToCallAfterInitialization]();
            }

            return this;
        },
        /* Verify keycode =========================================================================================================== */
        /*
         * 	arguments[0] = keycode value to be verified.
         */
        verifyKeycode: function() {
            var tmpKeycode = arguments[0];

            if ((parseInt(tmpKeycode, 10) >= 48 && parseInt(tmpKeycode, 10) <= 57) ||
                (parseInt(tmpKeycode, 10) >= 96 && parseInt(tmpKeycode, 10) <= 105) ||
                parseInt(tmpKeycode, 10) == 8 || parseInt(tmpKeycode, 10) == 46 ||
                parseInt(tmpKeycode, 10) == 86 || parseInt(tmpKeycode, 10) == 17) {
                return true;
            }
            return false;
        },
        /* Init result box ========================================================================================================== */
        /*
         * 	No arguments.
         */
        initResultBox: function() {
            var rtvObj = this;
            if (rtvObj.resultCSS.fontFamily == null)
                rtvObj.resultCSS.fontFamily = "arial";
            if (rtvObj.resultCSS.fontSize == null)
                rtvObj.resultCSS.fontSize = "10px";
            if (rtvObj.resultCSS.fontWeight == null)
                rtvObj.resultCSS.fontWeight = "normal";
            if (rtvObj.resultCSS.fontStyle == null)
                rtvObj.resultCSS.fontStyle = "normal";
            if (rtvObj.resultCSS.color == null)
                rtvObj.resultCSS.color = window.ValidationTextColor != null ? window.ValidationTextColor : "black";
            if (rtvObj.resultCSS.textAlign == null)
                rtvObj.resultCSS.textAlign = "center";
            if (rtvObj.resultCSS.verticalAlign == null)
                rtvObj.resultCSS.verticalAlign = "middle";
            if (rtvObj.resultCSS.padding == null)
                rtvObj.resultCSS.padding = "2px";
            if (rtvObj.resultCSS.whiteSpace == null)
                rtvObj.resultCSS.whiteSpace = "nowrap";
            if (rtvObj.resultCSS.Float == null)
                rtvObj.resultCSS.Float = "left";
            if (rtvObj.resultCSS.marginLeft == null)
                rtvObj.resultCSS.marginLeft = window.adjustValidationTextLeft != null ? window.ValidationTextLeft : "0px";
            rtvObj.jqObj.after('<br /><div id="' + rtvObj.resultID + '">&nbsp;</div>');
            rtvObj.jqObjResult = $("#" + rtvObj.resultID);
            rtvObj.jqObjResult.css("color", rtvObj.resultCSS.color)
                .css("padding", rtvObj.resultCSS.padding)
                .css("font-size", rtvObj.resultCSS.fontSize)
                .css("font-weight", rtvObj.resultCSS.fontWeight)
                .css("font-style", rtvObj.resultCSS.fontStyle)
                .css("font-family", rtvObj.resultCSS.fontFamily)
                .css("text-align", rtvObj.resultCSS.textAlign)
                .css("vertical-align", rtvObj.resultCSS.verticalAlign)
                .css("white-space", rtvObj.resultCSS.whiteSpace)
                .css("float", rtvObj.resultCSS.Float)
                .css("margin-left", rtvObj.resultCSS.marginLeft)

            if (rtvObj.jqObj.prev("label").length) {
                rtvObj.jqObjResult.css("margin-top", "0")
                    .css("text-align", "right")
                    .css("width", "92%")
                    .css("padding-right", "0");
            } else {
                rtvObj.jqObjResult.css("width", "95%");
            }
        },
        /* Init and reset result box content. ======================================================================================= */
        /*
         * 	No arguments.
         */
        initMessage: function() {
            var rtvObj = this;
            rtvObj.jqObjResult.html("&nbsp;");
        },
        /* Reset the result box position and dimensions. ============================================================================ */
        /*
         *  No arguments.
         */
        setDivPosition: function() {
            var rtvObj = this;
            var o, w, h;
            var minW = 232;
            var tmpW = (rtvObj.jqObjResult.html().replace(/<\/?[^>]+>/gi, "").length * 6) + 5;

            o = rtvObj.jqObj.offset();
            w = rtvObj.jqObj.width();
            h = rtvObj.jqObj.height();

            rtvObj.width = (tmpW < minW) ? minW : tmpW;
            rtvObj.height = 30;
            rtvObj.top = 0;
            rtvObj.left = 0;

            rtvObj.jqObjResult.css("top", rtvObj.top + "px")
                .css("left", rtvObj.left + "px")
                .css("height", rtvObj.height + "px");
        },
        /* Utility function to get domain =========================================================================================== */
        /*
         * 	No arguments.
         */
        getDomain: function() {
            var myDomain = document.domain;
            return myDomain;
        },
        /* ReadCookie value ========================================================================================================= */
        /*
         * arguments[0] = cookie value to read.
         */
        readCookie: function() {
            var name = arguments[0];
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) return eval('(' + unescape(c.substring(nameEQ.length, c.length)) + ')');
            }
            return null;
        },
        /* MatchCookie value ======================================================================================================== */
        /*
         * arguments[0] = prefix to match with tocountry cookie value.
         */
        matchCookie: function() {
            var rtvObj = this;
            var chkValue = arguments[0];
            if (typeof arguments[1] == "undefined")
                arguments[1] = "";
            var iso = arguments[1];

            if (typeof rtvObj.readCookie("TRYNUMBER") == "object") {
                var tryNumberISO = rtvObj.readCookie("TRYNUMBER")["TOCOUNTRYCODEISO"];
                if (parseInt(chkValue, 10) == parseInt(rtvObj.readCookie("TRYNUMBER")["TOCOUNTRY"], 10) && (iso == "" || tryNumberISO == "" || iso == tryNumberISO)) {
                    return true;
                }
            }
            return false;
        },
        /* Update ringTo select with MINPREFIX ====================================================================================== */
        /*
         * 	arguments[0] = Ring to prefix.
         */
        updRingToSelect: function() {
            var rtvObj = this;
            if (isNaN(arguments[0]))
                arguments[0] = "";
            var tmpPrefix = arguments[0];
            if (typeof arguments[1] == "undefined")
                arguments[1] = arguments[0];
            var e164 = arguments[1];
            if (typeof arguments[2] == "undefined")
                if (tmpPrefix.split("^").length > 1)
                    arguments[2] = tmpPrefix.split("^")[1].split("^")[0];
                else
                    arguments[2] = "";
            var iso = arguments[2];
            var destPrefix = tmpPrefix.replace(/\.0$/ig, "").replace(/\D/ig, "");
            var destPrefixMinLOne = destPrefix.replace(/^1/ig, "");
            var isFound = false;
            var isChange = false;
            var isMatchCookie = true;

            /* Set destination if select field exists.  */
            if (rtvObj.jqSel.length != 0) {

                /* Special Case for SIP/VoIP destination */
                if (arguments[0].match(/^SIP\/VoIP$/i)) {
                    destPrefix = "999";
                }

                //var prevE164 = $(rtvObj.jqSel).val();
                var selectedIndex = $(rtvObj.jqSel).find("option:selected")[0].index;
                if (typeof selectedIndex == "undefined")
                    selectedIndex = 0;

                var currDestCountryName = $.trim(rtvObj.jqObjResult.html().split(" - ")[0].split("(")[0]);
                var optionValue = "";
                var optionText = "";

                //	Ring-to country select options can be pipe-delimited to allow for multiple pieces of data (e.g., ISO and E164),
                //	but the E164 value must always be the first (or only) element in the list in order for this to work correctly.
                rtvObj.jqSel.find("option").filter(function(index) {
                    optionValue = $(this).val().split("|")[0];
                    optionText = $.trim($(this).text().replace(/\(?\+/gi, "+").replace(/\s1/gi, "").split("+")[0]).toLowerCase();
                    if (!isFound &&
                        (
                            (
                                (
                                    optionText == currDestCountryName.toLowerCase() ||
                                    currDestCountryName.toLowerCase() == 'united states' ||
                                    (currDestCountryName.toLowerCase() == 'canada' && optionText.indexOf('canada') >= 0)
                                ) &&
                                (
                                    /*optionValue.match("^,?\s?" + destPrefix + "\D?$") || optionValue.match("^,?\s?" + destPrefix + "\s?,?-?") || */
                                    optionValue.split("-")[0] == e164
                                )
                            ) ||
                            (iso != "" && $(this).val().split("|").length > 1 && $(this).val().split("|")[1] == iso)
                        )
                    ) {
                        if (!$(this).is(":selected") && !isChange) {
                            isChange = true;
                        }
                        $(this).attr("selected", "selected");
                        selectedIndex = $(this).index();
                        rtvObj.destPrefixChoice = optionValue.replace(/\.0$/ig, "").replace(/\D/ig, "");
                        isMatchCookie = rtvObj.matchCookie(destPrefix, iso);
                        isFound = true;
                    } else if (isFound == false && destPrefixMinLOne == 684 && optionValue.match("^,?\s?" + destPrefixMinLOne + "\s?,?-?")) {
                        if (!$(this).is(":selected") && !isChange) {
                            isChange = true;
                        }
                        $(this).attr("selected", "selected");
                        selectedIndex = $(this).index();
                        rtvObj.destPrefixChoice = optionValue.replace(/\.0$/ig, "").replace(/\D/ig, "");
                        isMatchCookie = rtvObj.matchCookie(destPrefixMinLOne, iso);
                        isFound = true;
                    }
                });

                /* Assumes USA/Canada if the country prefix was not found. */
                if (!isFound && destPrefix.match("^1")) {
                    rtvObj.jqSel.find("option").filter(function(index) {
                        if (($(this).val().split("|")[0].match("^1-?$")) && rtvObj.destPrefixChoice.toString() != "1") {
                            if (!$(this).is(":selected") && !isChange) {
                                isChange = true;
                            }
                            $(this).attr("selected", "selected");
                            selectedIndex = $(this).index();
                            rtvObj.destPrefixChoice = "1";
                            isMatchCookie = rtvObj.matchCookie("1", "US");
                            isFound = true;
                        }
                    });
                }
                rtvObj.jqSel.find("option:selected").each(function(idx, val) {
                    $(this).removeAttr("selected");
                });
                var selectedValue = $(rtvObj.jqSel.find("option")[selectedIndex]).val();
                $(rtvObj.jqSel).val(selectedValue);
                if (isChange && !isMatchCookie) {
                    if (typeof saveUserSelections != "undefined" && typeof $("input[name='isTryNumberForm']") != "undefined") {
                        setTimeout(function() {
                            saveUserSelections(rtvObj.tryNumberFormName, rtvObj.refreshRates);
                        }, 300);
                    }
                    if (rtvObj.functionToCallAfterCountryChange != "") {
                        if (typeof rtvObj.functionToCallAfterCountryChange == "function")
                            rtvObj.functionToCallAfterCountryChange();
                        else
                            window[rtvObj.functionToCallAfterCountryChange]();
                    }
                }
            }
        },
        /* Update ringTo input with RINGTOCLEAN ===================================================================================== */
        /*
         * 	arguments[0] = Ring To value
         * 	arguments[1] = Is ring to a NANPA number flag
         */
        updRingToInput: function() {
            var rtvObj = this;
            var currRingTo = rtvObj.jqObj.val().replace(/\D*/ig, "");
            var tmpRingTo = arguments[0].replace(/\.0$/ig, "").replace(/\D*/ig, "");
            var isNANPA = arguments[1];
            var isSIP = (typeof arguments[2] != "boolean") ? false : arguments[2];
            tmpRingTo = (currRingTo != tmpRingTo) ? tmpRingTo : currRingTo;

            if (isSIP) {
                rtvObj.jqObj.val(arguments[0]);
            } else if (isNANPA) {
                tmpRingTo = tmpRingTo.replace(/^1?(\d*)/i, "$1"); /* Remove leading 1 to be added back below. */
                if (tmpRingTo.length >= 7) {
                    rtvObj.jqObj.val(tmpRingTo.replace(/(^\d{3})(\d{3})(\d*)/i, "1-$1-$2-$3"));
                } else if (tmpRingTo.length >= 3) {
                    rtvObj.jqObj.val(tmpRingTo.replace(/(^\d{3})(\d*)/i, "1-$1-$2"));
                } else {
                    rtvObj.jqObj.val(tmpRingTo.replace(/(^\d+)/i, "1-$1"));
                }
            } else {
                rtvObj.jqObj.val(tmpRingTo.replace(/(^\d*)/i, "+$1"));
            }
        },
        /* Set destPrefixChoice ===================================================================================================== */
        /*
         *  arguments[0] = DestPrefixChoice
         */
        setDestPrefixChoice: function() {
            var rtvObj = this;
            var tmpDestPrefixChoice = arguments[0];

            if (tmpDestPrefixChoice.toString().match(/^1(684)!/ig)) {
                rtvObj.destPrefixChoice = "1";
            } else if (tmpDestPrefixChoice.toString().match(/^1684/ig)) {
                rtvObj.destPrefixChoice = "684";
            } else {
                rtvObj.destPrefixChoice = tmpDestPrefixChoice.toString();
            }
        },
        /* Abort any requests in progress =========================================================================================== */
        /*
         * 	No arguments.
         */
        abortRequests: function() {
            var rtvObj = this;

            /* Clear previous ajax requests */
            for (var i = 0; i <= rtvObj.xhr.length; i++) {
                try {
                    rtvObj.xhr[i].abort();
                } catch (err) {
                    /* alert(err.description); */
                }
            }
        },
        /* Clear qTip =============================================================================================================== */
        /*
         * 	No arguments.
         */
        clearQTip: function() {
            var rtvObj = this;
            if (rtvObj.jqObj.data("qtip")) {
                rtvObj.jqObj.qtip("destroy");
            }
        },
        /* Run qTip plugin ========================================================================================================== */
        /*
         * 	arguments[0] = qTip message to display to the user.
         */
        runQTip: function() {
            var rtvObj = this;
            var qTipMessage = arguments[0];

            if (!rtvObj.isQtipSuppressed) {
                rtvObj.jqObjResult.html("&nbsp;");
                /* qTip (a jquery plugin) documentation can be found at http://craigsworks.com/projects/qtip/docs/ ================== BEGIN */
                rtvObj.jqObj.qtip({
                    content: {
                        text: qTipMessage,
                        title: {
                            /* Add a bunch of spacing to fix weird shifting. */
                            text: 'Do you mean&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
                            button: 'X'
                        }
                    },
                    position: {
                        corner: {
                            tooltip: "bottomMiddle",
                            target: "topMiddle"
                        }
                    },
                    show: {
                        delay: 0,
                        when: false,
                        ready: true
                    },
                    hide: false,
                    style: {
                        title: {
                            color: '#FFFFFF',
                            'font-size': 16,
                            'font-weight': 'bold',
                            'font-family': 'sans-serif',
                            'padding-top': 4,
                            'padding-right': 5,
                            'padding-left': 5,
                            'padding-bottom': 4,
                            'background-color': '#959595',
                            'white-space': 'nowrap'
                        },
                        button: {
                            color: '#FFFFFF',
                            'font-size': 12,
                            'margin-top': -3,
                            'font-weight': 'bold',
                            'font-family': 'arial'
                        },
                        border: {
                            color: '#4E4E4E',
                            width: 5,
                            radius: 10
                        },
                        width: {
                            max: 500
                        },
                        padding: 10,
                        'font-size': 12,
                        'text-align': 'center',
                        'font-family': 'arial',
                        tip: true,
                        name: 'red',
                        color: 'black',
                        'background-color': 'white',
                        'white-space': 'nowrap'
                    }
                });
                /* qTip (a jquery plugin) documentation can be found at http://craigsworks.com/projects/qtip/docs/ ================== END */
            }
            /*
            else {
            	rtvObj.isQtipSuppressed = false;
            }
            */
            rtvObj.isQtipSuppressed = true;
        },
        /* Main function to make AJAX call and process data returned from the server ================================================ */
        /*
         * 	arguments[0] = Ring to value.
         */
        runRingToValidation: function() {
            var rtvObj = this;
            var ringTo = arguments[0];
            if (rtvObj.resultCSS.errorColor == null)
                rtvObj.resultCSS.errorColor = "#CC0000";

            //var cfcServer = (rtvObj.getDomain() == "www.tollfreeforwarding.com" || rtvObj.getDomain() == "tollfreeforwarding.com") ? "www.tollfreeforwarding.com" : "stage.tollfreeforwarding.com";
            var cfcServer = rtvObj.getDomain();
            if (rtvObj.rootDir != "")
                cfcServer = rtvObj.rootDir;

            var urlInit = window.location.protocol + "//" + cfcServer;

            var requestData = {};
            rtvObj.xhr[rtvObj.xhr.length] = $.ajax({
                type: "GET",
                url: urlInit + "/cfc/entity/RingTo.cfc?method=wsValidate&ringto=" + escape(ringTo) + "&isRingTo=" + rtvObj.isRingTo + "&restrictedDestinations=" + rtvObj.restrictedDestinations + "&allowedRestrictedDestinations=" + rtvObj.allowedRestrictedDestinations + "&callback=?",
                async: true,
                cache: false,
                data: requestData,
                dataType: "json",
                timeout: 2000,
                success: function(data) {
                    var jqObjResult = $("#" + rtvObj.resultID);
                    var minW = 232;

                    if (typeof data == "object") {
                        var tmpRegX = "/^1?" + rtvObj.destPrefixChoice.toString().replace(/(^1)/ig, "") + "/i";
                        var tmpRingToClean1 = data["RINGTOCLEAN"].toString();
                        var tmpDestinationName1 = data["DESTINATIONNAME"].toString();
                        var tmpError1 = data["ERROR"].toString();
                        var tmpRingToClean2 = data["ALTERNATE"]["RINGTOCLEAN"].toString();
                        var tmpDestinationName2 = data["ALTERNATE"]["DESTINATIONNAME"].toString();
                        var tmpError2 = data["ALTERNATE"]["ERROR"].toString();
                        var tmpPath = document.location.href;

                        /* Suppress DNIS match errors. */
                        if ((tmpError1.search("existing") > 0) && (!(tmpPath.match(/callcontrol/i)))) {
                            tmpError1 = ""
                        }
                        if ((tmpError2.search("existing")) > 0 && (!(tmpPath.match(/callcontrol/i)))) {
                            tmpError2 = ""
                        }


                        /* To avoid initial tip question on internal site, set to original min prefix. */
                        if (tmpPath.match(/secure/i) && rtvObj.destPrefixChoice == "" && data["MINPREFIX"] != "") {
                            rtvObj.destPrefixChoice = data["MINPREFIX"];
                        }

                        /* Clear destPrefixChoice if set and no longer matches results */
                        if ((rtvObj.destPrefixChoice != "" && rtvObj.destPrefixChoice != "999" && !tmpRingToClean1.match(eval(tmpRegX)) && !tmpRingToClean2.match(eval(tmpRegX))) ||
                            (rtvObj.destPrefixChoice == "999" && !(tmpDestinationName1.match(/^SIP\/VoIP$/i) || tmpDestinationName2.match(/^SIP\/VoIP$/i)))) {
                            rtvObj.destPrefixChoice = "";
                        }

                        if (rtvObj.destPrefixChoice == "" && data["MINPREFIX"] != "" && data["ALTERNATE"]["MINPREFIX"] == "") {
                            rtvObj.setDestPrefixChoice(data["MINPREFIX"]);
                        } else if (rtvObj.destPrefixChoice == "" && data["MINPREFIX"] == "" && data["ALTERNATE"]["MINPREFIX"] != "") {
                            rtvObj.setDestPrefixChoice(data["ALTERNATE"]["MINPREFIX"]);
                        }

                        /* Determine result box content based on response from server. */
                        if (data["DESTINATIONNAME"] != "" && data["ALTERNATE"]["DESTINATIONNAME"] != "" && rtvObj.destPrefixChoice != data["MINPREFIX"] && rtvObj.destPrefixChoice != data["ALTERNATE"]["MINPREFIX"]) {
                            var resultMessage = "<strong>" +
                                '<a href="" class="' + rtvObj.prefixLookUpOpt + '" style="text-decoration:underline;">' +
                                data["DESTINATIONNAME"] +
                                '<span style="display:none;">^' + data["COUNTRYCODEISO"] + '^</span>' +
                                "</a></strong> or <strong>" +
                                '<a href="" class="' + rtvObj.prefixLookUpOpt + '" style="text-decoration:underline;">' +
                                data["ALTERNATE"]["DESTINATIONNAME"] +
                                '<span style="display:none;">^' + data["ALTERNATE"]["COUNTRYCODEISO"] + '^</span>' +
                                "</a></strong>?";

                            rtvObj.runQTip(resultMessage);
                            //rtvObj.jqObjResult.html("&nbsp;");

                            rtvObj.isValid = false;
                        } else if (data["DESTINATIONNAME"] != "" && data["ALTERNATE"]["DESTINATIONNAME"] == "" && data["DESTINATIONNAME"].match(/\d+/ig) &&
                            (rtvObj.destPrefixChoice != data["MINPREFIX"] && !(rtvObj.destPrefixChoice == 1 && data["MINPREFIX"].toString().match(/^1/ig)))) {
                            var resultMessage = "<strong>" +
                                '<a href="" class="' + rtvObj.prefixLookUpOpt + '" style="text-decoration:underline;">' +
                                data["DESTINATIONNAME"] +
                                "</a></strong>?" +
                                "&nbsp;&nbsp;&nbsp;&nbsp;" +
                                '<a href="" class="' + rtvObj.prefixLookUpOpt + '" style="text-decoration:underline;" data-destination="' + data["DESTINATIONNAME"] + '">' +
                                '<img src="http://' + cfcServer + '/images/btn_yes.gif" width="44" height="21" style="border:0; vertical-align:middle;" />' +
                                "</a>" +
                                "&nbsp;&nbsp;" +
                                '<a href="" class="' + rtvObj.closeQTip + '" style="text-decoration:underline;">' +
                                '<img src="http://' + cfcServer + '/images/btn_no.gif" width="44" height="21" style="border:0; vertical-align:middle;" />' +
                                "</a>";

                            rtvObj.runQTip(resultMessage);
                            //rtvObj.jqObjResult.html("&nbsp;");

                            rtvObj.isValid = false;
                        } else if (data["DESTINATIONNAME"] == "" && data["ALTERNATE"]["DESTINATIONNAME"] != "" && data["ALTERNATE"]["DESTINATIONNAME"].match(/\d+/ig) && rtvObj.destPrefixChoice != data["ALTERNATE"]["MINPREFIX"]) {
                            var resultMessage = "<strong>" +
                                '<a href="" class="' + rtvObj.prefixLookUpOpt + '" style="text-decoration:underline;">' +
                                data["ALTERNATE"]["DESTINATIONNAME"] +
                                "</a></strong>?" +
                                "&nbsp;&nbsp;&nbsp;&nbsp;" +
                                '<a href="" class="' + rtvObj.prefixLookUpOpt + '" style="text-decoration:underline;" data-destination="' + data["ALTERNATE"]["DESTINATIONNAME"] + '">' +
                                '<img src="http://' + cfcServer + '/images/btn_yes.gif" width="44" height="21" style="border:0; vertical-align:middle;" />' +
                                "</a>" +
                                "&nbsp;&nbsp;" +
                                '<a href="" class="' + rtvObj.closeQTip + '" style="text-decoration:underline;">' +
                                '<img src="http://' + cfcServer + '/images/btn_no.gif" width="44" height="21" style="border:0; vertical-align:middle;" />' +
                                "</a>";

                            rtvObj.runQTip(resultMessage);
                            //rtvObj.jqObjResult.html("&nbsp;");

                            rtvObj.isValid = false;
                        } else if (data["DESTINATIONNAME"] != "" && tmpError1 == "") {
                            var tmpW = (data["DESTINATIONNAME"].length * 6) + 5;
                            tmpW = (tmpW < minW) ? minW : tmpW;

                            jqObjResult.html(data["DESTINATIONNAME"]);

                            if (data["DESTINATIONNAME"] == "SIP/VoIP") {
                                rtvObj.updRingToSelect("999");
                            } else {
                                var isNANPA = data["RINGTOCLEAN"].toString().replace(/\D/ig, "").match(/^1/i);
                                /* Reset value if input doesn't match with clean version */
                                rtvObj.updRingToInput(data["RINGTOCLEAN"].toString(), isNANPA);
                            }

                            if (data["MINPREFIX"] != "") {
                                rtvObj.updRingToSelect(data["MINPREFIX"].toString(), data["COUNTRYCODEE164"].toString(), data["COUNTRYCODEISO"].toString());
                            }

                            rtvObj.isValid = true;
                        } else if (data["ALTERNATE"]["DESTINATIONNAME"] != "" && tmpError2 == "") {
                            var tmpW = (data["ALTERNATE"]["DESTINATIONNAME"].length * 6) + 5;
                            tmpW = (tmpW < minW) ? minW : tmpW;
                            jqObjResult.html(data["ALTERNATE"]["DESTINATIONNAME"]);

                            if (data["ALTERNATE"]["DESTINATIONNAME"] != "SIP/VoIP") {
                                var isNANPA = data["ALTERNATE"]["RINGTOCLEAN"].toString().replace(/\D/ig, "").match(/^1/i);
                                /* Reset value if input doesn't match with clean version */
                                rtvObj.updRingToInput(data["ALTERNATE"]["RINGTOCLEAN"].toString(), isNANPA);
                            }

                            if (data["ALTERNATE"]["MINPREFIX"] != "") {
                                rtvObj.updRingToSelect(data["ALTERNATE"]["MINPREFIX"].toString(), data["ALTERNATE"]["COUNTRYCODEE164"].toString(), data["ALTERNATE"]["COUNTRYCODEISO"].toString());
                            }

                            rtvObj.isValid = true;
                        } else if (data["MINPREFIX"] != "" && data["ALTERNATE"]["MINPREFIX"] == "" && tmpError1 != "" && (data["ALTERNATE"]["MINPREFIX"] == "" || rtvObj.destPrefixChoice == data["MINPREFIX"])) {
                            jqObjResult.html('<span style="color:' + rtvObj.resultCSS.errorColor + ';">' + tmpError1 + '</span>');

                            if (data["MINPREFIX"] != "") {
                                rtvObj.updRingToSelect(data["MINPREFIX"].toString(), data["COUNTRYCODEE164"].toString(), data["COUNTRYCODEISO"].toString());
                            }
                            rtvObj.isValid = false;
                        } else if (data["ALTERNATE"]["MINPREFIX"] != "" && tmpError2 != "" && (data["MINPREFIX"] == "" || rtvObj.destPrefixChoice == data["ALTERNATE"]["MINPREFIX"])) {
                            jqObjResult.html('<span style="color:' + rtvObj.resultCSS.errorColor + ';">' + tmpError2 + '</span>');

                            /* Special Case for SIP/VoIP */
                            if (data["ALTERNATE"]["MINPREFIX"].toString() == "999") {
                                rtvObj.updRingToInput(data["ALTERNATE"]["RINGTOCLEAN"].toString(), false, true);
                            }

                            if (data["ALTERNATE"]["MINPREFIX"] != "") {
                                rtvObj.updRingToSelect(data["ALTERNATE"]["MINPREFIX"].toString(), data["ALTERNATE"]["COUNTRYCODEE164"].toString(), data["ALTERNATE"]["COUNTRYCODEISO"].toString());
                            }
                            rtvObj.isValid = false;
                        } else if (tmpError1 != "") {
                            jqObjResult.html('<span style="color:' + rtvObj.resultCSS.errorColor + ';">' + tmpError1 + '</span>');
                        } else {
                            jqObjResult.html('<span style="color:' + rtvObj.resultCSS.errorColor + ';">The phone number you entered was not found<br />in our database. Please double-check the number<br />and proceed.</span>');
                            rtvObj.isValid = false;
                        }
                    } else {
                        if (rtvObj.jqObj.val().replace(/\D*/ig, "").length <= rtvObj.minRingToLength) {
                            jqObjResult.html('<span style="color:' + rtvObj.resultCSS.errorColor + ';">Phone number is too short.</span>');
                        } else {
                            jqObjResult.html('<span style="color:' + rtvObj.resultCSS.errorColor + ';">The phone number you entered was not found<br />in our database. Please double-check the number<br />and proceed.</span>');
                        }

                        rtvObj.isValid = false;
                    }

                    /* Use existing method to programmatically submit ringto. */
                    if (rtvObj.isSubmitOnEnd && typeof addToCart == "function" && (rtvObj.isValid || rtvObj.allowOverrideOn == data["RINGTOCLEAN"])) {
                        addToCart();
                    } else if (rtvObj.isSubmitOnEnd && (rtvObj.isValid || rtvObj.allowOverrideOn == data["RINGTOCLEAN"])) {
                        try {
                            document.getElementById(rtvObj.jqObj.id).form.submit();
                        } catch (err) {
                            /* alert(err.description); */
                        }
                    } else if (rtvObj.isSubmitOnEnd && !rtvObj.isValid && rtvObj.allowOverrideOn != data["RINGTOCLEAN"]) {
                        rtvObj.allowOverrideOn = data["RINGTOCLEAN"];
                    } else {
                        rtvObj.allowOverrideOn = "";
                    }

                    rtvObj.isSubmitOnEnd = false;

                    if (rtvObj.functionToCallAfterValidation != "") {
                        if (typeof rtvObj.functionToCallAfterValidation == "function")
                            rtvObj.functionToCallAfterValidation();
                        else
                            window[rtvObj.functionToCallAfterValidation]();
                    }
                },
                error: function(objAJAXRequest, strError) {
                    /* Add error handling for AJAX request error; ie: abort request, etc. */
                }

            });
        }
    };
}