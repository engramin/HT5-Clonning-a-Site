(function() {
    function r(e, n, t) {
        function o(i, f) {
            if (!n[i]) {
                if (!e[i]) {
                    var c = "function" == typeof require && require;
                    if (!f && c) return c(i, !0);
                    if (u) return u(i, !0);
                    var a = new Error("Cannot find module '" + i + "'");
                    throw a.code = "MODULE_NOT_FOUND", a
                }
                var p = n[i] = {
                    exports: {}
                };
                e[i][0].call(p.exports, function(r) {
                    var n = e[i][1][r];
                    return o(n || r)
                }, p, p.exports, r, e, n, t)
            }
            return n[i].exports
        }
        for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
        return o
    }
    return r
})()({
    1: [function(require, module, exports) {
        'use strict';

        var _slider = require('@trustpilot/trustbox-framework-vanilla/modules/slider');

        var _impression = require('@trustpilot/trustbox-framework-vanilla/modules/impression');

        var _impression2 = _interopRequireDefault(_impression);

        var _api = require('@trustpilot/trustbox-framework-vanilla/modules/api');

        var _dom = require('@trustpilot/trustbox-framework-vanilla/modules/dom');

        var _utils = require('@trustpilot/trustbox-framework-vanilla/modules/utils');

        var _queryString = require('@trustpilot/trustbox-framework-vanilla/modules/queryString');

        var _reviews = require('@trustpilot/trustbox-framework-vanilla/modules/templates/reviews');

        var _reviews2 = _interopRequireDefault(_reviews);

        var _logo = require('@trustpilot/trustbox-framework-vanilla/modules/templates/logo');

        var _templating = require('@trustpilot/trustbox-framework-vanilla/modules/templating');

        var _summary = require('@trustpilot/trustbox-framework-vanilla/modules/templates/summary');

        var _init = require('@trustpilot/trustbox-framework-vanilla/modules/init');

        var _init2 = _interopRequireDefault(_init);

        var _placeholder = require('./placeholder');

        var _reviewFilterText = require('@trustpilot/trustbox-framework-vanilla/modules/reviewFilterText');

        var _reviewFilterText2 = _interopRequireDefault(_reviewFilterText);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        _impression2.default.attachImpressionHandler();

        var _getQueryString = (0, _queryString.getAsObject)(),
            businessUnitId = _getQueryString.businessunitId,
            locale = _getQueryString.locale,
            _getQueryString$theme = _getQueryString.theme,
            theme = _getQueryString$theme === undefined ? 'light' : _getQueryString$theme,
            reviewLanguages = _getQueryString.reviewLanguages,
            reviewStars = _getQueryString.stars,
            reviewTagValue = _getQueryString.tags,
            location = _getQueryString.location,
            templateId = _getQueryString.templateId,
            fontFamily = _getQueryString.fontFamily,
            textColor = _getQueryString.textColor;

        var addUtm = (0, _utils.addUtmParams)('Slider');
        var mkTracking = function mkTracking(source) {
            return function() {
                return _impression2.default.engagement({
                    source: source
                });
            };
        };

        var populateEmptySummary = function populateEmptySummary(_ref) {
            var title = _ref.title,
                url = _ref.url;

            var widgetContentElement = document.getElementById('tp-widget-wrapper');
            var options = {
                title: title,
                url: url,
                orientation: _summary.ORIENTATION.HORIZONTAL
            };
            var emptySummary = (0, _summary.makeEmptySummary)(options);
            (0, _utils.setHtmlContent)(widgetContentElement, emptySummary, false);
        };

        var populateSlider = function populateSlider(_ref2) {
            var locale = _ref2.locale,
                reviews = _ref2.reviews;

            var sliderElements = {
                slider: document.getElementById('tp-widget-reviews'),
                sliderContainer: document.getElementById('tp-widget-reviews-wrapper')
            };
            var sliderArrows = {
                prevArrow: document.getElementById('review-arrow-left'),
                nextArrow: document.getElementById('review-arrow-right')
            };
            var templateOptions = {
                reviewLinkGenerator: function reviewLinkGenerator(review) {
                    return addUtm(review.reviewUrl);
                }
            };
            var template = (0, _reviews2.default)(locale.toLowerCase(), templateOptions);
            var svgSliderArrows = [].slice.call(document.getElementsByClassName('svg-slider-arrow'));
            svgSliderArrows.forEach(function(item) {
                return (0, _dom.populateElements)([{
                    element: item,
                    string: (0, _templating.mkElemWithSvgLookup)('arrowSlider')
                }, {
                    element: item,
                    string: (0, _templating.mkElemWithSvgLookup)('arrowSlider')
                }]);
            });

            var callbacks = {
                prevPage: mkTracking('Prev'),
                nextPage: mkTracking('Next')
            };
            var breakpoints = [{
                minWidth: 1200,
                reviewsForWidth: 5
            }, {
                minWidth: 980,
                reviewsForWidth: 4
            }, {
                minWidth: 760,
                reviewsForWidth: 3
            }, {
                minWidth: 540,
                reviewsForWidth: 2
            }, {
                minWidth: 0,
                reviewsForWidth: 1
            }];

            var sliderHandler = new _slider.ReviewSlider(reviews, sliderElements, template, {
                reviewClass: 'tp-widget-review',
                reviewsPerPage: breakpoints
            });
            var sliderControls = new _slider.ArrowControls(sliderHandler, sliderArrows, {
                callbacks: callbacks,
                disabledClass: 'display-none'
            });
            sliderControls.initialize();
        };

        var populateFooter = function populateFooter(_ref3) {
            var locale = _ref3.locale,
                _ref3$baseData = _ref3.baseData,
                _ref3$baseData$busine = _ref3$baseData.businessEntity,
                numberOfReviews = _ref3$baseData$busine.numberOfReviews.total,
                trustScore = _ref3$baseData$busine.trustScore,
                profileUrl = _ref3$baseData.links.profileUrl,
                translations = _ref3$baseData.translations;

            var ratingElementLong = document.getElementById('rating-long');
            (0, _dom.populateElements)([{
                element: ratingElementLong,
                string: translations.mainLong,
                substitutions: {
                    '[RATING]': trustScore.toFixed(1),
                    '[NOREVIEWS]': (0, _utils.insertNumberSeparator)(numberOfReviews, locale)
                }
            }]);
            var linkElementLong = document.querySelector('#rating-long a');
            linkElementLong.href = addUtm(profileUrl);

            var ratingElementShort = document.getElementById('rating-short');
            (0, _dom.populateElements)([{
                element: ratingElementShort,
                string: translations.mainShort,
                substitutions: {
                    '[RATING]': trustScore.toFixed(1),
                    '[NOREVIEWS]': (0, _utils.insertNumberSeparator)(numberOfReviews, locale)
                }
            }]);
            var linkElementShort = document.querySelector('#rating-short a');
            linkElementShort.href = addUtm(profileUrl);

            var reviewsFilterTextElement = document.getElementById('tp-widget-reviews-filter-label');
            var reviewsFilterText = (0, _reviewFilterText2.default)(locale, reviewStars, reviewTagValue);
            (0, _utils.setTextContent)(reviewsFilterTextElement, reviewsFilterText);

            var reviewsFilterDot = document.getElementById('tp-widget-reviews-filter-dot');
            (0, _dom.populateElements)([{
                element: reviewsFilterDot,
                string: translations.dot
            }]);

            var logoLink = document.getElementById('tp-widget-logo');
            logoLink.href = addUtm(profileUrl);
            (0, _logo.populateLogo)();
        };

        var applyCustomStyling = function applyCustomStyling() {
            if (fontFamily) {
                (0, _utils.setFont)(fontFamily);
            }
            if (textColor) {
                (0, _utils.setTextColor)(textColor);
            }
        };

        var constructTrustBox = function constructTrustBox(_ref4) {
            var baseData = _ref4.baseData,
                locale = _ref4.locale;

            var numberOfReviews = baseData.businessEntity.numberOfReviews.total;
            if (numberOfReviews > 0) {
                populateSlider({
                    locale: locale,
                    reviews: baseData.reviews
                });
                populateFooter({
                    locale: locale,
                    baseData: baseData
                });
            } else {
                var url = addUtm(baseData.links.evaluateUrl);
                var title = baseData.translations.noReviews;
                populateEmptySummary({
                    title: title,
                    url: url
                });
            }
            if (baseData.settings.customStylesAllowed) {
                applyCustomStyling();
            }
        };

        var fetchParams = {
            businessUnitId: businessUnitId,
            locale: locale,
            reviewLanguages: reviewLanguages,
            reviewStars: reviewStars,
            reviewTagValue: reviewTagValue,
            reviewsPerPage: 15,
            theme: theme,
            location: location
        };
        (0, _dom.populateElements)([{
            element: document.getElementById('tp-widget-loader'),
            string: (0, _placeholder.createPlaceholder)()
        }]);

        (0, _init2.default)(function() {
            (0, _api.fetchServiceReviewData)(templateId)(fetchParams, constructTrustBox);
        });

    }, {
        "./placeholder": 2,
        "@trustpilot/trustbox-framework-vanilla/modules/api": 31,
        "@trustpilot/trustbox-framework-vanilla/modules/dom": 38,
        "@trustpilot/trustbox-framework-vanilla/modules/impression": 40,
        "@trustpilot/trustbox-framework-vanilla/modules/init": 41,
        "@trustpilot/trustbox-framework-vanilla/modules/queryString": 42,
        "@trustpilot/trustbox-framework-vanilla/modules/reviewFilterText": 43,
        "@trustpilot/trustbox-framework-vanilla/modules/slider": 47,
        "@trustpilot/trustbox-framework-vanilla/modules/templates/logo": 53,
        "@trustpilot/trustbox-framework-vanilla/modules/templates/reviews": 54,
        "@trustpilot/trustbox-framework-vanilla/modules/templates/summary": 56,
        "@trustpilot/trustbox-framework-vanilla/modules/templating": 57,
        "@trustpilot/trustbox-framework-vanilla/modules/utils": 61
    }],
    38: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.populateElements = /* common-shake removed: exports.hasClass = */ exports.removeClass = exports.addClass = undefined;

        var _utils = require('./utils');

        function _toConsumableArray(arr) {
            if (Array.isArray(arr)) {
                for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            } else {
                return Array.from(arr);
            }
        }

        var hasClass = function hasClass(elem, className) {
            if (elem) {
                var elemClassList = elem.getAttribute('class');
                var classNames = elemClassList ? elemClassList.split(' ') : '';
                return classNames.indexOf(className) !== -1;
            }
            return false;
        };

        var addClass = function addClass(elem, forAddition) {
            if (elem) {
                var elemClassList = elem.getAttribute('class');
                var classNames = elemClassList ? elemClassList.split(' ') : [];

                if (!hasClass(elem, forAddition)) {
                    var newClasses = [].concat(_toConsumableArray(classNames), [forAddition]).join(' ');
                    elem.setAttribute('class', newClasses);
                }
            }
        };

        var removeClass = function removeClass(elem, forRemoval) {
            if (elem) {
                var classNames = elem.className.split(' ');
                elem.className = classNames.filter(function(name) {
                    return name !== forRemoval;
                }).join(' ');
            }
        };

        /**
         * Populates a series of elements with HTML content.
         *
         * For each object in a list, either a given string value is used to populate
         * the given element (including optional substitutions); or, where no string
         * value is provided, remove the given element.
         */
        var populateElements = function populateElements(elements) {
            elements.forEach(function(_ref) {
                var element = _ref.element,
                    string = _ref.string,
                    _ref$substitutions = _ref.substitutions,
                    substitutions = _ref$substitutions === undefined ? {} : _ref$substitutions;

                if (string) {
                    (0, _utils.setHtmlContent)(element, (0, _utils.makeTranslations)(substitutions, string), false);
                } else {
                    (0, _utils.removeElement)(element);
                }
            });
        };

        exports.addClass = addClass;
        exports.removeClass = removeClass;
        /* common-shake removed: exports.hasClass = */
        void hasClass;
        exports.populateElements = populateElements;

    }, {
        "./utils": 61
    }],
    40: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _queryString3 = require('./queryString');

        var _utils = require('./utils');

        var _rootUri = require('./rootUri');

        var _rootUri2 = _interopRequireDefault(_rootUri);

        var _xhr = require('./xhr');

        var _xhr2 = _interopRequireDefault(_xhr);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function _objectWithoutProperties(obj, keys) {
            var target = {};
            for (var i in obj) {
                if (keys.indexOf(i) >= 0) continue;
                if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
                target[i] = obj[i];
            }
            return target;
        }

        function setCookie(cname, cvalue, expires) {
            var path = 'path=/';
            var domain = 'domain=' + window.location.hostname.replace(/^.*\.([^.]+\.[^.]+)/, '$1');
            var samesite = 'samesite=none';
            var secure = 'secure';
            document.cookie = [cname + '=' + cvalue, path, expires, domain, samesite, secure].join('; ');
            document.cookie = [cname + '-legacy=' + cvalue, path, expires, domain].join('; ');
        }

        function makeTrackingUrl(eventName, impressionData) {
            // Destructure the impressionData and query params so that we only pass the
            // desired values for constructing the tracking URL.
            var userId = impressionData.anonymousId,
                _ = impressionData.sessionExpiry,
                impressionParams = _objectWithoutProperties(impressionData, ['anonymousId', 'sessionExpiry']);

            var _queryString = (0, _queryString3.getAsObject)(),
                businessUnitId = _queryString.businessunitId,
                widgetId = _queryString.templateId,
                widgetSettings = _objectWithoutProperties(_queryString, ['businessunitId', 'templateId']);

            var urlParams = _extends({}, widgetSettings, impressionParams, widgetSettings.group && userId ? {
                userId: userId
            } : {
                nosettings: 1
            }, {
                businessUnitId: businessUnitId,
                widgetId: widgetId
            });
            var urlParamsString = Object.keys(urlParams).map(function(property) {
                return property + '=' + encodeURIComponent(urlParams[property]);
            }).join('&');
            return (0, _rootUri2.default)() + '/stats/' + eventName + '?' + urlParamsString;
        }

        function setTrackingCookies(eventName, _ref) {
            var session = _ref.session,
                testId = _ref.testId,
                sessionExpiry = _ref.sessionExpiry;

            var _queryString2 = (0, _queryString3.getAsObject)(),
                group = _queryString2.group,
                businessUnitId = _queryString2.businessunitId;

            if (!group) {
                return;
            }

            if (!testId || !session) {
                // eslint-disable-next-line
                console.warn('TrustBox Optimizer test group detected but no running test settings found!');
            }

            if (sessionExpiry) {
                var settings = {
                    group: group,
                    session: session,
                    testId: testId
                };
                setCookie('TrustboxSplitTest_' + businessUnitId, encodeURIComponent(JSON.stringify(settings)), sessionExpiry);
            }
        }

        function trackEventRequest(eventName, impressionData) {
            setTrackingCookies(eventName, impressionData);
            var url = makeTrackingUrl(eventName, impressionData);
            try {
                (0, _xhr2.default)({
                    url: url
                });
            } catch (e) {
                // do nothing
            }
        }

        var trackImpression = function trackImpression(data) {
            trackEventRequest('TrustboxImpression', data);
        };

        var trackView = function trackView(data) {
            trackEventRequest('TrustboxView', data);
        };

        var trackEngagement = function trackEngagement(data) {
            trackEventRequest('TrustboxEngagement', data);
        };

        var id = null;

        var attachImpressionHandler = function attachImpressionHandler() {
            (0, _utils.addEventListener)(window, 'message', function(event) {
                if (typeof event.data !== 'string') {
                    return;
                }

                var e = void 0;
                try {
                    e = {
                        data: JSON.parse(event.data)
                    };
                } catch (e) {
                    // probably not for us
                    return;
                }

                if (e.data.command === 'setId') {
                    id = e.data.widgetId;
                    window.parent.postMessage(JSON.stringify({
                        command: 'impression',
                        widgetId: id
                    }), '*');
                    return;
                }

                if (e.data.command === 'impression-received') {
                    delete e.data.command;
                    trackImpression(e.data);
                }

                if (e.data.command === 'trustbox-in-viewport') {
                    delete e.data.command;
                    trackView(e.data);
                }
            });
        };

        var tracking = {
            engagement: trackEngagement,
            attachImpressionHandler: attachImpressionHandler
        };

        exports.default = tracking;

    }, {
        "./queryString": 42,
        "./rootUri": 44,
        "./utils": 61,
        "./xhr": 62
    }],
    53: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.populateLogo = exports.makeLogo = undefined;

        var _templating = require('../templating');

        var _dom = require('../dom');

        var makeLogo = function makeLogo() {
            return (0, _templating.mkElemWithSvgLookup)('logo');
        };

        var populateLogo = function populateLogo() {
            var logoContainer = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'tp-widget-logo';

            var container = typeof logoContainer === 'string' ? document.getElementById(logoContainer) : logoContainer;

            (0, _dom.populateElements)([{
                element: container,
                string: makeLogo()
            }]);
        };

        exports.makeLogo = makeLogo;
        exports.populateLogo = populateLogo;

    }, {
        "../dom": 38,
        "../templating": 57
    }],
    56: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.ORIENTATION = exports.makeEmptySummary = undefined;

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _templating = require('../templating');

        var _stars = require('./stars');

        var _logo = require('./logo');

        var _utils = require('../utils');

        function _toConsumableArray(arr) {
            if (Array.isArray(arr)) {
                for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            } else {
                return Array.from(arr);
            }
        }

        var HORIZONTAL = 'horizontal';
        var VERTICAL = 'vertical';
        var ORIENTATION = {
            HORIZONTAL: HORIZONTAL,
            VERTICAL: VERTICAL
        };

        var useNofollow = function useNofollow(nofollow) {
            return nofollow ? {
                rel: 'nofollow'
            } : {};
        };

        var renderSubtitle = function renderSubtitle(options) {
            var subtitle = options.subtitle,
                url = options.url,
                hasLogo = options.hasLogo,
                nofollow = options.nofollow;

            var translatedSubtitle = subtitle && (0, _utils.makeTranslations)({}, subtitle);
            var children = [translatedSubtitle && (0, _templating.span)({
                class: 'tp-widget-empty-vertical__subtitle'
            }, translatedSubtitle), url && (0, _templating.a)(_extends({
                class: 'tp-widget-empty-vertical__logo',
                href: url,
                target: '_blank'
            }, useNofollow(nofollow)), (0, _logo.makeLogo)()), hasLogo && !url && (0, _templating.span)({
                class: 'tp-widget-empty-vertical__logo'
            }, (0, _logo.makeLogo)())].filter(Boolean);

            return _templating.div.apply(undefined, [{
                class: 'tp-widget-empty-vertical__subtitle-wrapper'
            }].concat(_toConsumableArray(children)));
        };

        var makeEmptyVerticalSummary = function makeEmptyVerticalSummary(options) {
            var translatedTitle = (0, _utils.makeTranslations)({}, options.title);
            var subtitleElement = renderSubtitle(options);
            return (0, _templating.div)({
                class: 'tp-widget-empty-vertical'
            }, (0, _templating.span)({
                class: 'tp-widget-empty-vertical__title'
            }, translatedTitle), (0, _stars.makeStars)({
                num: 0,
                wrapperClass: 'tp-widget-empty-vertical__stars'
            }), subtitleElement);
        };

        var makeEmptyHorizontalSummary = function makeEmptyHorizontalSummary(options) {
            var title = options.title,
                url = options.url,
                nofollow = options.nofollow;

            var translatedTitle = (0, _utils.makeTranslations)({}, title);
            return (0, _templating.div)({
                class: 'tp-widget-empty-horizontal'
            }, (0, _templating.span)({
                class: 'tp-widget-empty-horizontal__title'
            }, translatedTitle), (0, _templating.a)(_extends({
                class: 'tp-widget-empty-horizontal__logo',
                href: url,
                target: '_blank'
            }, useNofollow(nofollow)), (0, _logo.makeLogo)()));
        };

        var makeEmptySummary = function makeEmptySummary(options) {
            return options.orientation === ORIENTATION.HORIZONTAL ? makeEmptyHorizontalSummary(options) : makeEmptyVerticalSummary(options);
        };

        exports.makeEmptySummary = makeEmptySummary;
        exports.ORIENTATION = ORIENTATION;

    }, {
        "../templating": 57,
        "../utils": 61,
        "./logo": 53,
        "./stars": 55
    }],
    57: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        /* common-shake removed: exports.customElement = */
        exports.mkElemWithSvgLookup = exports.span = /* common-shake removed: exports.input = */ /* common-shake removed: exports.label = */ /* common-shake removed: exports.img = */ exports.div = exports.a = undefined;

        var _svg = require('./assets/svg');

        var flatten = function flatten(arrs) {
            return [].concat.apply([], arrs);
        };

        var mkProps = function mkProps(props) {
            return Object.keys(props).map(function(key) {
                return key + '="' + props[key] + '"';
            }).join(' ');
        };

        var mkElem = function mkElem(tag) {
            return function(props) {
                for (var _len = arguments.length, children = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                    children[_key - 1] = arguments[_key];
                }

                return '<' + tag + ' ' + mkProps(props) + '>' + flatten(children).join('\n') + '</' + tag + '>';
            };
        };

        var mkNonClosingElem = function mkNonClosingElem(tag) {
            return function(props) {
                return '<' + tag + ' ' + mkProps(props) + '>';
            };
        };

        var a = mkElem('a');
        var div = mkElem('div');
        var img = mkElem('img');
        var label = mkElem('label');
        var span = mkElem('span');
        var input = mkNonClosingElem('input');
        var customElement = mkElem;

        var mkElemWithSvgLookup = function mkElemWithSvgLookup(svgKey) {
            var className = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
            var props = arguments[2];
            return div({
                class: className
            }, _svg.svgMap[svgKey](props));
        };

        exports.a = a;
        exports.div = div;
        /* common-shake removed: exports.img = */
        void img;
        /* common-shake removed: exports.label = */
        void label;
        /* common-shake removed: exports.input = */
        void input;
        exports.span = span;
        exports.mkElemWithSvgLookup = mkElemWithSvgLookup;
        /* common-shake removed: exports.customElement = */
        void customElement;

    }, {
        "./assets/svg": 36
    }],
    41: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _communication = require('./communication');

        var _errorFallback = require('./templates/errorFallback');

        var FALLBACK_DELAY = 500;

        /**
         * Makes sure that the widget is initialized only when the bootstrapper is present.
         *
         * Sends a "ping" message to the bootstrapper and waits for a "pong" reply before initializing the widget.
         *
         * @param {Function} onInit the callback to be executed when the init is done.
         */
        var init = function init(onInit) {
            var initialized = false;
            (0, _communication.onPong)(function() {
                initialized = true;
                if (typeof onInit === 'function') {
                    onInit();
                } else {
                    console.warn('`onInit` not supplied');
                }
            });

            (0, _communication.ping)();

            // we want to avoid rendering the fallback right away in case the "pong" message from the bootstrapper comes back immediately
            // this way we will avoid a flicker from "empty screen" -> "fallback" -> "TrustBox" and have "empty screen" -> "TrustBox"
            setTimeout(function() {
                if (!initialized) {
                    (0, _errorFallback.errorFallback)();
                }
            }, FALLBACK_DELAY);
        };

        exports.default = init;

    }, {
        "./communication": 37,
        "./templates/errorFallback": 51
    }],
    2: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.createPlaceholder = /* common-shake removed: exports.hidePlaceholders = */ undefined;

        var _templating = require('@trustpilot/trustbox-framework-vanilla/modules/templating');

        var _stars = require('@trustpilot/trustbox-framework-vanilla/modules/templates/stars');

        var _utils = require('@trustpilot/trustbox-framework-vanilla/modules/utils');

        function _toConsumableArray(arr) {
            if (Array.isArray(arr)) {
                for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            } else {
                return Array.from(arr);
            }
        }

        var hidePlaceholders = function hidePlaceholders() {
            var readyElements = document.querySelectorAll('.hidden-element');
            for (var i = 0; i < readyElements.length; i++) {
                readyElements[i].classList.add('hidden-element--loaded');
            }

            var loadingElements = document.querySelectorAll('.tp-widget-reviews--placeholder');
            for (var _i = 0; _i < loadingElements.length; _i++) {
                loadingElements[_i].classList.add('tp-widget-reviews--placeholder-hide');
            }
        };

        var createPlaceholderPart = function createPlaceholderPart() {
            return (0, _templating.div)({
                class: 'tp-widget-review tp-widget-review--placeholder'
            }, [(0, _stars.makeStars)({
                num: 0
            }), (0, _templating.div)({
                class: 'tp-widget-review__placeholder tp-widget-review__placeholder--small'
            })].concat(_toConsumableArray((0, _utils.range)(2).map(function() {
                return (0, _templating.div)({
                    class: 'tp-widget-review__placeholder tp-widget-review__placeholder'
                });
            }))));
        };

        var createPlaceholder = function createPlaceholder() {
            return (0, _templating.div)({
                class: 'tp-widget-reviews tp-widget-reviews--placeholder'
            }, (0, _utils.range)(5).map(createPlaceholderPart));
        };

        /* common-shake removed: exports.hidePlaceholders = */
        void hidePlaceholders;
        exports.createPlaceholder = createPlaceholder;

    }, {
        "@trustpilot/trustbox-framework-vanilla/modules/templates/stars": 55,
        "@trustpilot/trustbox-framework-vanilla/modules/templating": 57,
        "@trustpilot/trustbox-framework-vanilla/modules/utils": 61
    }],
    54: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
            return typeof obj;
        } : function(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };

        var _templating = require('../templating');

        var _smartAge = require('../smartAge');

        var _smartAge2 = _interopRequireDefault(_smartAge);

        var _stars = require('./stars');

        var _text = require('../text');

        var _translations = require('../translations');

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        var processOpts = function processOpts(opts) {
            var optsIsFunction = typeof opts === 'function';
            var optsIsObject = opts !== null && (typeof opts === 'undefined' ? 'undefined' : _typeof(opts)) === 'object';

            var reviewLinkGenerator = optsIsFunction ? opts : optsIsObject ? opts.reviewLinkGenerator : null;

            var _ref = optsIsObject ? opts : {},
                textLength = _ref.textLength,
                starColor = _ref.starColor,
                importedReviews = _ref.importedReviews,
                showReviewSource = _ref.showReviewSource;

            return {
                reviewLinkGenerator: reviewLinkGenerator,
                textLength: textLength,
                starColor: starColor,
                importedReviews: importedReviews,
                showReviewSource: showReviewSource
            };
        };

        var makeVerificationMethod = function makeVerificationMethod(locale, verifiedBy) {
            if (verifiedBy) {
                return (0, _translations.getFrameworkTranslation)('reviews.collectedVia', (0, _translations.formatLocale)(locale), {
                    '[source]': verifiedBy
                });
            }
            return (0, _translations.getFrameworkTranslation)('reviews.verifiedVia', (0, _translations.formatLocale)(locale), {
                '[source]': 'Trustpilot'
            });
        };

        // Template for reviews displayed within Carousel, TestimonialSlider, Product Reviews Carousel TrustBoxes.
        var reviewTemplate = function reviewTemplate(locale) {
            var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            return function(review) {
                // Check if opts contain only the reviewLinkGenerator. This is to maintain the
                // old API for this function, which only took a locale and a reviewLinkGenerator.
                var _processOpts = processOpts(opts),
                    reviewLinkGenerator = _processOpts.reviewLinkGenerator,
                    _processOpts$textLeng = _processOpts.textLength,
                    textLength = _processOpts$textLeng === undefined ? 85 : _processOpts$textLeng,
                    starColor = _processOpts.starColor,
                    importedReviews = _processOpts.importedReviews,
                    _processOpts$showRevi = _processOpts.showReviewSource,
                    showReviewSource = _processOpts$showRevi === undefined ? false : _processOpts$showRevi;

                var wrappedDiv = function wrappedDiv() {
                    return reviewLinkGenerator ? (0, _templating.a)({
                        href: reviewLinkGenerator(review),
                        target: '_blank',
                        rel: 'nofollow'
                    }, _templating.div.apply(undefined, arguments)) : _templating.div.apply(undefined, arguments);
                };

                return (0, _templating.div)({
                        class: 'tp-widget-review' + (importedReviews ? ' tp-widget-review--imported' : '')
                    }, (0, _templating.div)({
                        class: 'tp-widget-stars'
                    }, (0, _stars.makeStars)({
                        num: review.stars,
                        color: starColor
                    })), (0, _templating.div)({
                        class: 'date secondary-text'
                    }, (0, _smartAge2.default)(locale, review.createdAt)), review.title ? wrappedDiv({
                        class: 'header'
                    }, (0, _text.escapeHtml)(review.title)) : '',
                    // service reviews use `text` while product reviews use `content`
                    wrappedDiv({
                        class: 'text'
                    }, (0, _text.truncateText)(review.text || review.content, textLength)), wrappedDiv({
                        class: 'name secondary-text'
                    }, review.consumer.displayName), showReviewSource ? (0, _templating.div)({
                        class: 'tp-widget-review__source'
                    }, [makeVerificationMethod(locale, review.verifiedBy)]) : null);
            };
        };

        exports.default = reviewTemplate;

    }, {
        "../smartAge": 50,
        "../templating": 57,
        "../text": 58,
        "../translations": 60,
        "./stars": 55
    }],
    47: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        /* common-shake removed: exports.PaginationControls = */
        exports.ArrowControls = exports.ReviewSlider = undefined;

        var _reviewSlider = require('./reviewSlider');

        var _reviewSlider2 = _interopRequireDefault(_reviewSlider);

        var _arrowControls = require('./arrowControls');

        var _arrowControls2 = _interopRequireDefault(_arrowControls);

        var _paginationControls = require('./paginationControls');

        var _paginationControls2 = _interopRequireDefault(_paginationControls);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        exports.ReviewSlider = _reviewSlider2.default;
        exports.ArrowControls = _arrowControls2.default;
        /* common-shake removed: exports.PaginationControls = */
        void _paginationControls2.default;

    }, {
        "./arrowControls": 45,
        "./paginationControls": 48,
        "./reviewSlider": 49
    }],
    42: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.getAsObject = /* common-shake removed: exports.getQueryParams = */ undefined;

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _slicedToArray = function() {
            function sliceIterator(arr, i) {
                var _arr = [];
                var _n = true;
                var _d = false;
                var _e = undefined;
                try {
                    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
                        _arr.push(_s.value);
                        if (i && _arr.length === i) break;
                    }
                } catch (err) {
                    _d = true;
                    _e = err;
                } finally {
                    try {
                        if (!_n && _i["return"]) _i["return"]();
                    } finally {
                        if (_d) throw _e;
                    }
                }
                return _arr;
            }
            return function(arr, i) {
                if (Array.isArray(arr)) {
                    return arr;
                } else if (Symbol.iterator in Object(arr)) {
                    return sliceIterator(arr, i);
                } else {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }
            };
        }();

        var _fn = require('./fn');

        /**
         * Convert a parameter string to an object.
         */
        function paramsToObject(paramString) {
            var tokens = ['?', '#'];
            var dropFirstIfToken = function dropFirstIfToken(str) {
                return tokens.indexOf(str[0]) !== -1 ? str.substring(1) : str;
            };
            var toPairs = function toPairs(str) {
                return str.split('&').filter(Boolean).map(function(pairString) {
                    var _pairString$split = pairString.split('='),
                        _pairString$split2 = _slicedToArray(_pairString$split, 2),
                        key = _pairString$split2[0],
                        value = _pairString$split2[1];

                    try {
                        var dKey = decodeURIComponent(key);
                        var dValue = decodeURIComponent(value);
                        return [dKey, dValue];
                    } catch (e) {
                        console.log('Error while decoding URI, skipping parameter');
                    }
                }).filter(Boolean);
            };
            var mkObject = (0, _fn.compose)(_fn.pairsToObject, toPairs, dropFirstIfToken);
            return mkObject(paramString);
        }

        /**
         * Get all params from the TrustBox's URL.
         *
         * The only query parameters required to run the initial load of a TrustBox are
         * businessUnitId and templateId. The rest are only used within the TrustBox to
         * make the data call(s) and set options. These are passed as part of the hash
         * to ensure that we can properly utilise browser caching.
         *
         * Note: this only captures single occurences of values in the URL.
         *
         * @param {Location} location - A location object for which to get query params.
         * @return {Object} - All query params for the given location.
         */
        function getQueryParams() {
            var location = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : window.location;

            var queryParams = paramsToObject(location.search);
            var hashParams = paramsToObject(location.hash);
            return _extends({}, queryParams, hashParams);
        }

        /* common-shake removed: exports.getQueryParams = */
        void getQueryParams;
        exports.getAsObject = getQueryParams;

    }, {
        "./fn": 39
    }],
    43: [function(require, module, exports) {
        "use strict";

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _translations = require("./translations");

        var reviewFilterText = function reviewFilterText(locale, reviewStars, reviewTagValue) {
            var formattedLocale = (0, _translations.formatLocale)(locale);
            if (reviewTagValue) {
                return (0, _translations.getFrameworkTranslation)("reviewFilters.byFavoriteOrTag", formattedLocale);
            }

            if (reviewStars && !["1", "2", "3", "4", "5"].every(function(star) {
                    return reviewStars.split(",").indexOf(star) > -1;
                })) {
                return generateStarsString(locale, reviewStars.split(",").sort());
            }

            return (0, _translations.getFrameworkTranslation)("reviewFilters.byLatest", formattedLocale);
        };

        var generateStarsString = function generateStarsString(locale, stars) {
            var id = "reviewFilters.byLatest";
            var interpolations = {};
            var formattedLocale = (0, _translations.formatLocale)(locale);

            switch (stars.length) {
                case 4:
                    id = "reviewFilters.byStars4";
                    interpolations['[star1]'] = stars[0];
                    interpolations['[star2]'] = stars[1];
                    interpolations['[star3]'] = stars[2];
                    interpolations['[star4]'] = stars[3];
                    break;
                case 3:
                    id = "reviewFilters.byStars3";
                    interpolations['[star1]'] = stars[0];
                    interpolations["[star2]"] = stars[1];
                    interpolations["[star3]"] = stars[2];
                    break;
                case 2:
                    id = "reviewFilters.byStars2";
                    interpolations["[star1]"] = stars[0];
                    interpolations["[star2]"] = stars[1];
                    break;
                case 1:
                    id = "reviewFilters.byStars1";
                    interpolations["[star1]"] = stars[0];
                    break;
                default:
                    break;
            }

            return (0, _translations.getFrameworkTranslation)(id, formattedLocale, interpolations);;
        };

        exports.default = reviewFilterText;

    }, {
        "./translations": 60
    }],
    61: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.sanitizeColor = exports.sanitizeHtml = /* common-shake removed: exports.setHtmlLanguage = */ exports.setFont = /* common-shake removed: exports.setBorderColor = */ exports.setTextColor = exports.range = /* common-shake removed: exports.injectWidgetLinks = */ /* common-shake removed: exports.regulateFollowForLocation = */ exports.addUtmParams = exports.showTrustBox = exports.removeElement = exports.makeTranslations = exports.getOnPageReady = exports.addEventListener = exports.setHtmlContent = exports.setTextContent = exports.insertNumberSeparator = undefined;

        var _slicedToArray = function() {
            function sliceIterator(arr, i) {
                var _arr = [];
                var _n = true;
                var _d = false;
                var _e = undefined;
                try {
                    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
                        _arr.push(_s.value);
                        if (i && _arr.length === i) break;
                    }
                } catch (err) {
                    _d = true;
                    _e = err;
                } finally {
                    try {
                        if (!_n && _i["return"]) _i["return"]();
                    } finally {
                        if (_d) throw _e;
                    }
                }
                return _arr;
            }
            return function(arr, i) {
                if (Array.isArray(arr)) {
                    return arr;
                } else if (Symbol.iterator in Object(arr)) {
                    return sliceIterator(arr, i);
                } else {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }
            };
        }();

        var _promise = require('promise');

        var _promise2 = _interopRequireDefault(_promise);

        var _dom = require('./dom');

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function addEventListener(element, type, listener) {
            if (element) {
                if (element.addEventListener) {
                    element.addEventListener(type, listener);
                } else {
                    element.attachEvent('on' + type, function(e) {
                        e = e || window.event;
                        e.preventDefault = e.preventDefault || function() {
                            e.returnValue = false;
                        };
                        e.stopPropagation = e.stopPropagation || function() {
                            e.cancelBubble = true;
                        };
                        listener.call(element, e);
                    });
                }
            }
        }

        function getOnPageReady() {
            return new _promise2.default(function(resolve) {
                var resolveWithTimeout = function resolveWithTimeout() {
                    setTimeout(function() {
                        resolve();
                    }, 0);
                };
                if (document.readyState === 'complete') {
                    resolveWithTimeout();
                } else {
                    addEventListener(window, 'load', function() {
                        resolveWithTimeout();
                    });
                }
            });
        }

        function insertNumberSeparator(input, locale) {
            try {
                input.toLocaleString();
            } catch (e) {
                return input;
            }
            return input.toLocaleString(locale || 'en-US');
        }

        function setTextContent(element, content) {
            if (!element) {
                console.log('Attempting to set content on missing element');
            } else if ('innerText' in element) {
                // IE8
                element.innerText = content;
            } else {
                element.textContent = content;
            }
        }

        var sanitizeHtml = function sanitizeHtml(string) {
            if (typeof string !== 'string') {
                return string;
            }
            // TODO: Get rid of <a> tags in translations
            // Remove html tags, except <p> <b> <i> <li> <ul> <a> <strong>
            // Breakdown:
            //  (<\/?(?:p|b|i|li|ul|a|strong)\/?>) — 1st capturing group, selects allowed tags (opening and closing)
            //  (?:<\/?.*?\/?>) — non-capturing group (?:), matches all html tags
            //  $1 — keep matches from 1st capturing group as is, matches from non-capturing group will be omitted
            //  /gi — global (matches all occurrences) and case-insensitive
            // Test: https://regex101.com/r/cDa8jr/1
            return string.replace(/(<\/?(?:p|b|i|li|ul|a|strong)\/?>)|(?:<\/?.*?\/?>)/gi, '$1');
        };

        /**
         * Safely sets innerHTML to DOM element. Always use it instead of setting .innerHTML directly on element.
         * Sanitizes HTML by default. Use sanitize flag to control this behaviour.
         *
         * @param element
         * @param content
         * @param sanitize
         */
        function setHtmlContent(element, content) {
            var sanitize = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;

            if (!element) {
                console.log('Attempting to set HTML content on missing element');
            } else {
                element.innerHTML = sanitize ? sanitizeHtml(content) : content;
            }
        }

        function makeTranslations(translations, string) {
            if (!string) {
                console.log('Missing translation string');
                return '';
            }
            return Object.keys(translations).reduce(function(result, key) {
                return result.split(key).join(translations[key]);
            }, string);
        }

        function removeElement(element) {
            if (!element || !element.parentNode) {
                console.log('Attempting to remove a non-existing element');
                return;
            }
            return element.parentNode.removeChild(element);
        }

        var showTrustBox = function showTrustBox(theme, hasReviews) {
            var body = document.getElementsByTagName('body')[0];
            var wrapper = document.getElementById('tp-widget-wrapper');

            (0, _dom.addClass)(body, theme);
            (0, _dom.addClass)(wrapper, 'visible');

            if (!hasReviews) {
                (0, _dom.addClass)(body, 'first-reviewer');
            }
        };

        // url can already have query params in it
        var verifyQueryParamSeparator = function verifyQueryParamSeparator(url) {
            return '' + url + (url.indexOf('?') === -1 ? '?' : '&');
        };

        var addUtmParams = function addUtmParams(trustBoxName) {
            return function(url) {
                return verifyQueryParamSeparator(url) + 'utm_medium=trustbox&utm_source=' + trustBoxName;
            };
        };

        var regulateFollowForLocation = function regulateFollowForLocation(location) {
            return function(element) {
                if (location && element) {
                    element.rel = 'nofollow';
                }
            };
        };

        var injectWidgetLinks = function injectWidgetLinks(baseData, utmTrustBoxId) {
            var linksClass = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'profile-url';
            var numberOfReviews = baseData.businessEntity.numberOfReviews.total,
                links = baseData.links;

            var items = [].slice.call(document.getElementsByClassName(linksClass));
            var baseUrl = numberOfReviews ? links.profileUrl : links.evaluateUrl;
            for (var i = 0; i < items.length; i++) {
                items[i].href = addUtmParams(utmTrustBoxId)(baseUrl);
            }
        };

        // Create a range of numbers, up to (but excluding) the argument.
        // Written to support IE11.
        var range = function range(num) {
            var result = [];
            while (num > 0) {
                result.push(result.length);
                num--;
            }
            return result;
        };

        // Shifts the given color to either lighter or darker based on the base value given.
        // Positive values give you lighter color, negative darker.
        var colorShift = function colorShift(col, amt) {
            var validateBounds = function validateBounds(v) {
                return v > 255 ? 255 : v < 0 ? 0 : v;
            };
            var usePound = false;

            if (col[0] === "#") {
                col = col.slice(1);
                usePound = true;
            }

            var num = parseInt(col, 16);
            if (!num) {
                return col;
            }

            var r = (num >> 16) + amt;
            r = validateBounds(r);

            var g = (num >> 8 & 0x00FF) + amt;
            g = validateBounds(g);

            var b = (num & 0x0000FF) + amt;
            b = validateBounds(b);

            var _map = [r, g, b].map(function(color) {
                return color <= 15 ? '0' + color.toString(16) : color.toString(16);
            });

            var _map2 = _slicedToArray(_map, 3);

            r = _map2[0];
            g = _map2[1];
            b = _map2[2];

            return (usePound ? "#" : "") + r + g + b;
        };

        var hexToRGBA = function hexToRGBA(hex) {
            var alpha = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

            var num = hex[0] === '#' ? parseInt(hex.slice(1), 16) : parseInt(hex, 16);
            var red = num >> 16;
            var green = num >> 8 & 0x00FF;
            var blue = num & 0x0000FF;
            return 'rgba(' + red + ',' + green + ',' + blue + ',' + alpha + ')';
        };

        var setTextColor = function setTextColor(textColor) {
            var textColorStyle = document.createElement('style');
            textColorStyle.appendChild(document.createTextNode('\n      * {\n        color: inherit !important;\n      }\n      body {\n        color: ' + textColor + ' !important;\n      }\n      .bold-underline {\n        border-bottom-color: ' + textColor + ' !important;\n      }\n      .bold-underline:hover {\n        border-color: ' + colorShift(textColor, -30) + ' !important;\n      }\n      .secondary-text {\n        color: ' + hexToRGBA(textColor, 0.6) + ' !important;\n      }\n      .secondary-text-arrow {\n        border-color: ' + hexToRGBA(textColor, 0.6) + ' transparent transparent transparent !important;\n      }\n      .read-more {\n        color: ' + textColor + ' !important;\n      }\n    '));
            document.head.appendChild(textColorStyle);
        };

        var setBorderColor = function setBorderColor(borderColor) {
            var borderColorStyle = document.createElement('style');
            borderColorStyle.appendChild(document.createTextNode('\n     * {\n        border-color: ' + borderColor + ' !important;\n      }\n    '));
            document.head.appendChild(borderColorStyle);
        };

        var setFont = function setFont(fontFamily) {
            var fontLink = document.createElement('link');
            fontLink.rel = 'stylesheet';
            // we are using the following three weights in most of our TrustBoxes
            // in future iterations, we can optimize the bytes transferred by having a list of weights per TrustBox
            fontLink.href = 'https://fonts.googleapis.com/css?family=' + fontFamily + ':wght@400,500,700';
            document.head.appendChild(fontLink);

            var cleanFontName = fontFamily.replace(/\+/g, ' ');
            var fontStyle = document.createElement('style');
            fontStyle.appendChild(document.createTextNode('\n    * {\n      font-family: inherit !important;\n    }\n    body {\n      font-family: "' + cleanFontName + '", sans-serif !important;\n    }\n    '));
            document.head.appendChild(fontStyle);
        };

        var setHtmlLanguage = function setHtmlLanguage(language) {
            document.documentElement.setAttribute('lang', language);
        };

        var sanitizeColor = function sanitizeColor(color) {
            var hexRegExp = /^#(?:[\da-fA-F]{3}){1,2}$/;
            return typeof color === 'string' && hexRegExp.test(color) ? color : null;
        };

        exports.insertNumberSeparator = insertNumberSeparator;
        exports.setTextContent = setTextContent;
        exports.setHtmlContent = setHtmlContent;
        exports.addEventListener = addEventListener;
        exports.getOnPageReady = getOnPageReady;
        exports.makeTranslations = makeTranslations;
        exports.removeElement = removeElement;
        exports.showTrustBox = showTrustBox;
        exports.addUtmParams = addUtmParams;
        /* common-shake removed: exports.regulateFollowForLocation = */
        void regulateFollowForLocation;
        /* common-shake removed: exports.injectWidgetLinks = */
        void injectWidgetLinks;
        exports.range = range;
        exports.setTextColor = setTextColor;
        /* common-shake removed: exports.setBorderColor = */
        void setBorderColor;
        exports.setFont = setFont;
        /* common-shake removed: exports.setHtmlLanguage = */
        void setHtmlLanguage;
        exports.sanitizeHtml = sanitizeHtml;
        exports.sanitizeColor = sanitizeColor;

    }, {
        "./dom": 38,
        "promise": 65
    }],
    31: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        /* common-shake removed: exports.fetchServiceRevieMultipleData = */
        exports.fetchServiceReviewData = /* common-shake removed: exports.constructTrustBoxAndComplete = */ /* common-shake removed: exports.fetchProductReview = */ /* common-shake removed: exports.fetchProductData = */ undefined;

        var _fetchData = require('./fetchData');

        var _productReviews = require('./productReviews');

        var fetchServiceReviewData = function fetchServiceReviewData(templateId) {
            return function(fetchParams, constructTrustBox, passToPopup) {
                (0, _fetchData.fetchData)('/trustbox-data/' + templateId)(fetchParams, constructTrustBox, passToPopup, _fetchData.hasServiceReviews);
            };
        };

        var fetchServiceRevieMultipleData = function fetchServiceRevieMultipleData(templateId) {
            return function(fetchParams, constructTrustBox, passToPopup) {
                (0, _fetchData.multiFetchData)('/trustbox-data/' + templateId)(fetchParams, constructTrustBox, passToPopup, _fetchData.hasServiceReviewsMultiFetch);
            };
        };

        /* common-shake removed: exports.fetchProductData = */
        void _productReviews.fetchProductData;
        /* common-shake removed: exports.fetchProductReview = */
        void _productReviews.fetchProductReview;
        /* common-shake removed: exports.constructTrustBoxAndComplete = */
        void _fetchData.constructTrustBoxAndComplete;
        exports.fetchServiceReviewData = fetchServiceReviewData;
        /* common-shake removed: exports.fetchServiceRevieMultipleData = */
        void fetchServiceRevieMultipleData;

    }, {
        "./fetchData": 30,
        "./productReviews": 32
    }],
    55: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        /* common-shake removed: exports.populateStars = */
        exports.makeStars = undefined;

        var _templating = require('../templating');

        var _dom = require('../dom');

        var _utils = require('../utils');

        var makeStars = function makeStars(_ref) {
            var num = _ref.num,
                _ref$trustScore = _ref.trustScore,
                trustScore = _ref$trustScore === undefined ? null : _ref$trustScore,
                _ref$wrapperClass = _ref.wrapperClass,
                wrapperClass = _ref$wrapperClass === undefined ? '' : _ref$wrapperClass,
                color = _ref.color;

            var fullPart = Math.floor(num);
            var halfPart = num === fullPart ? '' : ' tp-stars--' + fullPart + '--half';
            var sanitizedColor = (0, _utils.sanitizeColor)(color);
            return (0, _templating.div)({
                    class: wrapperClass
                },
                // add a different class so that styles from widgets-styleguide do not apply
                (0, _templating.mkElemWithSvgLookup)('stars', '' + (sanitizedColor ? 'tp-stars-custom-color' : 'tp-stars tp-stars--' + fullPart + halfPart), {
                    rating: num,
                    trustScore: trustScore || num,
                    color: sanitizedColor
                }));
        };

        var populateStars = function populateStars(_ref2) {
            var _ref2$businessEntity = _ref2.businessEntity,
                stars = _ref2$businessEntity.stars,
                trustScore = _ref2$businessEntity.trustScore,
                total = _ref2$businessEntity.numberOfReviews.total;
            var starsContainer = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'tp-widget-stars';
            var starsColor = arguments[2];

            var sanitizedColor = (0, _utils.sanitizeColor)(starsColor);
            var container = typeof starsContainer === 'string' ? document.getElementById(starsContainer) : starsContainer;

            // Ensure we properly handle empty review state - we sometimes get a rating
            // back from the API even where we have no reviews, so explicitly check.
            var displayedStars = total ? stars : 0;

            (0, _dom.populateElements)([{
                element: container,
                string: makeStars({
                    num: displayedStars,
                    trustScore: trustScore,
                    color: sanitizedColor
                })
            }]);
        };

        exports.makeStars = makeStars;
        /* common-shake removed: exports.populateStars = */
        void populateStars;

    }, {
        "../dom": 38,
        "../templating": 57,
        "../utils": 61
    }],
    3: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "anmeldelse",
                "plural": "anmeldelser",
                "collectedVia": "Indsamlet via [source]",
                "verifiedVia": "Verificeret – indsamlet via [source]"
            },
            "monthNames": {
                "january": "januar",
                "february": "februar",
                "march": "marts",
                "april": "april",
                "may": "maj",
                "june": "juni",
                "july": "juli",
                "august": "august",
                "september": "september",
                "october": "oktober",
                "november": "november",
                "december": "december"
            },
            "timeAgo": {
                "days": {
                    "singular": "For [count] dag siden",
                    "plural": "For [count] dage siden"
                },
                "hours": {
                    "singular": "For [count] time siden",
                    "plural": "For [count] timer siden"
                },
                "minutes": {
                    "singular": "For [count] minut siden",
                    "plural": "For [count] minutter siden"
                },
                "seconds": {
                    "singular": "For [count] sekund siden",
                    "plural": "For [count] sekunder siden"
                }
            },
            "reviewFilters": {
                "byStars1": "Viser vores [star1]-stjernede anmeldelser",
                "byStars2": "Viser vores [star1]- og [star2]-stjernede anmeldelser",
                "byStars3": "Viser vores [star1]-, [star2]- og [star3]-stjernede anmeldelser",
                "byStars4": "Viser vores [star1]-, [star2]-, [star3]- og [star4]-stjernede anmeldelser",
                "byLatest": "Viser vores seneste anmeldelser",
                "byFavoriteOrTag": "Viser vores yndlingsanmeldelser"
            }
        }
    }, {}],
    4: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "Bewertung",
                "plural": "Bewertungen",
                "collectedVia": "Gesammelt über [source]",
                "verifiedVia": "Verifiziert, gesammelt über [source]"
            },
            "monthNames": {
                "january": "Januar",
                "february": "Februar",
                "march": "März",
                "april": "April",
                "may": "Mai",
                "june": "Juni",
                "july": "Juli",
                "august": "August",
                "september": "September",
                "october": "Oktober",
                "november": "November",
                "december": "Dezember"
            },
            "timeAgo": {
                "days": {
                    "singular": "vor [count] Tag",
                    "plural": "vor [count] Tagen"
                },
                "hours": {
                    "singular": "vor [count] Stunde",
                    "plural": "vor [count] Stunden"
                },
                "minutes": {
                    "singular": "vor [count] Minute",
                    "plural": "vor [count] Minuten"
                },
                "seconds": {
                    "singular": "vor [count] Sekunde",
                    "plural": "vor [count] Sekunden"
                }
            },
            "reviewFilters": {
                "byStars1": "Einige unserer [star1]-Sterne-Bewertungen",
                "byStars2": "Einige unserer [star1]- & [star2]-Sterne-Bewertungen",
                "byStars3": "Einige unserer [star1]-, [star2]- & [star3]-Sterne-Bewertungen",
                "byStars4": "Einige unserer [star1]-, [star2]-, [star3]- & [star4]-Sterne-Bewertungen",
                "byLatest": "Unsere neuesten Bewertungen",
                "byFavoriteOrTag": "Unsere Lieblingsbewertungen"
            }
        }
    }, {}],
    5: [function(require, module, exports) {
        arguments[4][4][0].apply(exports, arguments)
    }, {
        "dup": 4
    }],
    6: [function(require, module, exports) {
        arguments[4][4][0].apply(exports, arguments)
    }, {
        "dup": 4
    }],
    7: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "review",
                "plural": "reviews",
                "collectedVia": "Collected via [source]",
                "verifiedVia": "Verified, collected via [source]"
            },
            "monthNames": {
                "january": "January",
                "february": "February",
                "march": "March",
                "april": "April",
                "may": "May",
                "june": "June",
                "july": "July",
                "august": "August",
                "september": "September",
                "october": "October",
                "november": "November",
                "december": "December"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] day ago",
                    "plural": "[count] days ago"
                },
                "hours": {
                    "singular": "[count] hour ago",
                    "plural": "[count] hours ago"
                },
                "minutes": {
                    "singular": "[count] minute ago",
                    "plural": "[count] minutes ago"
                },
                "seconds": {
                    "singular": "[count] second ago",
                    "plural": "[count] seconds ago"
                }
            },
            "reviewFilters": {
                "byStars1": "Showing our [star1] star reviews",
                "byStars2": "Showing our [star1] & [star2] star reviews",
                "byStars3": "Showing our [star1], [star2] & [star3] star reviews",
                "byStars4": "Showing our [star1], [star2], [star3] & [star4] star reviews",
                "byLatest": "Showing our latest reviews",
                "byFavoriteOrTag": "Showing our favourite reviews"
            }
        }
    }, {}],
    8: [function(require, module, exports) {
        arguments[4][7][0].apply(exports, arguments)
    }, {
        "dup": 7
    }],
    9: [function(require, module, exports) {
        arguments[4][7][0].apply(exports, arguments)
    }, {
        "dup": 7
    }],
    10: [function(require, module, exports) {
        arguments[4][7][0].apply(exports, arguments)
    }, {
        "dup": 7
    }],
    11: [function(require, module, exports) {
        arguments[4][7][0].apply(exports, arguments)
    }, {
        "dup": 7
    }],
    12: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "review",
                "plural": "reviews",
                "collectedVia": "Collected via [source]",
                "verifiedVia": "Verified, collected via [source]"
            },
            "monthNames": {
                "january": "January",
                "february": "February",
                "march": "March",
                "april": "April",
                "may": "May",
                "june": "June",
                "july": "July",
                "august": "August",
                "september": "September",
                "october": "October",
                "november": "November",
                "december": "December"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] day ago",
                    "plural": "[count] days ago"
                },
                "hours": {
                    "singular": "[count] hour ago",
                    "plural": "[count] hours ago"
                },
                "minutes": {
                    "singular": "[count] minute ago",
                    "plural": "[count] minutes ago"
                },
                "seconds": {
                    "singular": "[count] second ago",
                    "plural": "[count] seconds ago"
                }
            },
            "reviewFilters": {
                "byStars1": "Showing our [star1] star reviews",
                "byStars2": "Showing our [star1] & [star2] star reviews",
                "byStars3": "Showing our [star1], [star2] & [star3] star reviews",
                "byStars4": "Showing our [star1], [star2], [star3] & [star4] star reviews",
                "byLatest": "Showing our latest reviews",
                "byFavoriteOrTag": "Showing our favorite reviews"
            }
        }
    }, {}],
    13: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "opinión",
                "plural": "opiniones",
                "collectedVia": "Fuente: [source]",
                "verifiedVia": "Verificada, recopilada vía [source]"
            },
            "monthNames": {
                "january": "enero",
                "february": "febrero",
                "march": "marzo",
                "april": "abril",
                "may": "mayo",
                "june": "junio",
                "july": "julio",
                "august": "agosto",
                "september": "septiembre",
                "october": "octubre",
                "november": "noviembre",
                "december": "diciembre"
            },
            "timeAgo": {
                "days": {
                    "singular": "Hace [count] día",
                    "plural": "Hace [count] días"
                },
                "hours": {
                    "singular": "Hace [count] hora",
                    "plural": "Hace [count] horas"
                },
                "minutes": {
                    "singular": "Hace [count] minuto",
                    "plural": "Hace [count] minutos"
                },
                "seconds": {
                    "singular": "Hace [count] segundo",
                    "plural": "Hace [count] segundos"
                }
            },
            "reviewFilters": {
                "byStars1": "Nuestras opiniones de [star1] estrellas",
                "byStars2": "Nuestras opiniones de [star1] y [star2] estrellas",
                "byStars3": "Nuestras opiniones de [star1], [star2] y [star3] estrellas",
                "byStars4": "Nuestras opiniones de [star1], [star2], [star3] y [star4] estrellas",
                "byLatest": "Nuestras opiniones más recientes",
                "byFavoriteOrTag": "Nuestras opiniones preferidas"
            }
        }
    }, {}],
    14: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "arvostelu",
                "plural": "arvostelua",
                "collectedVia": "Arvostelun lähde: [source]",
                "verifiedVia": "Varmennettu, lähde: [source]"
            },
            "monthNames": {
                "january": "tammikuuta",
                "february": "helmikuuta",
                "march": "maaliskuuta",
                "april": "huhtikuuta",
                "may": "toukokuuta",
                "june": "kesäkuuta",
                "july": "heinäkuuta",
                "august": "elokuuta",
                "september": "syyskuuta",
                "october": "lokakuuta",
                "november": "marraskuuta",
                "december": "joulukuuta"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] päivää sitten",
                    "plural": "[count] päivää sitten"
                },
                "hours": {
                    "singular": "[count] tuntia sitten",
                    "plural": "[count] tuntia sitten"
                },
                "minutes": {
                    "singular": "[count] minuuttia sitten",
                    "plural": "[count] minuuttia sitten"
                },
                "seconds": {
                    "singular": "[count] sekuntia sitten",
                    "plural": "[count] sekuntia sitten"
                }
            },
            "reviewFilters": {
                "byStars1": "Näytetään [star1] tähden arvostelumme",
                "byStars2": "Näytetään [star1] & [star2] tähden arvostelumme",
                "byStars3": "Näytetään [star1], [star2] & [star3] tähden arvostelumme",
                "byStars4": "Näytetään [star1], [star2], [star3] & [star4] tähden arvostelumme",
                "byLatest": "Näytetään viimeisimmät arvostelumme",
                "byFavoriteOrTag": "Näytetään suosikkiarvostelumme"
            }
        }
    }, {}],
    15: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "avis",
                "plural": "avis",
                "collectedVia": "Collecté via [source]",
                "verifiedVia": "Vérifié, collecté via [source]"
            },
            "monthNames": {
                "january": "janvier",
                "february": "février",
                "march": "mars",
                "april": "avril",
                "may": "mai",
                "june": "juin",
                "july": "juillet",
                "august": "août",
                "september": "septembre",
                "october": "octobre",
                "november": "novembre",
                "december": "décembre"
            },
            "timeAgo": {
                "days": {
                    "singular": "ll y a [count] jour",
                    "plural": "Il y a [count] jours"
                },
                "hours": {
                    "singular": "Il y a [count] heure",
                    "plural": "Il y a [count] heures"
                },
                "minutes": {
                    "singular": "Il y a [count] minute",
                    "plural": "Il y a [count] minutes"
                },
                "seconds": {
                    "singular": "Il y a [count] seconde",
                    "plural": "Il y a [count] secondes"
                }
            },
            "reviewFilters": {
                "byStars1": "Nos avis [star1] étoiles",
                "byStars2": "Nos avis [star1] et [star2] étoiles",
                "byStars3": "Nos avis [star1], [star2] et [star3] étoiles",
                "byStars4": "Nos avis [star1], [star2], [star3] et [star4] étoiles",
                "byLatest": "Nos derniers avis",
                "byFavoriteOrTag": "Nos avis préférés"
            }
        }
    }, {}],
    16: [function(require, module, exports) {
        arguments[4][15][0].apply(exports, arguments)
    }, {
        "dup": 15
    }],
    17: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _strings = require('./da-DK/strings.json');

        var dk = _interopRequireWildcard(_strings);

        var _strings2 = require('./de-AT/strings.json');

        var at = _interopRequireWildcard(_strings2);

        var _strings3 = require('./de-CH/strings.json');

        var ch = _interopRequireWildcard(_strings3);

        var _strings4 = require('./de-DE/strings.json');

        var de = _interopRequireWildcard(_strings4);

        var _strings5 = require('./en-AU/strings.json');

        var au = _interopRequireWildcard(_strings5);

        var _strings6 = require('./en-CA/strings.json');

        var ca = _interopRequireWildcard(_strings6);

        var _strings7 = require('./en-GB/strings.json');

        var gb = _interopRequireWildcard(_strings7);

        var _strings8 = require('./en-IE/strings.json');

        var ie = _interopRequireWildcard(_strings8);

        var _strings9 = require('./en-NZ/strings.json');

        var nz = _interopRequireWildcard(_strings9);

        var _strings10 = require('./en-US/strings.json');

        var us = _interopRequireWildcard(_strings10);

        var _strings11 = require('./es-ES/strings.json');

        var es = _interopRequireWildcard(_strings11);

        var _strings12 = require('./fi-FI/strings.json');

        var fi = _interopRequireWildcard(_strings12);

        var _strings13 = require('./fr-BE/strings.json');

        var be = _interopRequireWildcard(_strings13);

        var _strings14 = require('./fr-FR/strings.json');

        var fr = _interopRequireWildcard(_strings14);

        var _strings15 = require('./it-IT/strings.json');

        var it = _interopRequireWildcard(_strings15);

        var _strings16 = require('./ja-JP/strings.json');

        var jp = _interopRequireWildcard(_strings16);

        var _strings17 = require('./nb-NO/strings.json');

        var no = _interopRequireWildcard(_strings17);

        var _strings18 = require('./nl-BE/strings.json');

        var beNl = _interopRequireWildcard(_strings18);

        var _strings19 = require('./nl-NL/strings.json');

        var nl = _interopRequireWildcard(_strings19);

        var _strings20 = require('./pl-PL/strings.json');

        var pl = _interopRequireWildcard(_strings20);

        var _strings21 = require('./pt-BR/strings.json');

        var br = _interopRequireWildcard(_strings21);

        var _strings22 = require('./pt-PT/strings.json');

        var pt = _interopRequireWildcard(_strings22);

        var _strings23 = require('./ru-RU/strings.json');

        var ru = _interopRequireWildcard(_strings23);

        var _strings24 = require('./sv-SE/strings.json');

        var se = _interopRequireWildcard(_strings24);

        var _strings25 = require('./zh-CN/strings.json');

        var cn = _interopRequireWildcard(_strings25);

        function _interopRequireWildcard(obj) {
            if (obj && obj.__esModule) {
                return obj;
            } else {
                var newObj = {};
                if (obj != null) {
                    for (var key in obj) {
                        if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
                    }
                }
                newObj.default = obj;
                return newObj;
            }
        }

        var locales = {
            'da-DK': dk,
            'de-AT': at,
            'de-CH': ch,
            'de-DE': de,
            'en-AU': au,
            'en-CA': ca,
            'en-GB': gb,
            'en-IE': ie,
            'en-NZ': nz,
            'en-US': us,
            'es-ES': es,
            'fi-FI': fi,
            'fr-BE': be,
            'fr-FR': fr,
            'it-IT': it,
            'ja-JP': jp,
            'nb-NO': no,
            'nl-BE': beNl,
            'nl-NL': nl,
            'pl-PL': pl,
            'pt-BR': br,
            'pt-PT': pt,
            'ru-RU': ru,
            'sv-SE': se,
            'zh-CN': cn
        };

        exports.default = locales;

    }, {
        "./da-DK/strings.json": 3,
        "./de-AT/strings.json": 4,
        "./de-CH/strings.json": 5,
        "./de-DE/strings.json": 6,
        "./en-AU/strings.json": 7,
        "./en-CA/strings.json": 8,
        "./en-GB/strings.json": 9,
        "./en-IE/strings.json": 10,
        "./en-NZ/strings.json": 11,
        "./en-US/strings.json": 12,
        "./es-ES/strings.json": 13,
        "./fi-FI/strings.json": 14,
        "./fr-BE/strings.json": 15,
        "./fr-FR/strings.json": 16,
        "./it-IT/strings.json": 18,
        "./ja-JP/strings.json": 19,
        "./nb-NO/strings.json": 20,
        "./nl-BE/strings.json": 21,
        "./nl-NL/strings.json": 22,
        "./pl-PL/strings.json": 23,
        "./pt-BR/strings.json": 24,
        "./pt-PT/strings.json": 25,
        "./ru-RU/strings.json": 26,
        "./sv-SE/strings.json": 27,
        "./zh-CN/strings.json": 28
    }],
    18: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "recensione",
                "plural": "recensioni",
                "collectedVia": "Raccolta tramite [source]",
                "verifiedVia": "Verificata, raccolta da [source]"
            },
            "monthNames": {
                "january": "gennaio",
                "february": "febbraio",
                "march": "marzo",
                "april": "aprile",
                "may": "maggio",
                "june": "giugno",
                "july": "luglio",
                "august": "agosto",
                "september": "settembre",
                "october": "ottobre",
                "november": "novembre",
                "december": "dicembre"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] giorno fa",
                    "plural": "[count] giorni fa"
                },
                "hours": {
                    "singular": "[count] ora fa",
                    "plural": "[count] ore fa"
                },
                "minutes": {
                    "singular": "[count] minuto fa",
                    "plural": "[count] minuti fa"
                },
                "seconds": {
                    "singular": "[count] secondo fa",
                    "plural": "[count] secondi fa"
                }
            },
            "reviewFilters": {
                "byStars1": "Le nostre recensioni a [star1] stelle",
                "byStars2": "Le nostre recensioni a [star1] e a [star2] stelle",
                "byStars3": "Le nostre recensioni a [star1], a [star2] e a [star3] stelle",
                "byStars4": "Le nostre recensioni a [star1], a [star2], a [star3] e a [star4] stelle",
                "byLatest": "Le nostre ultime recensioni",
                "byFavoriteOrTag": "Le nostre recensioni preferite"
            }
        }
    }, {}],
    19: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "レビュー",
                "plural": "レビュー",
                "collectedVia": "[source] によって収集",
                "verifiedVia": "[source] によって確認・収集"
            },
            "monthNames": {
                "january": "1月",
                "february": "2月",
                "march": "3月",
                "april": "4月",
                "may": "5月",
                "june": "6月",
                "july": "7月",
                "august": "8月",
                "september": "9月",
                "october": "10月",
                "november": "11月",
                "december": "12月"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count]日前",
                    "plural": "[count]日前"
                },
                "hours": {
                    "singular": "[count]時間前",
                    "plural": "[count]時間前"
                },
                "minutes": {
                    "singular": "[count]分前",
                    "plural": "[count]分前"
                },
                "seconds": {
                    "singular": "[count]秒前",
                    "plural": "[count]秒前"
                }
            },
            "reviewFilters": {
                "byStars1": "[star1]つ星のレビューを表示",
                "byStars2": "[star1]つ星と[star2]つ星のレビューを表示",
                "byStars3": "[star1]つ星、[star2]つ星、[star3]つ星のレビューを表示",
                "byStars4": "[star1]つ星、[star2]つ星、[star3]つ星、[star4]つ星のレビューを表示",
                "byLatest": "最新のレビューを表示",
                "byFavoriteOrTag": "お気に入りのレビューを表示"
            }
        }
    }, {}],
    20: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "anmeldelse",
                "plural": "anmeldelser",
                "collectedVia": "Samlet inn gjennom [source]",
                "verifiedVia": "Bekreftet – samlet inn via [source]"
            },
            "monthNames": {
                "january": "januar",
                "february": "februar",
                "march": "mars",
                "april": "april",
                "may": "mai",
                "june": "juni",
                "july": "juli",
                "august": "august",
                "september": "september",
                "october": "oktober",
                "november": "november",
                "december": "desember"
            },
            "timeAgo": {
                "days": {
                    "singular": "For [count] dag siden",
                    "plural": "For [count] dager siden"
                },
                "hours": {
                    "singular": "For [count] time siden",
                    "plural": "For [count] timer siden"
                },
                "minutes": {
                    "singular": "For [count] minutt siden",
                    "plural": "For [count] minutter siden"
                },
                "seconds": {
                    "singular": "For [count] sekund siden",
                    "plural": "For [count] sekunder siden"
                }
            },
            "reviewFilters": {
                "byStars1": "Viser [star1]-stjernersanmeldelsene",
                "byStars2": "Viser [star1]- og [star2]-stjernersanmeldelsene",
                "byStars3": "Viser [star1]-, [star2]- og [star3]-stjernersanmeldelsene",
                "byStars4": "Viser [star1]-, [star2]-, [star3]- og [star4]-stjernersanmeldelsene",
                "byLatest": "Viser de nyeste anmeldelsene",
                "byFavoriteOrTag": "Viser favorittene våre"
            }
        }
    }, {}],
    21: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "review",
                "plural": "reviews",
                "collectedVia": "Verzameld via [source]",
                "verifiedVia": "Geverifieerd — verzameld via [source]"
            },
            "monthNames": {
                "january": "januari",
                "february": "februari",
                "march": "maart",
                "april": "april",
                "may": "mei",
                "june": "juni",
                "july": "juli",
                "august": "augustus",
                "september": "september",
                "october": "oktober",
                "november": "november",
                "december": "December"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] dag geleden",
                    "plural": "[count] dagen geleden"
                },
                "hours": {
                    "singular": "[count] uur geleden",
                    "plural": "[count] uur geleden"
                },
                "minutes": {
                    "singular": "[count] minuut geleden",
                    "plural": "[count] minuten geleden"
                },
                "seconds": {
                    "singular": "[count] seconde geleden",
                    "plural": "[count] seconden geleden"
                }
            },
            "reviewFilters": {
                "byStars1": "Onze reviews met [star1] sterren",
                "byStars2": "Onze reviews met [star1] en [star2] sterren",
                "byStars3": "Onze reviews met [star1], [star2] en [star3] sterren",
                "byStars4": "Onze reviews met [star1], [star2], [star3] en [star4] sterren",
                "byLatest": "Onze meest recente reviews",
                "byFavoriteOrTag": "Onze favoriete reviews"
            }
        }
    }, {}],
    22: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "review",
                "plural": "reviews",
                "collectedVia": "Verzameld via [source]",
                "verifiedVia": "Geverifieerd — verzameld via [source]"
            },
            "monthNames": {
                "january": "januari",
                "february": "februari",
                "march": "maart",
                "april": "april",
                "may": "mei",
                "june": "juni",
                "july": "juli",
                "august": "augustus",
                "september": "september",
                "october": "oktober",
                "november": "november",
                "december": "december"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] dag geleden",
                    "plural": "[count] dagen geleden"
                },
                "hours": {
                    "singular": "[count] uur geleden",
                    "plural": "[count] uur geleden"
                },
                "minutes": {
                    "singular": "[count] minuut geleden",
                    "plural": "[count] minuten geleden"
                },
                "seconds": {
                    "singular": "[count] seconde geleden",
                    "plural": "[count] seconden geleden"
                }
            },
            "reviewFilters": {
                "byStars1": "Onze reviews met [star1] sterren",
                "byStars2": "Onze reviews met [star1] en [star2] sterren",
                "byStars3": "Onze reviews met [star1], [star2] en [star3] sterren",
                "byStars4": "Onze reviews met [star1], [star2], [star3] en [star4] sterren",
                "byLatest": "Onze meest recente reviews",
                "byFavoriteOrTag": "Onze favoriete reviews"
            }
        }
    }, {}],
    23: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "recenzja",
                "plural": "recenzji",
                "collectedVia": "Zebrane przez [source]",
                "verifiedVia": "Zweryfikowano i zebrano przez [source]"
            },
            "monthNames": {
                "january": "stycznia",
                "february": "lutego",
                "march": "marca",
                "april": "kwietnia",
                "may": "maja",
                "june": "czerwca",
                "july": "lipca",
                "august": "sierpnia",
                "september": "września",
                "october": "października",
                "november": "listopada",
                "december": "grudnia"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] dzień temu",
                    "plural": "[count] dni temu"
                },
                "hours": {
                    "singular": "[count] godzinę temu",
                    "plural": "[count] godz. temu"
                },
                "minutes": {
                    "singular": "[count] minutę temu",
                    "plural": "[count] min. temu"
                },
                "seconds": {
                    "singular": "[count] sekundę temu",
                    "plural": "[count] sek. temu"
                }
            },
            "reviewFilters": {
                "byStars1": "Wyświetlamy nasze [star1]-gwiazdkowe recenzje",
                "byStars2": "Wyświetlamy nasze [star1]- i [star2]-gwiazdkowe recenzje",
                "byStars3": "Wyświetlamy nasze [star1]-, [star2]- i [star3]-gwiazdkowe recenzje",
                "byStars4": "Wyświetlamy nasze [star1]-, [star2]-, [star3]- i [star4]-gwiazdkowe recenzje",
                "byLatest": "Wyświetlamy najnowsze recenzje",
                "byFavoriteOrTag": "Wyświetlamy nasze ulubione recenzje"
            }
        }
    }, {}],
    24: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "avaliação",
                "plural": "avaliações",
                "collectedVia": "Recolhida via [source]",
                "verifiedVia": "Verificada, recolhida via [source]"
            },
            "monthNames": {
                "january": "Janeiro",
                "february": "Fevereiro",
                "march": "Março",
                "april": "Abril",
                "may": "Maio",
                "june": "Junho",
                "july": "Julho",
                "august": "Agosto",
                "september": "Setembro",
                "october": "Outubro",
                "november": "Novembro",
                "december": "Dezembro"
            },
            "timeAgo": {
                "days": {
                    "singular": "há [count] dia",
                    "plural": "há [count] dias"
                },
                "hours": {
                    "singular": "há [count] hora",
                    "plural": "há [count] horas"
                },
                "minutes": {
                    "singular": "há [count] minuto",
                    "plural": "há [count] minutos"
                },
                "seconds": {
                    "singular": "há [count] segundo",
                    "plural": "há [count] segundos"
                }
            },
            "reviewFilters": {
                "byStars1": "Nossas avaliações com [star1] estrela(s)",
                "byStars2": "Nossas avaliações com [star1] & [star2] estrelas",
                "byStars3": "Nossas avaliações com [star1], [star2] & [star3] estrelas",
                "byStars4": "Nossas avaliações com [star1], [star2], [star3] & [star4] estrelas",
                "byLatest": "Mostrando nossas avaliações mais recentes",
                "byFavoriteOrTag": "Mostrando nossas avaliações favoritas"
            }
        }
    }, {}],
    25: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "opinião",
                "plural": "opiniões",
                "collectedVia": "Recolhida via [source]",
                "verifiedVia": "Verificada, recolhida via [source]"
            },
            "monthNames": {
                "january": "Janeiro",
                "february": "Fevereiro",
                "march": "Março",
                "april": "Abril",
                "may": "Maio",
                "june": "Junho",
                "july": "Julho",
                "august": "Agosto",
                "september": "Setembro",
                "october": "Outubro",
                "november": "Novembro",
                "december": "Dezembro"
            },
            "timeAgo": {
                "days": {
                    "singular": "há [count] dia",
                    "plural": "há [count] dias"
                },
                "hours": {
                    "singular": "há [count] hora",
                    "plural": "há [count] horas"
                },
                "minutes": {
                    "singular": "há [count] minuto",
                    "plural": "há [count] minutos"
                },
                "seconds": {
                    "singular": "há [count] segundo",
                    "plural": "há [count] segundos"
                }
            },
            "reviewFilters": {
                "byStars1": "As nossas opiniões com [star1] estrela(s)",
                "byStars2": "As nossas opiniões com [star1] e [star2] estrelas",
                "byStars3": "As nossas opiniões com [star1], [star2] e [star3] estrelas",
                "byStars4": "As nossas opiniões com [star1], [star2], [star3] e [star4] estrelas",
                "byLatest": "As nossas opiniões mais recentes",
                "byFavoriteOrTag": "As nossas opiniões favoritas"
            }
        }
    }, {}],
    26: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "отзыв",
                "plural": "отзывов",
                "collectedVia": "Собрано через [source]",
                "verifiedVia": "Подтверждено, собрано через [source]"
            },
            "monthNames": {
                "january": "января",
                "february": "февраля",
                "march": "марта",
                "april": "апреля",
                "may": "мая",
                "june": "июня",
                "july": "Июль",
                "august": "августа",
                "september": "сентября",
                "october": "Октябрь",
                "november": "ноября",
                "december": "Декабрь"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] день назад",
                    "plural": "[count] дней назад"
                },
                "hours": {
                    "singular": "[count] час назад",
                    "plural": "[count] часов назад"
                },
                "minutes": {
                    "singular": "[count] минуту назад",
                    "plural": "[count] минут назад"
                },
                "seconds": {
                    "singular": "[count] секунду назад",
                    "plural": "[count] секунд назад"
                }
            },
            "reviewFilters": {
                "byStars1": "Наши отзывы [star1] звезд",
                "byStars2": "Наши отзывы [star1] и [star2] звезд",
                "byStars3": "Наши отзывы [star1], [star2] и [star3] звезд",
                "byStars4": "Наши отзывы [star1], [star2], [star3] и [star4] звезд",
                "byLatest": "Наши недавние отзывы",
                "byFavoriteOrTag": "Наши любимые отзывы"
            }
        }
    }, {}],
    27: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "omdöme",
                "plural": "omdömen",
                "collectedVia": "Insamlat via [source]",
                "verifiedVia": "Verifierat – insamlat via [source]"
            },
            "monthNames": {
                "january": "januari",
                "february": "februari",
                "march": "mars",
                "april": "april",
                "may": "maj",
                "june": "juni",
                "july": "juli",
                "august": "augusti",
                "september": "september",
                "october": "oktober",
                "november": "november",
                "december": "december"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] dag sedan",
                    "plural": "[count] dagar sedan"
                },
                "hours": {
                    "singular": "[count] timme sedan",
                    "plural": "[count] timmar sedan"
                },
                "minutes": {
                    "singular": "[count] minut sedan",
                    "plural": "[count] minuter sedan"
                },
                "seconds": {
                    "singular": "[count] sekund sedan",
                    "plural": "[count] sekunder sedan"
                }
            },
            "reviewFilters": {
                "byStars1": "Visar våra [star1]-stjärniga omdömen",
                "byStars2": "Visar våra [star1]- och [star2]-stjärniga omdömen",
                "byStars3": "Visar våra [star1]-, [star2]- och [star3]-stjärniga omdömen",
                "byStars4": "Visar våra [star1]-, [star2]-, [star3]- och [star4]-stjärniga omdömen",
                "byLatest": "Visar våra senaste omdömen",
                "byFavoriteOrTag": "Visar våra favoritomdömen"
            }
        }
    }, {}],
    28: [function(require, module, exports) {
        module.exports = {
            "reviews": {
                "singular": "条评论",
                "plural": "条点评,"
            },
            "monthNames": {
                "january": "一月",
                "february": "二月",
                "march": "三月",
                "april": "四月",
                "may": "五月",
                "june": "六月",
                "july": "七月",
                "august": "八月",
                "september": "九月",
                "october": "十月",
                "november": "十一月",
                "december": "十二月"
            },
            "timeAgo": {
                "days": {
                    "singular": "[count] day ago",
                    "plural": "[count] days ago"
                },
                "hours": {
                    "singular": "[count] hour ago",
                    "plural": "[count] hours ago"
                },
                "minutes": {
                    "singular": "[count] minute ago",
                    "plural": "[count] minutes ago"
                },
                "seconds": {
                    "singular": "[count] second ago",
                    "plural": "[count] seconds ago"
                }
            },
            "reviewFilters": {
                "byStars1": "Showing our [star1] star reviews",
                "byStars2": "Showing our [star1] & [star2] star reviews",
                "byStars3": "Showing our [star1], [star2] & [star3] star reviews",
                "byStars4": "Showing our [star1], [star2], [star3] & [star4] star reviews",
                "byLatest": "Showing our latest reviews",
                "byFavoriteOrTag": "Showing our favorite reviews"
            }
        }
    }, {}],
    29: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.apiCall = undefined;

        var _promise = require('promise');

        var _promise2 = _interopRequireDefault(_promise);

        var _xhr = require('../xhr');

        var _xhr2 = _interopRequireDefault(_xhr);

        var _queryString = require('../queryString');

        var _rootUri = require('../rootUri');

        var _rootUri2 = _interopRequireDefault(_rootUri);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        // Make a random ID where an apiCall requires one.
        var makeId = function makeId(numOfChars) {
            var text = '';
            var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            for (var i = 0; i < numOfChars; i++) {
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            }
            return text;
        };

        /* eslint-disable compat/compat */
        var apiCall = function apiCall(uri, params) {
            return new _promise2.default(function(resolve, fail) {
                var values = void 0;
                var url = void 0;

                if (uri.indexOf('/') === 0) {
                    values = params || {};

                    var _getQuerystringAsObje = (0, _queryString.getAsObject)(),
                        token = _getQuerystringAsObje.token;

                    if (token) {
                        values.random = makeId(20);
                    }
                }

                if (uri.indexOf('http') === 0) {
                    // is a full url from a paging link, ensure https
                    url = uri.replace(/^https?:/, 'https:');
                } else if (uri.indexOf('/') === 0) {
                    // is a regular "/v1/..." add domain for local testing (value is empty in prod)
                    url = (0, _rootUri2.default)() + uri;
                } else {
                    // weird/broken url
                    return fail();
                }

                return (0, _xhr2.default)({
                    url: url,
                    data: values,
                    success: resolve,
                    error: fail
                });
            });
        };

        exports.apiCall = apiCall;
        /* eslint-enable compat/compat */

    }, {
        "../queryString": 42,
        "../rootUri": 44,
        "../xhr": 62,
        "promise": 65
    }],
    62: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        /* global ActiveXObject */

        function isIE() {
            var myNav = navigator.userAgent.toLowerCase();
            return myNav.indexOf('msie') != -1 ? parseInt(myNav.split('msie')[1]) : false;
        }

        // adapted (stolen) from https://github.com/toddmotto/atomic

        function parse(req) {
            try {
                return JSON.parse(req.responseText);
            } catch (e) {
                return req.responseText;
            }
        }

        // http://stackoverflow.com/a/1714899
        function toQueryString(obj) {
            var str = [];
            for (var p in obj) {
                if (obj.hasOwnProperty(p)) {
                    str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                }
            }
            return str.join('&');
        }

        function noop() {}

        function makeRequest(params) {
            var XMLHttpRequest = window.XMLHttpRequest || ActiveXObject;
            var request = new XMLHttpRequest('MSXML2.XMLHTTP.3.0');
            request.open(params.type, params.url, true);
            request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            request.onreadystatechange = function() {
                if (request.readyState === 4) {
                    if (request.status >= 200 && request.status < 300) {
                        params.success(parse(request));
                    } else {
                        params.error(parse(request));
                    }
                }
            };

            request.send(params.data);
        }

        /* IE9-compatible request function.

        IE9 does not permit cross-origin HTTP requests in the usual way. It also does
        not permit a request to be made to a URI with a different protocol from that
        of the page, e.g. an HTTPS request from an HTTP page.

        This function makes requests in a manner compatible with IE9's limitations.
        */
        function makeRequestIE(params) {
            var request = new window.XDomainRequest();
            var protocol = window.location.protocol;
            params.url = params.url.replace(/https?:/, protocol);
            request.open(params.type, params.url);
            request.onload = function() {
                params.success(parse(request));
            };
            request.onerror = function() {
                params.error(parse(request));
            };

            setTimeout(function() {
                request.send(params.data);
            }, 0);
        }

        function xhr(options) {
            var params = {
                type: options.type || 'GET',
                error: options.error || noop,
                success: options.success || noop,
                data: options.data,
                url: options.url || ''
            };

            if (params.type === 'GET' && params.data) {
                params.url = params.url + '?' + toQueryString(params.data);
                delete params.data;
            }

            if (isIE() && isIE() <= 9) {
                makeRequestIE(params);
            } else {
                makeRequest(params);
            }
        }

        exports.default = xhr;

    }, {}],
    44: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        exports.default = function() {
            var host = '#{WidgetApi.Host}';
            return host.indexOf('#') === 0 ? 'https://widget.tp-staging.com' : host;
        };

    }, {}],
    65: [function(require, module, exports) {
        'use strict';

        module.exports = require('./lib')

    }, {
        "./lib": 70
    }],
    30: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.hasProductReviews = exports.hasServiceReviewsMultiFetch = exports.hasServiceReviews = /* common-shake removed: exports.constructTrustBoxAndComplete = */ exports.multiFetchData = exports.fetchData = undefined;

        var _slicedToArray = function() {
            function sliceIterator(arr, i) {
                var _arr = [];
                var _n = true;
                var _d = false;
                var _e = undefined;
                try {
                    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
                        _arr.push(_s.value);
                        if (i && _arr.length === i) break;
                    }
                } catch (err) {
                    _d = true;
                    _e = err;
                } finally {
                    try {
                        if (!_n && _i["return"]) _i["return"]();
                    } finally {
                        if (_d) throw _e;
                    }
                }
                return _arr;
            }
            return function(arr, i) {
                if (Array.isArray(arr)) {
                    return arr;
                } else if (Symbol.iterator in Object(arr)) {
                    return sliceIterator(arr, i);
                } else {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }
            };
        }();

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _promise = require('promise');

        var _promise2 = _interopRequireDefault(_promise);

        var _call = require('./call');

        var _utils = require('../utils');

        var _loader = require('../templates/loader');

        var _errorFallback = require('../templates/errorFallback');

        var _communication = require('../communication');

        var _fn = require('../fn');

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }

        function _objectWithoutProperties(obj, keys) {
            var target = {};
            for (var i in obj) {
                if (keys.indexOf(i) >= 0) continue;
                if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
                target[i] = obj[i];
            }
            return target;
        }

        /**
         * Define a unique single fetch object key, allowing us to flatten back to a
         * single set of base data. This is arbitrary, and has been selected to ensure
         * it will not be accidentally used in a fetchParamsObject.
         */
        var singleFetchObjectKey = 'default_singleFetch_f98ac77b';

        /**
         * Flatten a fetchParamsObject value to one single set of fetchParams, where
         * that object contains only one value, and it is indexed by
         * singleFetchObjectKey.
         */
        var flattenSingleParams = function flattenSingleParams(fetchParamsObject) {
            var keys = Object.keys(fetchParamsObject);
            return singleFetchObjectKey in fetchParamsObject && keys.length === 1 ? fetchParamsObject[singleFetchObjectKey] : fetchParamsObject;
        };

        /**
         * Check if business has service reviews
         */
        var hasServiceReviews = function hasServiceReviews(_ref) {
            var total = _ref.businessEntity.numberOfReviews.total;
            return total > 0;
        };

        /**
         * Check if a business has service reviews using multi-fetch.
         *
         * This checks that any of the base data sets has service reviews present
         * within it.
         */
        var hasServiceReviewsMultiFetch = function hasServiceReviewsMultiFetch(baseData) {
            var keys = Object.keys(baseData);
            return keys.some(function(k) {
                return hasServiceReviews(baseData[k]);
            });
        };

        /**
         * Check if business has imported or regular product reviews
         */
        var hasProductReviews = function hasProductReviews(_ref2) {
            var productReviewsSummary = _ref2.productReviewsSummary,
                importedProductReviewsSummary = _ref2.importedProductReviewsSummary;

            var totalProductReviews = productReviewsSummary ? productReviewsSummary.numberOfReviews.total : 0;
            var totalImportedProductReviews = importedProductReviewsSummary ? importedProductReviewsSummary.numberOfReviews.total : 0;

            return totalProductReviews + totalImportedProductReviews > 0;
        };

        // Construct a base data call promise.
        var baseDataCall = function baseDataCall(uri) {
            return function(_ref3) {
                var businessUnitId = _ref3.businessUnitId,
                    locale = _ref3.locale,
                    opts = _objectWithoutProperties(_ref3, ['businessUnitId', 'locale']);

                var baseDataParams = (0, _fn.rejectNullaryValues)(_extends({
                    businessUnitId: businessUnitId,
                    locale: locale
                }, opts, {
                    theme: null // Force rejection of the theme param
                }));
                return (0, _call.apiCall)(uri, baseDataParams);
            };
        };

        /**
         * Call a constructTrustBox callback, and then complete the loading process
         * for the TrustBox.
         */
        var constructTrustBoxAndComplete = function constructTrustBoxAndComplete(constructTrustBox) {
            var passToPopup = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
            var hasReviewsFromBaseData = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : hasServiceReviews;
            return function(_ref4) {
                var baseData = _ref4.baseData,
                    locale = _ref4.locale,
                    theme = _ref4.theme,
                    hasMoreReviews = _ref4.hasMoreReviews,
                    loadMoreReviews = _ref4.loadMoreReviews;

                var hasReviews = hasReviewsFromBaseData(baseData);

                constructTrustBox({
                    baseData: baseData,
                    locale: locale,
                    hasMoreReviews: hasMoreReviews,
                    loadMoreReviews: loadMoreReviews
                });

                // Conditionally send to popup
                var sendOnPopupLoad = function sendOnPopupLoad(_ref5) {
                    var event = _ref5.data;

                    if ((0, _communication.isLoadedMessage)(event)) {
                        (0, _communication.sendAPIDataMessage)({
                            baseData: baseData,
                            locale: locale
                        });
                    }
                };
                if (passToPopup) {
                    (0, _communication.setListener)(sendOnPopupLoad);
                }

                (0, _utils.showTrustBox)(theme, hasReviews);
                (0, _errorFallback.removeErrorFallback)();
            };
        };

        /**
         * Fetch data from the data API, making zero or more requests.
         *
         * This function accepts an object with arbitrary keys, and values which are
         * each an object containing query params for one request. A request is made
         * for each query param object, and the result is wrapped within an object
         * indexed by the keys of the original argument object.
         *
         * These data, together with locale data, are passed to the
         * constructTrustBox callback.
         *
         * An optional argument, passToPopup, can be provided to this function. If set
         * to a truthy value, this function will attempt to pass the data obtained to
         * any popup iframe.
         */
        var multiFetchData = function multiFetchData(uri) {
            return function(fetchParamsObject, constructTrustBox, passToPopup, hasReviewsFromBaseData) {
                var firstFetchParams = fetchParamsObject[Object.keys(fetchParamsObject)[0]];
                var locale = firstFetchParams.locale,
                    _firstFetchParams$the = firstFetchParams.theme,
                    theme = _firstFetchParams$the === undefined ? 'light' : _firstFetchParams$the;


                var baseDataPromises = (0, _fn.promiseAllObject)((0, _fn.mapObject)(baseDataCall(uri), fetchParamsObject));
                var readyPromise = (0, _utils.getOnPageReady)();

                // eslint-disable-next-line compat/compat
                var fetchPromise = _promise2.default.all([baseDataPromises, readyPromise]).then(function(_ref6) {
                    var _ref7 = _slicedToArray(_ref6, 1),
                        originalBaseData = _ref7[0];

                    var baseData = flattenSingleParams(originalBaseData);

                    return {
                        baseData: baseData,
                        locale: locale,
                        theme: theme
                    };
                }).then(constructTrustBoxAndComplete(constructTrustBox, passToPopup, hasReviewsFromBaseData)).catch(function(e) {
                    if (e && e.FallbackLogo) {
                        // render fallback only if allowed, based on the response
                        return (0, _errorFallback.errorFallback)();
                    }
                    // do nothing
                });

                (0, _loader.withLoader)(fetchPromise);
            };
        };

        // Fetch and structure API data.
        var fetchData = function fetchData(uri) {
            return function(fetchParams, constructTrustBox, passToPopup, hasReviewsFromBaseData) {
                var fetchParamsObject = _defineProperty({}, singleFetchObjectKey, fetchParams);
                multiFetchData(uri)(fetchParamsObject, constructTrustBox, passToPopup, hasReviewsFromBaseData);
            };
        };

        exports.fetchData = fetchData;
        exports.multiFetchData = multiFetchData;
        /* common-shake removed: exports.constructTrustBoxAndComplete = */
        void constructTrustBoxAndComplete;
        exports.hasServiceReviews = hasServiceReviews;
        exports.hasServiceReviewsMultiFetch = hasServiceReviewsMultiFetch;
        exports.hasProductReviews = hasProductReviews;

    }, {
        "../communication": 37,
        "../fn": 39,
        "../templates/errorFallback": 51,
        "../templates/loader": 52,
        "../utils": 61,
        "./call": 29,
        "promise": 65
    }],
    37: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        /* common-shake removed: exports.scrollToTrustBox = */
        exports.onPong = exports.ping = /* common-shake removed: exports.isPopupToggleMessage = */ /* common-shake removed: exports.isAPIDataMessage = */ exports.sendAPIDataMessage = exports.isLoadedMessage = exports.setListener = /* common-shake removed: exports.resizeHeight = */ /* common-shake removed: exports.setStyles = */ /* common-shake removed: exports.loaded = */ /* common-shake removed: exports.focusModal = */ /* common-shake removed: exports.hideModal = */ /* common-shake removed: exports.showModal = */ /* common-shake removed: exports.focusPopup = */ /* common-shake removed: exports.hidePopup = */ /* common-shake removed: exports.showPopup = */ /* common-shake removed: exports.hideTrustBox = */ /* common-shake removed: exports.createModal = */ /* common-shake removed: exports.createPopup = */ /* common-shake removed: exports.send = */ undefined;

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _utils = require('./utils.js');

        var wparent = window.parent;
        var messageQueue = [];
        var defaultOptions = {
            command: 'createIFrame',
            position: 'center top',
            show: false,
            source: 'popup.html',
            queryString: ''
        };
        var popupOptions = {
            name: 'popup',
            modal: false,
            styles: {
                height: '300px',
                width: ''
            }
        };
        var modalOptions = {
            name: 'modal',
            modal: true,
            styles: {
                width: '100%',
                height: '100%',
                position: 'fixed',
                left: '0',
                right: '0',
                top: '0',
                bottom: '0',
                margin: '0 auto',
                zindex: 99
            }
        };

        var id = null;
        var listenerCallbacks = [];

        function sendMessage(message) {
            if (id) {
                message.widgetId = id;
                message = JSON.stringify(message); // This is to make it IE8 compatible
                wparent.postMessage(message, '*');
            } else {
                messageQueue.push(message);
            }
        }

        function sendMessageTo(target) {
            return function(message) {
                var payload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
                return sendMessage(_extends({}, payload, {
                    message: message,
                    command: 'message',
                    name: target
                }));
            };
        }

        function sendQueue() {
            while (messageQueue.length) {
                sendMessage(messageQueue.pop());
            }
        }

        function createPopupIframe(options) {
            sendMessage(_extends({}, defaultOptions, popupOptions, options));
        }

        function createModalIframe(options) {
            sendMessage(_extends({}, defaultOptions, modalOptions, options));
        }

        function setStyles(styles, optionalIframeName) {
            sendMessage({
                command: 'setStyle',
                name: optionalIframeName,
                style: styles
            });
        }

        function showIframe(iframeName) {
            sendMessage({
                command: 'show',
                name: iframeName
            });
            sendMessageTo('main')(iframeName + ' toggled', {
                visible: true
            });
        }

        function hideIframe(iframeName) {
            sendMessage({
                command: 'hide',
                name: iframeName
            });
            sendMessageTo('main')(iframeName + ' toggled', {
                visible: false
            });
        }

        function focusIframe(iframeName) {
            sendMessage({
                command: 'focus',
                name: iframeName
            });
        }

        function sendLoadedMessage() {
            sendMessage({
                command: 'loaded'
            });
        }

        function isLoadedMessage(message) {
            return message === 'loaded';
        }

        /**
         * Send data obtained from an API call to a popup iframe.
         */
        function sendAPIDataMessage(data) {
            sendMessageTo('popup')('API data', data);
        }

        /**
         * Test if two messages are of the same type.
         *
         * Ignores any additional data contained within the message.
         */
        function areMatchingMessages(message, otherMessage) {
            return ['message', 'command', 'name'].every(function(key) {
                return message[key] && otherMessage[key] && message[key] === otherMessage[key];
            });
        }

        function isAPIDataMessage(message) {
            return areMatchingMessages(message, {
                command: 'message',
                name: 'popup',
                message: 'API data'
            });
        }

        function isPopupToggleMessage(message) {
            return areMatchingMessages(message, {
                command: 'message',
                name: 'main',
                message: 'popup toggled'
            });
        }

        function addCallbackFunction(func) {
            listenerCallbacks.push(func);
        }

        function hideMainIframe() {
            hideIframe('main');
        }

        function showPopupIframe() {
            showIframe('popup');
        }

        function hidePopupIframe() {
            hideIframe('popup');
        }

        function focusPopupIframe() {
            focusIframe('popup');
        }

        function showModalIframe() {
            showIframe('modal');
        }

        function hideModalIframe() {
            hideIframe('modal');
        }

        function focusModalIframe() {
            focusIframe('modal');
        }

        var sendPing = function sendPing() {
            return sendMessage({
                command: 'ping'
            });
        };

        var onPong = function onPong(cb) {
            var pong = function pong(event) {
                if (event.data.command === 'pong') {
                    cb(event);
                }
            };
            addCallbackFunction(pong);
        };

        function resizeHeight(optionalHeight, optionalIframeName) {
            var body = document.getElementsByTagName('body')[0];
            sendMessage({
                command: 'resize-height',
                name: optionalIframeName,
                height: optionalHeight || body.offsetHeight
            });
        }

        function scrollToTrustBox(targets) {
            sendMessage({
                command: 'scrollTo',
                targets: targets
            });
        }

        (0, _utils.addEventListener)(window, 'message', function(event) {
            if (typeof event.data !== 'string') {
                return;
            }

            var e = void 0;
            try {
                e = {
                    data: JSON.parse(event.data)
                }; // This is to make it IE8 compatible
            } catch (e) {
                return; // probably not for us
            }

            if (e.data.command === 'setId') {
                id = e.data.widgetId;
                sendQueue();
            } else {
                for (var i = 0; i < listenerCallbacks.length; i++) {
                    var callback = listenerCallbacks[i];
                    callback(e);
                }
            }
        });

        /* common-shake removed: exports.send = */
        void sendMessage;
        /* common-shake removed: exports.createPopup = */
        void createPopupIframe;
        /* common-shake removed: exports.createModal = */
        void createModalIframe;
        /* common-shake removed: exports.hideTrustBox = */
        void hideMainIframe;
        /* common-shake removed: exports.showPopup = */
        void showPopupIframe;
        /* common-shake removed: exports.hidePopup = */
        void hidePopupIframe;
        /* common-shake removed: exports.focusPopup = */
        void focusPopupIframe;
        /* common-shake removed: exports.showModal = */
        void showModalIframe;
        /* common-shake removed: exports.hideModal = */
        void hideModalIframe;
        /* common-shake removed: exports.focusModal = */
        void focusModalIframe;
        /* common-shake removed: exports.loaded = */
        void sendLoadedMessage;
        /* common-shake removed: exports.setStyles = */
        void setStyles;
        /* common-shake removed: exports.resizeHeight = */
        void resizeHeight;
        exports.setListener = addCallbackFunction;
        exports.isLoadedMessage = isLoadedMessage;
        exports.sendAPIDataMessage = sendAPIDataMessage;
        /* common-shake removed: exports.isAPIDataMessage = */
        void isAPIDataMessage;
        /* common-shake removed: exports.isPopupToggleMessage = */
        void isPopupToggleMessage;
        exports.ping = sendPing;
        exports.onPong = onPong;
        /* common-shake removed: exports.scrollToTrustBox = */
        void scrollToTrustBox;

    }, {
        "./utils.js": 61
    }],
    39: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.rejectNullaryValues = exports.propMaybe = exports.prop = exports.promiseAllObject = exports.pipeMaybe = exports.pairsToObject = exports.mapObject = exports.map = exports.guard = /* common-shake removed: exports.first = */ exports.find = /* common-shake removed: exports.filter = */ exports.compose = /* common-shake removed: exports.chunkTranspose = */ /* common-shake removed: exports.chunk = */ undefined;

        var _slicedToArray = function() {
            function sliceIterator(arr, i) {
                var _arr = [];
                var _n = true;
                var _d = false;
                var _e = undefined;
                try {
                    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
                        _arr.push(_s.value);
                        if (i && _arr.length === i) break;
                    }
                } catch (err) {
                    _d = true;
                    _e = err;
                } finally {
                    try {
                        if (!_n && _i["return"]) _i["return"]();
                    } finally {
                        if (_d) throw _e;
                    }
                }
                return _arr;
            }
            return function(arr, i) {
                if (Array.isArray(arr)) {
                    return arr;
                } else if (Symbol.iterator in Object(arr)) {
                    return sliceIterator(arr, i);
                } else {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }
            };
        }();

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _promise = require('promise');

        var _promise2 = _interopRequireDefault(_promise);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function _toConsumableArray(arr) {
            if (Array.isArray(arr)) {
                for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            } else {
                return Array.from(arr);
            }
        }

        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }

        // Convert reduce method into a function
        var reduce = function reduce(f) {
            return function(init) {
                return function(xs) {
                    return xs.reduce(f, init);
                };
            };
        };

        // Convert filter method into a function
        var filter = function filter(p) {
            return function(xs) {
                return xs.filter(p);
            };
        };

        // Convert map method into a function
        var map = function map(f) {
            return function(xs) {
                return xs.map(f);
            };
        };

        // Implementation of map, but for an object. Values are replaced with the result
        // of calling the passed function of them; keys remain unchanged.
        var mapObject = function mapObject(f, obj) {
            return Object.keys(obj).reduce(function(all, k) {
                return _extends({}, all, _defineProperty({}, k, f(obj[k])));
            }, {});
        };

        // Transforms an object containing arbitrary keys, and promise values, into a
        // promise-wrapped object, with the same keys and the result of resolving each
        // promise as values.
        var promiseAllObject = function promiseAllObject(obj) {
            var keys = Object.keys(obj);
            var values = keys.map(function(k) {
                return obj[k];
            });
            // eslint-disable-next-line compat/compat
            return _promise2.default.all(values).then(function(promises) {
                return promises.reduce(function(all, promise, idx) {
                    return _extends({}, all, _defineProperty({}, keys[idx], promise));
                }, {});
            });
        };

        /**
         * Convert an array containing pairs of values into an object.
         *
         *   [[k1, v1], [k2, v2], ... ] -> { [k1]: v1, [k2]: v2, ... }
         */
        var pairsToObject = function pairsToObject(pairs) {
            return pairs.reduce(function(obj, _ref) {
                var _ref2 = _slicedToArray(_ref, 2),
                    k = _ref2[0],
                    v = _ref2[1];

                return _extends({}, obj, _defineProperty({}, k, v));
            }, {});
        };

        var isNullary = function isNullary(value) {
            return typeof value === 'undefined' || value === null;
        };

        var isNullaryOrFalse = function isNullaryOrFalse(value) {
            return isNullary(value) || value === false;
        };

        // Filter out all null or undefined values from an object.
        var rejectNullaryValues = function rejectNullaryValues(obj) {
            return Object.keys(obj).reduce(function(newObj, key) {
                return _extends({}, newObj, isNullary(obj[key]) ? {} : _defineProperty({}, key, obj[key]));
            }, {});
        };

        /**
         * Split an array of values into chunks of a given size.
         *
         * If the number of values does not divide evenly into the chunk size, the
         * final chunk will be smaller than chunkSize.
         *
         *   chunk 2 [a, b, c, d, e, f, g] -> [[a, b], [c, d], [e, f], [g]]
         */
        var chunk = function chunk(chunkSize) {
            return reduce(function(chunks, val, idx) {
                var lastChunk = chunks[chunks.length - 1];
                var isNewChunk = idx % chunkSize === 0;
                var newChunk = isNewChunk ? [val] : [].concat(_toConsumableArray(lastChunk), [val]);
                return [].concat(_toConsumableArray(chunks.slice(0, chunks.length - (isNewChunk ? 0 : 1))), [newChunk]);
            })([]);
        };

        /**
         * Split an array of values into chunks of a given size, and then transpose values.
         *
         * This is equivalent to {@link 'chunk'}, but with the values transposed:
         *
         *   chunkTranspose 2 [a, b, c, d, e, f, g] -> [[a, c, e, g], [b, d, f]]
         *
         * The transposition has the effect of turning an array of x chunks of size n,
         * into an array of n chunks of size x.
         */
        var chunkTranspose = function chunkTranspose(chunkSize) {
            return reduce(function(chunks, val, idx) {
                var chunkIdx = idx % chunkSize;
                var newChunk = [].concat(_toConsumableArray(chunks[chunkIdx] || []), [val]);
                return [].concat(_toConsumableArray(chunks.slice(0, chunkIdx)), [newChunk], _toConsumableArray(chunks.slice(chunkIdx + 1)));
            })([]);
        };

        /**
         * Compose a series of functions together.
         *
         * Equivalent to applying an array of functions to a value, right to left.
         *
         *   compose(f, g, h)(x) === f(g(h(x)))
         *
         */
        var compose = function compose() {
            for (var _len = arguments.length, fs = Array(_len), _key = 0; _key < _len; _key++) {
                fs[_key] = arguments[_key];
            }

            return function(x) {
                return fs.reduceRight(function(val, f) {
                    return f(val);
                }, x);
            };
        };

        // Pipe a value through a series of functions which terminates immediately on
        // receiving a nullary value.
        var pipeMaybe = function pipeMaybe() {
            for (var _len2 = arguments.length, fs = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
                fs[_key2] = arguments[_key2];
            }

            return function(x) {
                return fs.reduce(function(val, f) {
                    return isNullary(val) ? val : f(val);
                }, x);
            };
        };

        // Get first value from an array
        var first = function first(_ref4) {
            var _ref5 = _slicedToArray(_ref4, 1),
                x = _ref5[0];

            return x;
        };

        // First first value matching predicate p in an array of values.
        var find = function find(p) {
            return pipeMaybe(filter(p), first);
        };

        // Get a value from an object at a given key.
        var prop = function prop(k) {
            return function() {
                var obj = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                return obj[k];
            };
        };

        // Get a value from an object at a given key if it exists.	
        var propMaybe = function propMaybe(k) {
            return function() {
                var obj = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                return obj[k] || obj;
            };
        };

        // Test if a value is false or nullary, returning null if true, or a second value if false.
        // Intended for use within a pipeMaybe where you want to terminate execution where
        // an arbitrary value is null.
        var guard = function guard(p) {
            return function(x) {
                return isNullaryOrFalse(p) ? null : x;
            };
        };

        /* common-shake removed: exports.chunk = */
        void chunk;
        /* common-shake removed: exports.chunkTranspose = */
        void chunkTranspose;
        exports.compose = compose;
        /* common-shake removed: exports.filter = */
        void filter;
        exports.find = find;
        /* common-shake removed: exports.first = */
        void first;
        exports.guard = guard;
        exports.map = map;
        exports.mapObject = mapObject;
        exports.pairsToObject = pairsToObject;
        exports.pipeMaybe = pipeMaybe;
        exports.promiseAllObject = promiseAllObject;
        exports.prop = prop;
        exports.propMaybe = propMaybe;
        exports.rejectNullaryValues = rejectNullaryValues;

    }, {
        "promise": 65
    }],
    51: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.removeErrorFallback = exports.errorFallback = undefined;

        var _dom = require('../dom');

        var _templating = require('../templating');

        var _utils = require('../utils');

        var errorFallback = function errorFallback() {
            var containerElement = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'tp-widget-fallback';

            var container = document.getElementById(containerElement);

            (0, _dom.populateElements)([{
                element: container,
                string: (0, _templating.a)({
                    href: 'https://www.trustpilot.com?utm_medium=trustboxfallback',
                    target: '_blank',
                    rel: 'noopener noreferrer'
                }, (0, _templating.mkElemWithSvgLookup)('logo', 'fallback-logo'))
            }]);
        };

        var removeErrorFallback = function removeErrorFallback() {
            var containerElement = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'tp-widget-fallback';

            var container = document.getElementById(containerElement);
            (0, _utils.removeElement)(container);
        };

        exports.errorFallback = errorFallback;
        exports.removeErrorFallback = removeErrorFallback;

    }, {
        "../dom": 38,
        "../templating": 57,
        "../utils": 61
    }],
    52: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.withLoader = undefined;

        var _dom = require('../dom');

        var _utils = require('../utils');

        var _templating = require('../templating');

        var defaultLoaderContainer = 'tp-widget-loader';

        var addLoader = function addLoader(loaderElement) {
            var loader = document.getElementById(loaderElement);

            (0, _dom.populateElements)([{
                element: loader,
                string: (0, _templating.mkElemWithSvgLookup)('logo')
            }]);
        };

        var removeLoader = function removeLoader(loaderElement) {
            var loader = document.getElementById(loaderElement);
            var loaderLoadedClass = loaderElement + '--loaded';
            (0, _dom.addClass)(loader, loaderLoadedClass);

            // Remove loader after completion of animation.
            if (loader) {
                loader.addEventListener('animationend', function() {
                    return (0, _utils.removeElement)(loader);
                });
                loader.addEventListener('webkitAnimationEnd', function() {
                    return (0, _utils.removeElement)(loader);
                });
                loader.addEventListener('oanimationend', function() {
                    return (0, _utils.removeElement)(loader);
                });
            }
        };

        // Creates a loader element in the DOM, then resolves a passed promise and removes
        // the loader once complete. The loader is displayed only after the passed delay
        // has elapsed.
        var withLoader = function withLoader(promise) {
            var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
                _ref$loaderElement = _ref.loaderElement,
                loaderElement = _ref$loaderElement === undefined ? defaultLoaderContainer : _ref$loaderElement,
                _ref$delay = _ref.delay,
                delay = _ref$delay === undefined ? 1000 : _ref$delay;

            var loaderTimeoutId = setTimeout(function() {
                return addLoader(loaderElement);
            }, delay);
            return promise.finally(function() {
                clearTimeout(loaderTimeoutId);
                removeLoader(loaderElement);
            });
        };

        exports.withLoader = withLoader;

    }, {
        "../dom": 38,
        "../templating": 57,
        "../utils": 61
    }],
    32: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        /* common-shake removed: exports.fetchProductReview = */
        /* common-shake removed: exports.fetchProductData = */
        undefined;

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _fetchData = require('./fetchData');

        var _call = require('./call');

        var _reviewFetcher = require('./reviewFetcher');

        var _reviewFetcher2 = _interopRequireDefault(_reviewFetcher);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function _objectWithoutProperties(obj, keys) {
            var target = {};
            for (var i in obj) {
                if (keys.indexOf(i) >= 0) continue;
                if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
                target[i] = obj[i];
            }
            return target;
        }

        /**
         * Fetches data for a product attribute TrustBox.
         *
         * This uses a "new-style" endpoint, which takes a templateId and supplies data
         * based on that.
         */
        var fetchProductData = function fetchProductData(templateId) {
            return function(fetchParams, constructTrustBox) {
                var passToPopup = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
                var includeImportedReviews = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

                // Add extra data to the constructTrustBox callback, where we are fetching reviews
                var wrappedConstruct = function wrappedConstruct(_ref) {
                    var baseData = _ref.baseData,
                        locale = _ref.locale,
                        args = _objectWithoutProperties(_ref, ['baseData', 'locale']);

                    var fetcher = new _reviewFetcher2.default(_extends({
                        baseData: baseData,
                        includeImportedReviews: includeImportedReviews,
                        reviewsPerPage: parseInt(fetchParams.reviewsPerPage),
                        locale: locale
                    }, args));
                    return fetcher.consumeReviews(constructTrustBox)();
                };

                var construct = fetchParams.reviewsPerPage > 0 ? wrappedConstruct : constructTrustBox;
                (0, _fetchData.fetchData)('/trustbox-data/' + templateId)(fetchParams, construct, passToPopup, _fetchData.hasProductReviews);
            };
        };

        /**
         * Fetches product review data given an ID and a locale.
         */
        var fetchProductReview = function fetchProductReview(productReviewId, locale, callback) {
            (0, _call.apiCall)('/product-reviews/' + productReviewId, {
                locale: locale
            }).then(callback);
        };

        /* common-shake removed: exports.fetchProductData = */
        void fetchProductData;
        /* common-shake removed: exports.fetchProductReview = */
        void fetchProductReview;

    }, {
        "./call": 29,
        "./fetchData": 30,
        "./reviewFetcher": 33
    }],
    33: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || false;
                    descriptor.configurable = true;
                    if ("value" in descriptor) descriptor.writable = true;
                    Object.defineProperty(target, descriptor.key, descriptor);
                }
            }
            return function(Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);
                if (staticProps) defineProperties(Constructor, staticProps);
                return Constructor;
            };
        }(); // eslint-disable-next-line


        var _promise = require('promise');

        var _promise2 = _interopRequireDefault(_promise);

        var _fn = require('../../fn');

        var _call = require('../call');

        var _util = require('./util');

        var _responseProcessor = require('./responseProcessor');

        var _responseProcessor2 = _interopRequireDefault(_responseProcessor);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function _toConsumableArray(arr) {
            if (Array.isArray(arr)) {
                for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            } else {
                return Array.from(arr);
            }
        }

        function _objectWithoutProperties(obj, keys) {
            var target = {};
            for (var i in obj) {
                if (keys.indexOf(i) >= 0) continue;
                if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
                target[i] = obj[i];
            }
            return target;
        }

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        var NO_REVIEWS_ERROR = 'No reviews available';

        /**
         * This class provides reviews on request of a consumer. It collects reviews
         * through paginated API calls, and then provides one page of reviews on request
         * from the consumer.
         *
         * Three methods are exposed as intended for use: {@link ReviewFetcher#consumeReviews},
         * {@link ReviewFetcher#produceReviews}, and {@link ReviewFetcher#hasMoreReviews}. Other
         * methods should be considered private.
         */

        var ReviewFetcher = function() {
            /**
             * Construct a ReviewFetcher.
             *
             * The constructor takes an object containing options and data required to
             * obtain and produce reviews for consumption.
             *
             * @param {Object} args - An object containing the arguments below.
             * @param {number} args.reviewsPerPage - The number of reviews to provide per
             * request.
             * @param {boolean} args.includeImportedReviews - Whether to include imported
             * reviews in the reviews provided.
             * @param {Object} args.baseData - The baseData response received from a base-data
             * call.
             * @param {...Object} args.wrapArgs - An arbitrary set of arguments to add to
             * the data provided to the callback in {@link ReviewFetcher#consumeReviews}.
             */
            function ReviewFetcher(_ref) {
                var reviewsPerPage = _ref.reviewsPerPage,
                    includeImportedReviews = _ref.includeImportedReviews,
                    baseData = _ref.baseData,
                    wrapArgs = _objectWithoutProperties(_ref, ['reviewsPerPage', 'includeImportedReviews', 'baseData']);

                _classCallCheck(this, ReviewFetcher);

                // Get next page links from a base data response.
                var getBaseDataNextPageLinks = (0, _util.getNextPageLinks)(function(responseKey) {
                    return (0, _fn.pipeMaybe)((0, _fn.prop)(responseKey), (0, _fn.prop)('links'), (0, _fn.prop)('nextPage'));
                });

                this.reviewsPerPage = reviewsPerPage;
                this.includeImportedReviews = includeImportedReviews;
                this.baseData = baseData;
                this.nextPage = getBaseDataNextPageLinks(baseData, includeImportedReviews);
                this.wrapArgs = wrapArgs;

                this.reviews = this._makeResponseProcessor(baseData).getReviews();
            }

            /**
             * Consume a number of reviews using a callback function.
             *
             * This method gets one page of reviews, and combines this with the data in
             * the wrapArgs field and passes it all to a callback. The return value is
             * wrapped in an anonymous function to make it suitable for use within event
             * handlers.
             *
             * @param {Function} callback - A function to call with a set of review data.
             */


            _createClass(ReviewFetcher, [{
                key: 'consumeReviews',
                value: function consumeReviews(callback) {
                    var _this = this;

                    return function() {
                        return _this.produceReviews().then(function(reviews) {
                            return callback(_extends({}, _this.wrapArgs, {
                                baseData: _this.baseData,
                                reviews: reviews,
                                hasMoreReviews: _this.hasMoreReviews,
                                loadMoreReviews: _this.consumeReviews.bind(_this)
                            }));
                        }).catch(function(err) {
                            if (err === NO_REVIEWS_ERROR) {
                                return callback(_extends({}, _this.wrapArgs, {
                                    baseData: _this.baseData,
                                    reviews: [],
                                    hasMoreReviews: false,
                                    loadMoreReviews: _this.consumeReviews.bind(_this)
                                }));
                            } else {
                                // Rethrow error which is unexpected
                                throw err;
                            }
                        });
                    };
                }

                /**
                 * Produce a number of reviews.
                 *
                 * This method produces one page of reviews. It may require to fetch additional
                 * reviews from an API if there are insufficent reviews available locally. The
                 * reviews are thus returned wrapped in a Promise.
                 */

            }, {
                key: 'produceReviews',
                value: function produceReviews() {
                    var _this2 = this;

                    var processResponse = function processResponse(response) {
                        var _reviews;

                        var responseProcessor = _this2._makeResponseProcessor(response);
                        _this2.nextPage = responseProcessor.getNextPageLinks();
                        (_reviews = _this2.reviews).push.apply(_reviews, _toConsumableArray(responseProcessor.getReviews()));
                        return _this2._takeReviews();
                    };

                    if (this.reviews.length === 0) {
                        // eslint-disable-next-line compat/compat
                        return _promise2.default.reject(NO_REVIEWS_ERROR);
                    }
                    return this.reviewsPerPage >= this.reviews.length ? this._fetchReviews().then(processResponse) : // eslint-disable-next-line compat/compat
                        _promise2.default.resolve(this._takeReviews());
                }

                /**
                 * Flag whether more reviews are available for consumption.
                 *
                 * Where true, this means it is possible to load more reviews. If false, no
                 * more reviews are available.
                 */

            }, {
                key: '_takeReviews',


                // Private Methods //

                /**
                 * Take a page of reviews from internal cache of reviews, removing these and
                 * returning them from the method.
                 */
                value: function _takeReviews() {
                    return this.reviews.splice(0, this.reviewsPerPage);
                }

                /**
                 * Fetch more reviews from the API.
                 */

            }, {
                key: '_fetchReviews',
                value: function _fetchReviews() {
                    return (0, _fn.promiseAllObject)((0, _fn.mapObject)(_call.apiCall, this.nextPage));
                }

                /**
                 * Construct a {@link ResponseProcessor} instance using properties from this instance.
                 */

            }, {
                key: '_makeResponseProcessor',
                value: function _makeResponseProcessor(response) {
                    return new _responseProcessor2.default(response, {
                        includeImportedReviews: this.includeImportedReviews,
                        displayName: this.baseData.businessEntity.displayName
                    });
                }
            }, {
                key: 'hasMoreReviews',
                get: function get() {
                    return this.reviews.length > 0;
                }
            }]);

            return ReviewFetcher;
        }();

        exports.default = ReviewFetcher;

    }, {
        "../../fn": 39,
        "../call": 29,
        "./responseProcessor": 34,
        "./util": 35,
        "promise": 65
    }],
    35: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.getNextPageLinks = undefined;

        var _fn = require('../../fn');

        /**
         * Get next page links from a response.
         *
         * This function take a getter function, used to extract a particular type of link,
         * either for productReviews or importedProductReviews. It returns a function which
         * take a response and a flag to indicate whether to include imported reviews. This
         * can then be called to obtain available next page links.
         */
        var getNextPageLinks = function getNextPageLinks(getter) {
            return function(response) {
                var includeImportedReviews = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

                var productReviews = getter('productReviews')(response);
                var importedProductReviews = (0, _fn.pipeMaybe)((0, _fn.guard)(includeImportedReviews), getter('importedProductReviews'))(response);
                return (0, _fn.rejectNullaryValues)({
                    productReviews: productReviews,
                    importedProductReviews: importedProductReviews
                });
            };
        };

        exports.getNextPageLinks = getNextPageLinks;

    }, {
        "../../fn": 39
    }],
    34: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _extends = Object.assign || function(target) {
            for (var i = 1; i < arguments.length; i++) {
                var source = arguments[i];
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
            return target;
        };

        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || false;
                    descriptor.configurable = true;
                    if ("value" in descriptor) descriptor.writable = true;
                    Object.defineProperty(target, descriptor.key, descriptor);
                }
            }
            return function(Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);
                if (staticProps) defineProperties(Constructor, staticProps);
                return Constructor;
            };
        }();

        var _fn = require('../../fn');

        var _util = require('./util');

        function _toConsumableArray(arr) {
            if (Array.isArray(arr)) {
                for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            } else {
                return Array.from(arr);
            }
        }

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        /**
         * This class processes an API response containing reviews and pagination
         * data.
         */
        var ReviewResponseProcessor = function() {
            /**
             * Create a ReviewResponseProcessor instance.
             *
             * Takes an API response object for processing, together with a short list
             * of options for processing and annotating reviews.
             */
            function ReviewResponseProcessor(response, _ref) {
                var includeImportedReviews = _ref.includeImportedReviews,
                    displayName = _ref.displayName;

                _classCallCheck(this, ReviewResponseProcessor);

                this.response = response;
                this.includeImportedReviews = includeImportedReviews;
                this.displayName = displayName;
            }

            /**
             * Get a combined list of reviews from the API response.
             *
             * This method extracts all reviews from the response, including optionally
             * imported reviews, and then combines and sorts these by date, descending.
             */


            _createClass(ReviewResponseProcessor, [{
                key: 'getReviews',
                value: function getReviews() {
                    var _this = this;

                    var _response = this.response,
                        productReviews = _response.productReviews,
                        importedProductReviews = _response.importedProductReviews;

                    var orderByCreatedAtDesc = function orderByCreatedAtDesc(_ref2, _ref3) {
                        var c1 = _ref2.createdAt;
                        var c2 = _ref3.createdAt;
                        return new Date(c2) - new Date(c1);
                    };
                    var productReviewsList = (0, _fn.pipeMaybe)((0, _fn.propMaybe)('productReviews'), (0, _fn.propMaybe)('reviews'))(productReviews) || [];

                    var importedReviewsList = (0, _fn.pipeMaybe)((0, _fn.guard)(this.includeImportedReviews), (0, _fn.propMaybe)('importedProductReviews'), (0, _fn.propMaybe)('productReviews'), (0, _fn.map)(function(review) {
                        return _extends({}, review, {
                            verifiedBy: review.type === 'External' ? !!review.source ? review.source.name : _this.displayName : _this.displayName
                        });
                    }))(importedProductReviews) || [];

                    return [].concat(_toConsumableArray(productReviewsList), _toConsumableArray(importedReviewsList)).sort(orderByCreatedAtDesc);
                }

                /**
                 * Get an object containing links to the next page URIs contained within the
                 * API response.
                 */

            }, {
                key: 'getNextPageLinks',
                value: function getNextPageLinks() {
                    // Get next page links from a pagination response.
                    var getOldPaginationNextPageLinks = (0, _util.getNextPageLinks)(function(responseKey) {
                        return (0, _fn.pipeMaybe)((0, _fn.prop)(responseKey), (0, _fn.prop)('links'), (0, _fn.find)(function(link) {
                            return link.rel === 'next-page';
                        }), (0, _fn.prop)('href'));
                    });

                    var getNewPaginationNextPageLinks = (0, _util.getNextPageLinks)(function(responseKey) {
                        return (0, _fn.pipeMaybe)((0, _fn.prop)(responseKey), (0, _fn.prop)(responseKey), (0, _fn.prop)('links'), (0, _fn.prop)('nextPage'));
                    });

                    var newLinks = getNewPaginationNextPageLinks(this.response, this.includeImportedReviews);
                    var oldLinks = getOldPaginationNextPageLinks(this.response, this.includeImportedReviews);

                    return _extends({}, oldLinks, newLinks);
                }
            }]);

            return ReviewResponseProcessor;
        }();

        exports.default = ReviewResponseProcessor;

    }, {
        "../../fn": 39,
        "./util": 35
    }],
    36: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.svgMap = undefined;

        var _utils = require('../utils');

        var svgScalingStyle = 'style="position: absolute; height: 100%; width: 100%; left: 0; top: 0;"';
        /* This module defines a number of SVG elements.
         *
         * IE11 does not properly display SVG tags, except using one of several hacks.
         * So, we use one below: we wrap each SVG in a div element, with particular
         * styling attached. We do this following Option 4 in the article at
         * https://css-tricks.com/scale-svg/.
         */

        var wrapSvg = function wrapSvg(dimensions, inner) {
            var props = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

            var sanitizedProps = Object.keys(props).reduce(function(acc, cur) {
                acc[cur] = (0, _utils.sanitizeHtml)(props[cur]);
                if (cur === 'color') {
                    acc[cur] = (0, _utils.sanitizeColor)(acc[cur]);
                }
                return acc;
            }, {});
            return '\n    <div style="position: relative; height: 0; width: 100%; padding: 0; padding-bottom: ' + dimensions.height / dimensions.width * 100 + '%;">\n      ' + inner(dimensions, sanitizedProps) + '\n    </div>\n  ';
        };

        var emptyStarColor = '#dcdce6';
        var _stars = function _stars(dimensions, _ref) {
            var rating = _ref.rating,
                trustScore = _ref.trustScore,
                color = _ref.color;
            return '\n  <svg role="img" aria-labelledby="starRating" viewBox="0 0 ' + dimensions.width + ' ' + dimensions.height + '" xmlns="http://www.w3.org/2000/svg" ' + svgScalingStyle + '>\n      <title id="starRating" lang="en">' + trustScore + ' out of five star rating on Trustpilot</title>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (rating >= 1 && color ? color : emptyStarColor) + '" d="M0 46.330002h46.375586V0H0z"/>\n          <path class="tp-star__shape" d="M39.533936 19.711433L13.230239 38.80065l3.838216-11.797827L7.02115 19.711433h12.418975l3.837417-11.798624 3.837418 11.798624h12.418975zM23.2785 31.510075l7.183595-1.509576 2.862114 8.800152L23.2785 31.510075z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (rating >= 2 && color ? color : emptyStarColor) + '" d="M51.24816 46.330002h46.375587V0H51.248161z"/>\n          <path class="tp-star__canvas--half" fill="' + (rating >= 1.5 && color ? color : emptyStarColor) + '" d="M51.24816 46.330002h23.187793V0H51.248161z"/>\n          <path class="tp-star__shape" d="M74.990978 31.32991L81.150908 30 84 39l-9.660206-7.202786L64.30279 39l3.895636-11.840666L58 19.841466h12.605577L74.499595 8l3.895637 11.841466H91L74.990978 31.329909z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (rating >= 3 && color ? color : emptyStarColor) + '" d="M102.532209 46.330002h46.375586V0h-46.375586z"/>\n          <path class="tp-star__canvas--half" fill="' + (rating >= 2.5 && color ? color : emptyStarColor) + '" d="M102.532209 46.330002h23.187793V0h-23.187793z"/>\n          <path class="tp-star__shape" d="M142.066994 19.711433L115.763298 38.80065l3.838215-11.797827-10.047304-7.291391h12.418975l3.837418-11.798624 3.837417 11.798624h12.418975zM125.81156 31.510075l7.183595-1.509576 2.862113 8.800152-10.045708-7.290576z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (rating >= 4 && color ? color : emptyStarColor) + '" d="M153.815458 46.330002h46.375586V0h-46.375586z"/>\n          <path class="tp-star__canvas--half" fill="' + (rating >= 3.5 && color ? color : emptyStarColor) + '" d="M153.815458 46.330002h23.187793V0h-23.187793z"/>\n          <path class="tp-star__shape" d="M193.348355 19.711433L167.045457 38.80065l3.837417-11.797827-10.047303-7.291391h12.418974l3.837418-11.798624 3.837418 11.798624h12.418974zM177.09292 31.510075l7.183595-1.509576 2.862114 8.800152-10.045709-7.290576z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (rating === 5 && color ? color : emptyStarColor) + '" d="M205.064416 46.330002h46.375587V0h-46.375587z"/>\n          <path class="tp-star__canvas--half" fill="' + (rating >= 4.5 && color ? color : emptyStarColor) + '" d="M205.064416 46.330002h23.187793V0h-23.187793z"/>\n          <path class="tp-star__shape" d="M244.597022 19.711433l-26.3029 19.089218 3.837419-11.797827-10.047304-7.291391h12.418974l3.837418-11.798624 3.837418 11.798624h12.418975zm-16.255436 11.798642l7.183595-1.509576 2.862114 8.800152-10.045709-7.290576z" fill="#FFF"/>\n      </g>\n  </svg>';
        };

        var _logo = function _logo(dimensions) {
            return '\n  <svg role="img" aria-labelledby="trustpilotLogo" viewBox="0 0 ' + dimensions.width + ' ' + dimensions.height + '" xmlns="http://www.w3.org/2000/svg" ' + svgScalingStyle + '>\n      <title id="trustpilotLogo">Trustpilot</title>\n      <path class="tp-logo__text" d="M33.074774 11.07005H45.81806v2.364196h-5.010656v13.290316h-2.755306V13.434246h-4.988435V11.07005h.01111zm12.198892 4.319629h2.355341v2.187433h.04444c.077771-.309334.222203-.60762.433295-.894859.211092-.287239.466624-.56343.766597-.79543.299972-.243048.633276-.430858.999909-.585525.366633-.14362.744377-.220953 1.12212-.220953.288863 0 .499955.011047.611056.022095.1111.011048.222202.033143.344413.04419v2.408387c-.177762-.033143-.355523-.055238-.544395-.077333-.188872-.022096-.366633-.033143-.544395-.033143-.422184 0-.822148.08838-1.199891.254096-.377744.165714-.699936.41981-.977689.740192-.277753.331429-.499955.729144-.666606 1.21524-.166652.486097-.244422 1.03848-.244422 1.668195v5.39125h-2.510883V15.38968h.01111zm18.220567 11.334883H61.02779v-1.579813h-.04444c-.311083.574477-.766597 1.02743-1.377653 1.369908-.611055.342477-1.233221.51924-1.866497.51924-1.499864 0-2.588654-.364573-3.25526-1.104765-.666606-.740193-.999909-1.856005-.999909-3.347437V15.38968h2.510883v6.948968c0 .994288.188872 1.701337.577725 2.1101.377744.408763.922139.618668 1.610965.618668.533285 0 .96658-.077333 1.322102-.243048.355524-.165714.644386-.37562.855478-.65181.222202-.265144.377744-.596574.477735-.972194.09999-.37562.144431-.784382.144431-1.226288v-6.573349h2.510883v11.323836zm4.27739-3.634675c.07777.729144.355522 1.237336.833257 1.535623.488844.287238 1.06657.441905 1.744286.441905.233312 0 .499954-.022095.799927-.055238.299973-.033143.588836-.110476.844368-.209905.266642-.099429.477734-.254096.655496-.452954.166652-.198857.244422-.452953.233312-.773335-.01111-.320381-.133321-.585525-.355523-.784382-.222202-.209906-.499955-.364573-.844368-.497144-.344413-.121525-.733267-.232-1.17767-.320382-.444405-.088381-.888809-.18781-1.344323-.287239-.466624-.099429-.922138-.232-1.355432-.37562-.433294-.14362-.822148-.342477-1.166561-.596573-.344413-.243048-.622166-.56343-.822148-.950097-.211092-.386668-.311083-.861716-.311083-1.436194 0-.618668.155542-1.12686.455515-1.54667.299972-.41981.688826-.75124 1.14434-1.005336.466624-.254095.97769-.430858 1.544304-.541334.566615-.099429 1.11101-.154667 1.622075-.154667.588836 0 1.15545.066286 1.688736.18781.533285.121524 1.02213.320381 1.455423.60762.433294.276191.788817.640764 1.07768 1.08267.288863.441905.466624.98324.544395 1.612955h-2.621984c-.122211-.596572-.388854-1.005335-.822148-1.204193-.433294-.209905-.933248-.309334-1.488753-.309334-.177762 0-.388854.011048-.633276.04419-.244422.033144-.466624.088382-.688826.165715-.211092.077334-.388854.198858-.544395.353525-.144432.154667-.222203.353525-.222203.60762 0 .309335.111101.552383.322193.740193.211092.18781.488845.342477.833258.475048.344413.121524.733267.232 1.177671.320382.444404.088381.899918.18781 1.366542.287239.455515.099429.899919.232 1.344323.37562.444404.14362.833257.342477 1.17767.596573.344414.254095.622166.56343.833258.93905.211092.37562.322193.850668.322193 1.40305 0 .673906-.155541 1.237336-.466624 1.712385-.311083.464001-.711047.850669-1.199891 1.137907-.488845.28724-1.04435.508192-1.644295.640764-.599946.132572-1.199891.198857-1.788727.198857-.722156 0-1.388762-.077333-1.999818-.243048-.611056-.165714-1.14434-.408763-1.588745-.729144-.444404-.33143-.799927-.740192-1.05546-1.226289-.255532-.486096-.388853-1.071621-.411073-1.745528h2.533103v-.022095zm8.288135-7.700208h1.899828v-3.402675h2.510883v3.402675h2.26646v1.867052h-2.26646v6.054109c0 .265143.01111.486096.03333.684954.02222.18781.07777.353524.155542.486096.07777.132572.199981.232.366633.298287.166651.066285.377743.099428.666606.099428.177762 0 .355523 0 .533285-.011047.177762-.011048.355523-.033143.533285-.077334v1.933338c-.277753.033143-.555505.055238-.811038.088381-.266642.033143-.533285.04419-.811037.04419-.666606 0-1.199891-.066285-1.599855-.18781-.399963-.121523-.722156-.309333-.944358-.552381-.233313-.243049-.377744-.541335-.466625-.905907-.07777-.364573-.13332-.784383-.144431-1.248384v-6.683825h-1.899827v-1.889147h-.02222zm8.454788 0h2.377562V16.9253h.04444c.355523-.662858.844368-1.12686 1.477644-1.414098.633276-.287239 1.310992-.430858 2.055369-.430858.899918 0 1.677625.154667 2.344231.475048.666606.309335 1.222111.740193 1.666515 1.292575.444405.552382.766597 1.193145.9888 1.92229.222202.729145.333303 1.513527.333303 2.3421 0 .762288-.099991 1.50248-.299973 2.20953-.199982.718096-.499955 1.347812-.899918 1.900194-.399964.552383-.911029.98324-1.533194 1.31467-.622166.33143-1.344323.497144-2.18869.497144-.366634 0-.733267-.033143-1.0999-.099429-.366634-.066286-.722157-.176762-1.05546-.320381-.333303-.14362-.655496-.33143-.933249-.56343-.288863-.232-.522175-.497144-.722157-.79543h-.04444v5.656393h-2.510883V15.38968zm8.77698 5.67849c0-.508193-.06666-1.005337-.199981-1.491433-.133321-.486096-.333303-.905907-.599946-1.281527-.266642-.37562-.599945-.673906-.988799-.894859-.399963-.220953-.855478-.342477-1.366542-.342477-1.05546 0-1.855387.364572-2.388672 1.093717-.533285.729144-.799928 1.701337-.799928 2.916578 0 .574478.066661 1.104764.211092 1.59086.144432.486097.344414.905908.633276 1.259432.277753.353525.611056.629716.99991.828574.388853.209905.844367.309334 1.355432.309334.577725 0 1.05546-.121524 1.455423-.353525.399964-.232.722157-.541335.97769-.905907.255531-.37562.444403-.79543.555504-1.270479.099991-.475049.155542-.961145.155542-1.458289zm4.432931-9.99812h2.510883v2.364197h-2.510883V11.07005zm0 4.31963h2.510883v11.334883h-2.510883V15.389679zm4.755124-4.31963h2.510883v15.654513h-2.510883V11.07005zm10.210184 15.963847c-.911029 0-1.722066-.154667-2.433113-.452953-.711046-.298287-1.310992-.718097-1.810946-1.237337-.488845-.530287-.866588-1.160002-1.12212-1.889147-.255533-.729144-.388854-1.535622-.388854-2.408386 0-.861716.133321-1.657147.388853-2.386291.255533-.729145.633276-1.35886 1.12212-1.889148.488845-.530287 1.0999-.93905 1.810947-1.237336.711047-.298286 1.522084-.452953 2.433113-.452953.911028 0 1.722066.154667 2.433112.452953.711047.298287 1.310992.718097 1.810947 1.237336.488844.530287.866588 1.160003 1.12212 1.889148.255532.729144.388854 1.524575.388854 2.38629 0 .872765-.133322 1.679243-.388854 2.408387-.255532.729145-.633276 1.35886-1.12212 1.889147-.488845.530287-1.0999.93905-1.810947 1.237337-.711046.298286-1.522084.452953-2.433112.452953zm0-1.977528c.555505 0 1.04435-.121524 1.455423-.353525.411074-.232.744377-.541335 1.01102-.916954.266642-.37562.455513-.806478.588835-1.281527.12221-.475049.188872-.961145.188872-1.45829 0-.486096-.066661-.961144-.188872-1.44724-.122211-.486097-.322193-.905907-.588836-1.281527-.266642-.37562-.599945-.673907-1.011019-.905907-.411074-.232-.899918-.353525-1.455423-.353525-.555505 0-1.04435.121524-1.455424.353525-.411073.232-.744376.541334-1.011019.905907-.266642.37562-.455514.79543-.588835 1.281526-.122211.486097-.188872.961145-.188872 1.447242 0 .497144.06666.98324.188872 1.458289.12221.475049.322193.905907.588835 1.281527.266643.37562.599946.684954 1.01102.916954.411073.243048.899918.353525 1.455423.353525zm6.4883-9.66669h1.899827v-3.402674h2.510883v3.402675h2.26646v1.867052h-2.26646v6.054109c0 .265143.01111.486096.03333.684954.02222.18781.07777.353524.155541.486096.077771.132572.199982.232.366634.298287.166651.066285.377743.099428.666606.099428.177762 0 .355523 0 .533285-.011047.177762-.011048.355523-.033143.533285-.077334v1.933338c-.277753.033143-.555505.055238-.811038.088381-.266642.033143-.533285.04419-.811037.04419-.666606 0-1.199891-.066285-1.599855-.18781-.399963-.121523-.722156-.309333-.944358-.552381-.233313-.243049-.377744-.541335-.466625-.905907-.07777-.364573-.133321-.784383-.144431-1.248384v-6.683825h-1.899827v-1.889147h-.02222z" fill="#191919"/>\n      <path class="tp-logo__star" fill="#00B67A" d="M30.141707 11.07005H18.63164L15.076408.177071l-3.566342 10.892977L0 11.059002l9.321376 6.739063-3.566343 10.88193 9.321375-6.728016 9.310266 6.728016-3.555233-10.88193 9.310266-6.728016z"/>\n      <path class="tp-logo__star-notch" fill="#005128" d="M21.631369 20.26169l-.799928-2.463625-5.755033 4.153914z"/>\n  </svg>';
        };

        var _arrowSlider = function _arrowSlider(dimensions) {
            return '\n  <svg viewBox="0 0 ' + dimensions.width + ' ' + dimensions.height + '" xmlns="http://www.w3.org/2000/svg" ' + svgScalingStyle + '>\n      <circle class="arrow-slider-circle" cx="12" cy="12" r="11.5" fill="none" stroke="#8C8C8C"/>\n      <path class="arrow-slider-shape" fill="#8C8C8C" d="M10.5088835 12l3.3080582-3.02451041c.2440777-.22315674.2440777-.5849653 0-.80812204-.2440776-.22315673-.6398058-.22315673-.8838834 0L9.18305826 11.595939c-.24407768.2231567-.24407768.5849653 0 .808122l3.75000004 3.4285714c.2440776.2231568.6398058.2231568.8838834 0 .2440777-.2231567.2440777-.5849653 0-.808122L10.5088835 12z"/>\n  </svg>\n';
        };

        var _replyArrow = function _replyArrow(dimensions, _ref2) {
            var elementColor = _ref2.elementColor;
            return '\n<svg viewBox="0 0 ' + dimensions.width + ' ' + dimensions.height + '" xmlns=\u201Chttp://www.w3.org/2000/svg\u201C ' + svgScalingStyle + '>\n  <path d="M5.24040526 8.60770645c0 .40275007-.25576387.51300008-.57003092.24825004L.2361338 4.98520583C.0871841 4.86986375 0 4.69208677 0 4.50370575s.0871841-.366158.2361338-.48150008L4.67037434.14470501c.31501709-.26625004.57003092-.15450003.57003092.24825004V2.9992055h.75004069c2.86515541 0 5.31553833 2.3745004 5.91257072 4.93950083a4.3385348 4.3385348 0 0 1 .09375508.5782501c.02250123.20025004-.07500406.24450004-.21826184.10350002 0 0-.0405022-.036-.07500406-.07500001C10.18673699 7.00766398 8.14655579 6.09727666 5.98894586 5.995456h-.75004068l.00150008 2.61225045z" fill="' + (elementColor || '#00B67A') + '" fill-rule="evenodd"/>\n</svg>\n';
        };
        /* eslint-enable max-len */

        // Define a series of objects containing width and height values. These are
        // used in setting the styling of the SVG, and creating the div wrapper for
        // IE11 support.
        var starsDimensions = {
            width: 251,
            height: 46
        };
        var logoDimensions = {
            width: 126,
            height: 31
        };
        var arrowSliderDimensions = {
            width: 24,
            height: 24
        };
        var replyArrowDimensions = {
            width: 12,
            height: 9
        };

        var svgMap = {
            stars: function stars(props) {
                return wrapSvg(starsDimensions, _stars, props);
            },
            logo: function logo() {
                return wrapSvg(logoDimensions, _logo);
            },
            arrowSlider: function arrowSlider() {
                return wrapSvg(arrowSliderDimensions, _arrowSlider);
            },
            replyArrow: function replyArrow(props) {
                return wrapSvg(replyArrowDimensions, _replyArrow, props);
            }
        };

        exports.svgMap = svgMap;

    }, {
        "../utils": 61
    }],
    60: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.getFrameworkTranslation = exports.formatLocale = exports.defaultLocale = undefined;

        var _localization = require('../localization');

        var _localization2 = _interopRequireDefault(_localization);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        var defaultLocale = 'en-US';

        var LOCALE_DIVIDER = '-';

        var languageToCountryMap = {
            'da': 'DK',
            'en': 'US',
            'ja': 'JP',
            'nb': 'NO',
            'sv': 'SE'
            // other languages assumed to have the same country code as the language code itself
        };

        /**
         * Tries to find the country for the given language.
         * If no country is found, the language itself is returned.
         * Acts as a safety mechanism for translations when only the language part is present in the given locale.
         *
         * @param {string} language the language for which the country should be found.
         */
        var tryGetCountryForLanguage = function tryGetCountryForLanguage(language) {
            var country = languageToCountryMap[language] || language;
            return country;
        };

        var formatLocale = function formatLocale(locale) {
            var localeParts = locale.split(LOCALE_DIVIDER);
            var language = localeParts[0];
            var country = localeParts[1];

            if (!country) {
                country = tryGetCountryForLanguage(language);
            }

            return language && country ? '' + language + LOCALE_DIVIDER + country.toUpperCase() : defaultLocale;
        };

        var getFrameworkTranslation = function getFrameworkTranslation(key) {
            var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultLocale;
            var interpolations = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

            var translationTable = _localization2.default[formatLocale(locale)] || _localization2.default[defaultLocale];
            var rawTranslation = key.split('.').reduce(function(a, b) {
                return a[b];
            }, translationTable);
            var translation = Object.keys(interpolations).reduce(function(value, key) {
                return value.replace(key, interpolations[key]);
            }, rawTranslation);

            return translation;
        };

        exports.defaultLocale = defaultLocale;
        exports.formatLocale = formatLocale;
        exports.getFrameworkTranslation = getFrameworkTranslation;

    }, {
        "../localization": 17
    }],
    45: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || false;
                    descriptor.configurable = true;
                    if ("value" in descriptor) descriptor.writable = true;
                    Object.defineProperty(target, descriptor.key, descriptor);
                }
            }
            return function(Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);
                if (staticProps) defineProperties(Constructor, staticProps);
                return Constructor;
            };
        }();

        var _utils = require('../utils');

        var _dom = require('../dom');

        var _controls = require('./controls');

        var _controls2 = _interopRequireDefault(_controls);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        function _possibleConstructorReturn(self, call) {
            if (!self) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return call && (typeof call === "object" || typeof call === "function") ? call : self;
        }

        function _inherits(subClass, superClass) {
            if (typeof superClass !== "function" && superClass !== null) {
                throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
            }
            subClass.prototype = Object.create(superClass && superClass.prototype, {
                constructor: {
                    value: subClass,
                    enumerable: false,
                    writable: true,
                    configurable: true
                }
            });
            if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
        }

        /**
         * The ArrowControls class provides logic for controlling a sliding review
         * carousel with previous/next page buttons.
         *
         * To use ArrowControls, construct an instance of it and then call
         * {@link ArrowControls#initialize}.
         */
        var ArrowControls = function(_Controls) {
            _inherits(ArrowControls, _Controls);

            /**
             * Create an ArrowControls instance.
             *
             * @param {ReviewSlider} slider - The ReviewSlider to which to attach controls.
             * @param {Object} elements - DOM elements for the controls.
             * @param {HTMLElement} elements.prevArrow - The previous arrow element.
             * @param {HTMLElement} elements.nextArrow - The next arrow element.
             * @param {Object} [options={}] - Options for the controls.
             * @param {Object} [options.callbacks] - Callbacks to trigger after clicking a control.
             * @param {callback} [options.callbacks.prevPage] - Callback to trigger on clicking
             * the previous arrow.
             * @param {callback} [options.callbacks.nextPage] - Callback to trigger on clicking
             * the next arrow.
             * @param {string} [options.disabledClass] - The class to set on disabled controls.
             */
            function ArrowControls(slider, elements) {
                var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

                _classCallCheck(this, ArrowControls);

                var _this = _possibleConstructorReturn(this, (ArrowControls.__proto__ || Object.getPrototypeOf(ArrowControls)).call(this, slider, elements));

                _this.callbacks = options.callbacks || {};
                _this.disabledClass = options.disabledClass;
                return _this;
            }

            _createClass(ArrowControls, [{
                key: 'attachListeners',
                value: function attachListeners() {
                    var _this2 = this;

                    var noOp = function noOp() {};
                    var _elements = this.elements,
                        prevArrow = _elements.prevArrow,
                        nextArrow = _elements.nextArrow;
                    var _callbacks = this.callbacks,
                        _callbacks$prevPage = _callbacks.prevPage,
                        prevPage = _callbacks$prevPage === undefined ? noOp : _callbacks$prevPage,
                        _callbacks$nextPage = _callbacks.nextPage,
                        nextPage = _callbacks$nextPage === undefined ? noOp : _callbacks$nextPage;

                    (0, _utils.addEventListener)(prevArrow, 'click', function() {
                        _this2.slider.moveContent(-1);
                        prevPage();
                    });
                    (0, _utils.addEventListener)(nextArrow, 'click', function() {
                        _this2.slider.moveContent(1);
                        nextPage();
                    });
                }
            }, {
                key: 'styleArrow',
                value: function styleArrow(elem, isDisabled) {
                    var disabledClass = this.disabledClass;
                    if (isDisabled) {
                        (0, _dom.addClass)(elem, disabledClass);
                    } else {
                        (0, _dom.removeClass)(elem, disabledClass);
                    }
                }
            }, {
                key: 'styleArrows',
                value: function styleArrows() {
                    var _elements2 = this.elements,
                        prevArrow = _elements2.prevArrow,
                        nextArrow = _elements2.nextArrow;

                    this.styleArrow(prevArrow, this.slider.isAtFirstPage());
                    this.styleArrow(nextArrow, this.slider.isAtLastPage());
                }
            }, {
                key: 'onUpdate',
                value: function onUpdate() {
                    this.styleArrows();
                }
            }]);

            return ArrowControls;
        }(_controls2.default);

        exports.default = ArrowControls;

    }, {
        "../dom": 38,
        "../utils": 61,
        "./controls": 46
    }],
    46: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || false;
                    descriptor.configurable = true;
                    if ("value" in descriptor) descriptor.writable = true;
                    Object.defineProperty(target, descriptor.key, descriptor);
                }
            }
            return function(Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);
                if (staticProps) defineProperties(Constructor, staticProps);
                return Constructor;
            };
        }();

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        /**
         * The Controls class is an abstract base class for concrete controls to use.
         *
         * A number of required methods are defined, together with a default
         * implementaton of the {@link Controls#initialize} method. These required methods
         * are used to update the controls on a change taking place within the slider,
         * and must be implemented. By default, the page change and resize events are
         * both handled by the {@link Controls#onUpdate} method.
         */
        var Controls = function() {
            /**
             * Create a Controls instance.
             *
             * @param {ReviewSlider} slider - The ReviewSlider to which to attach controls.
             * @param {Object|Array} elements - DOM elements for the controls.
             */
            function Controls(slider, elements) {
                _classCallCheck(this, Controls);

                this.slider = slider;
                this.elements = elements;
            }

            /**
             * Initialize this Controls instance.
             *
             * This method attaches listener callbacks to the control elements and
             * attaches the controls themselves to the slider and initializes that.
             */


            _createClass(Controls, [{
                key: 'initialize',
                value: function initialize() {
                    this.attachListeners();
                    this.slider.attachObserver(this);
                    this.slider.initialize();
                    this.onUpdate();
                }

                /**
                 * Intended to be used to attach callbacks to events on the associated control
                 * elements.
                 */

            }, {
                key: 'attachListeners',
                value: function attachListeners() {
                    throw new Error('attachListeners method not yet implemented');
                }

                /**
                 * Called upon initialization, and where a page change or resize event occurs
                 * in the slider.
                 */

            }, {
                key: 'onUpdate',
                value: function onUpdate() {
                    throw new Error('onUpdate method not yet implemented');
                }

                /**
                 * Called by the associated slider when it encounters a page change event.
                 */

            }, {
                key: 'onPageChange',
                value: function onPageChange() {
                    this.onUpdate();
                }

                /**
                 * Called by the associated slider when it encounters a resize event.
                 */

            }, {
                key: 'onResize',
                value: function onResize() {
                    this.onUpdate();
                }
            }]);

            return Controls;
        }();

        exports.default = Controls;

    }, {}],
    48: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || false;
                    descriptor.configurable = true;
                    if ("value" in descriptor) descriptor.writable = true;
                    Object.defineProperty(target, descriptor.key, descriptor);
                }
            }
            return function(Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);
                if (staticProps) defineProperties(Constructor, staticProps);
                return Constructor;
            };
        }();

        var _utils = require('../utils');

        var _dom = require('../dom');

        var _controls = require('./controls');

        var _controls2 = _interopRequireDefault(_controls);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        function _possibleConstructorReturn(self, call) {
            if (!self) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return call && (typeof call === "object" || typeof call === "function") ? call : self;
        }

        function _inherits(subClass, superClass) {
            if (typeof superClass !== "function" && superClass !== null) {
                throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
            }
            subClass.prototype = Object.create(superClass && superClass.prototype, {
                constructor: {
                    value: subClass,
                    enumerable: false,
                    writable: true,
                    configurable: true
                }
            });
            if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
        }

        /**
         * The PaginationControls class provides logic for controlling a sliding review
         * carousel with page selection buttons.
         *
         * To use PaginationControls, construct an instance of it and then call
         * {@link PaginationControls#initialize}.
         */
        var PaginationControls = function(_Controls) {
            _inherits(PaginationControls, _Controls);

            /**
             * Create an PaginationControls instance.
             *
             * An array of elements is required, with element x triggering a page change
             * to page x+1. An array of callbacks is optional, each of which correspond
             * to an element on the page, i.e. callback x is trigger by clicking element
             * x.
             *
             * @param {ReviewSlider} slider - The ReviewSlider to which to attach controls.
             * @param {Object[]} elements - DOM elements for the controls.
             * @param {Object} [options={}] - Options for the controls.
             * @param {Array} [options.callbacks] - Callbacks to trigger after clicking a control.
             * @param {string} [options.activeClass] - The class to set on the active control.
             */
            function PaginationControls(slider, elements) {
                var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

                _classCallCheck(this, PaginationControls);

                var _this = _possibleConstructorReturn(this, (PaginationControls.__proto__ || Object.getPrototypeOf(PaginationControls)).call(this, slider, elements));

                _this.callbacks = options.callbacks || [];
                _this.activeClass = options.activeClass;
                return _this;
            }

            _createClass(PaginationControls, [{
                key: 'attachListeners',
                value: function attachListeners() {
                    var _this2 = this;

                    var pagination = this.elements;
                    var noOp = function noOp() {};
                    pagination.forEach(function(elem, index) {
                        if (index === 0) {
                            (0, _dom.addClass)(elem, _this2.activeClass);
                        }
                        (0, _utils.addEventListener)(elem, 'click', function() {
                            _this2.slider.jumpToPage(index + 1);
                            var callback = _this2.callbacks[index] || noOp;
                            callback();
                        });
                    });
                }
            }, {
                key: 'onUpdate',
                value: function onUpdate() {
                    var _this3 = this;

                    var pagination = this.elements;
                    pagination.forEach(function(elem, index) {
                        var isActive = _this3.slider.currentPage === index + 1;
                        if (isActive) {
                            (0, _dom.addClass)(elem, _this3.activeClass);
                        } else {
                            (0, _dom.removeClass)(elem, _this3.activeClass);
                        }
                    });
                }
            }]);

            return PaginationControls;
        }(_controls2.default);

        exports.default = PaginationControls;

    }, {
        "../dom": 38,
        "../utils": 61,
        "./controls": 46
    }],
    49: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || false;
                    descriptor.configurable = true;
                    if ("value" in descriptor) descriptor.writable = true;
                    Object.defineProperty(target, descriptor.key, descriptor);
                }
            }
            return function(Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);
                if (staticProps) defineProperties(Constructor, staticProps);
                return Constructor;
            };
        }();

        var _utils = require('../utils');

        var _touch = require('../touch');

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        var clamp = function clamp(val, min, max) {
            return Math.max(Math.min(val, max), min);
        };
        /**
         * The ReviewSlider class provides logic for handling sliding review carousel
         * elements.
         *
         * A review carousel is a series of HTML elements used to contain and display
         * reviews within a TrustBox. A ReviewSlider instance expects certain HTML
         * elements within the DOM: a "slider" element; a container element for the
         * slider; and a list of review elements. (See {@link ReviewSlider#constructor}
         * on how these elements are provided to the ReviewSlider.)
         *
         * To use a ReviewSlider, first construct an instance of it. Then, if controls
         * are required, construct an instance of one of the controls classes (see
         * {@link ArrowControls} and {@link PaginationControls}) and following their
         * instructions for initialization. If controls are not required, simply call
         * {@link ReviewSlider#initialize}.
         */

        var ReviewSlider = function() {
            /**
             * Create a ReviewSlider instance.
             *
             * @param {Object[]} reviews - Reviews to be displayed in the slider.
             * @param {Object} elements - DOM elements for the slider.
             * @param {HTMLElement} elements.slider - The slider element.
             * @param {HTMLElement} elements.sliderContainer - The container for the slider.
             * @param {Callback} template - function which generates HTML for a review.
             * @param {Object} [options={}] - Options for the slider.
             * @param {string} [options.reviewClass] - The class name for a review element.
             * @param {string} [options.transitionClass] - The class name for elements
             * with a sliding animation/transition.
             * @param {int|Object[]} [options.reviewsPerPage] - Either the number of
             * reviews to display per page, or a list of objects containing breakpoints
             * with associated review counts (see {@link ReviewSlider#setReviewsPerPage}).
             */
            function ReviewSlider(reviews, elements, template) {
                var _this = this;

                var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

                _classCallCheck(this, ReviewSlider);

                this.reviews = reviews;
                this.elements = elements;
                this.reviewCount = reviews.length;
                this.template = template;
                this.reviewClass = options.reviewClass;
                this.setReviewsPerPage(options.reviewsPerPage);
                this.currentPage = 1;
                this.resizeTimeout = null;
                this.observers = [];
                this.isInitialized = false;

                // Touch callbacks

                this.touchStartCallback = function(_ref) {
                    var translateX = _ref.translateX,
                        originPage = _ref.originPage;

                    _this.setSliderTransitionDuration(0);
                    _this.setSliderTranslateX(translateX);
                    _this.currentPage = originPage;
                };
                this.touchMoveCallback = function(_ref2) {
                    var translateX = _ref2.translateX;

                    _this.setSliderTranslateX(translateX);
                };
                this.touchEndCallback = function(_ref3) {
                    var pagesToSwipe = _ref3.pagesToSwipe,
                        transitionDuration = _ref3.transitionDuration;

                    _this.moveContent(pagesToSwipe, clamp(transitionDuration, 0.2, 1));
                };
            }

            /**
             * Set the reviewsPerPage property.
             *
             * @param {int|Object[]} reviewsPerPage - Either the number of reviews to
             * display per page, or a list of objects containing breakpoints with
             * associated review counts. In the case of the latter, each object must
             * contain a minWidth and a reviewsForWidth property. The number of reviews
             * displayed is equal to the reviewsForWidth value associated with the largest
             * minimum width value less than the width of the sliderContainer.
             */


            _createClass(ReviewSlider, [{
                key: 'setReviewsPerPage',
                value: function setReviewsPerPage(reviewsPerPage) {
                    if (typeof reviewsPerPage === 'number') {
                        this.reviewsPerPage = [{
                            minWidth: 0,
                            reviewsForWidth: reviewsPerPage
                        }];
                    } else {
                        this.reviewsPerPage = reviewsPerPage;
                        this.reviewsPerPage.sort(function(_ref4, _ref5) {
                            var a = _ref4.minWidth;
                            var b = _ref5.minWidth;
                            return b - a;
                        });
                    }
                }

                /**
                 * Populate the slider with reviews using the template.
                 */

            }, {
                key: 'populateSlider',
                value: function populateSlider() {
                    this.elements.slider.innerHTML = this.reviews.map(this.template.bind(this)).join('');
                }

                /**
                 * Initialize this ReviewSlider instance.
                 *
                 * This method attaches this instance to the slider and window. It attaches
                 * a touch handler to the slider and ensures the resize events are listened
                 * to.
                 */

            }, {
                key: 'initialize',
                value: function initialize() {
                    if (this.isInitialized) {
                        return;
                    }

                    this.populateSlider();
                    this.calculateReviewsPerPage();

                    this.touch = new _touch.TrustBoxesTouch({
                        targetElement: this.elements.slider,
                        pageWidth: this.sliderContainerWidth,
                        touchStartCallback: this.touchStartCallback,
                        touchMoveCallback: this.touchMoveCallback,
                        touchEndCallback: this.touchEndCallback
                    });

                    this.touch.attach();
                    this.windowResize();
                    this.attachResizeListener();

                    this.isInitialized = true;
                }

                // Getters & properties //

            }, {
                key: 'getFirstVisibleReviewIndex',
                value: function getFirstVisibleReviewIndex() {
                    return this._reviewsPerPage * (this.currentPage - 1);
                }
            }, {
                key: 'isAtFirstPage',
                value: function isAtFirstPage() {
                    return this.currentPage === 1;
                }
            }, {
                key: 'isAtLastPage',
                value: function isAtLastPage() {
                    return this.currentPage === this.totalPages;
                }
            }, {
                key: 'setSliderTranslateX',
                value: function setSliderTranslateX(pixels) {
                    this.elements.slider.style.transform = 'translateX(' + pixels + 'px)';
                }
            }, {
                key: 'setSliderTransitionDuration',
                value: function setSliderTransitionDuration(seconds) {
                    this.elements.slider.style.transitionDuration = seconds + 's';
                }

                // Review calculations //

            }, {
                key: 'reviewElementMargins',
                value: function reviewElementMargins() {
                    if (this.reviewElements.length === 0 || !this.reviewElements[0]) {
                        return {
                            left: 0,
                            right: 0
                        };
                    } else {
                        var computedStyle = window.getComputedStyle(this.reviewElements[0]);
                        return {
                            left: parseInt(computedStyle.marginLeft),
                            right: parseInt(computedStyle.marginRight)
                        };
                    }
                }
            }, {
                key: 'calculateReviewsPerPage',
                value: function calculateReviewsPerPage() {
                    var currentBreakpoint = this.reviewsPerPage.reduce(function(reviewCount, _ref6) {
                        var minWidth = _ref6.minWidth,
                            reviewsForWidth = _ref6.reviewsForWidth;
                        return !reviewCount && document.documentElement.clientWidth >= minWidth ? {
                            minWidth: minWidth,
                            reviewsForWidth: reviewsForWidth
                        } : reviewCount;
                    }, null);
                    this._reviewsPerPage = currentBreakpoint.reviewsForWidth;
                    this._defaultSliderWidth = currentBreakpoint.minWidth;
                }

                // Observer methods //

            }, {
                key: 'attachObserver',
                value: function attachObserver(observer) {
                    this.observers.push(observer);
                }
            }, {
                key: 'detachObserver',
                value: function detachObserver(observer) {
                    this.observers = this.observers.filter(function(obs) {
                        return obs !== observer;
                    });
                }

                // Window resize methods //

            }, {
                key: 'attachResizeListener',
                value: function attachResizeListener() {
                    var _this2 = this;

                    (0, _utils.addEventListener)(window, 'resize', function() {
                        if (_this2.resizeTimeout !== null) {
                            window.clearTimeout(_this2.resizeTimeout);
                        }
                        _this2.resizeTimeout = window.setTimeout(function() {
                            _this2.windowResize();
                        }, 200);
                    });
                }
            }, {
                key: 'windowResize',
                value: function windowResize() {
                    var _this3 = this;

                    this.setPageOnResize();
                    this.elements.slider.style.width = this.reviewCount * this.reviewWidthWithMargins + 'px';
                    this.reviewElements.forEach(function(elem) {
                        elem.style.width = _this3.reviewWidth + 'px';
                    });
                    this.observers.forEach(function(observer) {
                        return observer.onResize();
                    });
                }
            }, {
                key: 'setPageOnResize',
                value: function setPageOnResize() {
                    var preResize = {
                        page: this.currentPage,
                        focusedReviewIndex: this._reviewsPerPage * (this.currentPage - 1)
                    };
                    this.calculateReviewsPerPage();
                    var newPage = Math.floor(preResize.focusedReviewIndex / this._reviewsPerPage) + 1;
                    this.jumpToPage(newPage, 0);
                    this.touch.setPageWidth(this.sliderContainerWidth);
                }

                // Pagination methods //

            }, {
                key: 'moveContent',
                value: function moveContent(numPages) {
                    var transitionDuration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

                    var pageNumber = clamp(numPages + this.currentPage, 1, this.totalPages);
                    this.jumpToPage(pageNumber, transitionDuration);
                }
            }, {
                key: 'pageOffset',
                value: function pageOffset(pageNumber) {
                    return this.sliderContainerWidth * (pageNumber - 1) * -1;
                }
            }, {
                key: 'jumpToPage',
                value: function jumpToPage(pageNumber) {
                    var transitionDuration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

                    var offset = this.pageOffset(pageNumber);
                    this.setSliderTranslateX(offset);
                    this.setSliderTransitionDuration(transitionDuration);
                    this.currentPage = pageNumber;
                    this.observers.forEach(function(observer) {
                        return observer.onPageChange();
                    });
                }
            }, {
                key: 'totalPages',
                get: function get() {
                    return Math.ceil(this.reviewCount / this._reviewsPerPage);
                }
            }, {
                key: 'reviewWidth',
                get: function get() {
                    var _reviewElementMargins = this.reviewElementMargins(),
                        left = _reviewElementMargins.left,
                        right = _reviewElementMargins.right;

                    return this.reviewWidthWithMargins - (left + right);
                }
            }, {
                key: 'reviewWidthWithMargins',
                get: function get() {
                    return this.sliderContainerWidth / this._reviewsPerPage;
                }
            }, {
                key: 'sliderContainerWidth',
                get: function get() {
                    var _reviewElementMargins2 = this.reviewElementMargins(),
                        adjustmentForLastRightMargin = _reviewElementMargins2.right,
                        adjustmentForFirstLeftMargin = _reviewElementMargins2.left;

                    return (this.elements.sliderContainer.offsetWidth || this._defaultSliderWidth) + adjustmentForLastRightMargin + adjustmentForFirstLeftMargin;
                }
            }, {
                key: 'reviewElements',
                get: function get() {
                    return [].slice.call(this.elements.slider.getElementsByClassName(this.reviewClass));
                }
            }]);

            return ReviewSlider;
        }();

        exports.default = ReviewSlider;

    }, {
        "../touch": 59,
        "../utils": 61
    }],
    59: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || false;
                    descriptor.configurable = true;
                    if ("value" in descriptor) descriptor.writable = true;
                    Object.defineProperty(target, descriptor.key, descriptor);
                }
            }
            return function(Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);
                if (staticProps) defineProperties(Constructor, staticProps);
                return Constructor;
            };
        }();

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        // polyfill for Math.sign (not supported in some mobile browsers)
        var sign = function sign(x) {
            return (x > 0) - (x < 0) || +x;
        };
        Math.sign = Math.sign || sign;

        var TrustBoxesTouch = exports.TrustBoxesTouch = function() {
            function TrustBoxesTouch(_ref) {
                var _ref$targetElement = _ref.targetElement,
                    targetElement = _ref$targetElement === undefined ? null : _ref$targetElement,
                    _ref$pageWidth = _ref.pageWidth,
                    pageWidth = _ref$pageWidth === undefined ? null : _ref$pageWidth,
                    _ref$sensitivity = _ref.sensitivity,
                    sensitivity = _ref$sensitivity === undefined ? 25 : _ref$sensitivity,
                    _ref$touchEndCallback = _ref.touchEndCallback,
                    touchEndCallback = _ref$touchEndCallback === undefined ? function() {} : _ref$touchEndCallback,
                    _ref$touchMoveCallbac = _ref.touchMoveCallback,
                    touchMoveCallback = _ref$touchMoveCallbac === undefined ? function() {} : _ref$touchMoveCallbac,
                    _ref$touchStartCallba = _ref.touchStartCallback,
                    touchStartCallback = _ref$touchStartCallba === undefined ? function() {} : _ref$touchStartCallba;

                _classCallCheck(this, TrustBoxesTouch);

                this.targetElement = targetElement;
                this.pageWidth = pageWidth;
                this.sensitivity = sensitivity;
                this.touchEndCallback = touchEndCallback;
                this.touchMoveCallback = touchMoveCallback;
                this.touchStartCallback = touchStartCallback;
                this.initialX = 0;
                this.offsetDistanceX = 0;
                this.startTouchTime = 0;
                this.lastDragDistanceX = 0;
                this.directionX = 0;
                this.scrollAxis = 'none';
                this.touchPosition = {
                    start: {
                        x: 0,
                        y: 0
                    },
                    stop: {
                        x: 0,
                        y: 0
                    }
                };
                this.targetElement.style.userSelect = 'none';
                this.targetElement.style.transitionTimingFunction = 'ease';
            }

            _createClass(TrustBoxesTouch, [{
                key: 'getDragDistance',
                value: function getDragDistance() {
                    return {
                        x: this.touchPosition.stop.x - this.touchPosition.start.x,
                        y: this.touchPosition.stop.y - this.touchPosition.start.y
                    };
                }
            }, {
                key: 'getPagesToSwipe',
                value: function getPagesToSwipe(towardsInitialX) {
                    var distance = this.getDragDistance().x + this.offsetDistanceX;
                    var distFromClosestPage = Math.abs(distance) % this.pageWidth;
                    var maxPagesToSwipe = Math.ceil(Math.abs(distance / this.pageWidth)) || 1;
                    var exceedsThreshold = distFromClosestPage > this.sensitivity;
                    return exceedsThreshold && !towardsInitialX ? maxPagesToSwipe : maxPagesToSwipe - 1;
                }
            }, {
                key: 'setPageWidth',
                value: function setPageWidth(pageWidth) {
                    this.pageWidth = pageWidth;
                }
            }, {
                key: 'attach',
                value: function attach() {
                    var _this = this;

                    this.targetElement.addEventListener('touchstart', function(evt) {
                        _this.startTouchTime = new Date().getTime();
                        _this.touchPosition.start.x = evt.changedTouches[0].screenX;
                        _this.touchPosition.start.y = evt.changedTouches[0].screenY;
                        var style = window.getComputedStyle(_this.targetElement);
                        var translateX = 0;
                        if (window.DOMMatrix) {
                            var matrix = new window.DOMMatrix(style.webkitTransform);
                            translateX = matrix.m41;
                            _this.initialX = Math.round(translateX / _this.pageWidth) * _this.pageWidth;
                            _this.offsetDistanceX = translateX - _this.initialX;
                        }
                        _this.scrollAxis = 'none';
                        // Don't press links when pages are offset
                        // Assume user wants to scroll on x in this case.
                        if (Math.abs(_this.offsetDistanceX) > 5) {
                            evt.preventDefault();
                            _this.scrollAxis = 'x';
                        }
                        _this.touchStartCallback({
                            translateX: translateX,
                            originPage: Math.abs(_this.initialX) / _this.pageWidth + 1
                        });
                    });

                    this.targetElement.addEventListener('touchmove', function(evt) {
                        _this.touchPosition.stop.x = evt.changedTouches[0].screenX;
                        _this.touchPosition.stop.y = evt.changedTouches[0].screenY;
                        var dragDistance = _this.getDragDistance();
                        if (_this.scrollAxis === 'none') {
                            _this.scrollAxis = Math.abs(dragDistance.x) >= Math.abs(dragDistance.y) ? 'x' : 'y';
                        }
                        if (_this.scrollAxis === 'x') {
                            evt.preventDefault();
                            _this.directionX = dragDistance.x - _this.lastDragDistanceX;
                            _this.lastDragDistanceX = dragDistance.x;

                            _this.touchMoveCallback({
                                translateX: dragDistance.x + _this.offsetDistanceX + _this.initialX
                            });
                        }
                    });

                    this.targetElement.addEventListener('touchend', function() {
                        var endTouchTime = new Date().getTime();
                        var deltaTime = (endTouchTime - _this.startTouchTime) / 1000;
                        var dragDistance = _this.getDragDistance();
                        var fingerSpeed = Math.abs(dragDistance.x) / deltaTime;
                        var transitionDuration = _this.pageWidth / fingerSpeed;
                        var translateX = dragDistance.x + _this.offsetDistanceX + _this.initialX;
                        var dirToInitialX = Math.sign(_this.initialX - translateX);
                        var towardsInitialX = Math.sign(_this.directionX) === dirToInitialX;
                        var pagesToSwipe = _this.scrollAxis === 'x' ? _this.getPagesToSwipe(towardsInitialX) : 0;

                        _this.touchEndCallback({
                            pagesToSwipe: pagesToSwipe * dirToInitialX,
                            transitionDuration: transitionDuration
                        });
                    });
                }
            }]);

            return TrustBoxesTouch;
        }();

    }, {}],
    50: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        var _translations = require('./translations');

        var mapDateNumberToHuman = {
            '0': 'january',
            '1': 'february',
            '2': 'march',
            '3': 'april',
            '4': 'may',
            '5': 'june',
            '6': 'july',
            '7': 'august',
            '8': 'september',
            '9': 'october',
            '10': 'november',
            '11': 'december'
        };

        var smartAge = function smartAge(locale, date) {
            if (!date) {
                return null;
            }

            var formattedLocale = (0, _translations.formatLocale)(locale);
            var parsedDate = Date.parse(date);
            var parsedDateAsObject = new Date(parsedDate);
            var now = new Date();
            var seconds = Math.floor((now - parsedDate) / 1000);
            var minutes = roundUpOrDown(seconds, 60);
            var hours = roundUpOrDown(minutes, 60);
            var days = roundUpOrDown(hours, 24);

            if (days >= 7) {
                var month = parsedDateAsObject.getMonth();
                var day = parsedDateAsObject.getDate();
                var monthName = mapDateNumberToHuman[month];
                var monthNameTranslated = (0, _translations.getFrameworkTranslation)('monthNames.' + monthName, formattedLocale);
                var japaneseLocale = 'ja-JP';

                if (formattedLocale === _translations.defaultLocale) {
                    return monthNameTranslated + ' ' + day;
                } else if (formattedLocale === japaneseLocale) {
                    return monthNameTranslated + ' ' + day + '\u65E5';
                } else {
                    return day + ' ' + monthNameTranslated;
                }
            }

            if (days > 0) {
                return (0, _translations.getFrameworkTranslation)('timeAgo.days.' + singularOrPlural(days), formattedLocale, {
                    '[count]': days
                });
            }

            if (hours > 0) {
                return (0, _translations.getFrameworkTranslation)('timeAgo.hours.' + singularOrPlural(hours), formattedLocale, {
                    '[count]': hours
                });
            }

            if (minutes > 0) {
                return (0, _translations.getFrameworkTranslation)('timeAgo.minutes.' + singularOrPlural(minutes), formattedLocale, {
                    '[count]': minutes
                });
            }

            if (seconds >= 0) {
                return (0, _translations.getFrameworkTranslation)('timeAgo.seconds.' + singularOrPlural(seconds), formattedLocale, {
                    '[count]': seconds
                });
            }
        };

        function roundUpOrDown(value, interval) {
            return inSecondPartOfTimeInterval(value, interval) ? Math.ceil(value / interval) : Math.floor(value / interval);
        }

        function inSecondPartOfTimeInterval(value, interval) {
            return value > interval && value % interval >= interval / 2;
        }

        function singularOrPlural(value) {
            return value === 1 ? 'singular' : 'plural';
        }

        exports.default = smartAge;

    }, {
        "./translations": 60
    }],
    58: [function(require, module, exports) {
        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });

        function escapeHtml(string) {
            var specialCharacters = {
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                '\'': '&apos;',
                '/': '&sol;',
                '=': '&equals;',
                '`': '&grave;'
            };
            return string.replace(/[<>"'`=\/]/g, function(s) {
                return specialCharacters[s];
            });
        }

        function truncateText(input, maximumLength) {
            if (isNaN(maximumLength)) {
                return input;
            }
            if (maximumLength <= 0) {
                return '';
            }
            if (input && input.length > maximumLength) {
                input = input.substring(0, maximumLength);
                var lastChar = input.charAt(input.length - 1);
                while (lastChar === ' ' || lastChar === '.' || lastChar === ',') {
                    input = input.substr(0, input.length - 1);
                    lastChar = input.charAt(input.length - 1);
                }
                input += '...';
            }
            return escapeHtml(input);
        }

        exports.truncateText = truncateText;
        exports.escapeHtml = escapeHtml;

    }, {}],
    63: [function(require, module, exports) {
        "use strict";

        // rawAsap provides everything we need except exception management.
        var rawAsap = require("./raw");
        // RawTasks are recycled to reduce GC churn.
        var freeTasks = [];
        // We queue errors to ensure they are thrown in right order (FIFO).
        // Array-as-queue is good enough here, since we are just dealing with exceptions.
        var pendingErrors = [];
        var requestErrorThrow = rawAsap.makeRequestCallFromTimer(throwFirstError);

        function throwFirstError() {
            if (pendingErrors.length) {
                throw pendingErrors.shift();
            }
        }

        /**
         * Calls a task as soon as possible after returning, in its own event, with priority
         * over other events like animation, reflow, and repaint. An error thrown from an
         * event will not interrupt, nor even substantially slow down the processing of
         * other events, but will be rather postponed to a lower priority event.
         * @param {{call}} task A callable object, typically a function that takes no
         * arguments.
         */
        module.exports = asap;

        function asap(task) {
            var rawTask;
            if (freeTasks.length) {
                rawTask = freeTasks.pop();
            } else {
                rawTask = new RawTask();
            }
            rawTask.task = task;
            rawAsap(rawTask);
        }

        // We wrap tasks with recyclable task objects.  A task object implements
        // `call`, just like a function.
        function RawTask() {
            this.task = null;
        }

        // The sole purpose of wrapping the task is to catch the exception and recycle
        // the task object after its single use.
        RawTask.prototype.call = function() {
            try {
                this.task.call();
            } catch (error) {
                if (asap.onerror) {
                    // This hook exists purely for testing purposes.
                    // Its name will be periodically randomized to break any code that
                    // depends on its existence.
                    asap.onerror(error);
                } else {
                    // In a web browser, exceptions are not fatal. However, to avoid
                    // slowing down the queue of pending tasks, we rethrow the error in a
                    // lower priority turn.
                    pendingErrors.push(error);
                    requestErrorThrow();
                }
            } finally {
                this.task = null;
                freeTasks[freeTasks.length] = this;
            }
        };

    }, {
        "./raw": 64
    }],
    64: [function(require, module, exports) {
        (function(global) {
            (function() {
                "use strict";

                // Use the fastest means possible to execute a task in its own turn, with
                // priority over other events including IO, animation, reflow, and redraw
                // events in browsers.
                //
                // An exception thrown by a task will permanently interrupt the processing of
                // subsequent tasks. The higher level `asap` function ensures that if an
                // exception is thrown by a task, that the task queue will continue flushing as
                // soon as possible, but if you use `rawAsap` directly, you are responsible to
                // either ensure that no exceptions are thrown from your task, or to manually
                // call `rawAsap.requestFlush` if an exception is thrown.
                module.exports = rawAsap;

                function rawAsap(task) {
                    if (!queue.length) {
                        requestFlush();
                        flushing = true;
                    }
                    // Equivalent to push, but avoids a function call.
                    queue[queue.length] = task;
                }

                var queue = [];
                // Once a flush has been requested, no further calls to `requestFlush` are
                // necessary until the next `flush` completes.
                var flushing = false;
                // `requestFlush` is an implementation-specific method that attempts to kick
                // off a `flush` event as quickly as possible. `flush` will attempt to exhaust
                // the event queue before yielding to the browser's own event loop.
                var requestFlush;
                // The position of the next task to execute in the task queue. This is
                // preserved between calls to `flush` so that it can be resumed if
                // a task throws an exception.
                var index = 0;
                // If a task schedules additional tasks recursively, the task queue can grow
                // unbounded. To prevent memory exhaustion, the task queue will periodically
                // truncate already-completed tasks.
                var capacity = 1024;

                // The flush function processes all tasks that have been scheduled with
                // `rawAsap` unless and until one of those tasks throws an exception.
                // If a task throws an exception, `flush` ensures that its state will remain
                // consistent and will resume where it left off when called again.
                // However, `flush` does not make any arrangements to be called again if an
                // exception is thrown.
                function flush() {
                    while (index < queue.length) {
                        var currentIndex = index;
                        // Advance the index before calling the task. This ensures that we will
                        // begin flushing on the next task the task throws an error.
                        index = index + 1;
                        queue[currentIndex].call();
                        // Prevent leaking memory for long chains of recursive calls to `asap`.
                        // If we call `asap` within tasks scheduled by `asap`, the queue will
                        // grow, but to avoid an O(n) walk for every task we execute, we don't
                        // shift tasks off the queue after they have been executed.
                        // Instead, we periodically shift 1024 tasks off the queue.
                        if (index > capacity) {
                            // Manually shift all values starting at the index back to the
                            // beginning of the queue.
                            for (var scan = 0, newLength = queue.length - index; scan < newLength; scan++) {
                                queue[scan] = queue[scan + index];
                            }
                            queue.length -= index;
                            index = 0;
                        }
                    }
                    queue.length = 0;
                    index = 0;
                    flushing = false;
                }

                // `requestFlush` is implemented using a strategy based on data collected from
                // every available SauceLabs Selenium web driver worker at time of writing.
                // https://docs.google.com/spreadsheets/d/1mG-5UYGup5qxGdEMWkhP6BWCz053NUb2E1QoUTU16uA/edit#gid=783724593

                // Safari 6 and 6.1 for desktop, iPad, and iPhone are the only browsers that
                // have WebKitMutationObserver but not un-prefixed MutationObserver.
                // Must use `global` or `self` instead of `window` to work in both frames and web
                // workers. `global` is a provision of Browserify, Mr, Mrs, or Mop.

                /* globals self */
                var scope = typeof global !== "undefined" ? global : self;
                var BrowserMutationObserver = scope.MutationObserver || scope.WebKitMutationObserver;

                // MutationObservers are desirable because they have high priority and work
                // reliably everywhere they are implemented.
                // They are implemented in all modern browsers.
                //
                // - Android 4-4.3
                // - Chrome 26-34
                // - Firefox 14-29
                // - Internet Explorer 11
                // - iPad Safari 6-7.1
                // - iPhone Safari 7-7.1
                // - Safari 6-7
                if (typeof BrowserMutationObserver === "function") {
                    requestFlush = makeRequestCallFromMutationObserver(flush);

                    // MessageChannels are desirable because they give direct access to the HTML
                    // task queue, are implemented in Internet Explorer 10, Safari 5.0-1, and Opera
                    // 11-12, and in web workers in many engines.
                    // Although message channels yield to any queued rendering and IO tasks, they
                    // would be better than imposing the 4ms delay of timers.
                    // However, they do not work reliably in Internet Explorer or Safari.

                    // Internet Explorer 10 is the only browser that has setImmediate but does
                    // not have MutationObservers.
                    // Although setImmediate yields to the browser's renderer, it would be
                    // preferrable to falling back to setTimeout since it does not have
                    // the minimum 4ms penalty.
                    // Unfortunately there appears to be a bug in Internet Explorer 10 Mobile (and
                    // Desktop to a lesser extent) that renders both setImmediate and
                    // MessageChannel useless for the purposes of ASAP.
                    // https://github.com/kriskowal/q/issues/396

                    // Timers are implemented universally.
                    // We fall back to timers in workers in most engines, and in foreground
                    // contexts in the following browsers.
                    // However, note that even this simple case requires nuances to operate in a
                    // broad spectrum of browsers.
                    //
                    // - Firefox 3-13
                    // - Internet Explorer 6-9
                    // - iPad Safari 4.3
                    // - Lynx 2.8.7
                } else {
                    requestFlush = makeRequestCallFromTimer(flush);
                }

                // `requestFlush` requests that the high priority event queue be flushed as
                // soon as possible.
                // This is useful to prevent an error thrown in a task from stalling the event
                // queue if the exception handled by Node.js’s
                // `process.on("uncaughtException")` or by a domain.
                rawAsap.requestFlush = requestFlush;

                // To request a high priority event, we induce a mutation observer by toggling
                // the text of a text node between "1" and "-1".
                function makeRequestCallFromMutationObserver(callback) {
                    var toggle = 1;
                    var observer = new BrowserMutationObserver(callback);
                    var node = document.createTextNode("");
                    observer.observe(node, {
                        characterData: true
                    });
                    return function requestCall() {
                        toggle = -toggle;
                        node.data = toggle;
                    };
                }

                // The message channel technique was discovered by Malte Ubl and was the
                // original foundation for this library.
                // http://www.nonblocking.io/2011/06/windownexttick.html

                // Safari 6.0.5 (at least) intermittently fails to create message ports on a
                // page's first load. Thankfully, this version of Safari supports
                // MutationObservers, so we don't need to fall back in that case.

                // function makeRequestCallFromMessageChannel(callback) {
                //     var channel = new MessageChannel();
                //     channel.port1.onmessage = callback;
                //     return function requestCall() {
                //         channel.port2.postMessage(0);
                //     };
                // }

                // For reasons explained above, we are also unable to use `setImmediate`
                // under any circumstances.
                // Even if we were, there is another bug in Internet Explorer 10.
                // It is not sufficient to assign `setImmediate` to `requestFlush` because
                // `setImmediate` must be called *by name* and therefore must be wrapped in a
                // closure.
                // Never forget.

                // function makeRequestCallFromSetImmediate(callback) {
                //     return function requestCall() {
                //         setImmediate(callback);
                //     };
                // }

                // Safari 6.0 has a problem where timers will get lost while the user is
                // scrolling. This problem does not impact ASAP because Safari 6.0 supports
                // mutation observers, so that implementation is used instead.
                // However, if we ever elect to use timers in Safari, the prevalent work-around
                // is to add a scroll event listener that calls for a flush.

                // `setTimeout` does not call the passed callback if the delay is less than
                // approximately 7 in web workers in Firefox 8 through 18, and sometimes not
                // even then.

                function makeRequestCallFromTimer(callback) {
                    return function requestCall() {
                        // We dispatch a timeout with a specified delay of 0 for engines that
                        // can reliably accommodate that request. This will usually be snapped
                        // to a 4 milisecond delay, but once we're flushing, there's no delay
                        // between events.
                        var timeoutHandle = setTimeout(handleTimer, 0);
                        // However, since this timer gets frequently dropped in Firefox
                        // workers, we enlist an interval handle that will try to fire
                        // an event 20 times per second until it succeeds.
                        var intervalHandle = setInterval(handleTimer, 50);

                        function handleTimer() {
                            // Whichever timer succeeds will cancel both timers and
                            // execute the callback.
                            clearTimeout(timeoutHandle);
                            clearInterval(intervalHandle);
                            callback();
                        }
                    };
                }

                // This is for `asap.js` only.
                // Its name will be periodically randomized to break any code that depends on
                // its existence.
                rawAsap.makeRequestCallFromTimer = makeRequestCallFromTimer;

                // ASAP was originally a nextTick shim included in Q. This was factored out
                // into this ASAP package. It was later adapted to RSVP which made further
                // amendments. These decisions, particularly to marginalize MessageChannel and
                // to capture the MutationObserver implementation in a closure, were integrated
                // back into ASAP proper.
                // https://github.com/tildeio/rsvp.js/blob/cddf7232546a9cf858524b75cde6f9edf72620a7/lib/rsvp/asap.js

            }).call(this)
        }).call(this, typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

    }, {}],
    70: [function(require, module, exports) {
        'use strict';

        module.exports = require('./core.js');
        require('./done.js');
        require('./finally.js');
        require('./es6-extensions.js');
        require('./node-extensions.js');
        require('./synchronous.js');

    }, {
        "./core.js": 66,
        "./done.js": 67,
        "./es6-extensions.js": 68,
        "./finally.js": 69,
        "./node-extensions.js": 71,
        "./synchronous.js": 72
    }],
    66: [function(require, module, exports) {
        'use strict';

        var asap = require('asap/raw');

        function noop() {}

        // States:
        //
        // 0 - pending
        // 1 - fulfilled with _value
        // 2 - rejected with _value
        // 3 - adopted the state of another promise, _value
        //
        // once the state is no longer pending (0) it is immutable

        // All `_` prefixed properties will be reduced to `_{random number}`
        // at build time to obfuscate them and discourage their use.
        // We don't use symbols or Object.defineProperty to fully hide them
        // because the performance isn't good enough.


        // to avoid using try/catch inside critical functions, we
        // extract them to here.
        var LAST_ERROR = null;
        var IS_ERROR = {};

        function getThen(obj) {
            try {
                return obj.then;
            } catch (ex) {
                LAST_ERROR = ex;
                return IS_ERROR;
            }
        }

        function tryCallOne(fn, a) {
            try {
                return fn(a);
            } catch (ex) {
                LAST_ERROR = ex;
                return IS_ERROR;
            }
        }

        function tryCallTwo(fn, a, b) {
            try {
                fn(a, b);
            } catch (ex) {
                LAST_ERROR = ex;
                return IS_ERROR;
            }
        }

        module.exports = Promise;

        function Promise(fn) {
            if (typeof this !== 'object') {
                throw new TypeError('Promises must be constructed via new');
            }
            if (typeof fn !== 'function') {
                throw new TypeError('Promise constructor\'s argument is not a function');
            }
            this._40 = 0;
            this._65 = 0;
            this._55 = null;
            this._72 = null;
            if (fn === noop) return;
            doResolve(fn, this);
        }
        Promise._37 = null;
        Promise._87 = null;
        Promise._61 = noop;

        Promise.prototype.then = function(onFulfilled, onRejected) {
            if (this.constructor !== Promise) {
                return safeThen(this, onFulfilled, onRejected);
            }
            var res = new Promise(noop);
            handle(this, new Handler(onFulfilled, onRejected, res));
            return res;
        };

        function safeThen(self, onFulfilled, onRejected) {
            return new self.constructor(function(resolve, reject) {
                var res = new Promise(noop);
                res.then(resolve, reject);
                handle(self, new Handler(onFulfilled, onRejected, res));
            });
        }

        function handle(self, deferred) {
            while (self._65 === 3) {
                self = self._55;
            }
            if (Promise._37) {
                Promise._37(self);
            }
            if (self._65 === 0) {
                if (self._40 === 0) {
                    self._40 = 1;
                    self._72 = deferred;
                    return;
                }
                if (self._40 === 1) {
                    self._40 = 2;
                    self._72 = [self._72, deferred];
                    return;
                }
                self._72.push(deferred);
                return;
            }
            handleResolved(self, deferred);
        }

        function handleResolved(self, deferred) {
            asap(function() {
                var cb = self._65 === 1 ? deferred.onFulfilled : deferred.onRejected;
                if (cb === null) {
                    if (self._65 === 1) {
                        resolve(deferred.promise, self._55);
                    } else {
                        reject(deferred.promise, self._55);
                    }
                    return;
                }
                var ret = tryCallOne(cb, self._55);
                if (ret === IS_ERROR) {
                    reject(deferred.promise, LAST_ERROR);
                } else {
                    resolve(deferred.promise, ret);
                }
            });
        }

        function resolve(self, newValue) {
            // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
            if (newValue === self) {
                return reject(
                    self,
                    new TypeError('A promise cannot be resolved with itself.')
                );
            }
            if (
                newValue &&
                (typeof newValue === 'object' || typeof newValue === 'function')
            ) {
                var then = getThen(newValue);
                if (then === IS_ERROR) {
                    return reject(self, LAST_ERROR);
                }
                if (
                    then === self.then &&
                    newValue instanceof Promise
                ) {
                    self._65 = 3;
                    self._55 = newValue;
                    finale(self);
                    return;
                } else if (typeof then === 'function') {
                    doResolve(then.bind(newValue), self);
                    return;
                }
            }
            self._65 = 1;
            self._55 = newValue;
            finale(self);
        }

        function reject(self, newValue) {
            self._65 = 2;
            self._55 = newValue;
            if (Promise._87) {
                Promise._87(self, newValue);
            }
            finale(self);
        }

        function finale(self) {
            if (self._40 === 1) {
                handle(self, self._72);
                self._72 = null;
            }
            if (self._40 === 2) {
                for (var i = 0; i < self._72.length; i++) {
                    handle(self, self._72[i]);
                }
                self._72 = null;
            }
        }

        function Handler(onFulfilled, onRejected, promise) {
            this.onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : null;
            this.onRejected = typeof onRejected === 'function' ? onRejected : null;
            this.promise = promise;
        }

        /**
         * Take a potentially misbehaving resolver function and make sure
         * onFulfilled and onRejected are only called once.
         *
         * Makes no guarantees about asynchrony.
         */
        function doResolve(fn, promise) {
            var done = false;
            var res = tryCallTwo(fn, function(value) {
                if (done) return;
                done = true;
                resolve(promise, value);
            }, function(reason) {
                if (done) return;
                done = true;
                reject(promise, reason);
            });
            if (!done && res === IS_ERROR) {
                done = true;
                reject(promise, LAST_ERROR);
            }
        }

    }, {
        "asap/raw": 64
    }],
    67: [function(require, module, exports) {
        'use strict';

        var Promise = require('./core.js');

        module.exports = Promise;
        Promise.prototype.done = function(onFulfilled, onRejected) {
            var self = arguments.length ? this.then.apply(this, arguments) : this;
            self.then(null, function(err) {
                setTimeout(function() {
                    throw err;
                }, 0);
            });
        };

    }, {
        "./core.js": 66
    }],
    68: [function(require, module, exports) {
        'use strict';

        //This file contains the ES6 extensions to the core Promises/A+ API

        var Promise = require('./core.js');

        module.exports = Promise;

        /* Static Functions */

        var TRUE = valuePromise(true);
        var FALSE = valuePromise(false);
        var NULL = valuePromise(null);
        var UNDEFINED = valuePromise(undefined);
        var ZERO = valuePromise(0);
        var EMPTYSTRING = valuePromise('');

        function valuePromise(value) {
            var p = new Promise(Promise._61);
            p._65 = 1;
            p._55 = value;
            return p;
        }
        Promise.resolve = function(value) {
            if (value instanceof Promise) return value;

            if (value === null) return NULL;
            if (value === undefined) return UNDEFINED;
            if (value === true) return TRUE;
            if (value === false) return FALSE;
            if (value === 0) return ZERO;
            if (value === '') return EMPTYSTRING;

            if (typeof value === 'object' || typeof value === 'function') {
                try {
                    var then = value.then;
                    if (typeof then === 'function') {
                        return new Promise(then.bind(value));
                    }
                } catch (ex) {
                    return new Promise(function(resolve, reject) {
                        reject(ex);
                    });
                }
            }
            return valuePromise(value);
        };

        Promise.all = function(arr) {
            var args = Array.prototype.slice.call(arr);

            return new Promise(function(resolve, reject) {
                if (args.length === 0) return resolve([]);
                var remaining = args.length;

                function res(i, val) {
                    if (val && (typeof val === 'object' || typeof val === 'function')) {
                        if (val instanceof Promise && val.then === Promise.prototype.then) {
                            while (val._65 === 3) {
                                val = val._55;
                            }
                            if (val._65 === 1) return res(i, val._55);
                            if (val._65 === 2) reject(val._55);
                            val.then(function(val) {
                                res(i, val);
                            }, reject);
                            return;
                        } else {
                            var then = val.then;
                            if (typeof then === 'function') {
                                var p = new Promise(then.bind(val));
                                p.then(function(val) {
                                    res(i, val);
                                }, reject);
                                return;
                            }
                        }
                    }
                    args[i] = val;
                    if (--remaining === 0) {
                        resolve(args);
                    }
                }
                for (var i = 0; i < args.length; i++) {
                    res(i, args[i]);
                }
            });
        };

        Promise.reject = function(value) {
            return new Promise(function(resolve, reject) {
                reject(value);
            });
        };

        Promise.race = function(values) {
            return new Promise(function(resolve, reject) {
                values.forEach(function(value) {
                    Promise.resolve(value).then(resolve, reject);
                });
            });
        };

        /* Prototype Methods */

        Promise.prototype['catch'] = function(onRejected) {
            return this.then(null, onRejected);
        };

    }, {
        "./core.js": 66
    }],
    69: [function(require, module, exports) {
        'use strict';

        var Promise = require('./core.js');

        module.exports = Promise;
        Promise.prototype['finally'] = function(f) {
            return this.then(function(value) {
                return Promise.resolve(f()).then(function() {
                    return value;
                });
            }, function(err) {
                return Promise.resolve(f()).then(function() {
                    throw err;
                });
            });
        };

    }, {
        "./core.js": 66
    }],
    72: [function(require, module, exports) {
        'use strict';

        var Promise = require('./core.js');

        module.exports = Promise;
        Promise.enableSynchronous = function() {
            Promise.prototype.isPending = function() {
                return this.getState() == 0;
            };

            Promise.prototype.isFulfilled = function() {
                return this.getState() == 1;
            };

            Promise.prototype.isRejected = function() {
                return this.getState() == 2;
            };

            Promise.prototype.getValue = function() {
                if (this._65 === 3) {
                    return this._55.getValue();
                }

                if (!this.isFulfilled()) {
                    throw new Error('Cannot get a value of an unfulfilled promise.');
                }

                return this._55;
            };

            Promise.prototype.getReason = function() {
                if (this._65 === 3) {
                    return this._55.getReason();
                }

                if (!this.isRejected()) {
                    throw new Error('Cannot get a rejection reason of a non-rejected promise.');
                }

                return this._55;
            };

            Promise.prototype.getState = function() {
                if (this._65 === 3) {
                    return this._55.getState();
                }
                if (this._65 === -1 || this._65 === -2) {
                    return 0;
                }

                return this._65;
            };
        };

        Promise.disableSynchronous = function() {
            Promise.prototype.isPending = undefined;
            Promise.prototype.isFulfilled = undefined;
            Promise.prototype.isRejected = undefined;
            Promise.prototype.getValue = undefined;
            Promise.prototype.getReason = undefined;
            Promise.prototype.getState = undefined;
        };

    }, {
        "./core.js": 66
    }],
    71: [function(require, module, exports) {
        'use strict';

        // This file contains then/promise specific extensions that are only useful
        // for node.js interop

        var Promise = require('./core.js');
        var asap = require('asap');

        module.exports = Promise;

        /* Static Functions */

        Promise.denodeify = function(fn, argumentCount) {
            if (
                typeof argumentCount === 'number' && argumentCount !== Infinity
            ) {
                return denodeifyWithCount(fn, argumentCount);
            } else {
                return denodeifyWithoutCount(fn);
            }
        };

        var callbackFn = (
            'function (err, res) {' +
            'if (err) { rj(err); } else { rs(res); }' +
            '}'
        );

        function denodeifyWithCount(fn, argumentCount) {
            var args = [];
            for (var i = 0; i < argumentCount; i++) {
                args.push('a' + i);
            }
            var body = [
                'return function (' + args.join(',') + ') {',
                'var self = this;',
                'return new Promise(function (rs, rj) {',
                'var res = fn.call(', ['self'].concat(args).concat([callbackFn]).join(','),
                ');',
                'if (res &&',
                '(typeof res === "object" || typeof res === "function") &&',
                'typeof res.then === "function"',
                ') {rs(res);}',
                '});',
                '};'
            ].join('');
            return Function(['Promise', 'fn'], body)(Promise, fn);
        }

        function denodeifyWithoutCount(fn) {
            var fnLength = Math.max(fn.length - 1, 3);
            var args = [];
            for (var i = 0; i < fnLength; i++) {
                args.push('a' + i);
            }
            var body = [
                'return function (' + args.join(',') + ') {',
                'var self = this;',
                'var args;',
                'var argLength = arguments.length;',
                'if (arguments.length > ' + fnLength + ') {',
                'args = new Array(arguments.length + 1);',
                'for (var i = 0; i < arguments.length; i++) {',
                'args[i] = arguments[i];',
                '}',
                '}',
                'return new Promise(function (rs, rj) {',
                'var cb = ' + callbackFn + ';',
                'var res;',
                'switch (argLength) {',
                args.concat(['extra']).map(function(_, index) {
                    return (
                        'case ' + (index) + ':' +
                        'res = fn.call(' + ['self'].concat(args.slice(0, index)).concat('cb').join(',') + ');' +
                        'break;'
                    );
                }).join(''),
                'default:',
                'args[argLength] = cb;',
                'res = fn.apply(self, args);',
                '}',

                'if (res &&',
                '(typeof res === "object" || typeof res === "function") &&',
                'typeof res.then === "function"',
                ') {rs(res);}',
                '});',
                '};'
            ].join('');

            return Function(
                ['Promise', 'fn'],
                body
            )(Promise, fn);
        }

        Promise.nodeify = function(fn) {
            return function() {
                var args = Array.prototype.slice.call(arguments);
                var callback =
                    typeof args[args.length - 1] === 'function' ? args.pop() : null;
                var ctx = this;
                try {
                    return fn.apply(this, arguments).nodeify(callback, ctx);
                } catch (ex) {
                    if (callback === null || typeof callback == 'undefined') {
                        return new Promise(function(resolve, reject) {
                            reject(ex);
                        });
                    } else {
                        asap(function() {
                            callback.call(ctx, ex);
                        })
                    }
                }
            }
        };

        Promise.prototype.nodeify = function(callback, ctx) {
            if (typeof callback != 'function') return this;

            this.then(function(value) {
                asap(function() {
                    callback.call(ctx, null, value);
                });
            }, function(err) {
                asap(function() {
                    callback.call(ctx, err);
                });
            });
        };

    }, {
        "./core.js": 66,
        "asap": 63
    }]
}, {}, [1])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJhcHAvanMvbWFpbi5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2RvbS5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2ltcHJlc3Npb24uanMiLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy90ZW1wbGF0ZXMvbG9nby5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3RlbXBsYXRlcy9zdW1tYXJ5LmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvdGVtcGxhdGluZy5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2luaXQuanMiLCJhcHAvanMvcGxhY2Vob2xkZXIuanMiLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy90ZW1wbGF0ZXMvcmV2aWV3cy5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3NsaWRlci9pbmRleC5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3F1ZXJ5U3RyaW5nLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvcmV2aWV3RmlsdGVyVGV4dC5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3V0aWxzLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvYXBpL2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvdGVtcGxhdGVzL3N0YXJzLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL2xvY2FsaXphdGlvbi9kYS1ESy9zdHJpbmdzLmpzb24iLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbG9jYWxpemF0aW9uL2RlLUFUL3N0cmluZ3MuanNvbiIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9sb2NhbGl6YXRpb24vZW4tQVUvc3RyaW5ncy5qc29uIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL2xvY2FsaXphdGlvbi9lbi1VUy9zdHJpbmdzLmpzb24iLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbG9jYWxpemF0aW9uL2VzLUVTL3N0cmluZ3MuanNvbiIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9sb2NhbGl6YXRpb24vZmktRkkvc3RyaW5ncy5qc29uIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL2xvY2FsaXphdGlvbi9mci1CRS9zdHJpbmdzLmpzb24iLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbG9jYWxpemF0aW9uL2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL2xvY2FsaXphdGlvbi9pdC1JVC9zdHJpbmdzLmpzb24iLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbG9jYWxpemF0aW9uL2phLUpQL3N0cmluZ3MuanNvbiIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9sb2NhbGl6YXRpb24vbmItTk8vc3RyaW5ncy5qc29uIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL2xvY2FsaXphdGlvbi9ubC1CRS9zdHJpbmdzLmpzb24iLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbG9jYWxpemF0aW9uL25sLU5ML3N0cmluZ3MuanNvbiIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9sb2NhbGl6YXRpb24vcGwtUEwvc3RyaW5ncy5qc29uIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL2xvY2FsaXphdGlvbi9wdC1CUi9zdHJpbmdzLmpzb24iLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbG9jYWxpemF0aW9uL3B0LVBUL3N0cmluZ3MuanNvbiIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9sb2NhbGl6YXRpb24vcnUtUlUvc3RyaW5ncy5qc29uIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL2xvY2FsaXphdGlvbi9zdi1TRS9zdHJpbmdzLmpzb24iLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbG9jYWxpemF0aW9uL3poLUNOL3N0cmluZ3MuanNvbiIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2FwaS9jYWxsLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMveGhyLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvcm9vdFVyaS5qcyIsIm5vZGVfbW9kdWxlcy9wcm9taXNlL2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvYXBpL2ZldGNoRGF0YS5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2NvbW11bmljYXRpb24uanMiLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy9mbi5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3RlbXBsYXRlcy9lcnJvckZhbGxiYWNrLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvdGVtcGxhdGVzL2xvYWRlci5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2FwaS9wcm9kdWN0UmV2aWV3cy5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2FwaS9yZXZpZXdGZXRjaGVyL2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvYXBpL3Jldmlld0ZldGNoZXIvdXRpbC5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL2FwaS9yZXZpZXdGZXRjaGVyL3Jlc3BvbnNlUHJvY2Vzc29yLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvYXNzZXRzL3N2Zy5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3RyYW5zbGF0aW9ucy5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3NsaWRlci9hcnJvd0NvbnRyb2xzLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvc2xpZGVyL2NvbnRyb2xzLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvc2xpZGVyL3BhZ2luYXRpb25Db250cm9scy5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3NsaWRlci9yZXZpZXdTbGlkZXIuanMiLCJub2RlX21vZHVsZXMvQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy90b3VjaC5qcyIsIm5vZGVfbW9kdWxlcy9AdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3NtYXJ0QWdlLmpzIiwibm9kZV9tb2R1bGVzL0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvdGV4dC5qcyIsIm5vZGVfbW9kdWxlcy9hc2FwL2Jyb3dzZXItYXNhcC5qcyIsIm5vZGVfbW9kdWxlcy9hc2FwL2Jyb3dzZXItcmF3LmpzIiwibm9kZV9tb2R1bGVzL3Byb21pc2UvbGliL2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL3Byb21pc2UvbGliL2NvcmUuanMiLCJub2RlX21vZHVsZXMvcHJvbWlzZS9saWIvZG9uZS5qcyIsIm5vZGVfbW9kdWxlcy9wcm9taXNlL2xpYi9lczYtZXh0ZW5zaW9ucy5qcyIsIm5vZGVfbW9kdWxlcy9wcm9taXNlL2xpYi9maW5hbGx5LmpzIiwibm9kZV9tb2R1bGVzL3Byb21pc2UvbGliL3N5bmNocm9ub3VzLmpzIiwibm9kZV9tb2R1bGVzL3Byb21pc2UvbGliL25vZGUtZXh0ZW5zaW9ucy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7O0FDQUEsSUFBQSxPQUFBLEdBQUEsT0FBQSxDQUFBLHVEQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLFdBQUEsR0FBQSxPQUFBLENBQUEsMkRBQUEsQ0FBQSxDQUFBOzs7O0FBQ0EsSUFBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLG9EQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLElBQUEsR0FBQSxPQUFBLENBQUEsb0RBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxzREFBQSxDQUFBLENBQUE7O0FBUUEsSUFBQSxZQUFBLEdBQUEsT0FBQSxDQUFBLDREQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLFFBQUEsR0FBQSxPQUFBLENBQUEsa0VBQUEsQ0FBQSxDQUFBOzs7O0FBQ0EsSUFBQSxLQUFBLEdBQUEsT0FBQSxDQUFBLCtEQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLFdBQUEsR0FBQSxPQUFBLENBQUEsMkRBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsUUFBQSxHQUFBLE9BQUEsQ0FBQSxrRUFBQSxDQUFBLENBQUE7O0FBSUEsSUFBQSxLQUFBLEdBQUEsT0FBQSxDQUFBLHFEQUFBLENBQUEsQ0FBQTs7OztBQUNBLElBQUEsWUFBQSxHQUFBLE9BQUEsQ0FBQSxlQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLGlCQUFBLEdBQUEsT0FBQSxDQUFBLGlFQUFBLENBQUEsQ0FBQTs7Ozs7O0FBRUEsWUFBQSxDQUFBLE9BQUEsQ0FBUyx1QkFBVCxFQUFBLENBQUE7O3NCQWFJLENBQUEsQ0FBQSxFQUFBLFlBQUEsQ0FBQSxXQUFBO0lBVmMsaUNBQWhCO0lBQ0EseUJBQUE7NENBQ0E7SUFBQSw4Q0FBUTtJQUNSLGtDQUFBO0lBQ08sOEJBQVA7SUFDTSxpQ0FBTjtJQUNBLDJCQUFBO0lBQ0EsNkJBQUE7SUFDQSw2QkFBQTtJQUNBLDRCQUFBOztBQUdGLElBQU0sTUFBQSxHQUFTLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxZQUFBLEVBQWEsUUFBYixDQUFmLENBQUE7QUFDQSxJQUFNLFVBQUEsR0FBYSxTQUFiLFVBQWEsQ0FBQyxNQUFELEVBQUE7RUFBQSxPQUFZLFlBQUE7SUFBQSxPQUFNLFlBQUEsQ0FBQSxPQUFBLENBQVMsVUFBVCxDQUFvQixFQUFFLE1BQUEsRUFBQSxNQUFGLEVBQXBCLENBQU4sQ0FBQTtHQUFaLENBQUE7Q0FBbkIsQ0FBQTs7QUFFQSxJQUFNLG9CQUFBLEdBQXVCLFNBQXZCLG9CQUF1QixDQUFBLElBQUEsRUFBb0I7RUFBQSxJQUFqQixLQUFpQixHQUFBLElBQUEsQ0FBakIsS0FBaUI7TUFBVixHQUFVLEdBQUEsSUFBQSxDQUFWLEdBQVUsQ0FBQTs7RUFDL0MsSUFBTSxvQkFBQSxHQUF1QixRQUFBLENBQVMsY0FBVCxDQUF3QixtQkFBeEIsQ0FBN0IsQ0FBQTtFQUNBLElBQU0sT0FBQSxHQUFVLEVBQUUsS0FBQSxFQUFBLEtBQUYsRUFBUyxHQUFBLEVBQUEsR0FBVCxFQUFjLFdBQUEsRUFBYSxRQUFBLENBQUEsV0FBQSxDQUFZLFVBQXZDLEVBQWhCLENBQUE7RUFDQSxJQUFNLFlBQUEsR0FBZSxDQUFBLENBQUEsRUFBQSxRQUFBLENBQUEsZ0JBQUEsRUFBaUIsT0FBakIsQ0FBckIsQ0FBQTtFQUNBLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxjQUFBLEVBQWUsb0JBQWYsRUFBcUMsWUFBckMsRUFBbUQsS0FBbkQsQ0FBQSxDQUFBO0NBSkYsQ0FBQTs7QUFPQSxJQUFNLGNBQUEsR0FBaUIsU0FBakIsY0FBaUIsQ0FBQSxLQUFBLEVBQXlCO0VBQUEsSUFBdEIsTUFBc0IsR0FBQSxLQUFBLENBQXRCLE1BQXNCO01BQWQsT0FBYyxHQUFBLEtBQUEsQ0FBZCxPQUFjLENBQUE7O0VBQzlDLElBQU0sY0FBQSxHQUFpQjtJQUNyQixNQUFBLEVBQVEsUUFBQSxDQUFTLGNBQVQsQ0FBd0IsbUJBQXhCLENBRGE7SUFFckIsZUFBQSxFQUFpQixRQUFBLENBQVMsY0FBVCxDQUF3QiwyQkFBeEIsQ0FBQTtHQUZuQixDQUFBO0VBSUEsSUFBTSxZQUFBLEdBQWU7SUFDbkIsU0FBQSxFQUFXLFFBQUEsQ0FBUyxjQUFULENBQXdCLG1CQUF4QixDQURRO0lBRW5CLFNBQUEsRUFBVyxRQUFBLENBQVMsY0FBVCxDQUF3QixvQkFBeEIsQ0FBQTtHQUZiLENBQUE7RUFJQSxJQUFNLGVBQUEsR0FBa0I7SUFDdEIsbUJBQUEsRUFBcUIsU0FBQSxtQkFBQSxDQUFDLE1BQUQsRUFBQTtNQUFBLE9BQVksTUFBQSxDQUFPLE1BQUEsQ0FBTyxTQUFkLENBQVosQ0FBQTtLQUFBO0dBRHZCLENBQUE7RUFHQSxJQUFNLFFBQUEsR0FBVyxDQUFBLENBQUEsRUFBQSxTQUFBLENBQUEsT0FBQSxFQUFlLE1BQUEsQ0FBTyxXQUFQLEVBQWYsRUFBcUMsZUFBckMsQ0FBakIsQ0FBQTtFQUNBLElBQU0sZUFBQSxHQUFrQixFQUFBLENBQUcsS0FBSCxDQUFTLElBQVQsQ0FBYyxRQUFBLENBQVMsc0JBQVQsQ0FBZ0Msa0JBQWhDLENBQWQsQ0FBeEIsQ0FBQTtFQUNBLGVBQUEsQ0FBZ0IsT0FBaEIsQ0FBd0IsVUFBQyxJQUFELEVBQUE7SUFBQSxPQUN0QixDQUFBLENBQUEsRUFBQSxJQUFBLENBQUEsZ0JBQUEsRUFBaUIsQ0FDZjtNQUNFLE9BQUEsRUFBUyxJQURYO01BRUUsTUFBQSxFQUFRLENBQUEsQ0FBQSxFQUFBLFdBQUEsQ0FBQSxtQkFBQSxFQUFvQixhQUFwQixDQUFBO0tBSEssRUFLZjtNQUNFLE9BQUEsRUFBUyxJQURYO01BRUUsTUFBQSxFQUFRLENBQUEsQ0FBQSxFQUFBLFdBQUEsQ0FBQSxtQkFBQSxFQUFvQixhQUFwQixDQUFBO0tBUEssQ0FBakIsQ0FEc0IsQ0FBQTtHQUF4QixDQUFBLENBQUE7O0VBYUEsSUFBTSxTQUFBLEdBQVk7SUFDaEIsUUFBQSxFQUFVLFVBQUEsQ0FBVyxNQUFYLENBRE07SUFFaEIsUUFBQSxFQUFVLFVBQUEsQ0FBVyxNQUFYLENBQUE7R0FGWixDQUFBO0VBSUEsSUFBTSxXQUFBLEdBQWMsQ0FDbEI7SUFDRSxRQUFBLEVBQVUsSUFEWjtJQUVFLGVBQUEsRUFBaUIsQ0FBQTtHQUhELEVBS2xCO0lBQ0UsUUFBQSxFQUFVLEdBRFo7SUFFRSxlQUFBLEVBQWlCLENBQUE7R0FQRCxFQVNsQjtJQUNFLFFBQUEsRUFBVSxHQURaO0lBRUUsZUFBQSxFQUFpQixDQUFBO0dBWEQsRUFhbEI7SUFDRSxRQUFBLEVBQVUsR0FEWjtJQUVFLGVBQUEsRUFBaUIsQ0FBQTtHQWZELEVBaUJsQjtJQUNFLFFBQUEsRUFBVSxDQURaO0lBRUUsZUFBQSxFQUFpQixDQUFBO0dBbkJELENBQXBCLENBQUE7O0VBdUJBLElBQU0sYUFBQSxHQUFnQixJQUFJLE9BQUEsQ0FBQSxZQUFKLENBQWlCLE9BQWpCLEVBQTBCLGNBQTFCLEVBQTBDLFFBQTFDLEVBQW9EO0lBQ3hFLFdBQUEsRUFBYSxrQkFEMkQ7SUFFeEUsY0FBQSxFQUFnQixXQUFBO0dBRkksQ0FBdEIsQ0FBQTtFQUlBLElBQU0sY0FBQSxHQUFpQixJQUFJLE9BQUEsQ0FBQSxhQUFKLENBQWtCLGFBQWxCLEVBQWlDLFlBQWpDLEVBQStDO0lBQ3BFLFNBQUEsRUFBQSxTQURvRTtJQUVwRSxhQUFBLEVBQWUsY0FBQTtHQUZNLENBQXZCLENBQUE7RUFJQSxjQUFBLENBQWUsVUFBZixFQUFBLENBQUE7Q0E5REYsQ0FBQTs7QUFpRUEsSUFBTSxjQUFBLEdBQWlCLFNBQWpCLGNBQWlCLENBQUEsS0FBQSxFQVVqQjtFQUFBLElBVEosTUFTSSxHQUFBLEtBQUEsQ0FUSixNQVNJO01BQUEsY0FBQSxHQUFBLEtBQUEsQ0FSSixRQVFJO01BQUEscUJBQUEsR0FBQSxjQUFBLENBUEYsY0FPRTtNQU4wQixlQU0xQixHQUFBLHFCQUFBLENBTkEsZUFNQSxDQU5tQixLQU1uQjtNQUxBLFVBS0EsR0FBQSxxQkFBQSxDQUxBLFVBS0E7TUFITyxVQUdQLEdBQUEsY0FBQSxDQUhGLEtBR0UsQ0FITyxVQUdQO01BRkYsWUFFRSxHQUFBLGNBQUEsQ0FGRixZQUVFLENBQUE7O0VBQ0osSUFBTSxpQkFBQSxHQUFvQixRQUFBLENBQVMsY0FBVCxDQUF3QixhQUF4QixDQUExQixDQUFBO0VBQ0EsQ0FBQSxDQUFBLEVBQUEsSUFBQSxDQUFBLGdCQUFBLEVBQWlCLENBQ2Y7SUFDRSxPQUFBLEVBQVMsaUJBRFg7SUFFRSxNQUFBLEVBQVEsWUFBQSxDQUFhLFFBRnZCO0lBR0UsYUFBQSxFQUFlO01BQ2IsVUFBQSxFQUFZLFVBQUEsQ0FBVyxPQUFYLENBQW1CLENBQW5CLENBREM7TUFFYixhQUFBLEVBQWUsQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLHFCQUFBLEVBQXNCLGVBQXRCLEVBQXVDLE1BQXZDLENBQUE7S0FGRjtHQUpGLENBQWpCLENBQUEsQ0FBQTtFQVVBLElBQU0sZUFBQSxHQUFrQixRQUFBLENBQVMsYUFBVCxDQUF1QixnQkFBdkIsQ0FBeEIsQ0FBQTtFQUNBLGVBQUEsQ0FBZ0IsSUFBaEIsR0FBdUIsTUFBQSxDQUFPLFVBQVAsQ0FBdkIsQ0FBQTs7RUFFQSxJQUFNLGtCQUFBLEdBQXFCLFFBQUEsQ0FBUyxjQUFULENBQXdCLGNBQXhCLENBQTNCLENBQUE7RUFDQSxDQUFBLENBQUEsRUFBQSxJQUFBLENBQUEsZ0JBQUEsRUFBaUIsQ0FDZjtJQUNFLE9BQUEsRUFBUyxrQkFEWDtJQUVFLE1BQUEsRUFBUSxZQUFBLENBQWEsU0FGdkI7SUFHRSxhQUFBLEVBQWU7TUFDYixVQUFBLEVBQVksVUFBQSxDQUFXLE9BQVgsQ0FBbUIsQ0FBbkIsQ0FEQztNQUViLGFBQUEsRUFBZSxDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEscUJBQUEsRUFBc0IsZUFBdEIsRUFBdUMsTUFBdkMsQ0FBQTtLQUZGO0dBSkYsQ0FBakIsQ0FBQSxDQUFBO0VBVUEsSUFBTSxnQkFBQSxHQUFtQixRQUFBLENBQVMsYUFBVCxDQUF1QixpQkFBdkIsQ0FBekIsQ0FBQTtFQUNBLGdCQUFBLENBQWlCLElBQWpCLEdBQXdCLE1BQUEsQ0FBTyxVQUFQLENBQXhCLENBQUE7O0VBRUEsSUFBTSx3QkFBQSxHQUEyQixRQUFBLENBQVMsY0FBVCxDQUF3QixnQ0FBeEIsQ0FBakMsQ0FBQTtFQUNBLElBQU0saUJBQUEsR0FBb0IsQ0FBQSxDQUFBLEVBQUEsa0JBQUEsQ0FBQSxPQUFBLEVBQW9CLE1BQXBCLEVBQTRCLFdBQTVCLEVBQXlDLGNBQXpDLENBQTFCLENBQUE7RUFDQSxDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEsY0FBQSxFQUFlLHdCQUFmLEVBQXlDLGlCQUF6QyxDQUFBLENBQUE7O0VBRUEsSUFBTSxnQkFBQSxHQUFtQixRQUFBLENBQVMsY0FBVCxDQUF3Qiw4QkFBeEIsQ0FBekIsQ0FBQTtFQUNBLENBQUEsQ0FBQSxFQUFBLElBQUEsQ0FBQSxnQkFBQSxFQUFpQixDQUNmO0lBQ0UsT0FBQSxFQUFTLGdCQURYO0lBRUUsTUFBQSxFQUFRLFlBQUEsQ0FBYSxHQUFBO0dBSFIsQ0FBakIsQ0FBQSxDQUFBOztFQU9BLElBQU0sUUFBQSxHQUFXLFFBQUEsQ0FBUyxjQUFULENBQXdCLGdCQUF4QixDQUFqQixDQUFBO0VBQ0EsUUFBQSxDQUFTLElBQVQsR0FBZ0IsTUFBQSxDQUFPLFVBQVAsQ0FBaEIsQ0FBQTtFQUNBLENBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxZQUFBLEdBQUEsQ0FBQTtDQXJERixDQUFBOztBQXdEQSxJQUFNLGtCQUFBLEdBQXFCLFNBQXJCLGtCQUFxQixHQUFNO0VBQy9CLElBQUksVUFBSixFQUFnQjtJQUNkLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxPQUFBLEVBQVEsVUFBUixDQUFBLENBQUE7R0FDRDtFQUNELElBQUksU0FBSixFQUFlO0lBQ2IsQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLFlBQUEsRUFBYSxTQUFiLENBQUEsQ0FBQTtHQUNEO0NBTkgsQ0FBQTs7QUFTQSxJQUFNLGlCQUFBLEdBQW9CLFNBQXBCLGlCQUFvQixDQUFBLEtBQUEsRUFBMEI7RUFBQSxJQUF2QixRQUF1QixHQUFBLEtBQUEsQ0FBdkIsUUFBdUI7TUFBYixNQUFhLEdBQUEsS0FBQSxDQUFiLE1BQWEsQ0FBQTs7RUFDbEQsSUFBTSxlQUFBLEdBQWtCLFFBQUEsQ0FBUyxjQUFULENBQXdCLGVBQXhCLENBQXdDLEtBQWhFLENBQUE7RUFDQSxJQUFJLGVBQUEsR0FBa0IsQ0FBdEIsRUFBeUI7SUFDdkIsY0FBQSxDQUFlLEVBQUUsTUFBQSxFQUFBLE1BQUYsRUFBVSxPQUFBLEVBQVMsUUFBQSxDQUFTLE9BQTVCLEVBQWYsQ0FBQSxDQUFBO0lBQ0EsY0FBQSxDQUFlLEVBQUUsTUFBQSxFQUFBLE1BQUYsRUFBVSxRQUFBLEVBQUEsUUFBVixFQUFmLENBQUEsQ0FBQTtHQUZGLE1BR087SUFDTCxJQUFNLEdBQUEsR0FBTSxNQUFBLENBQU8sUUFBQSxDQUFTLEtBQVQsQ0FBZSxXQUF0QixDQUFaLENBQUE7SUFDQSxJQUFNLEtBQUEsR0FBUSxRQUFBLENBQVMsWUFBVCxDQUFzQixTQUFwQyxDQUFBO0lBQ0Esb0JBQUEsQ0FBcUIsRUFBRSxLQUFBLEVBQUEsS0FBRixFQUFTLEdBQUEsRUFBQSxHQUFULEVBQXJCLENBQUEsQ0FBQTtHQUNEO0VBQ0QsSUFBSSxRQUFBLENBQVMsUUFBVCxDQUFrQixtQkFBdEIsRUFBMkM7SUFDekMsa0JBQUEsRUFBQSxDQUFBO0dBQ0Q7Q0FaSCxDQUFBOztBQWVBLElBQU0sV0FBQSxHQUFjO0VBQ2xCLGNBQUEsRUFBQSxjQURrQjtFQUVsQixNQUFBLEVBQUEsTUFGa0I7RUFHbEIsZUFBQSxFQUFBLGVBSGtCO0VBSWxCLFdBQUEsRUFBQSxXQUprQjtFQUtsQixjQUFBLEVBQUEsY0FMa0I7RUFNbEIsY0FBQSxFQUFnQixFQU5FO0VBT2xCLEtBQUEsRUFBQSxLQVBrQjtFQVFsQixRQUFBLEVBQUEsUUFBQTtDQVJGLENBQUE7QUFVQSxDQUFBLENBQUEsRUFBQSxJQUFBLENBQUEsZ0JBQUEsRUFBaUIsQ0FDZjtFQUNFLE9BQUEsRUFBUyxRQUFBLENBQVMsY0FBVCxDQUF3QixrQkFBeEIsQ0FEWDtFQUVFLE1BQUEsRUFBUSxDQUFBLENBQUEsRUFBQSxZQUFBLENBQUEsaUJBQUEsR0FBQTtDQUhLLENBQWpCLENBQUEsQ0FBQTs7QUFPQSxDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEsT0FBQSxFQUFLLFlBQU07RUFDVCxDQUFBLENBQUEsRUFBQSxJQUFBLENBQUEsc0JBQUEsRUFBdUIsVUFBdkIsQ0FBQSxDQUFtQyxXQUFuQyxFQUFnRCxpQkFBaEQsQ0FBQSxDQUFBO0NBREYsQ0FBQSxDQUFBOzs7Ozs7Ozs7O0FDbk5BLElBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxTQUFBLENBQUEsQ0FBQTs7OztBQUVBLElBQU0sUUFBQSxHQUFXLFNBQVgsUUFBVyxDQUFDLElBQUQsRUFBTyxTQUFQLEVBQXFCO0VBQ3BDLElBQUksSUFBSixFQUFVO0lBQ1IsSUFBTSxhQUFBLEdBQWdCLElBQUEsQ0FBSyxZQUFMLENBQWtCLE9BQWxCLENBQXRCLENBQUE7SUFDQSxJQUFNLFVBQUEsR0FBYSxhQUFBLEdBQWdCLGFBQUEsQ0FBYyxLQUFkLENBQW9CLEdBQXBCLENBQWhCLEdBQTJDLEVBQTlELENBQUE7SUFDQSxPQUFPLFVBQUEsQ0FBVyxPQUFYLENBQW1CLFNBQW5CLENBQUEsS0FBa0MsQ0FBQyxDQUExQyxDQUFBO0dBQ0Q7RUFDRCxPQUFPLEtBQVAsQ0FBQTtDQU5GLENBQUE7O0FBU0EsSUFBTSxRQUFBLEdBQVcsU0FBWCxRQUFXLENBQUMsSUFBRCxFQUFPLFdBQVAsRUFBdUI7RUFDdEMsSUFBSSxJQUFKLEVBQVU7SUFDUixJQUFNLGFBQUEsR0FBZ0IsSUFBQSxDQUFLLFlBQUwsQ0FBa0IsT0FBbEIsQ0FBdEIsQ0FBQTtJQUNBLElBQU0sVUFBQSxHQUFhLGFBQUEsR0FBZ0IsYUFBQSxDQUFjLEtBQWQsQ0FBb0IsR0FBcEIsQ0FBaEIsR0FBMkMsRUFBOUQsQ0FBQTs7SUFFQSxJQUFJLENBQUMsUUFBQSxDQUFTLElBQVQsRUFBZSxXQUFmLENBQUwsRUFBa0M7TUFDaEMsSUFBTSxVQUFBLEdBQWEsRUFBQSxDQUFBLE1BQUEsQ0FBQSxrQkFBQSxDQUFJLFVBQUosQ0FBQSxFQUFBLENBQWdCLFdBQWhCLENBQUEsQ0FBQSxDQUE2QixJQUE3QixDQUFrQyxHQUFsQyxDQUFuQixDQUFBO01BQ0EsSUFBQSxDQUFLLFlBQUwsQ0FBa0IsT0FBbEIsRUFBMkIsVUFBM0IsQ0FBQSxDQUFBO0tBQ0Q7R0FDRjtDQVRILENBQUE7O0FBWUEsSUFBTSxXQUFBLEdBQWMsU0FBZCxXQUFjLENBQUMsSUFBRCxFQUFPLFVBQVAsRUFBc0I7RUFDeEMsSUFBSSxJQUFKLEVBQVU7SUFDUixJQUFNLFVBQUEsR0FBYSxJQUFBLENBQUssU0FBTCxDQUFlLEtBQWYsQ0FBcUIsR0FBckIsQ0FBbkIsQ0FBQTtJQUNBLElBQUEsQ0FBSyxTQUFMLEdBQWlCLFVBQUEsQ0FBVyxNQUFYLENBQWtCLFVBQUMsSUFBRCxFQUFBO01BQUEsT0FBVSxJQUFBLEtBQVMsVUFBbkIsQ0FBQTtLQUFsQixDQUFBLENBQWlELElBQWpELENBQXNELEdBQXRELENBQWpCLENBQUE7R0FDRDtDQUpILENBQUE7Ozs7Ozs7OztBQWNBLElBQU0sZ0JBQUEsR0FBbUIsU0FBbkIsZ0JBQW1CLENBQUMsUUFBRCxFQUFjO0VBQ3JDLFFBQUEsQ0FBUyxPQUFULENBQWlCLFVBQUEsSUFBQSxFQUE2QztJQUFBLElBQTFDLE9BQTBDLEdBQUEsSUFBQSxDQUExQyxPQUEwQztRQUFqQyxNQUFpQyxHQUFBLElBQUEsQ0FBakMsTUFBaUM7UUFBQSxrQkFBQSxHQUFBLElBQUEsQ0FBekIsYUFBeUI7UUFBekIsYUFBeUIsR0FBQSxrQkFBQSxLQUFBLFNBQUEsR0FBVCxFQUFTLEdBQUEsa0JBQUEsQ0FBQTs7SUFDNUQsSUFBSSxNQUFKLEVBQVk7TUFDVixDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEsY0FBQSxFQUFlLE9BQWYsRUFBd0IsQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLGdCQUFBLEVBQWlCLGFBQWpCLEVBQWdDLE1BQWhDLENBQXhCLEVBQWlFLEtBQWpFLENBQUEsQ0FBQTtLQURGLE1BRU87TUFDTCxDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEsYUFBQSxFQUFjLE9BQWQsQ0FBQSxDQUFBO0tBQ0Q7R0FMSCxDQUFBLENBQUE7Q0FERixDQUFBOztRQVVTLFdBQUE7UUFBVSxjQUFBO29EQUFhO1FBQVUsbUJBQUE7Ozs7Ozs7Ozs7O0FDL0MxQzs7QUFDQTs7QUFDQTs7OztBQUNBOzs7Ozs7OztBQUVBLFNBQVMsU0FBVCxDQUFtQixLQUFuQixFQUEwQixNQUExQixFQUFrQyxPQUFsQyxFQUEyQztBQUN6QyxNQUFNLE9BQU8sUUFBYjtBQUNBLE1BQU0scUJBQW1CLE9BQU8sUUFBUCxDQUFnQixRQUFoQixDQUF5QixPQUF6QixDQUFpQyxxQkFBakMsRUFBd0QsSUFBeEQsQ0FBekI7QUFDQSxNQUFNLDBCQUFOO0FBQ0EsTUFBTSxpQkFBTjtBQUNBLFdBQVMsTUFBVCxHQUFrQixDQUFJLEtBQUosU0FBYSxNQUFiLEVBQXVCLElBQXZCLEVBQTZCLE9BQTdCLEVBQXNDLE1BQXRDLEVBQThDLFFBQTlDLEVBQXdELE1BQXhELEVBQWdFLElBQWhFLENBQXFFLElBQXJFLENBQWxCO0FBQ0EsV0FBUyxNQUFULEdBQWtCLENBQUksS0FBSixnQkFBb0IsTUFBcEIsRUFBOEIsSUFBOUIsRUFBb0MsT0FBcEMsRUFBNkMsTUFBN0MsRUFBcUQsSUFBckQsQ0FBMEQsSUFBMUQsQ0FBbEI7QUFDRDs7QUFFRCxTQUFTLGVBQVQsQ0FBeUIsU0FBekIsRUFBb0MsY0FBcEMsRUFBb0Q7QUFDbEQ7QUFDQTtBQUZrRCxNQUc3QixNQUg2QixHQUdxQixjQUhyQixDQUcxQyxXQUgwQztBQUFBLE1BR04sQ0FITSxHQUdxQixjQUhyQixDQUdyQixhQUhxQjtBQUFBLE1BR0EsZ0JBSEEsNEJBR3FCLGNBSHJCOztBQUFBLHFCQUlrQyxnQ0FKbEM7QUFBQSxNQUkxQixjQUowQixnQkFJMUMsY0FKMEM7QUFBQSxNQUlFLFFBSkYsZ0JBSVYsVUFKVTtBQUFBLE1BSWUsY0FKZjs7QUFNbEQsTUFBTSx5QkFDRCxjQURDLEVBRUQsZ0JBRkMsRUFHQSxlQUFlLEtBQWYsSUFBd0IsTUFBeEIsR0FBaUMsRUFBRSxjQUFGLEVBQWpDLEdBQThDLEVBQUUsWUFBWSxDQUFkLEVBSDlDO0FBSUosa0NBSkk7QUFLSjtBQUxJLElBQU47QUFPQSxNQUFNLGtCQUFrQixPQUFPLElBQVAsQ0FBWSxTQUFaLEVBQ3JCLEdBRHFCLENBQ2pCLFVBQUMsUUFBRDtBQUFBLFdBQWlCLFFBQWpCLFNBQTZCLG1CQUFtQixVQUFVLFFBQVYsQ0FBbkIsQ0FBN0I7QUFBQSxHQURpQixFQUVyQixJQUZxQixDQUVoQixHQUZnQixDQUF4QjtBQUdBLFNBQVUsd0JBQVYsZUFBc0MsU0FBdEMsU0FBbUQsZUFBbkQ7QUFDRDs7QUFFRCxTQUFTLGtCQUFULENBQTRCLFNBQTVCLFFBQTJFO0FBQUEsTUFBbEMsT0FBa0MsUUFBbEMsT0FBa0M7QUFBQSxNQUF6QixNQUF5QixRQUF6QixNQUF5QjtBQUFBLE1BQWpCLGFBQWlCLFFBQWpCLGFBQWlCOztBQUFBLHNCQUN2QixnQ0FEdUI7QUFBQSxNQUNqRSxLQURpRSxpQkFDakUsS0FEaUU7QUFBQSxNQUMxQyxjQUQwQyxpQkFDMUQsY0FEMEQ7O0FBRXpFLE1BQUksQ0FBQyxLQUFMLEVBQVk7QUFDVjtBQUNEOztBQUVELE1BQUksQ0FBQyxNQUFELElBQVcsQ0FBQyxPQUFoQixFQUF5QjtBQUN2QjtBQUNBLFlBQVEsSUFBUixDQUNFLDRFQURGO0FBR0Q7O0FBRUQsTUFBSSxhQUFKLEVBQW1CO0FBQ2pCLFFBQU0sV0FBVyxFQUFFLFlBQUYsRUFBUyxnQkFBVCxFQUFrQixjQUFsQixFQUFqQjtBQUNBLHFDQUN1QixjQUR2QixFQUVFLG1CQUFtQixLQUFLLFNBQUwsQ0FBZSxRQUFmLENBQW5CLENBRkYsRUFHRSxhQUhGO0FBS0Q7QUFDRjs7QUFFRCxTQUFTLGlCQUFULENBQTJCLFNBQTNCLEVBQXNDLGNBQXRDLEVBQXNEO0FBQ3BELHFCQUFtQixTQUFuQixFQUE4QixjQUE5QjtBQUNBLE1BQU0sTUFBTSxnQkFBZ0IsU0FBaEIsRUFBMkIsY0FBM0IsQ0FBWjtBQUNBLE1BQUk7QUFDRix1QkFBSSxFQUFFLFFBQUYsRUFBSjtBQUNELEdBRkQsQ0FFRSxPQUFPLENBQVAsRUFBVTtBQUNWO0FBQ0Q7QUFDRjs7QUFFRCxJQUFNLGtCQUFrQixTQUFsQixlQUFrQixDQUFTLElBQVQsRUFBZTtBQUNyQyxvQkFBa0Isb0JBQWxCLEVBQXdDLElBQXhDO0FBQ0QsQ0FGRDs7QUFJQSxJQUFNLFlBQVksU0FBWixTQUFZLENBQVMsSUFBVCxFQUFlO0FBQy9CLG9CQUFrQixjQUFsQixFQUFrQyxJQUFsQztBQUNELENBRkQ7O0FBSUEsSUFBTSxrQkFBa0IsU0FBbEIsZUFBa0IsQ0FBUyxJQUFULEVBQWU7QUFDckMsb0JBQWtCLG9CQUFsQixFQUF3QyxJQUF4QztBQUNELENBRkQ7O0FBSUEsSUFBSSxLQUFLLElBQVQ7O0FBRUEsSUFBTSwwQkFBMEIsU0FBMUIsdUJBQTBCLEdBQVc7QUFDekMsK0JBQWlCLE1BQWpCLEVBQXlCLFNBQXpCLEVBQW9DLFVBQVMsS0FBVCxFQUFnQjtBQUNsRCxRQUFJLE9BQU8sTUFBTSxJQUFiLEtBQXNCLFFBQTFCLEVBQW9DO0FBQ2xDO0FBQ0Q7O0FBRUQsUUFBSSxVQUFKO0FBQ0EsUUFBSTtBQUNGLFVBQUksRUFBRSxNQUFNLEtBQUssS0FBTCxDQUFXLE1BQU0sSUFBakIsQ0FBUixFQUFKO0FBQ0QsS0FGRCxDQUVFLE9BQU8sQ0FBUCxFQUFVO0FBQ1Y7QUFDQTtBQUNEOztBQUVELFFBQUksRUFBRSxJQUFGLENBQU8sT0FBUCxLQUFtQixPQUF2QixFQUFnQztBQUM5QixXQUFLLEVBQUUsSUFBRixDQUFPLFFBQVo7QUFDQSxhQUFPLE1BQVAsQ0FBYyxXQUFkLENBQTBCLEtBQUssU0FBTCxDQUFlLEVBQUUsU0FBUyxZQUFYLEVBQXlCLFVBQVUsRUFBbkMsRUFBZixDQUExQixFQUFtRixHQUFuRjtBQUNBO0FBQ0Q7O0FBRUQsUUFBSSxFQUFFLElBQUYsQ0FBTyxPQUFQLEtBQW1CLHFCQUF2QixFQUE4QztBQUM1QyxhQUFPLEVBQUUsSUFBRixDQUFPLE9BQWQ7QUFDQSxzQkFBZ0IsRUFBRSxJQUFsQjtBQUNEOztBQUVELFFBQUksRUFBRSxJQUFGLENBQU8sT0FBUCxLQUFtQixzQkFBdkIsRUFBK0M7QUFDN0MsYUFBTyxFQUFFLElBQUYsQ0FBTyxPQUFkO0FBQ0EsZ0JBQVUsRUFBRSxJQUFaO0FBQ0Q7QUFDRixHQTVCRDtBQTZCRCxDQTlCRDs7QUFnQ0EsSUFBTSxXQUFXO0FBQ2YsY0FBWSxlQURHO0FBRWY7QUFGZSxDQUFqQjs7a0JBS2UsUTs7Ozs7Ozs7OztBQ3JIZixJQUFBLFdBQUEsR0FBQSxPQUFBLENBQUEsZUFBQSxDQUFBLENBQUE7O0FBQ0EsSUFBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLFFBQUEsQ0FBQSxDQUFBOztBQUVBLElBQU0sUUFBQSxHQUFXLFNBQVgsUUFBVyxHQUFBO0VBQUEsT0FBTSxDQUFBLENBQUEsRUFBQSxXQUFBLENBQUEsbUJBQUEsRUFBb0IsTUFBcEIsQ0FBTixDQUFBO0NBQWpCLENBQUE7O0FBRUEsSUFBTSxZQUFBLEdBQWUsU0FBZixZQUFlLEdBQXNDO0VBQUEsSUFBckMsYUFBcUMsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBckIsZ0JBQXFCLENBQUE7O0VBQ3pELElBQU0sU0FBQSxHQUNKLE9BQU8sYUFBUCxLQUF5QixRQUF6QixHQUFvQyxRQUFBLENBQVMsY0FBVCxDQUF3QixhQUF4QixDQUFwQyxHQUE2RSxhQUQvRSxDQUFBOztFQUdBLENBQUEsQ0FBQSxFQUFBLElBQUEsQ0FBQSxnQkFBQSxFQUFpQixDQUNmO0lBQ0UsT0FBQSxFQUFTLFNBRFg7SUFFRSxNQUFBLEVBQVEsUUFBQSxFQUFBO0dBSEssQ0FBakIsQ0FBQSxDQUFBO0NBSkYsQ0FBQTs7UUFZUyxXQUFBO1FBQVUsZUFBQTs7Ozs7Ozs7Ozs7O0FDakJuQixJQUFBLFdBQUEsR0FBQSxPQUFBLENBQUEsZUFBQSxDQUFBLENBQUE7O0FBQ0EsSUFBQSxNQUFBLEdBQUEsT0FBQSxDQUFBLFNBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsS0FBQSxHQUFBLE9BQUEsQ0FBQSxRQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLE1BQUEsR0FBQSxPQUFBLENBQUEsVUFBQSxDQUFBLENBQUE7Ozs7QUFFQSxJQUFNLFVBQUEsR0FBYSxZQUFuQixDQUFBO0FBQ0EsSUFBTSxRQUFBLEdBQVcsVUFBakIsQ0FBQTtBQUNBLElBQU0sV0FBQSxHQUFjO0VBQ2xCLFVBQUEsRUFBQSxVQURrQjtFQUVsQixRQUFBLEVBQUEsUUFBQTtDQUZGLENBQUE7O0FBS0EsSUFBTSxXQUFBLEdBQWMsU0FBZCxXQUFjLENBQUMsUUFBRCxFQUFBO0VBQUEsT0FBZSxRQUFBLEdBQVcsRUFBRSxHQUFBLEVBQUssVUFBUCxFQUFYLEdBQWlDLEVBQWhELENBQUE7Q0FBcEIsQ0FBQTs7QUFFQSxJQUFNLGNBQUEsR0FBaUIsU0FBakIsY0FBaUIsQ0FBQyxPQUFELEVBQWE7RUFBQSxJQUMxQixRQUQwQixHQUNXLE9BRFgsQ0FDMUIsUUFEMEI7TUFDaEIsR0FEZ0IsR0FDVyxPQURYLENBQ2hCLEdBRGdCO01BQ1gsT0FEVyxHQUNXLE9BRFgsQ0FDWCxPQURXO01BQ0YsUUFERSxHQUNXLE9BRFgsQ0FDRixRQURFLENBQUE7O0VBRWxDLElBQU0sa0JBQUEsR0FBcUIsUUFBQSxJQUFZLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxnQkFBQSxFQUFpQixFQUFqQixFQUFxQixRQUFyQixDQUF2QyxDQUFBO0VBQ0EsSUFBTSxRQUFBLEdBQVcsQ0FDZixrQkFBQSxJQUFzQixDQUFBLENBQUEsRUFBQSxXQUFBLENBQUEsSUFBQSxFQUFLLEVBQUUsS0FBQSxFQUFPLG9DQUFULEVBQUwsRUFBc0Qsa0JBQXRELENBRFAsRUFFZixHQUFBLElBQ0UsQ0FBQSxDQUFBLEVBQUEsV0FBQSxDQUFBLENBQUEsRUFBQSxRQUFBLENBQUE7SUFFSSxLQUFBLEVBQU8sZ0NBRlg7SUFHSSxJQUFBLEVBQU0sR0FIVjtJQUlJLE1BQUEsRUFBUSxRQUFBO0dBSlosRUFLTyxXQUFBLENBQVksUUFBWixDQUxQLENBQUEsRUFPRSxDQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsUUFBQSxHQVBGLENBSGEsRUFZZixPQUFBLElBQVcsQ0FBQyxHQUFaLElBQW1CLENBQUEsQ0FBQSxFQUFBLFdBQUEsQ0FBQSxJQUFBLEVBQUssRUFBRSxLQUFBLEVBQU8sZ0NBQVQsRUFBTCxFQUFrRCxDQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsUUFBQSxHQUFsRCxDQVpKLENBQUEsQ0FhZixNQWJlLENBYVIsT0FiUSxDQUFqQixDQUFBOztFQWVBLE9BQU8sV0FBQSxDQUFBLEdBQUEsQ0FBQSxLQUFBLENBQUEsU0FBQSxFQUFBLENBQUksRUFBRSxLQUFBLEVBQU8sNENBQVQsRUFBSixDQUFBLENBQUEsTUFBQSxDQUFBLGtCQUFBLENBQWdFLFFBQWhFLENBQUEsQ0FBQSxDQUFQLENBQUE7Q0FsQkYsQ0FBQTs7QUFxQkEsSUFBTSx3QkFBQSxHQUEyQixTQUEzQix3QkFBMkIsQ0FBQyxPQUFELEVBQWE7RUFDNUMsSUFBTSxlQUFBLEdBQWtCLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxnQkFBQSxFQUFpQixFQUFqQixFQUFxQixPQUFBLENBQVEsS0FBN0IsQ0FBeEIsQ0FBQTtFQUNBLElBQU0sZUFBQSxHQUFrQixjQUFBLENBQWUsT0FBZixDQUF4QixDQUFBO0VBQ0EsT0FBTyxDQUFBLENBQUEsRUFBQSxXQUFBLENBQUEsR0FBQSxFQUNMO0lBQ0UsS0FBQSxFQUFPLDBCQUFBO0dBRkosRUFJTCxDQUFBLENBQUEsRUFBQSxXQUFBLENBQUEsSUFBQSxFQUFLLEVBQUUsS0FBQSxFQUFPLGlDQUFULEVBQUwsRUFBbUQsZUFBbkQsQ0FKSyxFQUtMLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxTQUFBLEVBQVUsRUFBRSxHQUFBLEVBQUssQ0FBUCxFQUFVLFlBQUEsRUFBYyxpQ0FBeEIsRUFBVixDQUxLLEVBTUwsZUFOSyxDQUFQLENBQUE7Q0FIRixDQUFBOztBQWFBLElBQU0sMEJBQUEsR0FBNkIsU0FBN0IsMEJBQTZCLENBQUMsT0FBRCxFQUFhO0VBQUEsSUFDdEMsS0FEc0MsR0FDYixPQURhLENBQ3RDLEtBRHNDO01BQy9CLEdBRCtCLEdBQ2IsT0FEYSxDQUMvQixHQUQrQjtNQUMxQixRQUQwQixHQUNiLE9BRGEsQ0FDMUIsUUFEMEIsQ0FBQTs7RUFFOUMsSUFBTSxlQUFBLEdBQWtCLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxnQkFBQSxFQUFpQixFQUFqQixFQUFxQixLQUFyQixDQUF4QixDQUFBO0VBQ0EsT0FBTyxDQUFBLENBQUEsRUFBQSxXQUFBLENBQUEsR0FBQSxFQUNMLEVBQUUsS0FBQSxFQUFPLDRCQUFULEVBREssRUFFTCxDQUFBLENBQUEsRUFBQSxXQUFBLENBQUEsSUFBQSxFQUFLLEVBQUUsS0FBQSxFQUFPLG1DQUFULEVBQUwsRUFBcUQsZUFBckQsQ0FGSyxFQUdMLENBQUEsQ0FBQSxFQUFBLFdBQUEsQ0FBQSxDQUFBLEVBQUEsUUFBQSxDQUFBO0lBRUksS0FBQSxFQUFPLGtDQUZYO0lBR0ksSUFBQSxFQUFNLEdBSFY7SUFJSSxNQUFBLEVBQVEsUUFBQTtHQUpaLEVBS08sV0FBQSxDQUFZLFFBQVosQ0FMUCxDQUFBLEVBT0UsQ0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLFFBQUEsR0FQRixDQUhLLENBQVAsQ0FBQTtDQUhGLENBQUE7O0FBa0JBLElBQU0sZ0JBQUEsR0FBbUIsU0FBbkIsZ0JBQW1CLENBQUMsT0FBRCxFQUFhO0VBQ3BDLE9BQU8sT0FBQSxDQUFRLFdBQVIsS0FBd0IsV0FBQSxDQUFZLFVBQXBDLEdBQ0gsMEJBQUEsQ0FBMkIsT0FBM0IsQ0FERyxHQUVILHdCQUFBLENBQXlCLE9BQXpCLENBRkosQ0FBQTtDQURGLENBQUE7O1FBTVMsbUJBQUE7UUFBa0IsY0FBQTs7Ozs7Ozs7OztBQ3hFM0IsSUFBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLGNBQUEsQ0FBQSxDQUFBOztBQUVBLElBQU0sT0FBQSxHQUFVLFNBQVYsT0FBVSxDQUFDLElBQUQsRUFBQTtFQUFBLE9BQVUsRUFBQSxDQUFHLE1BQUgsQ0FBVSxLQUFWLENBQWdCLEVBQWhCLEVBQW9CLElBQXBCLENBQVYsQ0FBQTtDQUFoQixDQUFBOztBQUVBLElBQU0sT0FBQSxHQUFVLFNBQVYsT0FBVSxDQUFDLEtBQUQsRUFBQTtFQUFBLE9BQ2QsTUFBQSxDQUFPLElBQVAsQ0FBWSxLQUFaLENBQUEsQ0FDRyxHQURILENBQ08sVUFBQyxHQUFELEVBQUE7SUFBQSxPQUFZLEdBQVosR0FBQSxJQUFBLEdBQW9CLEtBQUEsQ0FBTSxHQUFOLENBQXBCLEdBQUEsR0FBQSxDQUFBO0dBRFAsQ0FBQSxDQUVHLElBRkgsQ0FFUSxHQUZSLENBRGMsQ0FBQTtDQUFoQixDQUFBOztBQUtBLElBQU0sTUFBQSxHQUFTLFNBQVQsTUFBUyxDQUFDLEdBQUQsRUFBQTtFQUFBLE9BQVMsVUFBQyxLQUFELEVBQUE7SUFBQSxLQUFBLElBQUEsSUFBQSxHQUFBLFNBQUEsQ0FBQSxNQUFBLEVBQVcsUUFBWCxHQUFBLEtBQUEsQ0FBQSxJQUFBLEdBQUEsQ0FBQSxHQUFBLElBQUEsR0FBQSxDQUFBLEdBQUEsQ0FBQSxDQUFBLEVBQUEsSUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLEdBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxFQUFBO01BQVcsUUFBWCxDQUFBLElBQUEsR0FBQSxDQUFBLENBQUEsR0FBQSxTQUFBLENBQUEsSUFBQSxDQUFBLENBQUE7S0FBQTs7SUFBQSxPQUFBLEdBQUEsR0FDbEIsR0FEa0IsR0FBQSxHQUFBLEdBQ1gsT0FBQSxDQUFRLEtBQVIsQ0FEVyxHQUFBLEdBQUEsR0FDTyxPQUFBLENBQVEsUUFBUixDQUFBLENBQWtCLElBQWxCLENBQXVCLElBQXZCLENBRFAsR0FBQSxJQUFBLEdBQ3dDLEdBRHhDLEdBQUEsR0FBQSxDQUFBO0dBQVQsQ0FBQTtDQUFmLENBQUE7O0FBR0EsSUFBTSxnQkFBQSxHQUFtQixTQUFuQixnQkFBbUIsQ0FBQyxHQUFELEVBQUE7RUFBQSxPQUFTLFVBQUMsS0FBRCxFQUFBO0lBQUEsT0FBQSxHQUFBLEdBQWUsR0FBZixHQUFBLEdBQUEsR0FBc0IsT0FBQSxDQUFRLEtBQVIsQ0FBdEIsR0FBQSxHQUFBLENBQUE7R0FBVCxDQUFBO0NBQXpCLENBQUE7O0FBRUEsSUFBTSxDQUFBLEdBQUksTUFBQSxDQUFPLEdBQVAsQ0FBVixDQUFBO0FBQ0EsSUFBTSxHQUFBLEdBQU0sTUFBQSxDQUFPLEtBQVAsQ0FBWixDQUFBO0FBQ0EsSUFBTSxHQUFBLEdBQU0sTUFBQSxDQUFPLEtBQVAsQ0FBWixDQUFBO0FBQ0EsSUFBTSxLQUFBLEdBQVEsTUFBQSxDQUFPLE9BQVAsQ0FBZCxDQUFBO0FBQ0EsSUFBTSxJQUFBLEdBQU8sTUFBQSxDQUFPLE1BQVAsQ0FBYixDQUFBO0FBQ0EsSUFBTSxLQUFBLEdBQVEsZ0JBQUEsQ0FBaUIsT0FBakIsQ0FBZCxDQUFBO0FBQ0EsSUFBTSxhQUFBLEdBQWdCLE1BQXRCLENBQUE7O0FBRUEsSUFBTSxtQkFBQSxHQUFzQixTQUF0QixtQkFBc0IsQ0FBQyxNQUFELEVBQUE7RUFBQSxJQUFTLFNBQVQsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBcUIsRUFBckIsQ0FBQTtFQUFBLElBQXlCLEtBQXpCLEdBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxDQUFBO0VBQUEsT0FDMUIsR0FBQSxDQUFJLEVBQUUsS0FBQSxFQUFPLFNBQVQsRUFBSixFQUEwQixJQUFBLENBQUEsTUFBQSxDQUFPLE1BQVAsQ0FBQSxDQUFlLEtBQWYsQ0FBMUIsQ0FEMEIsQ0FBQTtDQUE1QixDQUFBOztRQUdTLElBQUE7UUFBRyxNQUFBOytDQUFLO2lEQUFLO2lEQUFPO1FBQU8sT0FBQTtRQUFNLHNCQUFBO3lEQUFxQjs7Ozs7Ozs7O0FDekIvRDs7QUFDQTs7QUFFQSxJQUFNLGlCQUFpQixHQUF2Qjs7QUFFQTs7Ozs7OztBQU9BLElBQU0sT0FBTyxTQUFQLElBQU8sQ0FBQyxNQUFELEVBQVk7QUFDdkIsTUFBSSxjQUFjLEtBQWxCO0FBQ0EsNkJBQU8sWUFBTTtBQUNYLGtCQUFjLElBQWQ7QUFDQSxRQUFJLE9BQU8sTUFBUCxLQUFrQixVQUF0QixFQUFrQztBQUNoQztBQUNELEtBRkQsTUFFTztBQUNMLGNBQVEsSUFBUixDQUFhLHVCQUFiO0FBQ0Q7QUFDRixHQVBEOztBQVNBOztBQUVBO0FBQ0E7QUFDQSxhQUFXLFlBQU07QUFDZixRQUFJLENBQUMsV0FBTCxFQUFrQjtBQUNoQjtBQUNEO0FBQ0YsR0FKRCxFQUlHLGNBSkg7QUFLRCxDQXBCRDs7a0JBc0JlLEk7Ozs7Ozs7Ozs7QUNsQ2YsSUFBQSxXQUFBLEdBQUEsT0FBQSxDQUFBLDJEQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLE1BQUEsR0FBQSxPQUFBLENBQUEsZ0VBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxzREFBQSxDQUFBLENBQUE7Ozs7QUFFQSxJQUFNLGdCQUFBLEdBQW1CLFNBQW5CLGdCQUFtQixHQUFNO0VBQzdCLElBQU0sYUFBQSxHQUFnQixRQUFBLENBQVMsZ0JBQVQsQ0FBMEIsaUJBQTFCLENBQXRCLENBQUE7RUFDQSxLQUFLLElBQUksQ0FBQSxHQUFJLENBQWIsRUFBZ0IsQ0FBQSxHQUFJLGFBQUEsQ0FBYyxNQUFsQyxFQUEwQyxDQUFBLEVBQTFDLEVBQStDO0lBQzdDLGFBQUEsQ0FBYyxDQUFkLENBQUEsQ0FBaUIsU0FBakIsQ0FBMkIsR0FBM0IsQ0FBK0Isd0JBQS9CLENBQUEsQ0FBQTtHQUNEOztFQUVELElBQU0sZUFBQSxHQUFrQixRQUFBLENBQVMsZ0JBQVQsQ0FBMEIsaUNBQTFCLENBQXhCLENBQUE7RUFDQSxLQUFLLElBQUksRUFBQSxHQUFJLENBQWIsRUFBZ0IsRUFBQSxHQUFJLGVBQUEsQ0FBZ0IsTUFBcEMsRUFBNEMsRUFBQSxFQUE1QyxFQUFpRDtJQUMvQyxlQUFBLENBQWdCLEVBQWhCLENBQUEsQ0FBbUIsU0FBbkIsQ0FBNkIsR0FBN0IsQ0FBaUMscUNBQWpDLENBQUEsQ0FBQTtHQUNEO0NBVEgsQ0FBQTs7QUFZQSxJQUFNLHFCQUFBLEdBQXdCLFNBQXhCLHFCQUF3QixHQUFBO0VBQUEsT0FDNUIsQ0FBQSxDQUFBLEVBQUEsV0FBQSxDQUFBLEdBQUEsRUFDRTtJQUNFLEtBQUEsRUFBTyxnREFBQTtHQUZYLEVBQUEsQ0FLSSxDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEsU0FBQSxFQUFVLEVBQUUsR0FBQSxFQUFLLENBQVAsRUFBVixDQUxKLEVBTUksQ0FBQSxDQUFBLEVBQUEsV0FBQSxDQUFBLEdBQUEsRUFBSSxFQUFFLEtBQUEsRUFBTyxvRUFBVCxFQUFKLENBTkosQ0FBQSxDQUFBLE1BQUEsQ0FBQSxrQkFBQSxDQU9PLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxLQUFBLEVBQU0sQ0FBTixDQUFBLENBQVMsR0FBVCxDQUFhLFlBQUE7SUFBQSxPQUNkLENBQUEsQ0FBQSxFQUFBLFdBQUEsQ0FBQSxHQUFBLEVBQUksRUFBRSxLQUFBLEVBQU8sNkRBQVQsRUFBSixDQURjLENBQUE7R0FBYixDQVBQLENBQUEsQ0FBQSxDQUQ0QixDQUFBO0NBQTlCLENBQUE7O0FBY0EsSUFBTSxpQkFBQSxHQUFvQixTQUFwQixpQkFBb0IsR0FBQTtFQUFBLE9BQ3hCLENBQUEsQ0FBQSxFQUFBLFdBQUEsQ0FBQSxHQUFBLEVBQ0U7SUFDRSxLQUFBLEVBQU8sa0RBQUE7R0FGWCxFQUlFLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxLQUFBLEVBQU0sQ0FBTixDQUFBLENBQVMsR0FBVCxDQUFhLHFCQUFiLENBSkYsQ0FEd0IsQ0FBQTtDQUExQixDQUFBOzs0REFRUztRQUFrQixvQkFBQTs7Ozs7Ozs7Ozs7QUN0QzNCOztBQUNBOzs7O0FBQ0E7O0FBQ0E7O0FBQ0E7Ozs7QUFFQSxJQUFNLGNBQWMsU0FBZCxXQUFjLENBQUMsSUFBRCxFQUFVO0FBQzVCLE1BQU0saUJBQWlCLE9BQU8sSUFBUCxLQUFnQixVQUF2QztBQUNBLE1BQU0sZUFBZSxTQUFTLElBQVQsSUFBaUIsUUFBTyxJQUFQLHlDQUFPLElBQVAsT0FBZ0IsUUFBdEQ7O0FBRUEsTUFBTSxzQkFBc0IsaUJBQ3hCLElBRHdCLEdBRXhCLGVBQ0UsS0FBSyxtQkFEUCxHQUVFLElBSk47O0FBSjRCLGFBU3lDLGVBQWUsSUFBZixHQUFzQixFQVQvRDtBQUFBLE1BU3BCLFVBVG9CLFFBU3BCLFVBVG9CO0FBQUEsTUFTUixTQVRRLFFBU1IsU0FUUTtBQUFBLE1BU0csZUFUSCxRQVNHLGVBVEg7QUFBQSxNQVNvQixnQkFUcEIsUUFTb0IsZ0JBVHBCOztBQVU1QixTQUFPLEVBQUUsd0NBQUYsRUFBdUIsc0JBQXZCLEVBQW1DLG9CQUFuQyxFQUE4QyxnQ0FBOUMsRUFBK0Qsa0NBQS9ELEVBQVA7QUFDRCxDQVhEOztBQWFBLElBQU0seUJBQXlCLFNBQXpCLHNCQUF5QixDQUFDLE1BQUQsRUFBUyxVQUFULEVBQXdCO0FBQ3JELE1BQUksVUFBSixFQUFnQjtBQUNkLFdBQU8sbUVBRUwsZ0NBQWEsTUFBYixDQUZLLEVBR0w7QUFDRSxrQkFBWTtBQURkLEtBSEssQ0FBUDtBQU9EO0FBQ0QsU0FBTyxrRUFFTCxnQ0FBYSxNQUFiLENBRkssRUFHTDtBQUNFLGdCQUFZO0FBRGQsR0FISyxDQUFQO0FBT0QsQ0FqQkQ7O0FBbUJBO0FBQ0EsSUFBTSxpQkFBaUIsU0FBakIsY0FBaUIsQ0FBQyxNQUFEO0FBQUEsTUFBUyxJQUFULHVFQUFnQixFQUFoQjtBQUFBLFNBQXVCLFVBQUMsTUFBRCxFQUFZO0FBQ3hEO0FBQ0E7QUFGd0QsdUJBU3BELFlBQVksSUFBWixDQVRvRDtBQUFBLFFBSXRELG1CQUpzRCxnQkFJdEQsbUJBSnNEO0FBQUEsNkNBS3RELFVBTHNEO0FBQUEsUUFLdEQsVUFMc0QseUNBS3pDLEVBTHlDO0FBQUEsUUFNdEQsU0FOc0QsZ0JBTXRELFNBTnNEO0FBQUEsUUFPdEQsZUFQc0QsZ0JBT3RELGVBUHNEO0FBQUEsNkNBUXRELGdCQVJzRDtBQUFBLFFBUXRELGdCQVJzRCx5Q0FRbkMsS0FSbUM7O0FBV3hELFFBQU0sYUFBYSxTQUFiLFVBQWE7QUFBQSxhQUNqQixzQkFDSSxtQkFBRSxFQUFFLE1BQU0sb0JBQW9CLE1BQXBCLENBQVIsRUFBcUMsUUFBUSxRQUE3QyxFQUF1RCxLQUFLLFVBQTVELEVBQUYsRUFBNEUsMkNBQTVFLENBREosR0FFSSwyQ0FIYTtBQUFBLEtBQW5COztBQUtBLFdBQU8scUJBQ0wsRUFBRSw2QkFBMEIsa0JBQWtCLDZCQUFsQixHQUFrRCxFQUE1RSxDQUFGLEVBREssRUFFTCxxQkFBSSxFQUFFLE9BQU8saUJBQVQsRUFBSixFQUFrQyxzQkFBVSxFQUFFLEtBQUssT0FBTyxLQUFkLEVBQXFCLE9BQU8sU0FBNUIsRUFBVixDQUFsQyxDQUZLLEVBR0wscUJBQUksRUFBRSxPQUFPLHFCQUFULEVBQUosRUFBc0Msd0JBQVMsTUFBVCxFQUFpQixPQUFPLFNBQXhCLENBQXRDLENBSEssRUFJTCxPQUFPLEtBQVAsR0FBZSxXQUFXLEVBQUUsT0FBTyxRQUFULEVBQVgsRUFBZ0Msc0JBQVcsT0FBTyxLQUFsQixDQUFoQyxDQUFmLEdBQTJFLEVBSnRFO0FBS0w7QUFDQSxlQUFXLEVBQUUsT0FBTyxNQUFULEVBQVgsRUFBOEIsd0JBQWEsT0FBTyxJQUFQLElBQWUsT0FBTyxPQUFuQyxFQUE0QyxVQUE1QyxDQUE5QixDQU5LLEVBT0wsV0FBVyxFQUFFLE9BQU8scUJBQVQsRUFBWCxFQUE2QyxPQUFPLFFBQVAsQ0FBZ0IsV0FBN0QsQ0FQSyxFQVFMLG1CQUFtQixxQkFBSSxFQUFFLE9BQU8sMEJBQVQsRUFBSixFQUEyQyxDQUM1RCx1QkFBdUIsTUFBdkIsRUFBK0IsT0FBTyxVQUF0QyxDQUQ0RCxDQUEzQyxDQUFuQixHQUVLLElBVkEsQ0FBUDtBQVlELEdBNUJzQjtBQUFBLENBQXZCOztrQkE4QmUsYzs7Ozs7Ozs7OztBQ3JFZixJQUFBLGFBQUEsR0FBQSxPQUFBLENBQUEsZ0JBQUEsQ0FBQSxDQUFBOzs7O0FBQ0EsSUFBQSxjQUFBLEdBQUEsT0FBQSxDQUFBLGlCQUFBLENBQUEsQ0FBQTs7OztBQUNBLElBQUEsbUJBQUEsR0FBQSxPQUFBLENBQUEsc0JBQUEsQ0FBQSxDQUFBOzs7Ozs7UUFFUyxlQUFBLGNBQUEsQ0FBQTtRQUFjLGdCQUFBLGVBQUEsQ0FBQTs4REFBZSxvQkFBQSxDQUFBOzs7Ozs7Ozs7Ozs7OztBQ0p0QyxJQUFBLEdBQUEsR0FBQSxPQUFBLENBQUEsTUFBQSxDQUFBLENBQUE7Ozs7O0FBS0EsU0FBUyxjQUFULENBQXdCLFdBQXhCLEVBQXFDO0VBQ25DLElBQU0sTUFBQSxHQUFTLENBQUMsR0FBRCxFQUFNLEdBQU4sQ0FBZixDQUFBO0VBQ0EsSUFBTSxnQkFBQSxHQUFtQixTQUFuQixnQkFBbUIsQ0FBQyxHQUFELEVBQUE7SUFBQSxPQUFVLE1BQUEsQ0FBTyxPQUFQLENBQWUsR0FBQSxDQUFJLENBQUosQ0FBZixDQUFBLEtBQTJCLENBQUMsQ0FBNUIsR0FBZ0MsR0FBQSxDQUFJLFNBQUosQ0FBYyxDQUFkLENBQWhDLEdBQW1ELEdBQTdELENBQUE7R0FBekIsQ0FBQTtFQUNBLElBQU0sT0FBQSxHQUFVLFNBQVYsT0FBVSxDQUFDLEdBQUQsRUFBQTtJQUFBLE9BQ2QsR0FBQSxDQUNHLEtBREgsQ0FDUyxHQURULENBQUEsQ0FFRyxNQUZILENBRVUsT0FGVixDQUFBLENBR0csR0FISCxDQUdPLFVBQUMsVUFBRCxFQUFnQjtNQUFBLElBQUEsaUJBQUEsR0FDRSxVQUFBLENBQVcsS0FBWCxDQUFpQixHQUFqQixDQURGO1VBQUEsa0JBQUEsR0FBQSxjQUFBLENBQUEsaUJBQUEsRUFBQSxDQUFBLENBQUE7VUFDWixHQURZLEdBQUEsa0JBQUEsQ0FBQSxDQUFBLENBQUE7VUFDUCxLQURPLEdBQUEsa0JBQUEsQ0FBQSxDQUFBLENBQUEsQ0FBQTs7TUFFbkIsSUFBSTtRQUNGLElBQU0sSUFBQSxHQUFPLGtCQUFBLENBQW1CLEdBQW5CLENBQWIsQ0FBQTtRQUNBLElBQU0sTUFBQSxHQUFTLGtCQUFBLENBQW1CLEtBQW5CLENBQWYsQ0FBQTtRQUNBLE9BQU8sQ0FBQyxJQUFELEVBQU8sTUFBUCxDQUFQLENBQUE7T0FIRixDQUlFLE9BQU8sQ0FBUCxFQUFVO1FBQ1YsT0FBQSxDQUFRLEdBQVIsQ0FBWSw4Q0FBWixDQUFBLENBQUE7T0FDRDtLQVhMLENBQUEsQ0FhRyxNQWJILENBYVUsT0FiVixDQURjLENBQUE7R0FBaEIsQ0FBQTtFQWVBLElBQU0sUUFBQSxHQUFXLENBQUEsQ0FBQSxFQUFBLEdBQUEsQ0FBQSxPQUFBLEVBQ2YsR0FBQSxDQUFBLGFBRGUsRUFFZixPQUZlLEVBR2YsZ0JBSGUsQ0FBakIsQ0FBQTtFQUtBLE9BQU8sUUFBQSxDQUFTLFdBQVQsQ0FBUCxDQUFBO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7OztBQWVELFNBQVMsY0FBVCxHQUFvRDtFQUFBLElBQTVCLFFBQTRCLEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQWpCLE1BQUEsQ0FBTyxRQUFVLENBQUE7O0VBQ2xELElBQU0sV0FBQSxHQUFjLGNBQUEsQ0FBZSxRQUFBLENBQVMsTUFBeEIsQ0FBcEIsQ0FBQTtFQUNBLElBQU0sVUFBQSxHQUFhLGNBQUEsQ0FBZSxRQUFBLENBQVMsSUFBeEIsQ0FBbkIsQ0FBQTtFQUNBLE9BQUEsUUFBQSxDQUFBLEVBQUEsRUFBWSxXQUFaLEVBQTRCLFVBQTVCLENBQUEsQ0FBQTtDQUNEOzswREFHQztRQUNrQixjQUFsQjs7Ozs7Ozs7O0FDcERGOztBQUVBLElBQU0sbUJBQW1CLFNBQW5CLGdCQUFtQixDQUFDLE1BQUQsRUFBUyxXQUFULEVBQXNCLGNBQXRCLEVBQXlDO0FBQ2hFLE1BQU0sa0JBQWtCLGdDQUFhLE1BQWIsQ0FBeEI7QUFDQSxNQUFJLGNBQUosRUFBb0I7QUFDbEIsV0FBTyw0RUFFTCxlQUZLLENBQVA7QUFJRDs7QUFFRCxNQUNFLGVBQ0EsQ0FBQyxDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxFQUFnQixHQUFoQixFQUFxQixHQUFyQixFQUEwQixLQUExQixDQUNDLFVBQUMsSUFBRDtBQUFBLFdBQVUsWUFBWSxLQUFaLENBQWtCLEdBQWxCLEVBQXVCLE9BQXZCLENBQStCLElBQS9CLElBQXVDLENBQUMsQ0FBbEQ7QUFBQSxHQURELENBRkgsRUFLRTtBQUNBLFdBQU8sb0JBQW9CLE1BQXBCLEVBQTRCLFlBQVksS0FBWixDQUFrQixHQUFsQixFQUF1QixJQUF2QixFQUE1QixDQUFQO0FBQ0Q7O0FBRUQsU0FBTyxxRUFBa0QsZUFBbEQsQ0FBUDtBQUNELENBbkJEOztBQXFCQSxJQUFNLHNCQUFzQixTQUF0QixtQkFBc0IsQ0FBQyxNQUFELEVBQVMsS0FBVCxFQUFtQjtBQUM3QyxNQUFJLEtBQUssd0JBQVQ7QUFDQSxNQUFNLGlCQUFpQixFQUF2QjtBQUNBLE1BQU0sa0JBQWtCLGdDQUFhLE1BQWIsQ0FBeEI7O0FBRUEsVUFBUSxNQUFNLE1BQWQ7QUFDRSxTQUFLLENBQUw7QUFDRSxXQUFLLHdCQUFMO0FBQ0EscUJBQWUsU0FBZixJQUE0QixNQUFNLENBQU4sQ0FBNUI7QUFDQSxxQkFBZSxTQUFmLElBQTRCLE1BQU0sQ0FBTixDQUE1QjtBQUNBLHFCQUFlLFNBQWYsSUFBNEIsTUFBTSxDQUFOLENBQTVCO0FBQ0EscUJBQWUsU0FBZixJQUE0QixNQUFNLENBQU4sQ0FBNUI7QUFDQTtBQUNGLFNBQUssQ0FBTDtBQUNFLFdBQUssd0JBQUw7QUFDQSxxQkFBZSxTQUFmLElBQTRCLE1BQU0sQ0FBTixDQUE1QjtBQUNBLHFCQUFlLFNBQWYsSUFBNEIsTUFBTSxDQUFOLENBQTVCO0FBQ0EscUJBQWUsU0FBZixJQUE0QixNQUFNLENBQU4sQ0FBNUI7QUFDQTtBQUNGLFNBQUssQ0FBTDtBQUNFLFdBQUssd0JBQUw7QUFDQSxxQkFBZSxTQUFmLElBQTRCLE1BQU0sQ0FBTixDQUE1QjtBQUNBLHFCQUFlLFNBQWYsSUFBNEIsTUFBTSxDQUFOLENBQTVCO0FBQ0E7QUFDRixTQUFLLENBQUw7QUFDRSxXQUFLLHdCQUFMO0FBQ0EscUJBQWUsU0FBZixJQUE0QixNQUFNLENBQU4sQ0FBNUI7QUFDQTtBQUNGO0FBQ0U7QUF4Qko7O0FBMkJBLFNBQU8sMkNBQXdCLEVBQXhCLEVBQTRCLGVBQTVCLEVBQTZDLGNBQTdDLENBQVAsQ0FBb0U7QUFDckUsQ0FqQ0Q7O2tCQW1DZSxnQjs7Ozs7Ozs7Ozs7O0FDMURmLElBQUEsUUFBQSxHQUFBLE9BQUEsQ0FBQSxTQUFBLENBQUEsQ0FBQTs7OztBQUNBLElBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQSxPQUFBLENBQUEsQ0FBQTs7OztBQUVBLFNBQVMsZ0JBQVQsQ0FBMEIsT0FBMUIsRUFBbUMsSUFBbkMsRUFBeUMsUUFBekMsRUFBbUQ7RUFDakQsSUFBSSxPQUFKLEVBQWE7SUFDWCxJQUFJLE9BQUEsQ0FBUSxnQkFBWixFQUE4QjtNQUM1QixPQUFBLENBQVEsZ0JBQVIsQ0FBeUIsSUFBekIsRUFBK0IsUUFBL0IsQ0FBQSxDQUFBO0tBREYsTUFFTztNQUNMLE9BQUEsQ0FBUSxXQUFSLENBQUEsSUFBQSxHQUF5QixJQUF6QixFQUFpQyxVQUFTLENBQVQsRUFBWTtRQUMzQyxDQUFBLEdBQUksQ0FBQSxJQUFLLE1BQUEsQ0FBTyxLQUFoQixDQUFBO1FBQ0EsQ0FBQSxDQUFFLGNBQUYsR0FDRSxDQUFBLENBQUUsY0FBRixJQUNBLFlBQVc7VUFDVCxDQUFBLENBQUUsV0FBRixHQUFnQixLQUFoQixDQUFBO1NBSEosQ0FBQTtRQUtBLENBQUEsQ0FBRSxlQUFGLEdBQ0UsQ0FBQSxDQUFFLGVBQUYsSUFDQSxZQUFXO1VBQ1QsQ0FBQSxDQUFFLFlBQUYsR0FBaUIsSUFBakIsQ0FBQTtTQUhKLENBQUE7UUFLQSxRQUFBLENBQVMsSUFBVCxDQUFjLE9BQWQsRUFBdUIsQ0FBdkIsQ0FBQSxDQUFBO09BWkYsQ0FBQSxDQUFBO0tBY0Q7R0FDRjtDQUNGOztBQUVELFNBQVMsY0FBVCxHQUEwQjtFQUN4QixPQUFPLElBQUksU0FBQSxDQUFBLE9BQUosQ0FBWSxVQUFTLE9BQVQsRUFBa0I7SUFDbkMsSUFBTSxrQkFBQSxHQUFxQixTQUFyQixrQkFBcUIsR0FBVztNQUNwQyxVQUFBLENBQVcsWUFBVztRQUNwQixPQUFBLEVBQUEsQ0FBQTtPQURGLEVBRUcsQ0FGSCxDQUFBLENBQUE7S0FERixDQUFBO0lBS0EsSUFBSSxRQUFBLENBQVMsVUFBVCxLQUF3QixVQUE1QixFQUF3QztNQUN0QyxrQkFBQSxFQUFBLENBQUE7S0FERixNQUVPO01BQ0wsZ0JBQUEsQ0FBaUIsTUFBakIsRUFBeUIsTUFBekIsRUFBaUMsWUFBVztRQUMxQyxrQkFBQSxFQUFBLENBQUE7T0FERixDQUFBLENBQUE7S0FHRDtHQVpJLENBQVAsQ0FBQTtDQWNEOztBQUVELFNBQVMscUJBQVQsQ0FBK0IsS0FBL0IsRUFBc0MsTUFBdEMsRUFBOEM7RUFDNUMsSUFBSTtJQUNGLEtBQUEsQ0FBTSxjQUFOLEVBQUEsQ0FBQTtHQURGLENBRUUsT0FBTyxDQUFQLEVBQVU7SUFDVixPQUFPLEtBQVAsQ0FBQTtHQUNEO0VBQ0QsT0FBTyxLQUFBLENBQU0sY0FBTixDQUFxQixNQUFBLElBQVUsT0FBL0IsQ0FBUCxDQUFBO0NBQ0Q7O0FBRUQsU0FBUyxjQUFULENBQXdCLE9BQXhCLEVBQWlDLE9BQWpDLEVBQTBDO0VBQ3hDLElBQUksQ0FBQyxPQUFMLEVBQWM7SUFDWixPQUFBLENBQVEsR0FBUixDQUFZLDhDQUFaLENBQUEsQ0FBQTtHQURGLE1BRU8sSUFBSSxXQUFBLElBQWUsT0FBbkIsRUFBNEI7O0lBRWpDLE9BQUEsQ0FBUSxTQUFSLEdBQW9CLE9BQXBCLENBQUE7R0FGSyxNQUdBO0lBQ0wsT0FBQSxDQUFRLFdBQVIsR0FBc0IsT0FBdEIsQ0FBQTtHQUNEO0NBQ0Y7O0FBRUQsSUFBTSxZQUFBLEdBQWUsU0FBZixZQUFlLENBQUMsTUFBRCxFQUFZO0VBQy9CLElBQUksT0FBTyxNQUFQLEtBQWtCLFFBQXRCLEVBQWdDO0lBQzlCLE9BQU8sTUFBUCxDQUFBO0dBQ0Q7Ozs7Ozs7OztFQVNELE9BQU8sTUFBQSxDQUFPLE9BQVAsQ0FBZSxzREFBZixFQUF1RSxJQUF2RSxDQUFQLENBQUE7Q0FaRixDQUFBOzs7Ozs7Ozs7O0FBdUJBLFNBQVMsY0FBVCxDQUF3QixPQUF4QixFQUFpQyxPQUFqQyxFQUEyRDtFQUFBLElBQWpCLFFBQWlCLEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQU4sSUFBTSxDQUFBOztFQUN6RCxJQUFJLENBQUMsT0FBTCxFQUFjO0lBQ1osT0FBQSxDQUFRLEdBQVIsQ0FBWSxtREFBWixDQUFBLENBQUE7R0FERixNQUVPO0lBQ0wsT0FBQSxDQUFRLFNBQVIsR0FBb0IsUUFBQSxHQUFXLFlBQUEsQ0FBYSxPQUFiLENBQVgsR0FBbUMsT0FBdkQsQ0FBQTtHQUNEO0NBQ0Y7O0FBRUQsU0FBUyxnQkFBVCxDQUEwQixZQUExQixFQUF3QyxNQUF4QyxFQUFnRDtFQUM5QyxJQUFJLENBQUMsTUFBTCxFQUFhO0lBQ1gsT0FBQSxDQUFRLEdBQVIsQ0FBWSw0QkFBWixDQUFBLENBQUE7SUFDQSxPQUFPLEVBQVAsQ0FBQTtHQUNEO0VBQ0QsT0FBTyxNQUFBLENBQU8sSUFBUCxDQUFZLFlBQVosQ0FBQSxDQUEwQixNQUExQixDQUNMLFVBQUMsTUFBRCxFQUFTLEdBQVQsRUFBQTtJQUFBLE9BQWlCLE1BQUEsQ0FBTyxLQUFQLENBQWEsR0FBYixDQUFBLENBQWtCLElBQWxCLENBQXVCLFlBQUEsQ0FBYSxHQUFiLENBQXZCLENBQWpCLENBQUE7R0FESyxFQUVMLE1BRkssQ0FBUCxDQUFBO0NBSUQ7O0FBRUQsU0FBUyxhQUFULENBQXVCLE9BQXZCLEVBQWdDO0VBQzlCLElBQUksQ0FBQyxPQUFELElBQVksQ0FBQyxPQUFBLENBQVEsVUFBekIsRUFBcUM7SUFDbkMsT0FBQSxDQUFRLEdBQVIsQ0FBWSw2Q0FBWixDQUFBLENBQUE7SUFDQSxPQUFBO0dBQ0Q7RUFDRCxPQUFPLE9BQUEsQ0FBUSxVQUFSLENBQW1CLFdBQW5CLENBQStCLE9BQS9CLENBQVAsQ0FBQTtDQUNEOztBQUVELElBQU0sWUFBQSxHQUFlLFNBQWYsWUFBZSxDQUFDLEtBQUQsRUFBUSxVQUFSLEVBQXVCO0VBQzFDLElBQU0sSUFBQSxHQUFPLFFBQUEsQ0FBUyxvQkFBVCxDQUE4QixNQUE5QixDQUFBLENBQXNDLENBQXRDLENBQWIsQ0FBQTtFQUNBLElBQU0sT0FBQSxHQUFVLFFBQUEsQ0FBUyxjQUFULENBQXdCLG1CQUF4QixDQUFoQixDQUFBOztFQUVBLENBQUEsQ0FBQSxFQUFBLElBQUEsQ0FBQSxRQUFBLEVBQVMsSUFBVCxFQUFlLEtBQWYsQ0FBQSxDQUFBO0VBQ0EsQ0FBQSxDQUFBLEVBQUEsSUFBQSxDQUFBLFFBQUEsRUFBUyxPQUFULEVBQWtCLFNBQWxCLENBQUEsQ0FBQTs7RUFFQSxJQUFJLENBQUMsVUFBTCxFQUFpQjtJQUNmLENBQUEsQ0FBQSxFQUFBLElBQUEsQ0FBQSxRQUFBLEVBQVMsSUFBVCxFQUFlLGdCQUFmLENBQUEsQ0FBQTtHQUNEO0NBVEgsQ0FBQTs7O0FBYUEsSUFBTSx5QkFBQSxHQUE0QixTQUE1Qix5QkFBNEIsQ0FBQyxHQUFELEVBQUE7RUFBQSxPQUFBLEVBQUEsR0FBWSxHQUFaLElBQWtCLEdBQUEsQ0FBSSxPQUFKLENBQVksR0FBWixDQUFBLEtBQXFCLENBQUMsQ0FBdEIsR0FBMEIsR0FBMUIsR0FBZ0MsR0FBbEQsQ0FBQSxDQUFBO0NBQWxDLENBQUE7O0FBRUEsSUFBTSxZQUFBLEdBQWUsU0FBZixZQUFlLENBQUMsWUFBRCxFQUFBO0VBQUEsT0FBa0IsVUFBQyxHQUFELEVBQUE7SUFBQSxPQUNsQyx5QkFBQSxDQUEwQixHQUExQixDQURrQyxHQUFBLGlDQUFBLEdBQzhCLFlBRDlCLENBQUE7R0FBbEIsQ0FBQTtDQUFyQixDQUFBOztBQUdBLElBQU0seUJBQUEsR0FBNEIsU0FBNUIseUJBQTRCLENBQUMsUUFBRCxFQUFBO0VBQUEsT0FBYyxVQUFDLE9BQUQsRUFBYTtJQUMzRCxJQUFJLFFBQUEsSUFBWSxPQUFoQixFQUF5QjtNQUN2QixPQUFBLENBQVEsR0FBUixHQUFjLFVBQWQsQ0FBQTtLQUNEO0dBSCtCLENBQUE7Q0FBbEMsQ0FBQTs7QUFNQSxJQUFNLGlCQUFBLEdBQW9CLFNBQXBCLGlCQUFvQixDQUFDLFFBQUQsRUFBVyxhQUFYLEVBQXlEO0VBQUEsSUFBL0IsVUFBK0IsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBbEIsYUFBa0IsQ0FBQTtFQUFBLElBR25ELGVBSG1ELEdBTTdFLFFBTjZFLENBRS9FLGNBRitFLENBRzdFLGVBSDZFLENBRzFELEtBSDBEO01BSy9FLEtBTCtFLEdBTTdFLFFBTjZFLENBSy9FLEtBTCtFLENBQUE7O0VBT2pGLElBQU0sS0FBQSxHQUFRLEVBQUEsQ0FBRyxLQUFILENBQVMsSUFBVCxDQUFjLFFBQUEsQ0FBUyxzQkFBVCxDQUFnQyxVQUFoQyxDQUFkLENBQWQsQ0FBQTtFQUNBLElBQU0sT0FBQSxHQUFVLGVBQUEsR0FBa0IsS0FBQSxDQUFNLFVBQXhCLEdBQXFDLEtBQUEsQ0FBTSxXQUEzRCxDQUFBO0VBQ0EsS0FBSyxJQUFJLENBQUEsR0FBSSxDQUFiLEVBQWdCLENBQUEsR0FBSSxLQUFBLENBQU0sTUFBMUIsRUFBa0MsQ0FBQSxFQUFsQyxFQUF1QztJQUNyQyxLQUFBLENBQU0sQ0FBTixDQUFBLENBQVMsSUFBVCxHQUFnQixZQUFBLENBQWEsYUFBYixDQUFBLENBQTRCLE9BQTVCLENBQWhCLENBQUE7R0FDRDtDQVhILENBQUE7Ozs7QUFnQkEsSUFBTSxLQUFBLEdBQVEsU0FBUixLQUFRLENBQUMsR0FBRCxFQUFTO0VBQ3JCLElBQU0sTUFBQSxHQUFTLEVBQWYsQ0FBQTtFQUNBLE9BQU8sR0FBQSxHQUFNLENBQWIsRUFBZ0I7SUFDZCxNQUFBLENBQU8sSUFBUCxDQUFZLE1BQUEsQ0FBTyxNQUFuQixDQUFBLENBQUE7SUFDQSxHQUFBLEVBQUEsQ0FBQTtHQUNEO0VBQ0QsT0FBTyxNQUFQLENBQUE7Q0FORixDQUFBOzs7O0FBV0EsSUFBTSxVQUFBLEdBQWEsU0FBYixVQUFhLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBYztFQUMvQixJQUFNLGNBQUEsR0FBaUIsU0FBakIsY0FBaUIsQ0FBQyxDQUFELEVBQUE7SUFBQSxPQUFPLENBQUEsR0FBSSxHQUFKLEdBQVUsR0FBVixHQUFnQixDQUFBLEdBQUksQ0FBSixHQUFRLENBQVIsR0FBWSxDQUFuQyxDQUFBO0dBQXZCLENBQUE7RUFDQSxJQUFJLFFBQUEsR0FBVyxLQUFmLENBQUE7O0VBRUEsSUFBSSxHQUFBLENBQUksQ0FBSixDQUFBLEtBQVcsR0FBZixFQUFvQjtJQUNsQixHQUFBLEdBQU0sR0FBQSxDQUFJLEtBQUosQ0FBVSxDQUFWLENBQU4sQ0FBQTtJQUNBLFFBQUEsR0FBVyxJQUFYLENBQUE7R0FDRDs7RUFFRCxJQUFNLEdBQUEsR0FBTSxRQUFBLENBQVMsR0FBVCxFQUFjLEVBQWQsQ0FBWixDQUFBO0VBQ0EsSUFBSSxDQUFDLEdBQUwsRUFBVTtJQUNSLE9BQU8sR0FBUCxDQUFBO0dBQ0Q7O0VBRUQsSUFBSSxDQUFBLEdBQUksQ0FBQyxHQUFBLElBQU8sRUFBUixJQUFjLEdBQXRCLENBQUE7RUFDQSxDQUFBLEdBQUksY0FBQSxDQUFlLENBQWYsQ0FBSixDQUFBOztFQUVBLElBQUksQ0FBQSxHQUFJLENBQUUsR0FBQSxJQUFPLENBQVIsR0FBYSxNQUFkLElBQXdCLEdBQWhDLENBQUE7RUFDQSxDQUFBLEdBQUksY0FBQSxDQUFlLENBQWYsQ0FBSixDQUFBOztFQUVBLElBQUksQ0FBQSxHQUFJLENBQUMsR0FBQSxHQUFNLFFBQVAsSUFBbUIsR0FBM0IsQ0FBQTtFQUNBLENBQUEsR0FBSSxjQUFBLENBQWUsQ0FBZixDQUFKLENBQUE7O0VBckIrQixJQUFBLElBQUEsR0F1Qm5CLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLENBQUEsQ0FBVSxHQUFWLENBQWMsVUFBQSxLQUFBLEVBQUE7SUFBQSxPQUFTLEtBQUEsSUFBUyxFQUFULEdBQUEsR0FBQSxHQUFrQixLQUFBLENBQU0sUUFBTixDQUFlLEVBQWYsQ0FBbEIsR0FBeUMsS0FBQSxDQUFNLFFBQU4sQ0FBZSxFQUFmLENBQWxELENBQUE7R0FBZCxDQXZCbUIsQ0FBQTs7RUFBQSxJQUFBLEtBQUEsR0FBQSxjQUFBLENBQUEsSUFBQSxFQUFBLENBQUEsQ0FBQSxDQUFBOztFQXVCOUIsQ0F2QjhCLEdBQUEsS0FBQSxDQUFBLENBQUEsQ0FBQSxDQUFBO0VBdUIzQixDQXZCMkIsR0FBQSxLQUFBLENBQUEsQ0FBQSxDQUFBLENBQUE7RUF1QnhCLENBdkJ3QixHQUFBLEtBQUEsQ0FBQSxDQUFBLENBQUEsQ0FBQTs7RUF3Qi9CLE9BQU8sQ0FBQyxRQUFBLEdBQVcsR0FBWCxHQUFpQixFQUFsQixJQUF3QixDQUF4QixHQUE0QixDQUE1QixHQUFnQyxDQUF2QyxDQUFBO0NBeEJGLENBQUE7O0FBMkJBLElBQU0sU0FBQSxHQUFZLFNBQVosU0FBWSxDQUFDLEdBQUQsRUFBb0I7RUFBQSxJQUFkLEtBQWMsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBTixDQUFNLENBQUE7O0VBQ3BDLElBQU0sR0FBQSxHQUFNLEdBQUEsQ0FBSSxDQUFKLENBQUEsS0FBVyxHQUFYLEdBQWlCLFFBQUEsQ0FBUyxHQUFBLENBQUksS0FBSixDQUFVLENBQVYsQ0FBVCxFQUF1QixFQUF2QixDQUFqQixHQUE4QyxRQUFBLENBQVMsR0FBVCxFQUFjLEVBQWQsQ0FBMUQsQ0FBQTtFQUNBLElBQU0sR0FBQSxHQUFPLEdBQUEsSUFBTyxFQUFwQixDQUFBO0VBQ0EsSUFBTSxLQUFBLEdBQVUsR0FBQSxJQUFPLENBQVIsR0FBYSxNQUE1QixDQUFBO0VBQ0EsSUFBTSxJQUFBLEdBQVEsR0FBQSxHQUFNLFFBQXBCLENBQUE7RUFDQSxPQUFBLE9BQUEsR0FBZSxHQUFmLEdBQUEsR0FBQSxHQUFzQixLQUF0QixHQUFBLEdBQUEsR0FBK0IsSUFBL0IsR0FBQSxHQUFBLEdBQXVDLEtBQXZDLEdBQUEsR0FBQSxDQUFBO0NBTEYsQ0FBQTs7QUFRQSxJQUFNLFlBQUEsR0FBZSxTQUFmLFlBQWUsQ0FBQyxTQUFELEVBQWU7RUFDbEMsSUFBTSxjQUFBLEdBQWlCLFFBQUEsQ0FBUyxhQUFULENBQXVCLE9BQXZCLENBQXZCLENBQUE7RUFDQSxjQUFBLENBQWUsV0FBZixDQUNFLFFBQUEsQ0FBUyxjQUFULENBQUEseUZBQUEsR0FLYSxTQUxiLEdBQUEsK0VBQUEsR0FRMkIsU0FSM0IsR0FBQSw4RUFBQSxHQVdvQixVQUFBLENBQVcsU0FBWCxFQUFzQixDQUFDLEVBQXZCLENBWHBCLEdBQUEsaUVBQUEsR0FjYSxTQUFBLENBQVUsU0FBVixFQUFxQixHQUFyQixDQWRiLEdBQUEsOEVBQUEsR0FpQm9CLFNBQUEsQ0FBVSxTQUFWLEVBQXFCLEdBQXJCLENBakJwQixHQUFBLGdHQUFBLEdBb0JhLFNBcEJiLEdBQUEsNkJBQUEsQ0FERixDQUFBLENBQUE7RUF5QkEsUUFBQSxDQUFTLElBQVQsQ0FBYyxXQUFkLENBQTBCLGNBQTFCLENBQUEsQ0FBQTtDQTNCRixDQUFBOztBQThCQSxJQUFNLGNBQUEsR0FBaUIsU0FBakIsY0FBaUIsQ0FBQyxXQUFELEVBQWlCO0VBQ3RDLElBQU0sZ0JBQUEsR0FBbUIsUUFBQSxDQUFTLGFBQVQsQ0FBdUIsT0FBdkIsQ0FBekIsQ0FBQTtFQUNBLGdCQUFBLENBQWlCLFdBQWpCLENBQ0UsUUFBQSxDQUFTLGNBQVQsQ0FBQSxvQ0FBQSxHQUVvQixXQUZwQixHQUFBLDZCQUFBLENBREYsQ0FBQSxDQUFBO0VBT0EsUUFBQSxDQUFTLElBQVQsQ0FBYyxXQUFkLENBQTBCLGdCQUExQixDQUFBLENBQUE7Q0FURixDQUFBOztBQVlBLElBQU0sT0FBQSxHQUFVLFNBQVYsT0FBVSxDQUFDLFVBQUQsRUFBZ0I7RUFDOUIsSUFBTSxRQUFBLEdBQVcsUUFBQSxDQUFTLGFBQVQsQ0FBdUIsTUFBdkIsQ0FBakIsQ0FBQTtFQUNBLFFBQUEsQ0FBUyxHQUFULEdBQWUsWUFBZixDQUFBOzs7RUFHQSxRQUFBLENBQVMsSUFBVCxHQUFBLDBDQUFBLEdBQTJELFVBQTNELEdBQUEsbUJBQUEsQ0FBQTtFQUNBLFFBQUEsQ0FBUyxJQUFULENBQWMsV0FBZCxDQUEwQixRQUExQixDQUFBLENBQUE7O0VBRUEsSUFBTSxhQUFBLEdBQWdCLFVBQUEsQ0FBVyxPQUFYLENBQW1CLEtBQW5CLEVBQTBCLEdBQTFCLENBQXRCLENBQUE7RUFDQSxJQUFNLFNBQUEsR0FBWSxRQUFBLENBQVMsYUFBVCxDQUF1QixPQUF2QixDQUFsQixDQUFBO0VBQ0EsU0FBQSxDQUFVLFdBQVYsQ0FDRSxRQUFBLENBQVMsY0FBVCxDQUFBLDRGQUFBLEdBS2tCLGFBTGxCLEdBQUEsd0NBQUEsQ0FERixDQUFBLENBQUE7RUFVQSxRQUFBLENBQVMsSUFBVCxDQUFjLFdBQWQsQ0FBMEIsU0FBMUIsQ0FBQSxDQUFBO0NBcEJGLENBQUE7O0FBdUJBLElBQU0sZUFBQSxHQUFrQixTQUFsQixlQUFrQixDQUFDLFFBQUQsRUFBYztFQUNwQyxRQUFBLENBQVMsZUFBVCxDQUF5QixZQUF6QixDQUFzQyxNQUF0QyxFQUE4QyxRQUE5QyxDQUFBLENBQUE7Q0FERixDQUFBOztBQUlBLElBQU0sYUFBQSxHQUFnQixTQUFoQixhQUFnQixDQUFDLEtBQUQsRUFBVztFQUMvQixJQUFNLFNBQUEsR0FBWSwyQkFBbEIsQ0FBQTtFQUNBLE9BQVEsT0FBTyxLQUFQLEtBQWlCLFFBQWpCLElBQTZCLFNBQUEsQ0FBVSxJQUFWLENBQWUsS0FBZixDQUE5QixHQUF1RCxLQUF2RCxHQUErRCxJQUF0RSxDQUFBO0NBRkYsQ0FBQTs7UUFNRSx3QkFBQTtRQUNBLGlCQUFBO1FBQ0EsaUJBQUE7UUFDQSxtQkFBQTtRQUNBLGlCQUFBO1FBQ0EsbUJBQUE7UUFDQSxnQkFBQTtRQUNBLGVBQUE7UUFDQSxlQUFBO3FFQUNBOzZEQUNBO1FBQ0EsUUFBQTtRQUNBLGVBQUE7MERBQ0E7UUFDQSxVQUFBOzJEQUNBO1FBQ0EsZUFBQTtRQUNBLGdCQUFBOzs7Ozs7Ozs7O0FDblNGLElBQUEsVUFBQSxHQUFBLE9BQUEsQ0FBQSxhQUFBLENBQUEsQ0FBQTs7QUFPQSxJQUFBLGVBQUEsR0FBQSxPQUFBLENBQUEsa0JBQUEsQ0FBQSxDQUFBOztBQUtBLElBQU0sc0JBQUEsR0FBeUIsU0FBekIsc0JBQXlCLENBQUMsVUFBRCxFQUFBO0VBQUEsT0FBZ0IsVUFBQyxXQUFELEVBQWMsaUJBQWQsRUFBaUMsV0FBakMsRUFBaUQ7SUFDOUYsQ0FBQSxDQUFBLEVBQUEsVUFBQSxDQUFBLFNBQUEsRUFBQSxpQkFBQSxHQUE0QixVQUE1QixDQUFBLENBQ0UsV0FERixFQUVFLGlCQUZGLEVBR0UsV0FIRixFQUlFLFVBQUEsQ0FBQSxpQkFKRixDQUFBLENBQUE7R0FENkIsQ0FBQTtDQUEvQixDQUFBOztBQVNBLElBQU0sNkJBQUEsR0FBZ0MsU0FBaEMsNkJBQWdDLENBQUMsVUFBRCxFQUFBO0VBQUEsT0FBZ0IsVUFDcEQsV0FEb0QsRUFFcEQsaUJBRm9ELEVBR3BELFdBSG9ELEVBSWpEO0lBQ0gsQ0FBQSxDQUFBLEVBQUEsVUFBQSxDQUFBLGNBQUEsRUFBQSxpQkFBQSxHQUFpQyxVQUFqQyxDQUFBLENBQ0UsV0FERixFQUVFLGlCQUZGLEVBR0UsV0FIRixFQUlFLFVBQUEsQ0FBQSwyQkFKRixDQUFBLENBQUE7R0FMb0MsQ0FBQTtDQUF0QyxDQUFBOzs0REFjRSxlQUFBLENBQUE7OERBQ0EsZUFBQSxDQUFBO3dFQUNBLFVBQUEsQ0FBQTtRQUNBLHlCQUFBO3lFQUNBOzs7Ozs7Ozs7O0FDdkNGLElBQUEsV0FBQSxHQUFBLE9BQUEsQ0FBQSxlQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLElBQUEsR0FBQSxPQUFBLENBQUEsUUFBQSxDQUFBLENBQUE7O0FBQ0EsSUFBQSxNQUFBLEdBQUEsT0FBQSxDQUFBLFVBQUEsQ0FBQSxDQUFBOztBQUVBLElBQU0sU0FBQSxHQUFZLFNBQVosU0FBWSxDQUFBLElBQUEsRUFBMEQ7RUFBQSxJQUF2RCxHQUF1RCxHQUFBLElBQUEsQ0FBdkQsR0FBdUQ7TUFBQSxlQUFBLEdBQUEsSUFBQSxDQUFsRCxVQUFrRDtNQUFsRCxVQUFrRCxHQUFBLGVBQUEsS0FBQSxTQUFBLEdBQXJDLElBQXFDLEdBQUEsZUFBQTtNQUFBLGlCQUFBLEdBQUEsSUFBQSxDQUEvQixZQUErQjtNQUEvQixZQUErQixHQUFBLGlCQUFBLEtBQUEsU0FBQSxHQUFoQixFQUFnQixHQUFBLGlCQUFBO01BQVosS0FBWSxHQUFBLElBQUEsQ0FBWixLQUFZLENBQUE7O0VBQzFFLElBQU0sUUFBQSxHQUFXLElBQUEsQ0FBSyxLQUFMLENBQVcsR0FBWCxDQUFqQixDQUFBO0VBQ0EsSUFBTSxRQUFBLEdBQVcsR0FBQSxLQUFRLFFBQVIsR0FBbUIsRUFBbkIsR0FBQSxhQUFBLEdBQXNDLFFBQXRDLEdBQUEsUUFBakIsQ0FBQTtFQUNBLElBQU0sY0FBQSxHQUFpQixDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEsYUFBQSxFQUFjLEtBQWQsQ0FBdkIsQ0FBQTtFQUNBLE9BQU8sQ0FBQSxDQUFBLEVBQUEsV0FBQSxDQUFBLEdBQUEsRUFDTCxFQUFFLEtBQUEsRUFBTyxZQUFULEVBREs7O0VBR0wsQ0FBQSxDQUFBLEVBQUEsV0FBQSxDQUFBLG1CQUFBLEVBQ0UsT0FERixFQUFBLEVBQUEsSUFHSSxjQUFBLEdBQ0ksdUJBREosR0FBQSxxQkFBQSxHQUUwQixRQUYxQixHQUVxQyxRQUx6QyxDQUFBLEVBT0UsRUFBRSxNQUFBLEVBQVEsR0FBVixFQUFlLFVBQUEsRUFBWSxVQUFBLElBQWMsR0FBekMsRUFBOEMsS0FBQSxFQUFPLGNBQXJELEVBUEYsQ0FISyxDQUFQLENBQUE7Q0FKRixDQUFBOztBQW1CQSxJQUFNLGFBQUEsR0FBZ0IsU0FBaEIsYUFBZ0IsQ0FBQSxLQUFBLEVBVWpCO0VBQUEsSUFBQSxvQkFBQSxHQUFBLEtBQUEsQ0FSRCxjQVFDO01BUEMsS0FPRCxHQUFBLG9CQUFBLENBUEMsS0FPRDtNQU5DLFVBTUQsR0FBQSxvQkFBQSxDQU5DLFVBTUQ7TUFMb0IsS0FLcEIsR0FBQSxvQkFBQSxDQUxDLGVBS0QsQ0FMb0IsS0FLcEIsQ0FBQTtFQUFBLElBRkgsY0FFRyxHQUFBLFNBQUEsQ0FBQSxNQUFBLEdBQUEsQ0FBQSxJQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsS0FBQSxTQUFBLEdBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxHQUZjLGlCQUVkLENBQUE7RUFBQSxJQURILFVBQ0csR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLENBQUE7O0VBQ0gsSUFBTSxjQUFBLEdBQWlCLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxhQUFBLEVBQWMsVUFBZCxDQUF2QixDQUFBO0VBQ0EsSUFBTSxTQUFBLEdBQ0osT0FBTyxjQUFQLEtBQTBCLFFBQTFCLEdBQXFDLFFBQUEsQ0FBUyxjQUFULENBQXdCLGNBQXhCLENBQXJDLEdBQStFLGNBRGpGLENBQUE7Ozs7RUFLQSxJQUFNLGNBQUEsR0FBaUIsS0FBQSxHQUFRLEtBQVIsR0FBZ0IsQ0FBdkMsQ0FBQTs7RUFFQSxDQUFBLENBQUEsRUFBQSxJQUFBLENBQUEsZ0JBQUEsRUFBaUIsQ0FDZjtJQUNFLE9BQUEsRUFBUyxTQURYO0lBRUUsTUFBQSxFQUFRLFNBQUEsQ0FBVSxFQUFFLEdBQUEsRUFBSyxjQUFQLEVBQXVCLFVBQUEsRUFBQSxVQUF2QixFQUFtQyxLQUFBLEVBQU8sY0FBMUMsRUFBVixDQUFBO0dBSEssQ0FBakIsQ0FBQSxDQUFBO0NBbkJGLENBQUE7O1FBMkJTLFlBQUE7eURBQVc7OztBQ2xEcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7OztBQy9DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUMvQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7O0FDL0NBOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxFOztBQUNaOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxFOztBQUNaOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxFOztBQUNaOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxFOztBQUNaOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxFOztBQUNaOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxJOztBQUNaOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxFOztBQUNaOztJQUFZLEU7O0FBQ1o7O0lBQVksRTs7QUFDWjs7SUFBWSxFOztBQUNaOztJQUFZLEU7Ozs7QUFFWixJQUFNLFVBQVU7QUFDZCxXQUFTLEVBREs7QUFFZCxXQUFTLEVBRks7QUFHZCxXQUFTLEVBSEs7QUFJZCxXQUFTLEVBSks7QUFLZCxXQUFTLEVBTEs7QUFNZCxXQUFTLEVBTks7QUFPZCxXQUFTLEVBUEs7QUFRZCxXQUFTLEVBUks7QUFTZCxXQUFTLEVBVEs7QUFVZCxXQUFTLEVBVks7QUFXZCxXQUFTLEVBWEs7QUFZZCxXQUFTLEVBWks7QUFhZCxXQUFTLEVBYks7QUFjZCxXQUFTLEVBZEs7QUFlZCxXQUFTLEVBZks7QUFnQmQsV0FBUyxFQWhCSztBQWlCZCxXQUFTLEVBakJLO0FBa0JkLFdBQVMsSUFsQks7QUFtQmQsV0FBUyxFQW5CSztBQW9CZCxXQUFTLEVBcEJLO0FBcUJkLFdBQVMsRUFyQks7QUFzQmQsV0FBUyxFQXRCSztBQXVCZCxXQUFTLEVBdkJLO0FBd0JkLFdBQVMsRUF4Qks7QUF5QmQsV0FBUztBQXpCSyxDQUFoQjs7a0JBNEJlLE87OztBQ3REZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUM3Q0EsSUFBQSxRQUFBLEdBQUEsT0FBQSxDQUFBLFNBQUEsQ0FBQSxDQUFBOzs7O0FBQ0EsSUFBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLFFBQUEsQ0FBQSxDQUFBOzs7O0FBQ0EsSUFBQSxZQUFBLEdBQUEsT0FBQSxDQUFBLGdCQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLFFBQUEsR0FBQSxPQUFBLENBQUEsWUFBQSxDQUFBLENBQUE7Ozs7Ozs7QUFHQSxJQUFNLE1BQUEsR0FBUyxTQUFULE1BQVMsQ0FBQyxVQUFELEVBQWdCO0VBQzdCLElBQUksSUFBQSxHQUFPLEVBQVgsQ0FBQTtFQUNBLElBQU0sUUFBQSxHQUFXLGdFQUFqQixDQUFBO0VBQ0EsS0FBSyxJQUFJLENBQUEsR0FBSSxDQUFiLEVBQWdCLENBQUEsR0FBSSxVQUFwQixFQUFnQyxDQUFBLEVBQWhDLEVBQXFDO0lBQ25DLElBQUEsSUFBUSxRQUFBLENBQVMsTUFBVCxDQUFnQixJQUFBLENBQUssS0FBTCxDQUFXLElBQUEsQ0FBSyxNQUFMLEVBQUEsR0FBZ0IsUUFBQSxDQUFTLE1BQXBDLENBQWhCLENBQVIsQ0FBQTtHQUNEO0VBQ0QsT0FBTyxJQUFQLENBQUE7Q0FORixDQUFBOzs7QUFVQSxJQUFNLE9BQUEsR0FBVSxTQUFWLE9BQVUsQ0FBQyxHQUFELEVBQU0sTUFBTixFQUFBO0VBQUEsT0FDZCxJQUFJLFNBQUEsQ0FBQSxPQUFKLENBQVksVUFBQyxPQUFELEVBQVUsSUFBVixFQUFtQjtJQUM3QixJQUFJLE1BQUEsR0FBQSxLQUFBLENBQUosQ0FBQTtJQUNBLElBQUksR0FBQSxHQUFBLEtBQUEsQ0FBSixDQUFBOztJQUVBLElBQUksR0FBQSxDQUFJLE9BQUosQ0FBWSxHQUFaLENBQUEsS0FBcUIsQ0FBekIsRUFBNEI7TUFDMUIsTUFBQSxHQUFTLE1BQUEsSUFBVSxFQUFuQixDQUFBOztNQUQwQixJQUFBLHFCQUFBLEdBRVIsQ0FBQSxDQUFBLEVBQUEsWUFBQSxDQUFBLFdBQUEsR0FGUTtVQUVsQixLQUZrQixHQUFBLHFCQUFBLENBRWxCLEtBRmtCLENBQUE7O01BRzFCLElBQUksS0FBSixFQUFXO1FBQ1QsTUFBQSxDQUFPLE1BQVAsR0FBZ0IsTUFBQSxDQUFPLEVBQVAsQ0FBaEIsQ0FBQTtPQUNEO0tBQ0Y7O0lBRUQsSUFBSSxHQUFBLENBQUksT0FBSixDQUFZLE1BQVosQ0FBQSxLQUF3QixDQUE1QixFQUErQjs7TUFFN0IsR0FBQSxHQUFNLEdBQUEsQ0FBSSxPQUFKLENBQVksVUFBWixFQUF3QixRQUF4QixDQUFOLENBQUE7S0FGRixNQUdPLElBQUksR0FBQSxDQUFJLE9BQUosQ0FBWSxHQUFaLENBQUEsS0FBcUIsQ0FBekIsRUFBNEI7O01BRWpDLEdBQUEsR0FBTSxDQUFBLENBQUEsRUFBQSxTQUFBLENBQUEsT0FBQSxHQUFBLEdBQXFCLEdBQTNCLENBQUE7S0FGSyxNQUdBOztNQUVMLE9BQU8sSUFBQSxFQUFQLENBQUE7S0FDRDs7SUFFRCxPQUFPLENBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxPQUFBLEVBQUk7TUFDVCxHQUFBLEVBQUEsR0FEUztNQUVULElBQUEsRUFBTSxNQUZHO01BR1QsT0FBQSxFQUFTLE9BSEE7TUFJVCxLQUFBLEVBQU8sSUFBQTtLQUpGLENBQVAsQ0FBQTtHQXZCRixDQURjLENBQUE7Q0FBaEIsQ0FBQTs7UUFnQ1MsVUFBQTs7Ozs7Ozs7O0FDaERUOztBQUVBLFNBQVMsSUFBVCxHQUFnQjtBQUNkLE1BQU0sUUFBUSxVQUFVLFNBQVYsQ0FBb0IsV0FBcEIsRUFBZDtBQUNBLFNBQU8sTUFBTSxPQUFOLENBQWMsTUFBZCxLQUF5QixDQUFDLENBQTFCLEdBQThCLFNBQVMsTUFBTSxLQUFOLENBQVksTUFBWixFQUFvQixDQUFwQixDQUFULENBQTlCLEdBQWlFLEtBQXhFO0FBQ0Q7O0FBRUQ7O0FBRUEsU0FBUyxLQUFULENBQWUsR0FBZixFQUFvQjtBQUNsQixNQUFJO0FBQ0YsV0FBTyxLQUFLLEtBQUwsQ0FBVyxJQUFJLFlBQWYsQ0FBUDtBQUNELEdBRkQsQ0FFRSxPQUFPLENBQVAsRUFBVTtBQUNWLFdBQU8sSUFBSSxZQUFYO0FBQ0Q7QUFDRjs7QUFFRDtBQUNBLFNBQVMsYUFBVCxDQUF1QixHQUF2QixFQUE0QjtBQUMxQixNQUFNLE1BQU0sRUFBWjtBQUNBLE9BQUssSUFBTSxDQUFYLElBQWdCLEdBQWhCLEVBQXFCO0FBQ25CLFFBQUksSUFBSSxjQUFKLENBQW1CLENBQW5CLENBQUosRUFBMkI7QUFDekIsVUFBSSxJQUFKLENBQVksbUJBQW1CLENBQW5CLENBQVosU0FBcUMsbUJBQW1CLElBQUksQ0FBSixDQUFuQixDQUFyQztBQUNEO0FBQ0Y7QUFDRCxTQUFPLElBQUksSUFBSixDQUFTLEdBQVQsQ0FBUDtBQUNEOztBQUVELFNBQVMsSUFBVCxHQUFnQixDQUFFOztBQUVsQixTQUFTLFdBQVQsQ0FBcUIsTUFBckIsRUFBNkI7QUFDM0IsTUFBTSxpQkFBaUIsT0FBTyxjQUFQLElBQXlCLGFBQWhEO0FBQ0EsTUFBTSxVQUFVLElBQUksY0FBSixDQUFtQixvQkFBbkIsQ0FBaEI7QUFDQSxVQUFRLElBQVIsQ0FBYSxPQUFPLElBQXBCLEVBQTBCLE9BQU8sR0FBakMsRUFBc0MsSUFBdEM7QUFDQSxVQUFRLGdCQUFSLENBQXlCLGNBQXpCLEVBQXlDLG1DQUF6QztBQUNBLFVBQVEsa0JBQVIsR0FBNkIsWUFBWTtBQUN2QyxRQUFJLFFBQVEsVUFBUixLQUF1QixDQUEzQixFQUE4QjtBQUM1QixVQUFJLFFBQVEsTUFBUixJQUFrQixHQUFsQixJQUF5QixRQUFRLE1BQVIsR0FBaUIsR0FBOUMsRUFBbUQ7QUFDakQsZUFBTyxPQUFQLENBQWUsTUFBTSxPQUFOLENBQWY7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPLEtBQVAsQ0FBYSxNQUFNLE9BQU4sQ0FBYjtBQUNEO0FBQ0Y7QUFDRixHQVJEOztBQVVBLFVBQVEsSUFBUixDQUFhLE9BQU8sSUFBcEI7QUFDRDs7QUFFRDs7Ozs7Ozs7QUFRQSxTQUFTLGFBQVQsQ0FBdUIsTUFBdkIsRUFBK0I7QUFDN0IsTUFBTSxVQUFVLElBQUksT0FBTyxjQUFYLEVBQWhCO0FBQ0EsTUFBTSxXQUFXLE9BQU8sUUFBUCxDQUFnQixRQUFqQztBQUNBLFNBQU8sR0FBUCxHQUFhLE9BQU8sR0FBUCxDQUFXLE9BQVgsQ0FBbUIsU0FBbkIsRUFBOEIsUUFBOUIsQ0FBYjtBQUNBLFVBQVEsSUFBUixDQUFhLE9BQU8sSUFBcEIsRUFBMEIsT0FBTyxHQUFqQztBQUNBLFVBQVEsTUFBUixHQUFpQixZQUFZO0FBQzNCLFdBQU8sT0FBUCxDQUFlLE1BQU0sT0FBTixDQUFmO0FBQ0QsR0FGRDtBQUdBLFVBQVEsT0FBUixHQUFrQixZQUFZO0FBQzVCLFdBQU8sS0FBUCxDQUFhLE1BQU0sT0FBTixDQUFiO0FBQ0QsR0FGRDs7QUFJQSxhQUFXLFlBQVk7QUFDckIsWUFBUSxJQUFSLENBQWEsT0FBTyxJQUFwQjtBQUNELEdBRkQsRUFFRyxDQUZIO0FBR0Q7O0FBRUQsU0FBUyxHQUFULENBQWEsT0FBYixFQUFzQjtBQUNwQixNQUFNLFNBQVM7QUFDYixVQUFNLFFBQVEsSUFBUixJQUFnQixLQURUO0FBRWIsV0FBTyxRQUFRLEtBQVIsSUFBaUIsSUFGWDtBQUdiLGFBQVMsUUFBUSxPQUFSLElBQW1CLElBSGY7QUFJYixVQUFNLFFBQVEsSUFKRDtBQUtiLFNBQUssUUFBUSxHQUFSLElBQWU7QUFMUCxHQUFmOztBQVFBLE1BQUksT0FBTyxJQUFQLEtBQWdCLEtBQWhCLElBQXlCLE9BQU8sSUFBcEMsRUFBMEM7QUFDeEMsV0FBTyxHQUFQLEdBQWdCLE9BQU8sR0FBdkIsU0FBOEIsY0FBYyxPQUFPLElBQXJCLENBQTlCO0FBQ0EsV0FBTyxPQUFPLElBQWQ7QUFDRDs7QUFFRCxNQUFJLFVBQVUsVUFBVSxDQUF4QixFQUEyQjtBQUN6QixrQkFBYyxNQUFkO0FBQ0QsR0FGRCxNQUVPO0FBQ0wsZ0JBQVksTUFBWjtBQUNEO0FBQ0Y7O2tCQUVjLEc7Ozs7Ozs7OztrQkM3RkEsWUFBWTtBQUN6QixNQUFNLE9BQU8sbUJBQWI7QUFDQSxTQUFPLEtBQUssT0FBTCxDQUFhLEdBQWIsTUFBc0IsQ0FBdEIsR0FBMEIsK0JBQTFCLEdBQTRELElBQW5FO0FBQ0QsQzs7O0FDSkQ7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNIQSxJQUFBLFFBQUEsR0FBQSxPQUFBLENBQUEsU0FBQSxDQUFBLENBQUE7Ozs7QUFDQSxJQUFBLEtBQUEsR0FBQSxPQUFBLENBQUEsUUFBQSxDQUFBLENBQUE7O0FBQ0EsSUFBQSxNQUFBLEdBQUEsT0FBQSxDQUFBLFVBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsT0FBQSxHQUFBLE9BQUEsQ0FBQSxxQkFBQSxDQUFBLENBQUE7O0FBQ0EsSUFBQSxjQUFBLEdBQUEsT0FBQSxDQUFBLDRCQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLGNBQUEsR0FBQSxPQUFBLENBQUEsa0JBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQSxPQUFBLENBQUEsQ0FBQTs7Ozs7Ozs7Ozs7OztBQU9BLElBQU0sb0JBQUEsR0FBdUIsOEJBQTdCLENBQUE7Ozs7Ozs7QUFPQSxJQUFNLG1CQUFBLEdBQXNCLFNBQXRCLG1CQUFzQixDQUFDLGlCQUFELEVBQXVCO0VBQ2pELElBQU0sSUFBQSxHQUFPLE1BQUEsQ0FBTyxJQUFQLENBQVksaUJBQVosQ0FBYixDQUFBO0VBQ0EsT0FBTyxvQkFBQSxJQUF3QixpQkFBeEIsSUFBNkMsSUFBQSxDQUFLLE1BQUwsS0FBZ0IsQ0FBN0QsR0FDSCxpQkFBQSxDQUFrQixvQkFBbEIsQ0FERyxHQUVILGlCQUZKLENBQUE7Q0FGRixDQUFBOzs7OztBQVVBLElBQU0saUJBQUEsR0FBb0IsU0FBcEIsaUJBQW9CLENBQUEsSUFBQSxFQUFBO0VBQUEsSUFFSCxLQUZHLEdBQUEsSUFBQSxDQUN4QixjQUR3QixDQUV0QixlQUZzQixDQUVILEtBRkcsQ0FBQTtFQUFBLE9BSXBCLEtBQUEsR0FBUSxDQUpZLENBQUE7Q0FBMUIsQ0FBQTs7Ozs7Ozs7QUFZQSxJQUFNLDJCQUFBLEdBQThCLFNBQTlCLDJCQUE4QixDQUFDLFFBQUQsRUFBYztFQUNoRCxJQUFNLElBQUEsR0FBTyxNQUFBLENBQU8sSUFBUCxDQUFZLFFBQVosQ0FBYixDQUFBO0VBQ0EsT0FBTyxJQUFBLENBQUssSUFBTCxDQUFVLFVBQUMsQ0FBRCxFQUFBO0lBQUEsT0FBTyxpQkFBQSxDQUFrQixRQUFBLENBQVMsQ0FBVCxDQUFsQixDQUFQLENBQUE7R0FBVixDQUFQLENBQUE7Q0FGRixDQUFBOzs7OztBQVFBLElBQU0saUJBQUEsR0FBb0IsU0FBcEIsaUJBQW9CLENBQUEsS0FBQSxFQUE4RDtFQUFBLElBQTNELHFCQUEyRCxHQUFBLEtBQUEsQ0FBM0QscUJBQTJEO01BQXBDLDZCQUFvQyxHQUFBLEtBQUEsQ0FBcEMsNkJBQW9DLENBQUE7O0VBQ3RGLElBQU0sbUJBQUEsR0FBc0IscUJBQUEsR0FDeEIscUJBQUEsQ0FBc0IsZUFBdEIsQ0FBc0MsS0FEZCxHQUV4QixDQUZKLENBQUE7RUFHQSxJQUFNLDJCQUFBLEdBQThCLDZCQUFBLEdBQ2hDLDZCQUFBLENBQThCLGVBQTlCLENBQThDLEtBRGQsR0FFaEMsQ0FGSixDQUFBOztFQUlBLE9BQU8sbUJBQUEsR0FBc0IsMkJBQXRCLEdBQW9ELENBQTNELENBQUE7Q0FSRixDQUFBOzs7QUFZQSxJQUFNLFlBQUEsR0FBZSxTQUFmLFlBQWUsQ0FBQyxHQUFELEVBQUE7RUFBQSxPQUFTLFVBQUEsS0FBQSxFQUF5QztJQUFBLElBQXRDLGNBQXNDLEdBQUEsS0FBQSxDQUF0QyxjQUFzQztRQUF0QixNQUFzQixHQUFBLEtBQUEsQ0FBdEIsTUFBc0I7UUFBWCxJQUFXLEdBQUEsd0JBQUEsQ0FBQSxLQUFBLEVBQUEsQ0FBQSxnQkFBQSxFQUFBLFFBQUEsQ0FBQSxDQUFBLENBQUE7O0lBQ3JFLElBQU0sY0FBQSxHQUFpQixDQUFBLENBQUEsRUFBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxRQUFBLENBQUE7TUFDckIsY0FBQSxFQUFBLGNBRHFCO01BRXJCLE1BQUEsRUFBQSxNQUFBO0tBRnFCLEVBR2xCLElBSGtCLEVBQUE7TUFJckIsS0FBQSxFQUFPLElBSmM7S0FBQSxDQUFBLENBQXZCLENBQUE7SUFNQSxPQUFPLENBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxPQUFBLEVBQVEsR0FBUixFQUFhLGNBQWIsQ0FBUCxDQUFBO0dBUG1CLENBQUE7Q0FBckIsQ0FBQTs7Ozs7O0FBY0EsSUFBTSw0QkFBQSxHQUErQixTQUEvQiw0QkFBK0IsQ0FDbkMsaUJBRG1DLEVBQUE7RUFBQSxJQUVuQyxXQUZtQyxHQUFBLFNBQUEsQ0FBQSxNQUFBLEdBQUEsQ0FBQSxJQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsS0FBQSxTQUFBLEdBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxHQUVyQixLQUZxQixDQUFBO0VBQUEsSUFHbkMsc0JBSG1DLEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBR1YsaUJBSFUsQ0FBQTtFQUFBLE9BSWhDLFVBQUEsS0FBQSxFQUFrRTtJQUFBLElBQS9ELFFBQStELEdBQUEsS0FBQSxDQUEvRCxRQUErRDtRQUFyRCxNQUFxRCxHQUFBLEtBQUEsQ0FBckQsTUFBcUQ7UUFBN0MsS0FBNkMsR0FBQSxLQUFBLENBQTdDLEtBQTZDO1FBQXRDLGNBQXNDLEdBQUEsS0FBQSxDQUF0QyxjQUFzQztRQUF0QixlQUFzQixHQUFBLEtBQUEsQ0FBdEIsZUFBc0IsQ0FBQTs7SUFDckUsSUFBTSxVQUFBLEdBQWEsc0JBQUEsQ0FBdUIsUUFBdkIsQ0FBbkIsQ0FBQTs7SUFFQSxpQkFBQSxDQUFrQjtNQUNoQixRQUFBLEVBQUEsUUFEZ0I7TUFFaEIsTUFBQSxFQUFBLE1BRmdCO01BR2hCLGNBQUEsRUFBQSxjQUhnQjtNQUloQixlQUFBLEVBQUEsZUFBQTtLQUpGLENBQUEsQ0FBQTs7O0lBUUEsSUFBTSxlQUFBLEdBQWtCLFNBQWxCLGVBQWtCLENBQUEsS0FBQSxFQUFxQjtNQUFBLElBQVosS0FBWSxHQUFBLEtBQUEsQ0FBbEIsSUFBa0IsQ0FBQTs7TUFDM0MsSUFBSSxDQUFBLENBQUEsRUFBQSxjQUFBLENBQUEsZUFBQSxFQUFnQixLQUFoQixDQUFKLEVBQTRCO1FBQzFCLENBQUEsQ0FBQSxFQUFBLGNBQUEsQ0FBQSxrQkFBQSxFQUFtQjtVQUNqQixRQUFBLEVBQUEsUUFEaUI7VUFFakIsTUFBQSxFQUFBLE1BQUE7U0FGRixDQUFBLENBQUE7T0FJRDtLQU5ILENBQUE7SUFRQSxJQUFJLFdBQUosRUFBaUI7TUFDZixDQUFBLENBQUEsRUFBQSxjQUFBLENBQUEsV0FBQSxFQUFZLGVBQVosQ0FBQSxDQUFBO0tBQ0Q7O0lBRUQsQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLFlBQUEsRUFBYSxLQUFiLEVBQW9CLFVBQXBCLENBQUEsQ0FBQTtJQUNBLENBQUEsQ0FBQSxFQUFBLGNBQUEsQ0FBQSxtQkFBQSxHQUFBLENBQUE7R0E1Qm1DLENBQUE7Q0FBckMsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE4Q0EsSUFBTSxjQUFBLEdBQWlCLFNBQWpCLGNBQWlCLENBQUMsR0FBRCxFQUFBO0VBQUEsT0FBUyxVQUM5QixpQkFEOEIsRUFFOUIsaUJBRjhCLEVBRzlCLFdBSDhCLEVBSTlCLHNCQUo4QixFQUszQjtJQUNILElBQU0sZ0JBQUEsR0FBbUIsaUJBQUEsQ0FBa0IsTUFBQSxDQUFPLElBQVAsQ0FBWSxpQkFBWixDQUFBLENBQStCLENBQS9CLENBQWxCLENBQXpCLENBQUE7SUFERyxJQUVLLE1BRkwsR0FFaUMsZ0JBRmpDLENBRUssTUFGTDtRQUFBLHFCQUFBLEdBRWlDLGdCQUZqQyxDQUVhLEtBRmI7UUFFYSxLQUZiLEdBQUEscUJBQUEsS0FBQSxTQUFBLEdBRXFCLE9BRnJCLEdBQUEscUJBQUEsQ0FBQTs7O0lBSUgsSUFBTSxnQkFBQSxHQUFtQixDQUFBLENBQUEsRUFBQSxHQUFBLENBQUEsZ0JBQUEsRUFBaUIsQ0FBQSxDQUFBLEVBQUEsR0FBQSxDQUFBLFNBQUEsRUFBVSxZQUFBLENBQWEsR0FBYixDQUFWLEVBQTZCLGlCQUE3QixDQUFqQixDQUF6QixDQUFBO0lBQ0EsSUFBTSxZQUFBLEdBQWUsQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLGNBQUEsR0FBckIsQ0FBQTs7O0lBR0EsSUFBTSxZQUFBLEdBQWUsU0FBQSxDQUFBLE9BQUEsQ0FBUSxHQUFSLENBQVksQ0FBQyxnQkFBRCxFQUFtQixZQUFuQixDQUFaLENBQUEsQ0FDbEIsSUFEa0IsQ0FDYixVQUFBLEtBQUEsRUFBd0I7TUFBQSxJQUFBLEtBQUEsR0FBQSxjQUFBLENBQUEsS0FBQSxFQUFBLENBQUEsQ0FBQTtVQUF0QixnQkFBc0IsR0FBQSxLQUFBLENBQUEsQ0FBQSxDQUFBLENBQUE7O01BQzVCLElBQU0sUUFBQSxHQUFXLG1CQUFBLENBQW9CLGdCQUFwQixDQUFqQixDQUFBOztNQUVBLE9BQU87UUFDTCxRQUFBLEVBQUEsUUFESztRQUVMLE1BQUEsRUFBQSxNQUZLO1FBR0wsS0FBQSxFQUFBLEtBQUE7T0FIRixDQUFBO0tBSmlCLENBQUEsQ0FVbEIsSUFWa0IsQ0FVYiw0QkFBQSxDQUE2QixpQkFBN0IsRUFBZ0QsV0FBaEQsRUFBNkQsc0JBQTdELENBVmEsQ0FBQSxDQVdsQixLQVhrQixDQVdaLFVBQUMsQ0FBRCxFQUFPO01BQ1osSUFBSSxDQUFBLElBQUssQ0FBQSxDQUFFLFlBQVgsRUFBeUI7O1FBRXZCLE9BQU8sQ0FBQSxDQUFBLEVBQUEsY0FBQSxDQUFBLGFBQUEsR0FBUCxDQUFBO09BQ0Q7O0tBZmdCLENBQXJCLENBQUE7O0lBbUJBLENBQUEsQ0FBQSxFQUFBLE9BQUEsQ0FBQSxVQUFBLEVBQVcsWUFBWCxDQUFBLENBQUE7R0FoQ3FCLENBQUE7Q0FBdkIsQ0FBQTs7O0FBb0NBLElBQU0sU0FBQSxHQUFZLFNBQVosU0FBWSxDQUFDLEdBQUQsRUFBQTtFQUFBLE9BQVMsVUFDekIsV0FEeUIsRUFFekIsaUJBRnlCLEVBR3pCLFdBSHlCLEVBSXpCLHNCQUp5QixFQUt0QjtJQUNILElBQU0saUJBQUEsR0FBQSxlQUFBLENBQUEsRUFBQSxFQUF1QixvQkFBdkIsRUFBOEMsV0FBOUMsQ0FBTixDQUFBO0lBQ0EsY0FBQSxDQUFlLEdBQWYsQ0FBQSxDQUFvQixpQkFBcEIsRUFBdUMsaUJBQXZDLEVBQTBELFdBQTFELEVBQXVFLHNCQUF2RSxDQUFBLENBQUE7R0FQZ0IsQ0FBQTtDQUFsQixDQUFBOztRQVdFLFlBQUE7UUFDQSxpQkFBQTt3RUFDQTtRQUNBLG9CQUFBO1FBQ0EsOEJBQUE7UUFDQSxvQkFBQTs7Ozs7Ozs7Ozs7O0FDOUtGLElBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxZQUFBLENBQUEsQ0FBQTs7QUFFQSxJQUFNLE9BQUEsR0FBVSxNQUFBLENBQU8sTUFBdkIsQ0FBQTtBQUNBLElBQU0sWUFBQSxHQUFlLEVBQXJCLENBQUE7QUFDQSxJQUFNLGNBQUEsR0FBaUI7RUFDckIsT0FBQSxFQUFTLGNBRFk7RUFFckIsUUFBQSxFQUFVLFlBRlc7RUFHckIsSUFBQSxFQUFNLEtBSGU7RUFJckIsTUFBQSxFQUFRLFlBSmE7RUFLckIsV0FBQSxFQUFhLEVBQUE7Q0FMZixDQUFBO0FBT0EsSUFBTSxZQUFBLEdBQWU7RUFDbkIsSUFBQSxFQUFNLE9BRGE7RUFFbkIsS0FBQSxFQUFPLEtBRlk7RUFHbkIsTUFBQSxFQUFRO0lBQ04sTUFBQSxFQUFRLE9BREY7SUFFTixLQUFBLEVBQU8sRUFBQTtHQUZEO0NBSFYsQ0FBQTtBQVFBLElBQU0sWUFBQSxHQUFlO0VBQ25CLElBQUEsRUFBTSxPQURhO0VBRW5CLEtBQUEsRUFBTyxJQUZZO0VBR25CLE1BQUEsRUFBUTtJQUNOLEtBQUEsRUFBTyxNQUREO0lBRU4sTUFBQSxFQUFRLE1BRkY7SUFHTixRQUFBLEVBQVUsT0FISjtJQUlOLElBQUEsRUFBTSxHQUpBO0lBS04sS0FBQSxFQUFPLEdBTEQ7SUFNTixHQUFBLEVBQUssR0FOQztJQU9OLE1BQUEsRUFBUSxHQVBGO0lBUU4sTUFBQSxFQUFRLFFBUkY7SUFTTixNQUFBLEVBQVEsRUFBQTtHQVRGO0NBSFYsQ0FBQTs7QUFnQkEsSUFBSSxFQUFBLEdBQUssSUFBVCxDQUFBO0FBQ0EsSUFBTSxpQkFBQSxHQUFvQixFQUExQixDQUFBOztBQUVBLFNBQVMsV0FBVCxDQUFxQixPQUFyQixFQUE4QjtFQUM1QixJQUFJLEVBQUosRUFBUTtJQUNOLE9BQUEsQ0FBUSxRQUFSLEdBQW1CLEVBQW5CLENBQUE7SUFDQSxPQUFBLEdBQVUsSUFBQSxDQUFLLFNBQUwsQ0FBZSxPQUFmLENBQVYsQ0FGTTtJQUdOLE9BQUEsQ0FBUSxXQUFSLENBQW9CLE9BQXBCLEVBQTZCLEdBQTdCLENBQUEsQ0FBQTtHQUhGLE1BSU87SUFDTCxZQUFBLENBQWEsSUFBYixDQUFrQixPQUFsQixDQUFBLENBQUE7R0FDRDtDQUNGOztBQUVELFNBQVMsYUFBVCxDQUF1QixNQUF2QixFQUErQjtFQUM3QixPQUFPLFVBQUMsT0FBRCxFQUFBO0lBQUEsSUFBVSxPQUFWLEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQW9CLEVBQXBCLENBQUE7SUFBQSxPQUNMLFdBQUEsQ0FBQSxRQUFBLENBQUEsRUFBQSxFQUNLLE9BREwsRUFBQTtNQUVFLE9BQUEsRUFBQSxPQUZGO01BR0UsT0FBQSxFQUFTLFNBSFg7TUFJRSxJQUFBLEVBQU0sTUFBQTtLQUpSLENBQUEsQ0FESyxDQUFBO0dBQVAsQ0FBQTtDQU9EOztBQUVELFNBQVMsU0FBVCxHQUFxQjtFQUNuQixPQUFPLFlBQUEsQ0FBYSxNQUFwQixFQUE0QjtJQUMxQixXQUFBLENBQVksWUFBQSxDQUFhLEdBQWIsRUFBWixDQUFBLENBQUE7R0FDRDtDQUNGOztBQUVELFNBQVMsaUJBQVQsQ0FBMkIsT0FBM0IsRUFBb0M7RUFDbEMsV0FBQSxDQUFBLFFBQUEsQ0FBQSxFQUFBLEVBQ0ssY0FETCxFQUVLLFlBRkwsRUFHSyxPQUhMLENBQUEsQ0FBQSxDQUFBO0NBS0Q7O0FBRUQsU0FBUyxpQkFBVCxDQUEyQixPQUEzQixFQUFvQztFQUNsQyxXQUFBLENBQUEsUUFBQSxDQUFBLEVBQUEsRUFDSyxjQURMLEVBRUssWUFGTCxFQUdLLE9BSEwsQ0FBQSxDQUFBLENBQUE7Q0FLRDs7QUFFRCxTQUFTLFNBQVQsQ0FBbUIsTUFBbkIsRUFBMkIsa0JBQTNCLEVBQStDO0VBQzdDLFdBQUEsQ0FBWSxFQUFFLE9BQUEsRUFBUyxVQUFYLEVBQXVCLElBQUEsRUFBTSxrQkFBN0IsRUFBaUQsS0FBQSxFQUFPLE1BQXhELEVBQVosQ0FBQSxDQUFBO0NBQ0Q7O0FBRUQsU0FBUyxVQUFULENBQW9CLFVBQXBCLEVBQWdDO0VBQzlCLFdBQUEsQ0FBWSxFQUFFLE9BQUEsRUFBUyxNQUFYLEVBQW1CLElBQUEsRUFBTSxVQUF6QixFQUFaLENBQUEsQ0FBQTtFQUNBLGFBQUEsQ0FBYyxNQUFkLENBQUEsQ0FBeUIsVUFBekIsR0FBQSxVQUFBLEVBQStDLEVBQUUsT0FBQSxFQUFTLElBQVgsRUFBL0MsQ0FBQSxDQUFBO0NBQ0Q7O0FBRUQsU0FBUyxVQUFULENBQW9CLFVBQXBCLEVBQWdDO0VBQzlCLFdBQUEsQ0FBWSxFQUFFLE9BQUEsRUFBUyxNQUFYLEVBQW1CLElBQUEsRUFBTSxVQUF6QixFQUFaLENBQUEsQ0FBQTtFQUNBLGFBQUEsQ0FBYyxNQUFkLENBQUEsQ0FBeUIsVUFBekIsR0FBQSxVQUFBLEVBQStDLEVBQUUsT0FBQSxFQUFTLEtBQVgsRUFBL0MsQ0FBQSxDQUFBO0NBQ0Q7O0FBRUQsU0FBUyxXQUFULENBQXFCLFVBQXJCLEVBQWlDO0VBQy9CLFdBQUEsQ0FBWSxFQUFFLE9BQUEsRUFBUyxPQUFYLEVBQW9CLElBQUEsRUFBTSxVQUExQixFQUFaLENBQUEsQ0FBQTtDQUNEOztBQUVELFNBQVMsaUJBQVQsR0FBNkI7RUFDM0IsV0FBQSxDQUFZLEVBQUUsT0FBQSxFQUFTLFFBQVgsRUFBWixDQUFBLENBQUE7Q0FDRDs7QUFFRCxTQUFTLGVBQVQsQ0FBeUIsT0FBekIsRUFBa0M7RUFDaEMsT0FBTyxPQUFBLEtBQVksUUFBbkIsQ0FBQTtDQUNEOzs7OztBQUtELFNBQVMsa0JBQVQsQ0FBNEIsSUFBNUIsRUFBa0M7RUFDaEMsYUFBQSxDQUFjLE9BQWQsQ0FBQSxDQUF1QixVQUF2QixFQUFtQyxJQUFuQyxDQUFBLENBQUE7Q0FDRDs7Ozs7OztBQU9ELFNBQVMsbUJBQVQsQ0FBNkIsT0FBN0IsRUFBc0MsWUFBdEMsRUFBb0Q7RUFDbEQsT0FBTyxDQUFDLFNBQUQsRUFBWSxTQUFaLEVBQXVCLE1BQXZCLENBQUEsQ0FBK0IsS0FBL0IsQ0FDTCxVQUFDLEdBQUQsRUFBQTtJQUFBLE9BQVMsT0FBQSxDQUFRLEdBQVIsQ0FBQSxJQUFnQixZQUFBLENBQWEsR0FBYixDQUFoQixJQUFxQyxPQUFBLENBQVEsR0FBUixDQUFBLEtBQWlCLFlBQUEsQ0FBYSxHQUFiLENBQS9ELENBQUE7R0FESyxDQUFQLENBQUE7Q0FHRDs7QUFFRCxTQUFTLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DO0VBQ2pDLE9BQU8sbUJBQUEsQ0FBb0IsT0FBcEIsRUFBNkI7SUFDbEMsT0FBQSxFQUFTLFNBRHlCO0lBRWxDLElBQUEsRUFBTSxPQUY0QjtJQUdsQyxPQUFBLEVBQVMsVUFBQTtHQUhKLENBQVAsQ0FBQTtDQUtEOztBQUVELFNBQVMsb0JBQVQsQ0FBOEIsT0FBOUIsRUFBdUM7RUFDckMsT0FBTyxtQkFBQSxDQUFvQixPQUFwQixFQUE2QjtJQUNsQyxPQUFBLEVBQVMsU0FEeUI7SUFFbEMsSUFBQSxFQUFNLE1BRjRCO0lBR2xDLE9BQUEsRUFBUyxlQUFBO0dBSEosQ0FBUCxDQUFBO0NBS0Q7O0FBRUQsU0FBUyxtQkFBVCxDQUE2QixJQUE3QixFQUFtQztFQUNqQyxpQkFBQSxDQUFrQixJQUFsQixDQUF1QixJQUF2QixDQUFBLENBQUE7Q0FDRDs7QUFFRCxTQUFTLGNBQVQsR0FBMEI7RUFDeEIsVUFBQSxDQUFXLE1BQVgsQ0FBQSxDQUFBO0NBQ0Q7O0FBRUQsU0FBUyxlQUFULEdBQTJCO0VBQ3pCLFVBQUEsQ0FBVyxPQUFYLENBQUEsQ0FBQTtDQUNEOztBQUVELFNBQVMsZUFBVCxHQUEyQjtFQUN6QixVQUFBLENBQVcsT0FBWCxDQUFBLENBQUE7Q0FDRDs7QUFFRCxTQUFTLGdCQUFULEdBQTRCO0VBQzFCLFdBQUEsQ0FBWSxPQUFaLENBQUEsQ0FBQTtDQUNEOztBQUVELFNBQVMsZUFBVCxHQUEyQjtFQUN6QixVQUFBLENBQVcsT0FBWCxDQUFBLENBQUE7Q0FDRDs7QUFFRCxTQUFTLGVBQVQsR0FBMkI7RUFDekIsVUFBQSxDQUFXLE9BQVgsQ0FBQSxDQUFBO0NBQ0Q7O0FBRUQsU0FBUyxnQkFBVCxHQUE0QjtFQUMxQixXQUFBLENBQVksT0FBWixDQUFBLENBQUE7Q0FDRDs7QUFFRCxJQUFNLFFBQUEsR0FBVyxTQUFYLFFBQVcsR0FBQTtFQUFBLE9BQU0sV0FBQSxDQUFZLEVBQUUsT0FBQSxFQUFTLE1BQVgsRUFBWixDQUFOLENBQUE7Q0FBakIsQ0FBQTs7QUFFQSxJQUFNLE1BQUEsR0FBUyxTQUFULE1BQVMsQ0FBQyxFQUFELEVBQVE7RUFDckIsSUFBTSxJQUFBLEdBQU8sU0FBUCxJQUFPLENBQUMsS0FBRCxFQUFXO0lBQ3RCLElBQUksS0FBQSxDQUFNLElBQU4sQ0FBVyxPQUFYLEtBQXVCLE1BQTNCLEVBQW1DO01BQ2pDLEVBQUEsQ0FBRyxLQUFILENBQUEsQ0FBQTtLQUNEO0dBSEgsQ0FBQTtFQUtBLG1CQUFBLENBQW9CLElBQXBCLENBQUEsQ0FBQTtDQU5GLENBQUE7O0FBU0EsU0FBUyxZQUFULENBQXNCLGNBQXRCLEVBQXNDLGtCQUF0QyxFQUEwRDtFQUN4RCxJQUFNLElBQUEsR0FBTyxRQUFBLENBQVMsb0JBQVQsQ0FBOEIsTUFBOUIsQ0FBQSxDQUFzQyxDQUF0QyxDQUFiLENBQUE7RUFDQSxXQUFBLENBQVk7SUFDVixPQUFBLEVBQVMsZUFEQztJQUVWLElBQUEsRUFBTSxrQkFGSTtJQUdWLE1BQUEsRUFBUSxjQUFBLElBQWtCLElBQUEsQ0FBSyxZQUFBO0dBSGpDLENBQUEsQ0FBQTtDQUtEOztBQUVELFNBQVMsZ0JBQVQsQ0FBMEIsT0FBMUIsRUFBbUM7RUFDakMsV0FBQSxDQUFZO0lBQ1YsT0FBQSxFQUFTLFVBREM7SUFFVixPQUFBLEVBQUEsT0FBQTtHQUZGLENBQUEsQ0FBQTtDQUlEOztBQUVELENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxnQkFBQSxFQUFpQixNQUFqQixFQUF5QixTQUF6QixFQUFvQyxVQUFTLEtBQVQsRUFBZ0I7RUFDbEQsSUFBSSxPQUFPLEtBQUEsQ0FBTSxJQUFiLEtBQXNCLFFBQTFCLEVBQW9DO0lBQ2xDLE9BQUE7R0FDRDs7RUFFRCxJQUFJLENBQUEsR0FBQSxLQUFBLENBQUosQ0FBQTtFQUNBLElBQUk7SUFDRixDQUFBLEdBQUksRUFBRSxJQUFBLEVBQU0sSUFBQSxDQUFLLEtBQUwsQ0FBVyxLQUFBLENBQU0sSUFBakIsQ0FBUixFQUFKLENBREU7R0FBSixDQUVFLE9BQU8sQ0FBUCxFQUFVO0lBQ1YsT0FEVTtHQUVYOztFQUVELElBQUksQ0FBQSxDQUFFLElBQUYsQ0FBTyxPQUFQLEtBQW1CLE9BQXZCLEVBQWdDO0lBQzlCLEVBQUEsR0FBSyxDQUFBLENBQUUsSUFBRixDQUFPLFFBQVosQ0FBQTtJQUNBLFNBQUEsRUFBQSxDQUFBO0dBRkYsTUFHTztJQUNMLEtBQUssSUFBSSxDQUFBLEdBQUksQ0FBYixFQUFnQixDQUFBLEdBQUksaUJBQUEsQ0FBa0IsTUFBdEMsRUFBOEMsQ0FBQSxFQUE5QyxFQUFtRDtNQUNqRCxJQUFNLFFBQUEsR0FBVyxpQkFBQSxDQUFrQixDQUFsQixDQUFqQixDQUFBO01BQ0EsUUFBQSxDQUFTLENBQVQsQ0FBQSxDQUFBO0tBQ0Q7R0FDRjtDQXBCSCxDQUFBLENBQUE7O2dEQXdCRTt1REFDQTt1REFDQTt3REFDQTtxREFDQTtxREFDQTtzREFDQTtxREFDQTtxREFDQTtzREFDQTtrREFDQTtxREFDQTt3REFDQTtRQUN1QixjQUF2QjtRQUNBLGtCQUFBO1FBQ0EscUJBQUE7NERBQ0E7Z0VBQ0E7UUFDWSxPQUFaO1FBQ0EsU0FBQTs0REFDQTs7Ozs7Ozs7Ozs7Ozs7QUNuUEYsSUFBQSxRQUFBLEdBQUEsT0FBQSxDQUFBLFNBQUEsQ0FBQSxDQUFBOzs7Ozs7Ozs7OztBQUdBLElBQU0sTUFBQSxHQUFTLFNBQVQsTUFBUyxDQUFDLENBQUQsRUFBQTtFQUFBLE9BQU8sVUFBQyxJQUFELEVBQUE7SUFBQSxPQUFVLFVBQUMsRUFBRCxFQUFBO01BQUEsT0FBUSxFQUFBLENBQUcsTUFBSCxDQUFVLENBQVYsRUFBYSxJQUFiLENBQVIsQ0FBQTtLQUFWLENBQUE7R0FBUCxDQUFBO0NBQWYsQ0FBQTs7O0FBR0EsSUFBTSxNQUFBLEdBQVMsU0FBVCxNQUFTLENBQUMsQ0FBRCxFQUFBO0VBQUEsT0FBTyxVQUFDLEVBQUQsRUFBQTtJQUFBLE9BQVEsRUFBQSxDQUFHLE1BQUgsQ0FBVSxDQUFWLENBQVIsQ0FBQTtHQUFQLENBQUE7Q0FBZixDQUFBOzs7QUFHQSxJQUFNLEdBQUEsR0FBTSxTQUFOLEdBQU0sQ0FBQyxDQUFELEVBQUE7RUFBQSxPQUFPLFVBQUMsRUFBRCxFQUFBO0lBQUEsT0FBUSxFQUFBLENBQUcsR0FBSCxDQUFPLENBQVAsQ0FBUixDQUFBO0dBQVAsQ0FBQTtDQUFaLENBQUE7Ozs7QUFJQSxJQUFNLFNBQUEsR0FBWSxTQUFaLFNBQVksQ0FBQyxDQUFELEVBQUksR0FBSixFQUFBO0VBQUEsT0FBWSxNQUFBLENBQU8sSUFBUCxDQUFZLEdBQVosQ0FBQSxDQUFpQixNQUFqQixDQUF3QixVQUFDLEdBQUQsRUFBTSxDQUFOLEVBQUE7SUFBQSxPQUFBLFFBQUEsQ0FBQSxFQUFBLEVBQWtCLEdBQWxCLEVBQUEsZUFBQSxDQUFBLEVBQUEsRUFBd0IsQ0FBeEIsRUFBNEIsQ0FBQSxDQUFFLEdBQUEsQ0FBSSxDQUFKLENBQUYsQ0FBNUIsQ0FBQSxDQUFBLENBQUE7R0FBeEIsRUFBa0UsRUFBbEUsQ0FBWixDQUFBO0NBQWxCLENBQUE7Ozs7O0FBS0EsSUFBTSxnQkFBQSxHQUFtQixTQUFuQixnQkFBbUIsQ0FBQyxHQUFELEVBQVM7RUFDaEMsSUFBTSxJQUFBLEdBQU8sTUFBQSxDQUFPLElBQVAsQ0FBWSxHQUFaLENBQWIsQ0FBQTtFQUNBLElBQU0sTUFBQSxHQUFTLElBQUEsQ0FBSyxHQUFMLENBQVMsVUFBQyxDQUFELEVBQUE7SUFBQSxPQUFPLEdBQUEsQ0FBSSxDQUFKLENBQVAsQ0FBQTtHQUFULENBQWYsQ0FBQTs7RUFFQSxPQUFPLFNBQUEsQ0FBQSxPQUFBLENBQVEsR0FBUixDQUFZLE1BQVosQ0FBQSxDQUFvQixJQUFwQixDQUF5QixVQUFDLFFBQUQsRUFBQTtJQUFBLE9BQzlCLFFBQUEsQ0FBUyxNQUFULENBQWdCLFVBQUMsR0FBRCxFQUFNLE9BQU4sRUFBZSxHQUFmLEVBQUE7TUFBQSxPQUFBLFFBQUEsQ0FBQSxFQUFBLEVBQTZCLEdBQTdCLEVBQUEsZUFBQSxDQUFBLEVBQUEsRUFBbUMsSUFBQSxDQUFLLEdBQUwsQ0FBbkMsRUFBK0MsT0FBL0MsQ0FBQSxDQUFBLENBQUE7S0FBaEIsRUFBMkUsRUFBM0UsQ0FEOEIsQ0FBQTtHQUF6QixDQUFQLENBQUE7Q0FKRixDQUFBOzs7Ozs7O0FBY0EsSUFBTSxhQUFBLEdBQWdCLFNBQWhCLGFBQWdCLENBQUMsS0FBRCxFQUFBO0VBQUEsT0FBVyxLQUFBLENBQU0sTUFBTixDQUFhLFVBQUMsR0FBRCxFQUFBLElBQUEsRUFBQTtJQUFBLElBQUEsS0FBQSxHQUFBLGNBQUEsQ0FBQSxJQUFBLEVBQUEsQ0FBQSxDQUFBO1FBQU8sQ0FBUCxHQUFBLEtBQUEsQ0FBQSxDQUFBLENBQUE7UUFBVSxDQUFWLEdBQUEsS0FBQSxDQUFBLENBQUEsQ0FBQSxDQUFBOztJQUFBLE9BQUEsUUFBQSxDQUFBLEVBQUEsRUFBdUIsR0FBdkIsRUFBQSxlQUFBLENBQUEsRUFBQSxFQUE2QixDQUE3QixFQUFpQyxDQUFqQyxDQUFBLENBQUEsQ0FBQTtHQUFiLEVBQW9ELEVBQXBELENBQVgsQ0FBQTtDQUF0QixDQUFBOztBQUVBLElBQU0sU0FBQSxHQUFZLFNBQVosU0FBWSxDQUFDLEtBQUQsRUFBQTtFQUFBLE9BQVcsT0FBTyxLQUFQLEtBQWlCLFdBQWpCLElBQWdDLEtBQUEsS0FBVSxJQUFyRCxDQUFBO0NBQWxCLENBQUE7O0FBRUEsSUFBTSxnQkFBQSxHQUFtQixTQUFuQixnQkFBbUIsQ0FBQyxLQUFELEVBQUE7RUFBQSxPQUFXLFNBQUEsQ0FBVSxLQUFWLENBQUEsSUFBb0IsS0FBQSxLQUFVLEtBQXpDLENBQUE7Q0FBekIsQ0FBQTs7O0FBR0EsSUFBTSxtQkFBQSxHQUFzQixTQUF0QixtQkFBc0IsQ0FBQyxHQUFELEVBQVM7RUFDbkMsT0FBTyxNQUFBLENBQU8sSUFBUCxDQUFZLEdBQVosQ0FBQSxDQUFpQixNQUFqQixDQUNMLFVBQUMsTUFBRCxFQUFTLEdBQVQsRUFBQTtJQUFBLE9BQUEsUUFBQSxDQUFBLEVBQUEsRUFDSyxNQURMLEVBRU0sU0FBQSxDQUFVLEdBQUEsQ0FBSSxHQUFKLENBQVYsQ0FBQSxHQUFzQixFQUF0QixHQUFBLGVBQUEsQ0FBQSxFQUFBLEVBQThCLEdBQTlCLEVBQW9DLEdBQUEsQ0FBSSxHQUFKLENBQXBDLENBRk4sQ0FBQSxDQUFBO0dBREssRUFLTCxFQUxLLENBQVAsQ0FBQTtDQURGLENBQUE7Ozs7Ozs7Ozs7QUFrQkEsSUFBTSxLQUFBLEdBQVEsU0FBUixLQUFRLENBQUMsU0FBRCxFQUFBO0VBQUEsT0FDWixNQUFBLENBQU8sVUFBQyxNQUFELEVBQVMsR0FBVCxFQUFjLEdBQWQsRUFBc0I7SUFDM0IsSUFBTSxTQUFBLEdBQVksTUFBQSxDQUFPLE1BQUEsQ0FBTyxNQUFQLEdBQWdCLENBQXZCLENBQWxCLENBQUE7SUFDQSxJQUFNLFVBQUEsR0FBYSxHQUFBLEdBQU0sU0FBTixLQUFvQixDQUF2QyxDQUFBO0lBQ0EsSUFBTSxRQUFBLEdBQVcsVUFBQSxHQUFhLENBQUMsR0FBRCxDQUFiLEdBQUEsRUFBQSxDQUFBLE1BQUEsQ0FBQSxrQkFBQSxDQUF5QixTQUF6QixDQUFBLEVBQUEsQ0FBb0MsR0FBcEMsQ0FBQSxDQUFqQixDQUFBO0lBQ0EsT0FBQSxFQUFBLENBQUEsTUFBQSxDQUFBLGtCQUFBLENBQVcsTUFBQSxDQUFPLEtBQVAsQ0FBYSxDQUFiLEVBQWdCLE1BQUEsQ0FBTyxNQUFQLElBQWlCLFVBQUEsR0FBYSxDQUFiLEdBQWlCLENBQWxDLENBQWhCLENBQVgsQ0FBQSxFQUFBLENBQWtFLFFBQWxFLENBQUEsQ0FBQSxDQUFBO0dBSkYsQ0FBQSxDQUtHLEVBTEgsQ0FEWSxDQUFBO0NBQWQsQ0FBQTs7Ozs7Ozs7Ozs7O0FBa0JBLElBQU0sY0FBQSxHQUFpQixTQUFqQixjQUFpQixDQUFDLFNBQUQsRUFBQTtFQUFBLE9BQ3JCLE1BQUEsQ0FBTyxVQUFDLE1BQUQsRUFBUyxHQUFULEVBQWMsR0FBZCxFQUFzQjtJQUMzQixJQUFNLFFBQUEsR0FBVyxHQUFBLEdBQU0sU0FBdkIsQ0FBQTtJQUNBLElBQU0sUUFBQSxHQUFBLEVBQUEsQ0FBQSxNQUFBLENBQUEsa0JBQUEsQ0FBZ0IsTUFBQSxDQUFPLFFBQVAsQ0FBQSxJQUFvQixFQUFwQyxDQUFBLEVBQUEsQ0FBeUMsR0FBekMsQ0FBQSxDQUFOLENBQUE7SUFDQSxPQUFBLEVBQUEsQ0FBQSxNQUFBLENBQUEsa0JBQUEsQ0FBVyxNQUFBLENBQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsUUFBaEIsQ0FBWCxDQUFBLEVBQUEsQ0FBc0MsUUFBdEMsQ0FBQSxFQUFBLGtCQUFBLENBQW1ELE1BQUEsQ0FBTyxLQUFQLENBQWEsUUFBQSxHQUFXLENBQXhCLENBQW5ELENBQUEsQ0FBQSxDQUFBO0dBSEYsQ0FBQSxDQUlHLEVBSkgsQ0FEcUIsQ0FBQTtDQUF2QixDQUFBOzs7Ozs7Ozs7O0FBZUEsSUFBTSxPQUFBLEdBQVUsU0FBVixPQUFVLEdBQUE7RUFBQSxLQUFBLElBQUEsSUFBQSxHQUFBLFNBQUEsQ0FBQSxNQUFBLEVBQUksRUFBSixHQUFBLEtBQUEsQ0FBQSxJQUFBLENBQUEsRUFBQSxJQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsR0FBQSxJQUFBLEVBQUEsSUFBQSxFQUFBLEVBQUE7SUFBSSxFQUFKLENBQUEsSUFBQSxDQUFBLEdBQUEsU0FBQSxDQUFBLElBQUEsQ0FBQSxDQUFBO0dBQUE7O0VBQUEsT0FBVyxVQUFDLENBQUQsRUFBQTtJQUFBLE9BQU8sRUFBQSxDQUFHLFdBQUgsQ0FBZSxVQUFDLEdBQUQsRUFBTSxDQUFOLEVBQUE7TUFBQSxPQUFZLENBQUEsQ0FBRSxHQUFGLENBQVosQ0FBQTtLQUFmLEVBQW1DLENBQW5DLENBQVAsQ0FBQTtHQUFYLENBQUE7Q0FBaEIsQ0FBQTs7OztBQUlBLElBQU0sU0FBQSxHQUFZLFNBQVosU0FBWSxHQUFBO0VBQUEsS0FBQSxJQUFBLEtBQUEsR0FBQSxTQUFBLENBQUEsTUFBQSxFQUFJLEVBQUosR0FBQSxLQUFBLENBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxHQUFBLENBQUEsRUFBQSxLQUFBLEdBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQSxFQUFBO0lBQUksRUFBSixDQUFBLEtBQUEsQ0FBQSxHQUFBLFNBQUEsQ0FBQSxLQUFBLENBQUEsQ0FBQTtHQUFBOztFQUFBLE9BQVcsVUFBQyxDQUFELEVBQUE7SUFBQSxPQUFPLEVBQUEsQ0FBRyxNQUFILENBQVUsVUFBQyxHQUFELEVBQU0sQ0FBTixFQUFBO01BQUEsT0FBYSxTQUFBLENBQVUsR0FBVixDQUFBLEdBQWlCLEdBQWpCLEdBQXVCLENBQUEsQ0FBRSxHQUFGLENBQXBDLENBQUE7S0FBVixFQUF1RCxDQUF2RCxDQUFQLENBQUE7R0FBWCxDQUFBO0NBQWxCLENBQUE7OztBQUdBLElBQU0sS0FBQSxHQUFRLFNBQVIsS0FBUSxDQUFBLEtBQUEsRUFBQTtFQUFBLElBQUEsS0FBQSxHQUFBLGNBQUEsQ0FBQSxLQUFBLEVBQUEsQ0FBQSxDQUFBO01BQUUsQ0FBRixHQUFBLEtBQUEsQ0FBQSxDQUFBLENBQUEsQ0FBQTs7RUFBQSxPQUFTLENBQVQsQ0FBQTtDQUFkLENBQUE7OztBQUdBLElBQU0sSUFBQSxHQUFPLFNBQVAsSUFBTyxDQUFDLENBQUQsRUFBQTtFQUFBLE9BQU8sU0FBQSxDQUFVLE1BQUEsQ0FBTyxDQUFQLENBQVYsRUFBcUIsS0FBckIsQ0FBUCxDQUFBO0NBQWIsQ0FBQTs7O0FBR0EsSUFBTSxJQUFBLEdBQU8sU0FBUCxJQUFPLENBQUMsQ0FBRCxFQUFBO0VBQUEsT0FBTyxZQUFBO0lBQUEsSUFBQyxHQUFELEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQU8sRUFBUCxDQUFBO0lBQUEsT0FBYyxHQUFBLENBQUksQ0FBSixDQUFkLENBQUE7R0FBUCxDQUFBO0NBQWIsQ0FBQTs7O0FBR0EsSUFBTSxTQUFBLEdBQVksU0FBWixTQUFZLENBQUMsQ0FBRCxFQUFBO0VBQUEsT0FBTyxZQUFBO0lBQUEsSUFBQyxHQUFELEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQU8sRUFBUCxDQUFBO0lBQUEsT0FBYyxHQUFBLENBQUksQ0FBSixDQUFBLElBQVUsR0FBeEIsQ0FBQTtHQUFQLENBQUE7Q0FBbEIsQ0FBQTs7Ozs7QUFLQSxJQUFNLEtBQUEsR0FBUSxTQUFSLEtBQVEsQ0FBQyxDQUFELEVBQUE7RUFBQSxPQUFPLFVBQUMsQ0FBRCxFQUFBO0lBQUEsT0FBUSxnQkFBQSxDQUFpQixDQUFqQixDQUFBLEdBQXNCLElBQXRCLEdBQTZCLENBQXJDLENBQUE7R0FBUCxDQUFBO0NBQWQsQ0FBQTs7aURBR0U7MERBQ0E7UUFDQSxVQUFBO2tEQUNBO1FBQ0EsT0FBQTtpREFDQTtRQUNBLFFBQUE7UUFDQSxNQUFBO1FBQ0EsWUFBQTtRQUNBLGdCQUFBO1FBQ0EsWUFBQTtRQUNBLG1CQUFBO1FBQ0EsT0FBQTtRQUNBLFlBQUE7UUFDQSxzQkFBQTs7Ozs7Ozs7OztBQ2hJRixJQUFBLElBQUEsR0FBQSxPQUFBLENBQUEsUUFBQSxDQUFBLENBQUE7O0FBQ0EsSUFBQSxXQUFBLEdBQUEsT0FBQSxDQUFBLGVBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxVQUFBLENBQUEsQ0FBQTs7QUFFQSxJQUFNLGFBQUEsR0FBZ0IsU0FBaEIsYUFBZ0IsR0FBNkM7RUFBQSxJQUE1QyxnQkFBNEMsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBekIsb0JBQXlCLENBQUE7O0VBQ2pFLElBQU0sU0FBQSxHQUFZLFFBQUEsQ0FBUyxjQUFULENBQXdCLGdCQUF4QixDQUFsQixDQUFBOztFQUVBLENBQUEsQ0FBQSxFQUFBLElBQUEsQ0FBQSxnQkFBQSxFQUFpQixDQUNmO0lBQ0UsT0FBQSxFQUFTLFNBRFg7SUFFRSxNQUFBLEVBQVEsQ0FBQSxDQUFBLEVBQUEsV0FBQSxDQUFBLENBQUEsRUFDTjtNQUNFLElBQUEsRUFBTSx3REFEUjtNQUVFLE1BQUEsRUFBUSxRQUZWO01BR0UsR0FBQSxFQUFLLHFCQUFBO0tBSkQsRUFNTixDQUFBLENBQUEsRUFBQSxXQUFBLENBQUEsbUJBQUEsRUFBb0IsTUFBcEIsRUFBNEIsZUFBNUIsQ0FOTSxDQUFBO0dBSEssQ0FBakIsQ0FBQSxDQUFBO0NBSEYsQ0FBQTs7QUFrQkEsSUFBTSxtQkFBQSxHQUFzQixTQUF0QixtQkFBc0IsR0FBNkM7RUFBQSxJQUE1QyxnQkFBNEMsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBekIsb0JBQXlCLENBQUE7O0VBQ3ZFLElBQU0sU0FBQSxHQUFZLFFBQUEsQ0FBUyxjQUFULENBQXdCLGdCQUF4QixDQUFsQixDQUFBO0VBQ0EsQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLGFBQUEsRUFBYyxTQUFkLENBQUEsQ0FBQTtDQUZGLENBQUE7O1FBS1MsZ0JBQUE7UUFBZSxzQkFBQTs7Ozs7Ozs7OztBQzNCeEIsSUFBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLFFBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxVQUFBLENBQUEsQ0FBQTs7QUFDQSxJQUFBLFdBQUEsR0FBQSxPQUFBLENBQUEsZUFBQSxDQUFBLENBQUE7O0FBRUEsSUFBTSxzQkFBQSxHQUF5QixrQkFBL0IsQ0FBQTs7QUFFQSxJQUFNLFNBQUEsR0FBWSxTQUFaLFNBQVksQ0FBQyxhQUFELEVBQW1CO0VBQ25DLElBQU0sTUFBQSxHQUFTLFFBQUEsQ0FBUyxjQUFULENBQXdCLGFBQXhCLENBQWYsQ0FBQTs7RUFFQSxDQUFBLENBQUEsRUFBQSxJQUFBLENBQUEsZ0JBQUEsRUFBaUIsQ0FDZjtJQUNFLE9BQUEsRUFBUyxNQURYO0lBRUUsTUFBQSxFQUFRLENBQUEsQ0FBQSxFQUFBLFdBQUEsQ0FBQSxtQkFBQSxFQUFvQixNQUFwQixDQUFBO0dBSEssQ0FBakIsQ0FBQSxDQUFBO0NBSEYsQ0FBQTs7QUFXQSxJQUFNLFlBQUEsR0FBZSxTQUFmLFlBQWUsQ0FBQyxhQUFELEVBQW1CO0VBQ3RDLElBQU0sTUFBQSxHQUFTLFFBQUEsQ0FBUyxjQUFULENBQXdCLGFBQXhCLENBQWYsQ0FBQTtFQUNBLElBQU0saUJBQUEsR0FBdUIsYUFBdkIsR0FBQSxVQUFOLENBQUE7RUFDQSxDQUFBLENBQUEsRUFBQSxJQUFBLENBQUEsUUFBQSxFQUFTLE1BQVQsRUFBaUIsaUJBQWpCLENBQUEsQ0FBQTs7O0VBR0EsSUFBSSxNQUFKLEVBQVk7SUFDVixNQUFBLENBQU8sZ0JBQVAsQ0FBd0IsY0FBeEIsRUFBd0MsWUFBQTtNQUFBLE9BQU0sQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLGFBQUEsRUFBYyxNQUFkLENBQU4sQ0FBQTtLQUF4QyxDQUFBLENBQUE7SUFDQSxNQUFBLENBQU8sZ0JBQVAsQ0FBd0Isb0JBQXhCLEVBQThDLFlBQUE7TUFBQSxPQUFNLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxhQUFBLEVBQWMsTUFBZCxDQUFOLENBQUE7S0FBOUMsQ0FBQSxDQUFBO0lBQ0EsTUFBQSxDQUFPLGdCQUFQLENBQXdCLGVBQXhCLEVBQXlDLFlBQUE7TUFBQSxPQUFNLENBQUEsQ0FBQSxFQUFBLE1BQUEsQ0FBQSxhQUFBLEVBQWMsTUFBZCxDQUFOLENBQUE7S0FBekMsQ0FBQSxDQUFBO0dBQ0Q7Q0FWSCxDQUFBOzs7OztBQWdCQSxJQUFNLFVBQUEsR0FBYSxTQUFiLFVBQWEsQ0FBQyxPQUFELEVBQTRFO0VBQUEsSUFBQSxJQUFBLEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQVAsRUFBTztNQUFBLGtCQUFBLEdBQUEsSUFBQSxDQUFoRSxhQUFnRTtNQUFoRSxhQUFnRSxHQUFBLGtCQUFBLEtBQUEsU0FBQSxHQUFoRCxzQkFBZ0QsR0FBQSxrQkFBQTtNQUFBLFVBQUEsR0FBQSxJQUFBLENBQXhCLEtBQXdCO01BQXhCLEtBQXdCLEdBQUEsVUFBQSxLQUFBLFNBQUEsR0FBaEIsSUFBZ0IsR0FBQSxVQUFBLENBQUE7O0VBQzdGLElBQU0sZUFBQSxHQUFrQixVQUFBLENBQVcsWUFBQTtJQUFBLE9BQU0sU0FBQSxDQUFVLGFBQVYsQ0FBTixDQUFBO0dBQVgsRUFBMkMsS0FBM0MsQ0FBeEIsQ0FBQTtFQUNBLE9BQU8sT0FBQSxDQUFRLE9BQVIsQ0FBZ0IsWUFBTTtJQUMzQixZQUFBLENBQWEsZUFBYixDQUFBLENBQUE7SUFDQSxZQUFBLENBQWEsYUFBYixDQUFBLENBQUE7R0FGSyxDQUFQLENBQUE7Q0FGRixDQUFBOztRQVFTLGFBQUE7Ozs7Ozs7Ozs7OztBQ3pDVCxJQUFBLFVBQUEsR0FBQSxPQUFBLENBQUEsYUFBQSxDQUFBLENBQUE7O0FBQ0EsSUFBQSxLQUFBLEdBQUEsT0FBQSxDQUFBLFFBQUEsQ0FBQSxDQUFBOztBQUNBLElBQUEsY0FBQSxHQUFBLE9BQUEsQ0FBQSxpQkFBQSxDQUFBLENBQUE7Ozs7Ozs7Ozs7Ozs7O0FBUUEsSUFBTSxnQkFBQSxHQUFtQixTQUFuQixnQkFBbUIsQ0FBQyxVQUFELEVBQUE7RUFBQSxPQUFnQixVQUN2QyxXQUR1QyxFQUV2QyxpQkFGdUMsRUFLcEM7SUFBQSxJQUZILFdBRUcsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FGVyxLQUVYLENBQUE7SUFBQSxJQURILHNCQUNHLEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBRHNCLEtBQ3RCLENBQUE7OztJQUVILElBQU0sZ0JBQUEsR0FBbUIsU0FBbkIsZ0JBQW1CLENBQUEsSUFBQSxFQUFtQztNQUFBLElBQWhDLFFBQWdDLEdBQUEsSUFBQSxDQUFoQyxRQUFnQztVQUF0QixNQUFzQixHQUFBLElBQUEsQ0FBdEIsTUFBc0I7VUFBWCxJQUFXLEdBQUEsd0JBQUEsQ0FBQSxJQUFBLEVBQUEsQ0FBQSxVQUFBLEVBQUEsUUFBQSxDQUFBLENBQUEsQ0FBQTs7TUFDMUQsSUFBTSxPQUFBLEdBQVUsSUFBSSxlQUFBLENBQUEsT0FBSixDQUFBLFFBQUEsQ0FBQTtRQUNkLFFBQUEsRUFBQSxRQURjO1FBRWQsc0JBQUEsRUFBQSxzQkFGYztRQUdkLGNBQUEsRUFBZ0IsUUFBQSxDQUFTLFdBQUEsQ0FBWSxjQUFyQixDQUhGO1FBSWQsTUFBQSxFQUFBLE1BQUE7T0FKYyxFQUtYLElBTFcsQ0FBQSxDQUFoQixDQUFBO01BT0EsT0FBTyxPQUFBLENBQVEsY0FBUixDQUF1QixpQkFBdkIsQ0FBQSxFQUFQLENBQUE7S0FSRixDQUFBOztJQVdBLElBQU0sU0FBQSxHQUFZLFdBQUEsQ0FBWSxjQUFaLEdBQTZCLENBQTdCLEdBQWlDLGdCQUFqQyxHQUFvRCxpQkFBdEUsQ0FBQTtJQUNBLENBQUEsQ0FBQSxFQUFBLFVBQUEsQ0FBQSxTQUFBLEVBQUEsaUJBQUEsR0FBNEIsVUFBNUIsQ0FBQSxDQUEwQyxXQUExQyxFQUF1RCxTQUF2RCxFQUFrRSxXQUFsRSxFQUErRSxVQUFBLENBQUEsaUJBQS9FLENBQUEsQ0FBQTtHQW5CdUIsQ0FBQTtDQUF6QixDQUFBOzs7OztBQXlCQSxJQUFNLGtCQUFBLEdBQXFCLFNBQXJCLGtCQUFxQixDQUN6QixlQUR5QixFQUV6QixNQUZ5QixFQUd6QixRQUh5QixFQUl0QjtFQUNILENBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxPQUFBLEVBQUEsbUJBQUEsR0FBNEIsZUFBNUIsRUFBK0MsRUFBRSxNQUFBLEVBQUEsTUFBRixFQUEvQyxDQUFBLENBQTJELElBQTNELENBQWdFLFFBQWhFLENBQUEsQ0FBQTtDQUxGLENBQUE7OzREQVNFOzhEQUNBOzs7Ozs7Ozs7OztxakJDN0NGOzs7QUFDQTs7OztBQUVBOztBQUNBOztBQUNBOztBQUNBOzs7Ozs7Ozs7Ozs7QUFFQSxJQUFNLG1CQUFtQixzQkFBekI7O0FBRUE7Ozs7Ozs7Ozs7SUFTTSxhO0FBQ0o7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsK0JBQStFO0FBQUEsUUFBakUsY0FBaUUsUUFBakUsY0FBaUU7QUFBQSxRQUFqRCxzQkFBaUQsUUFBakQsc0JBQWlEO0FBQUEsUUFBekIsUUFBeUIsUUFBekIsUUFBeUI7QUFBQSxRQUFaLFFBQVk7O0FBQUE7O0FBQzdFO0FBQ0EsUUFBTSwyQkFBMkIsNEJBQWlCLFVBQUMsV0FBRDtBQUFBLGFBQ2hELG1CQUFVLGNBQUssV0FBTCxDQUFWLEVBQTZCLGNBQUssT0FBTCxDQUE3QixFQUE0QyxjQUFLLFVBQUwsQ0FBNUMsQ0FEZ0Q7QUFBQSxLQUFqQixDQUFqQzs7QUFJQSxTQUFLLGNBQUwsR0FBc0IsY0FBdEI7QUFDQSxTQUFLLHNCQUFMLEdBQThCLHNCQUE5QjtBQUNBLFNBQUssUUFBTCxHQUFnQixRQUFoQjtBQUNBLFNBQUssUUFBTCxHQUFnQix5QkFBeUIsUUFBekIsRUFBbUMsc0JBQW5DLENBQWhCO0FBQ0EsU0FBSyxRQUFMLEdBQWdCLFFBQWhCOztBQUVBLFNBQUssT0FBTCxHQUFlLEtBQUssc0JBQUwsQ0FBNEIsUUFBNUIsRUFBc0MsVUFBdEMsRUFBZjtBQUNEOztBQUVEOzs7Ozs7Ozs7Ozs7OzttQ0FVZSxRLEVBQVU7QUFBQTs7QUFDdkIsYUFBTztBQUFBLGVBQ0wsTUFBSyxjQUFMLEdBQ0csSUFESCxDQUNRLFVBQUMsT0FBRDtBQUFBLGlCQUNKLHNCQUNLLE1BQUssUUFEVjtBQUVFLHNCQUFVLE1BQUssUUFGakI7QUFHRSw0QkFIRjtBQUlFLDRCQUFnQixNQUFLLGNBSnZCO0FBS0UsNkJBQWlCLE1BQUssY0FBTCxDQUFvQixJQUFwQixDQUF5QixLQUF6QjtBQUxuQixhQURJO0FBQUEsU0FEUixFQVVHLEtBVkgsQ0FVUyxVQUFDLEdBQUQsRUFBUztBQUNkLGNBQUksUUFBUSxnQkFBWixFQUE4QjtBQUM1QixtQkFBTyxzQkFDRixNQUFLLFFBREg7QUFFTCx3QkFBVSxNQUFLLFFBRlY7QUFHTCx1QkFBUyxFQUhKO0FBSUwsOEJBQWdCLEtBSlg7QUFLTCwrQkFBaUIsTUFBSyxjQUFMLENBQW9CLElBQXBCLENBQXlCLEtBQXpCO0FBTFosZUFBUDtBQU9ELFdBUkQsTUFRTztBQUNMO0FBQ0Esa0JBQU0sR0FBTjtBQUNEO0FBQ0YsU0F2QkgsQ0FESztBQUFBLE9BQVA7QUF5QkQ7O0FBRUQ7Ozs7Ozs7Ozs7cUNBT2lCO0FBQUE7O0FBQ2YsVUFBTSxrQkFBa0IsU0FBbEIsZUFBa0IsQ0FBQyxRQUFELEVBQWM7QUFBQTs7QUFDcEMsWUFBTSxvQkFBb0IsT0FBSyxzQkFBTCxDQUE0QixRQUE1QixDQUExQjtBQUNBLGVBQUssUUFBTCxHQUFnQixrQkFBa0IsZ0JBQWxCLEVBQWhCO0FBQ0EsMkJBQUssT0FBTCxFQUFhLElBQWIsb0NBQXFCLGtCQUFrQixVQUFsQixFQUFyQjtBQUNBLGVBQU8sT0FBSyxZQUFMLEVBQVA7QUFDRCxPQUxEOztBQU9BLFVBQUksS0FBSyxPQUFMLENBQWEsTUFBYixLQUF3QixDQUE1QixFQUErQjtBQUM3QjtBQUNBLGVBQU8sa0JBQVEsTUFBUixDQUFlLGdCQUFmLENBQVA7QUFDRDtBQUNELGFBQU8sS0FBSyxjQUFMLElBQXVCLEtBQUssT0FBTCxDQUFhLE1BQXBDLEdBQ0gsS0FBSyxhQUFMLEdBQXFCLElBQXJCLENBQTBCLGVBQTFCLENBREcsR0FFSDtBQUNBLHdCQUFRLE9BQVIsQ0FBZ0IsS0FBSyxZQUFMLEVBQWhCLENBSEo7QUFJRDs7QUFFRDs7Ozs7Ozs7Ozs7QUFVQTs7QUFFQTs7OzttQ0FJZTtBQUNiLGFBQU8sS0FBSyxPQUFMLENBQWEsTUFBYixDQUFvQixDQUFwQixFQUF1QixLQUFLLGNBQTVCLENBQVA7QUFDRDs7QUFFRDs7Ozs7O29DQUdnQjtBQUNkLGFBQU8sMEJBQWlCLG1CQUFVLGFBQVYsRUFBbUIsS0FBSyxRQUF4QixDQUFqQixDQUFQO0FBQ0Q7O0FBRUQ7Ozs7OzsyQ0FHdUIsUSxFQUFVO0FBQy9CLGFBQU8sSUFBSSwyQkFBSixDQUFzQixRQUF0QixFQUFnQztBQUNyQyxnQ0FBd0IsS0FBSyxzQkFEUTtBQUVyQyxxQkFBYSxLQUFLLFFBQUwsQ0FBYyxjQUFkLENBQTZCO0FBRkwsT0FBaEMsQ0FBUDtBQUlEOzs7d0JBN0JvQjtBQUNuQixhQUFPLEtBQUssT0FBTCxDQUFhLE1BQWIsR0FBc0IsQ0FBN0I7QUFDRDs7Ozs7O2tCQThCWSxhOzs7Ozs7Ozs7O0FDeEpmLElBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQSxVQUFBLENBQUEsQ0FBQTs7Ozs7Ozs7OztBQVVBLElBQU0sZ0JBQUEsR0FBbUIsU0FBbkIsZ0JBQW1CLENBQUMsTUFBRCxFQUFBO0VBQUEsT0FBWSxVQUFDLFFBQUQsRUFBOEM7SUFBQSxJQUFuQyxzQkFBbUMsR0FBQSxTQUFBLENBQUEsTUFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEtBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBVixLQUFVLENBQUE7O0lBQ2pGLElBQU0sY0FBQSxHQUFpQixNQUFBLENBQU8sZ0JBQVAsQ0FBQSxDQUF5QixRQUF6QixDQUF2QixDQUFBO0lBQ0EsSUFBTSxzQkFBQSxHQUF5QixDQUFBLENBQUEsRUFBQSxHQUFBLENBQUEsU0FBQSxFQUM3QixDQUFBLENBQUEsRUFBQSxHQUFBLENBQUEsS0FBQSxFQUFNLHNCQUFOLENBRDZCLEVBRTdCLE1BQUEsQ0FBTyx3QkFBUCxDQUY2QixDQUFBLENBRzdCLFFBSDZCLENBQS9CLENBQUE7SUFJQSxPQUFPLENBQUEsQ0FBQSxFQUFBLEdBQUEsQ0FBQSxtQkFBQSxFQUFvQjtNQUN6QixjQUFBLEVBQUEsY0FEeUI7TUFFekIsc0JBQUEsRUFBQSxzQkFBQTtLQUZLLENBQVAsQ0FBQTtHQU51QixDQUFBO0NBQXpCLENBQUE7O1FBWVMsbUJBQUE7Ozs7Ozs7Ozs7Ozs7QUN0QlQ7O0FBQ0E7Ozs7OztBQUVBOzs7O0lBSU0sdUI7QUFDSjs7Ozs7O0FBTUEsbUNBQVksUUFBWixRQUErRDtBQUFBLFFBQXZDLHNCQUF1QyxRQUF2QyxzQkFBdUM7QUFBQSxRQUFmLFdBQWUsUUFBZixXQUFlOztBQUFBOztBQUM3RCxTQUFLLFFBQUwsR0FBZ0IsUUFBaEI7QUFDQSxTQUFLLHNCQUFMLEdBQThCLHNCQUE5QjtBQUNBLFNBQUssV0FBTCxHQUFtQixXQUFuQjtBQUNEOztBQUVEOzs7Ozs7Ozs7O2lDQU1hO0FBQUE7O0FBQUEsc0JBQ3dDLEtBQUssUUFEN0M7QUFBQSxVQUNILGNBREcsYUFDSCxjQURHO0FBQUEsVUFDYSxzQkFEYixhQUNhLHNCQURiOztBQUVYLFVBQU0sdUJBQXVCLFNBQXZCLG9CQUF1QjtBQUFBLFlBQWMsRUFBZCxTQUFHLFNBQUg7QUFBQSxZQUFpQyxFQUFqQyxTQUFzQixTQUF0QjtBQUFBLGVBQzNCLElBQUksSUFBSixDQUFTLEVBQVQsSUFBZSxJQUFJLElBQUosQ0FBUyxFQUFULENBRFk7QUFBQSxPQUE3QjtBQUVBLFVBQU0scUJBQ0osbUJBQVUsbUJBQVUsZ0JBQVYsQ0FBVixFQUF1QyxtQkFBVSxTQUFWLENBQXZDLEVBQTZELGNBQTdELEtBQWdGLEVBRGxGOztBQUdBLFVBQU0sc0JBQ0osbUJBQ0UsZUFBTSxLQUFLLHNCQUFYLENBREYsRUFFRSxtQkFBVSx3QkFBVixDQUZGLEVBR0UsbUJBQVUsZ0JBQVYsQ0FIRixFQUlFLGFBQUksVUFBQyxNQUFEO0FBQUEsNEJBQ0MsTUFERDtBQUVGLHNCQUFZLE9BQU8sSUFBUCxLQUFnQixVQUFoQixHQUNSLENBQUMsQ0FBQyxPQUFPLE1BQVQsR0FDRSxPQUFPLE1BQVAsQ0FBYyxJQURoQixHQUVFLE1BQUssV0FIQyxHQUlSLE1BQUs7QUFOUDtBQUFBLE9BQUosQ0FKRixFQVlFLHNCQVpGLEtBWTZCLEVBYi9COztBQWVBLGFBQU8sNkJBQUksa0JBQUosc0JBQTJCLG1CQUEzQixHQUFnRCxJQUFoRCxDQUFxRCxvQkFBckQsQ0FBUDtBQUNEOztBQUVEOzs7Ozs7O3VDQUltQjtBQUNqQjtBQUNBLFVBQU0sZ0NBQWdDLDRCQUFpQixVQUFDLFdBQUQ7QUFBQSxlQUNyRCxtQkFDRSxjQUFLLFdBQUwsQ0FERixFQUVFLGNBQUssT0FBTCxDQUZGLEVBR0UsY0FBSyxVQUFDLElBQUQ7QUFBQSxpQkFBVSxLQUFLLEdBQUwsS0FBYSxXQUF2QjtBQUFBLFNBQUwsQ0FIRixFQUlFLGNBQUssTUFBTCxDQUpGLENBRHFEO0FBQUEsT0FBakIsQ0FBdEM7O0FBU0EsVUFBTSxnQ0FBZ0MsNEJBQWlCLFVBQUMsV0FBRDtBQUFBLGVBQ3JELG1CQUFVLGNBQUssV0FBTCxDQUFWLEVBQTZCLGNBQUssV0FBTCxDQUE3QixFQUFnRCxjQUFLLE9BQUwsQ0FBaEQsRUFBK0QsY0FBSyxVQUFMLENBQS9ELENBRHFEO0FBQUEsT0FBakIsQ0FBdEM7O0FBSUEsVUFBTSxXQUFXLDhCQUE4QixLQUFLLFFBQW5DLEVBQTZDLEtBQUssc0JBQWxELENBQWpCO0FBQ0EsVUFBTSxXQUFXLDhCQUE4QixLQUFLLFFBQW5DLEVBQTZDLEtBQUssc0JBQWxELENBQWpCOztBQUVBLDBCQUFZLFFBQVosRUFBeUIsUUFBekI7QUFDRDs7Ozs7O2tCQUdZLHVCOzs7Ozs7Ozs7O0FDckVmLElBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxVQUFBLENBQUEsQ0FBQTs7QUFFQSxJQUFNLGVBQUEsR0FBa0IseUVBQXhCOzs7Ozs7OztBQUVBLElBQU0sT0FBQSxHQUFVLFNBQVYsT0FBVSxDQUFDLFVBQUQsRUFBYSxLQUFiLEVBQW1DO0VBQUEsSUFBZixLQUFlLEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQVAsRUFBTyxDQUFBOztFQUNqRCxJQUFNLGNBQUEsR0FBaUIsTUFBQSxDQUFPLElBQVAsQ0FBWSxLQUFaLENBQUEsQ0FBbUIsTUFBbkIsQ0FBMEIsVUFBQyxHQUFELEVBQU0sR0FBTixFQUFjO0lBQzdELEdBQUEsQ0FBSSxHQUFKLENBQUEsR0FBVyxDQUFBLENBQUEsRUFBQSxNQUFBLENBQUEsWUFBQSxFQUFhLEtBQUEsQ0FBTSxHQUFOLENBQWIsQ0FBWCxDQUFBO0lBQ0EsSUFBSSxHQUFBLEtBQVEsT0FBWixFQUFxQjtNQUNuQixHQUFBLENBQUksR0FBSixDQUFBLEdBQVcsQ0FBQSxDQUFBLEVBQUEsTUFBQSxDQUFBLGFBQUEsRUFBYyxHQUFBLENBQUksR0FBSixDQUFkLENBQVgsQ0FBQTtLQUNEO0lBQ0QsT0FBTyxHQUFQLENBQUE7R0FMcUIsRUFNcEIsRUFOb0IsQ0FBdkIsQ0FBQTtFQU9BLE9BQUEsNEZBQUEsR0FDeUYsVUFBQSxDQUFXLE1BQVgsR0FDckYsVUFBQSxDQUFXLEtBRHlFLEdBRXRGLEdBSEYsR0FBQSxjQUFBLEdBSU0sS0FBQSxDQUFNLFVBQU4sRUFBa0IsY0FBbEIsQ0FKTixHQUFBLGtCQUFBLENBQUE7Q0FSRixDQUFBOztBQWlCQSxJQUFNLGNBQUEsR0FBaUIsU0FBdkIsQ0FBQTtBQUNBLElBQU0sTUFBQSxHQUFRLFNBQVIsTUFBUSxDQUFDLFVBQUQsRUFBQSxJQUFBLEVBQUE7RUFBQSxJQUFlLE1BQWYsR0FBQSxJQUFBLENBQWUsTUFBZjtNQUF1QixVQUF2QixHQUFBLElBQUEsQ0FBdUIsVUFBdkI7TUFBbUMsS0FBbkMsR0FBQSxJQUFBLENBQW1DLEtBQW5DLENBQUE7RUFBQSxPQUFBLGdFQUFBLEdBQ2dELFVBQUEsQ0FBVyxLQUQzRCxHQUFBLEdBQUEsR0FFWixVQUFBLENBQVcsTUFGQyxHQUFBLHVDQUFBLEdBRzBCLGVBSDFCLEdBQUEsNENBQUEsR0FJMkIsVUFKM0IsR0FBQSwySEFBQSxJQU1rQyxNQUFBLElBQVUsQ0FBVixJQUFlLEtBQWYsR0FBdUIsS0FBdkIsR0FBK0IsY0FOakUsQ0FBQSxHQUFBLHVZQUFBLElBVWtDLE1BQUEsSUFBVSxDQUFWLElBQWUsS0FBZixHQUF1QixLQUF2QixHQUErQixjQVZqRSxDQUFBLEdBQUEsMEdBQUEsSUFXd0MsTUFBQSxJQUFVLEdBQVYsSUFBaUIsS0FBakIsR0FBeUIsS0FBekIsR0FBaUMsY0FYekUsQ0FBQSxHQUFBLDRXQUFBLElBZWtDLE1BQUEsSUFBVSxDQUFWLElBQWUsS0FBZixHQUF1QixLQUF2QixHQUErQixjQWZqRSxDQUFBLEdBQUEsNkdBQUEsSUFnQndDLE1BQUEsSUFBVSxHQUFWLElBQWlCLEtBQWpCLEdBQXlCLEtBQXpCLEdBQWlDLGNBaEJ6RSxDQUFBLEdBQUEsK1pBQUEsSUFvQmtDLE1BQUEsSUFBVSxDQUFWLElBQWUsS0FBZixHQUF1QixLQUF2QixHQUErQixjQXBCakUsQ0FBQSxHQUFBLDZHQUFBLElBcUJ3QyxNQUFBLElBQVUsR0FBVixJQUFpQixLQUFqQixHQUF5QixLQUF6QixHQUFpQyxjQXJCekUsQ0FBQSxHQUFBLCtaQUFBLElBeUJrQyxNQUFBLEtBQVcsQ0FBWCxJQUFnQixLQUFoQixHQUF3QixLQUF4QixHQUFnQyxjQXpCbEUsQ0FBQSxHQUFBLDZHQUFBLElBMEJ3QyxNQUFBLElBQVUsR0FBVixJQUFpQixLQUFqQixHQUF5QixLQUF6QixHQUFpQyxjQTFCekUsQ0FBQSxHQUFBLDhWQUFBLENBQUE7Q0FBZCxDQUFBOztBQStCQSxJQUFNLEtBQUEsR0FBTyxTQUFQLEtBQU8sQ0FBQyxVQUFELEVBQUE7RUFBQSxPQUFBLG9FQUFBLEdBQ3FELFVBQUEsQ0FBVyxLQURoRSxHQUFBLEdBQUEsR0FFWCxVQUFBLENBQVcsTUFGQSxHQUFBLHVDQUFBLEdBRzJCLGVBSDNCLEdBQUEseTNQQUFBLENBQUE7Q0FBYixDQUFBOztBQVVBLElBQU0sWUFBQSxHQUFjLFNBQWQsWUFBYyxDQUFDLFVBQUQsRUFBQTtFQUFBLE9BQUEsd0JBQUEsR0FDRSxVQUFBLENBQVcsS0FEYixHQUFBLEdBQUEsR0FFbEIsVUFBQSxDQUFXLE1BRk8sR0FBQSx1Q0FBQSxHQUdvQixlQUhwQixHQUFBLG9mQUFBLENBQUE7Q0FBcEIsQ0FBQTs7QUFTQSxJQUFNLFdBQUEsR0FBYSxTQUFiLFdBQWEsQ0FBQyxVQUFELEVBQUEsS0FBQSxFQUFBO0VBQUEsSUFBZSxZQUFmLEdBQUEsS0FBQSxDQUFlLFlBQWYsQ0FBQTtFQUFBLE9BQUEsc0JBQUEsR0FDQyxVQUFBLENBQVcsS0FEWixHQUFBLEdBQUEsR0FDcUIsVUFBQSxDQUFXLE1BRGhDLEdBQUEsaURBQUEsR0FDOEUsZUFEOUUsR0FBQSwya0JBQUEsSUFFcWpCLFlBQUEsSUFBZ0IsU0FGcmtCLENBQUEsR0FBQSxtQ0FBQSxDQUFBO0NBQW5CLENBQUE7Ozs7OztBQVVBLElBQU0sZUFBQSxHQUFrQixFQUFFLEtBQUEsRUFBTyxHQUFULEVBQWMsTUFBQSxFQUFRLEVBQXRCLEVBQXhCLENBQUE7QUFDQSxJQUFNLGNBQUEsR0FBaUIsRUFBRSxLQUFBLEVBQU8sR0FBVCxFQUFjLE1BQUEsRUFBUSxFQUF0QixFQUF2QixDQUFBO0FBQ0EsSUFBTSxxQkFBQSxHQUF3QixFQUFFLEtBQUEsRUFBTyxFQUFULEVBQWEsTUFBQSxFQUFRLEVBQXJCLEVBQTlCLENBQUE7QUFDQSxJQUFNLG9CQUFBLEdBQXVCLEVBQUUsS0FBQSxFQUFPLEVBQVQsRUFBYSxNQUFBLEVBQVEsQ0FBckIsRUFBN0IsQ0FBQTs7QUFFQSxJQUFNLE1BQUEsR0FBUztFQUNiLEtBQUEsRUFBTyxTQUFBLEtBQUEsQ0FBQyxLQUFELEVBQUE7SUFBQSxPQUFXLE9BQUEsQ0FBUSxlQUFSLEVBQXlCLE1BQXpCLEVBQWdDLEtBQWhDLENBQVgsQ0FBQTtHQURNO0VBRWIsSUFBQSxFQUFNLFNBQUEsSUFBQSxHQUFBO0lBQUEsT0FBTSxPQUFBLENBQVEsY0FBUixFQUF3QixLQUF4QixDQUFOLENBQUE7R0FGTztFQUdiLFdBQUEsRUFBYSxTQUFBLFdBQUEsR0FBQTtJQUFBLE9BQU0sT0FBQSxDQUFRLHFCQUFSLEVBQStCLFlBQS9CLENBQU4sQ0FBQTtHQUhBO0VBSWIsVUFBQSxFQUFZLFNBQUEsVUFBQSxDQUFDLEtBQUQsRUFBQTtJQUFBLE9BQVcsT0FBQSxDQUFRLG9CQUFSLEVBQThCLFdBQTlCLEVBQTBDLEtBQTFDLENBQVgsQ0FBQTtHQUFBO0NBSmQsQ0FBQTs7UUFPUyxTQUFBOzs7Ozs7Ozs7O0FDdEdULElBQUEsYUFBQSxHQUFBLE9BQUEsQ0FBQSxpQkFBQSxDQUFBLENBQUE7Ozs7OztBQUVBLElBQU0sYUFBQSxHQUFnQixPQUF0QixDQUFBOztBQUVBLElBQU0sY0FBQSxHQUFpQixHQUF2QixDQUFBOztBQUVBLElBQU0sb0JBQUEsR0FBdUI7RUFDM0IsSUFBQSxFQUFNLElBRHFCO0VBRTNCLElBQUEsRUFBTSxJQUZxQjtFQUczQixJQUFBLEVBQU0sSUFIcUI7RUFJM0IsSUFBQSxFQUFNLElBSnFCO0VBSzNCLElBQUEsRUFBTSxJQUFBOztDQUxSLENBQUE7Ozs7Ozs7OztBQWdCQSxJQUFNLHdCQUFBLEdBQTJCLFNBQTNCLHdCQUEyQixDQUFDLFFBQUQsRUFBYztFQUM3QyxJQUFNLE9BQUEsR0FBVSxvQkFBQSxDQUFxQixRQUFyQixDQUFBLElBQWtDLFFBQWxELENBQUE7RUFDQSxPQUFPLE9BQVAsQ0FBQTtDQUZGLENBQUE7O0FBS0EsSUFBTSxZQUFBLEdBQWUsU0FBZixZQUFlLENBQUMsTUFBRCxFQUFZO0VBQy9CLElBQU0sV0FBQSxHQUFjLE1BQUEsQ0FBTyxLQUFQLENBQWEsY0FBYixDQUFwQixDQUFBO0VBQ0EsSUFBTSxRQUFBLEdBQVcsV0FBQSxDQUFZLENBQVosQ0FBakIsQ0FBQTtFQUNBLElBQUksT0FBQSxHQUFVLFdBQUEsQ0FBWSxDQUFaLENBQWQsQ0FBQTs7RUFFQSxJQUFJLENBQUMsT0FBTCxFQUFjO0lBQ1osT0FBQSxHQUFVLHdCQUFBLENBQXlCLFFBQXpCLENBQVYsQ0FBQTtHQUNEOztFQUVELE9BQU8sUUFBQSxJQUFZLE9BQVosR0FBQSxFQUFBLEdBQ0EsUUFEQSxHQUNXLGNBRFgsR0FDNEIsT0FBQSxDQUFRLFdBQVIsRUFENUIsR0FFSCxhQUZKLENBQUE7Q0FURixDQUFBOztBQWNBLElBQU0sdUJBQUEsR0FBMEIsU0FBMUIsdUJBQTBCLENBQUMsR0FBRCxFQUFzRDtFQUFBLElBQWhELE1BQWdELEdBQUEsU0FBQSxDQUFBLE1BQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxLQUFBLFNBQUEsR0FBQSxTQUFBLENBQUEsQ0FBQSxDQUFBLEdBQXZDLGFBQXVDLENBQUE7RUFBQSxJQUF4QixjQUF3QixHQUFBLFNBQUEsQ0FBQSxNQUFBLEdBQUEsQ0FBQSxJQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsS0FBQSxTQUFBLEdBQUEsU0FBQSxDQUFBLENBQUEsQ0FBQSxHQUFQLEVBQU8sQ0FBQTs7RUFDcEYsSUFBTSxnQkFBQSxHQUFtQixjQUFBLENBQUEsT0FBQSxDQUFRLFlBQUEsQ0FBYSxNQUFiLENBQVIsQ0FBQSxJQUFpQyxjQUFBLENBQUEsT0FBQSxDQUFRLGFBQVIsQ0FBMUQsQ0FBQTtFQUNBLElBQU0sY0FBQSxHQUFpQixHQUFBLENBQUksS0FBSixDQUFVLEdBQVYsQ0FBQSxDQUFlLE1BQWYsQ0FBc0IsVUFBQyxDQUFELEVBQUksQ0FBSixFQUFBO0lBQUEsT0FBVSxDQUFBLENBQUUsQ0FBRixDQUFWLENBQUE7R0FBdEIsRUFBc0MsZ0JBQXRDLENBQXZCLENBQUE7RUFDQSxJQUFNLFdBQUEsR0FBYyxNQUFBLENBQU8sSUFBUCxDQUFZLGNBQVosQ0FBQSxDQUE0QixNQUE1QixDQUNsQixVQUFDLEtBQUQsRUFBUSxHQUFSLEVBQUE7SUFBQSxPQUFnQixLQUFBLENBQU0sT0FBTixDQUFjLEdBQWQsRUFBbUIsY0FBQSxDQUFlLEdBQWYsQ0FBbkIsQ0FBaEIsQ0FBQTtHQURrQixFQUVsQixjQUZrQixDQUFwQixDQUFBOztFQUtBLE9BQU8sV0FBUCxDQUFBO0NBUkYsQ0FBQTs7UUFXUyxnQkFBQTtRQUFlLGVBQUE7UUFBYywwQkFBQTs7Ozs7Ozs7Ozs7QUNwRHRDOztBQUNBOztBQUNBOzs7Ozs7Ozs7Ozs7QUFFQTs7Ozs7OztJQU9NLGE7OztBQUNKOzs7Ozs7Ozs7Ozs7Ozs7QUFlQSx5QkFBWSxNQUFaLEVBQW9CLFFBQXBCLEVBQTRDO0FBQUEsUUFBZCxPQUFjLHVFQUFKLEVBQUk7O0FBQUE7O0FBQUEsOEhBQ3BDLE1BRG9DLEVBQzVCLFFBRDRCOztBQUUxQyxVQUFLLFNBQUwsR0FBaUIsUUFBUSxTQUFSLElBQXFCLEVBQXRDO0FBQ0EsVUFBSyxhQUFMLEdBQXFCLFFBQVEsYUFBN0I7QUFIMEM7QUFJM0M7Ozs7c0NBRWlCO0FBQUE7O0FBQ2hCLFVBQU0sT0FBTyxTQUFQLElBQU8sR0FBTSxDQUFFLENBQXJCO0FBRGdCLHNCQUVpQixLQUFLLFFBRnRCO0FBQUEsVUFFUixTQUZRLGFBRVIsU0FGUTtBQUFBLFVBRUcsU0FGSCxhQUVHLFNBRkg7QUFBQSx1QkFHNkIsS0FBSyxTQUhsQztBQUFBLDJDQUdSLFFBSFE7QUFBQSxVQUdSLFFBSFEsdUNBR0csSUFISDtBQUFBLDJDQUdTLFFBSFQ7QUFBQSxVQUdTLFFBSFQsdUNBR29CLElBSHBCOztBQUloQixtQ0FBaUIsU0FBakIsRUFBNEIsT0FBNUIsRUFBcUMsWUFBTTtBQUN6QyxlQUFLLE1BQUwsQ0FBWSxXQUFaLENBQXdCLENBQUMsQ0FBekI7QUFDQTtBQUNELE9BSEQ7QUFJQSxtQ0FBaUIsU0FBakIsRUFBNEIsT0FBNUIsRUFBcUMsWUFBTTtBQUN6QyxlQUFLLE1BQUwsQ0FBWSxXQUFaLENBQXdCLENBQXhCO0FBQ0E7QUFDRCxPQUhEO0FBSUQ7OzsrQkFFVSxJLEVBQU0sVSxFQUFZO0FBQzNCLFVBQU0sZ0JBQWdCLEtBQUssYUFBM0I7QUFDQSxVQUFJLFVBQUosRUFBZ0I7QUFDZCwyQkFBUyxJQUFULEVBQWUsYUFBZjtBQUNELE9BRkQsTUFFTztBQUNMLDhCQUFZLElBQVosRUFBa0IsYUFBbEI7QUFDRDtBQUNGOzs7a0NBRWE7QUFBQSx1QkFDcUIsS0FBSyxRQUQxQjtBQUFBLFVBQ0osU0FESSxjQUNKLFNBREk7QUFBQSxVQUNPLFNBRFAsY0FDTyxTQURQOztBQUVaLFdBQUssVUFBTCxDQUFnQixTQUFoQixFQUEyQixLQUFLLE1BQUwsQ0FBWSxhQUFaLEVBQTNCO0FBQ0EsV0FBSyxVQUFMLENBQWdCLFNBQWhCLEVBQTJCLEtBQUssTUFBTCxDQUFZLFlBQVosRUFBM0I7QUFDRDs7OytCQUVVO0FBQ1QsV0FBSyxXQUFMO0FBQ0Q7Ozs7RUFyRHlCLGtCOztrQkF3RGIsYTs7Ozs7Ozs7Ozs7OztBQ25FZjs7Ozs7Ozs7O0lBU00sUTtBQUNKOzs7Ozs7QUFNQSxvQkFBWSxNQUFaLEVBQW9CLFFBQXBCLEVBQThCO0FBQUE7O0FBQzVCLFNBQUssTUFBTCxHQUFjLE1BQWQ7QUFDQSxTQUFLLFFBQUwsR0FBZ0IsUUFBaEI7QUFDRDs7QUFFRDs7Ozs7Ozs7OztpQ0FNYTtBQUNYLFdBQUssZUFBTDtBQUNBLFdBQUssTUFBTCxDQUFZLGNBQVosQ0FBMkIsSUFBM0I7QUFDQSxXQUFLLE1BQUwsQ0FBWSxVQUFaO0FBQ0EsV0FBSyxRQUFMO0FBQ0Q7O0FBRUQ7Ozs7Ozs7c0NBSWtCO0FBQ2hCLFlBQU0sSUFBSSxLQUFKLENBQVUsNENBQVYsQ0FBTjtBQUNEOztBQUVEOzs7Ozs7OytCQUlXO0FBQ1QsWUFBTSxJQUFJLEtBQUosQ0FBVSxxQ0FBVixDQUFOO0FBQ0Q7O0FBRUQ7Ozs7OzttQ0FHZTtBQUNiLFdBQUssUUFBTDtBQUNEOztBQUVEOzs7Ozs7K0JBR1c7QUFDVCxXQUFLLFFBQUw7QUFDRDs7Ozs7O2tCQUdZLFE7Ozs7Ozs7Ozs7O0FDakVmOztBQUNBOztBQUNBOzs7Ozs7Ozs7Ozs7QUFFQTs7Ozs7OztJQU9NLGtCOzs7QUFDSjs7Ozs7Ozs7Ozs7Ozs7QUFjQSw4QkFBWSxNQUFaLEVBQW9CLFFBQXBCLEVBQTRDO0FBQUEsUUFBZCxPQUFjLHVFQUFKLEVBQUk7O0FBQUE7O0FBQUEsd0lBQ3BDLE1BRG9DLEVBQzVCLFFBRDRCOztBQUUxQyxVQUFLLFNBQUwsR0FBaUIsUUFBUSxTQUFSLElBQXFCLEVBQXRDO0FBQ0EsVUFBSyxXQUFMLEdBQW1CLFFBQVEsV0FBM0I7QUFIMEM7QUFJM0M7Ozs7c0NBRWlCO0FBQUE7O0FBQ2hCLFVBQU0sYUFBYSxLQUFLLFFBQXhCO0FBQ0EsVUFBTSxPQUFPLFNBQVAsSUFBTyxHQUFNLENBQUUsQ0FBckI7QUFDQSxpQkFBVyxPQUFYLENBQW1CLFVBQUMsSUFBRCxFQUFPLEtBQVAsRUFBaUI7QUFDbEMsWUFBSSxVQUFVLENBQWQsRUFBaUI7QUFDZiw2QkFBUyxJQUFULEVBQWUsT0FBSyxXQUFwQjtBQUNEO0FBQ0QscUNBQWlCLElBQWpCLEVBQXVCLE9BQXZCLEVBQWdDLFlBQU07QUFDcEMsaUJBQUssTUFBTCxDQUFZLFVBQVosQ0FBdUIsUUFBUSxDQUEvQjtBQUNBLGNBQU0sV0FBVyxPQUFLLFNBQUwsQ0FBZSxLQUFmLEtBQXlCLElBQTFDO0FBQ0E7QUFDRCxTQUpEO0FBS0QsT0FURDtBQVVEOzs7K0JBRVU7QUFBQTs7QUFDVCxVQUFNLGFBQWEsS0FBSyxRQUF4QjtBQUNBLGlCQUFXLE9BQVgsQ0FBbUIsVUFBQyxJQUFELEVBQU8sS0FBUCxFQUFpQjtBQUNsQyxZQUFNLFdBQVcsT0FBSyxNQUFMLENBQVksV0FBWixLQUE0QixRQUFRLENBQXJEO0FBQ0EsWUFBSSxRQUFKLEVBQWM7QUFDWiw2QkFBUyxJQUFULEVBQWUsT0FBSyxXQUFwQjtBQUNELFNBRkQsTUFFTztBQUNMLGdDQUFZLElBQVosRUFBa0IsT0FBSyxXQUF2QjtBQUNEO0FBQ0YsT0FQRDtBQVFEOzs7O0VBOUM4QixrQjs7a0JBaURsQixrQjs7Ozs7Ozs7Ozs7QUM1RGY7O0FBQ0E7Ozs7QUFDQSxJQUFNLFFBQVEsU0FBUixLQUFRLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYO0FBQUEsU0FBbUIsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLENBQVMsR0FBVCxFQUFjLEdBQWQsQ0FBVCxFQUE2QixHQUE3QixDQUFuQjtBQUFBLENBQWQ7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFnQk0sWTtBQUNKOzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLHdCQUFZLE9BQVosRUFBcUIsUUFBckIsRUFBK0IsUUFBL0IsRUFBdUQ7QUFBQTs7QUFBQSxRQUFkLE9BQWMsdUVBQUosRUFBSTs7QUFBQTs7QUFDckQsU0FBSyxPQUFMLEdBQWUsT0FBZjtBQUNBLFNBQUssUUFBTCxHQUFnQixRQUFoQjtBQUNBLFNBQUssV0FBTCxHQUFtQixRQUFRLE1BQTNCO0FBQ0EsU0FBSyxRQUFMLEdBQWdCLFFBQWhCO0FBQ0EsU0FBSyxXQUFMLEdBQW1CLFFBQVEsV0FBM0I7QUFDQSxTQUFLLGlCQUFMLENBQXVCLFFBQVEsY0FBL0I7QUFDQSxTQUFLLFdBQUwsR0FBbUIsQ0FBbkI7QUFDQSxTQUFLLGFBQUwsR0FBcUIsSUFBckI7QUFDQSxTQUFLLFNBQUwsR0FBaUIsRUFBakI7QUFDQSxTQUFLLGFBQUwsR0FBcUIsS0FBckI7O0FBRUE7O0FBRUEsU0FBSyxrQkFBTCxHQUEwQixnQkFBZ0M7QUFBQSxVQUE3QixVQUE2QixRQUE3QixVQUE2QjtBQUFBLFVBQWpCLFVBQWlCLFFBQWpCLFVBQWlCOztBQUN4RCxZQUFLLDJCQUFMLENBQWlDLENBQWpDO0FBQ0EsWUFBSyxtQkFBTCxDQUF5QixVQUF6QjtBQUNBLFlBQUssV0FBTCxHQUFtQixVQUFuQjtBQUNELEtBSkQ7QUFLQSxTQUFLLGlCQUFMLEdBQXlCLGlCQUFvQjtBQUFBLFVBQWpCLFVBQWlCLFNBQWpCLFVBQWlCOztBQUMzQyxZQUFLLG1CQUFMLENBQXlCLFVBQXpCO0FBQ0QsS0FGRDtBQUdBLFNBQUssZ0JBQUwsR0FBd0IsaUJBQTBDO0FBQUEsVUFBdkMsWUFBdUMsU0FBdkMsWUFBdUM7QUFBQSxVQUF6QixrQkFBeUIsU0FBekIsa0JBQXlCOztBQUNoRSxZQUFLLFdBQUwsQ0FBaUIsWUFBakIsRUFBK0IsTUFBTSxrQkFBTixFQUEwQixHQUExQixFQUErQixDQUEvQixDQUEvQjtBQUNELEtBRkQ7QUFHRDs7QUFFRDs7Ozs7Ozs7Ozs7Ozs7c0NBVWtCLGMsRUFBZ0I7QUFDaEMsVUFBSSxPQUFPLGNBQVAsS0FBMEIsUUFBOUIsRUFBd0M7QUFDdEMsYUFBSyxjQUFMLEdBQXNCLENBQUMsRUFBRSxVQUFVLENBQVosRUFBZSxpQkFBaUIsY0FBaEMsRUFBRCxDQUF0QjtBQUNELE9BRkQsTUFFTztBQUNMLGFBQUssY0FBTCxHQUFzQixjQUF0QjtBQUNBLGFBQUssY0FBTCxDQUFvQixJQUFwQixDQUF5QjtBQUFBLGNBQWEsQ0FBYixTQUFHLFFBQUg7QUFBQSxjQUE4QixDQUE5QixTQUFvQixRQUFwQjtBQUFBLGlCQUFzQyxJQUFJLENBQTFDO0FBQUEsU0FBekI7QUFDRDtBQUNGOztBQUVEOzs7Ozs7cUNBR2lCO0FBQ2YsV0FBSyxRQUFMLENBQWMsTUFBZCxDQUFxQixTQUFyQixHQUFpQyxLQUFLLE9BQUwsQ0FBYSxHQUFiLENBQWlCLEtBQUssUUFBTCxDQUFjLElBQWQsQ0FBbUIsSUFBbkIsQ0FBakIsRUFBMkMsSUFBM0MsQ0FBZ0QsRUFBaEQsQ0FBakM7QUFDRDs7QUFFRDs7Ozs7Ozs7OztpQ0FPYTtBQUNYLFVBQUksS0FBSyxhQUFULEVBQXdCO0FBQ3RCO0FBQ0Q7O0FBRUQsV0FBSyxjQUFMO0FBQ0EsV0FBSyx1QkFBTDs7QUFFQSxXQUFLLEtBQUwsR0FBYSxJQUFJLHNCQUFKLENBQW9CO0FBQy9CLHVCQUFlLEtBQUssUUFBTCxDQUFjLE1BREU7QUFFL0IsbUJBQVcsS0FBSyxvQkFGZTtBQUcvQiw0QkFBb0IsS0FBSyxrQkFITTtBQUkvQiwyQkFBbUIsS0FBSyxpQkFKTztBQUsvQiwwQkFBa0IsS0FBSztBQUxRLE9BQXBCLENBQWI7O0FBUUEsV0FBSyxLQUFMLENBQVcsTUFBWDtBQUNBLFdBQUssWUFBTDtBQUNBLFdBQUssb0JBQUw7O0FBRUEsV0FBSyxhQUFMLEdBQXFCLElBQXJCO0FBQ0Q7O0FBRUQ7Ozs7aURBK0I2QjtBQUMzQixhQUFPLEtBQUssZUFBTCxJQUF3QixLQUFLLFdBQUwsR0FBbUIsQ0FBM0MsQ0FBUDtBQUNEOzs7b0NBRWU7QUFDZCxhQUFPLEtBQUssV0FBTCxLQUFxQixDQUE1QjtBQUNEOzs7bUNBRWM7QUFDYixhQUFPLEtBQUssV0FBTCxLQUFxQixLQUFLLFVBQWpDO0FBQ0Q7Ozt3Q0FFbUIsTSxFQUFRO0FBQzFCLFdBQUssUUFBTCxDQUFjLE1BQWQsQ0FBcUIsS0FBckIsQ0FBMkIsU0FBM0IsbUJBQXFELE1BQXJEO0FBQ0Q7OztnREFFMkIsTyxFQUFTO0FBQ25DLFdBQUssUUFBTCxDQUFjLE1BQWQsQ0FBcUIsS0FBckIsQ0FBMkIsa0JBQTNCLEdBQW1ELE9BQW5EO0FBQ0Q7O0FBRUQ7Ozs7MkNBRXVCO0FBQ3JCLFVBQUksS0FBSyxjQUFMLENBQW9CLE1BQXBCLEtBQStCLENBQS9CLElBQW9DLENBQUMsS0FBSyxjQUFMLENBQW9CLENBQXBCLENBQXpDLEVBQWlFO0FBQy9ELGVBQU8sRUFBRSxNQUFNLENBQVIsRUFBVyxPQUFPLENBQWxCLEVBQVA7QUFDRCxPQUZELE1BRU87QUFDTCxZQUFNLGdCQUFnQixPQUFPLGdCQUFQLENBQXdCLEtBQUssY0FBTCxDQUFvQixDQUFwQixDQUF4QixDQUF0QjtBQUNBLGVBQU87QUFDTCxnQkFBTSxTQUFTLGNBQWMsVUFBdkIsQ0FERDtBQUVMLGlCQUFPLFNBQVMsY0FBYyxXQUF2QjtBQUZGLFNBQVA7QUFJRDtBQUNGOzs7OENBRXlCO0FBQ3hCLFVBQU0sb0JBQW9CLEtBQUssY0FBTCxDQUFvQixNQUFwQixDQUN4QixVQUFDLFdBQUQ7QUFBQSxZQUFnQixRQUFoQixTQUFnQixRQUFoQjtBQUFBLFlBQTBCLGVBQTFCLFNBQTBCLGVBQTFCO0FBQUEsZUFDRSxDQUFDLFdBQUQsSUFBZ0IsU0FBUyxlQUFULENBQXlCLFdBQXpCLElBQXdDLFFBQXhELEdBQ0ksRUFBRSxrQkFBRixFQUFZLGdDQUFaLEVBREosR0FFSSxXQUhOO0FBQUEsT0FEd0IsRUFLeEIsSUFMd0IsQ0FBMUI7QUFPQSxXQUFLLGVBQUwsR0FBdUIsa0JBQWtCLGVBQXpDO0FBQ0EsV0FBSyxtQkFBTCxHQUEyQixrQkFBa0IsUUFBN0M7QUFDRDs7QUFFRDs7OzttQ0FFZSxRLEVBQVU7QUFDdkIsV0FBSyxTQUFMLENBQWUsSUFBZixDQUFvQixRQUFwQjtBQUNEOzs7bUNBRWMsUSxFQUFVO0FBQ3ZCLFdBQUssU0FBTCxHQUFpQixLQUFLLFNBQUwsQ0FBZSxNQUFmLENBQXNCLFVBQUMsR0FBRDtBQUFBLGVBQVMsUUFBUSxRQUFqQjtBQUFBLE9BQXRCLENBQWpCO0FBQ0Q7O0FBRUQ7Ozs7MkNBRXVCO0FBQUE7O0FBQ3JCLG1DQUFpQixNQUFqQixFQUF5QixRQUF6QixFQUFtQyxZQUFNO0FBQ3ZDLFlBQUksT0FBSyxhQUFMLEtBQXVCLElBQTNCLEVBQWlDO0FBQy9CLGlCQUFPLFlBQVAsQ0FBb0IsT0FBSyxhQUF6QjtBQUNEO0FBQ0QsZUFBSyxhQUFMLEdBQXFCLE9BQU8sVUFBUCxDQUFrQixZQUFNO0FBQzNDLGlCQUFLLFlBQUw7QUFDRCxTQUZvQixFQUVsQixHQUZrQixDQUFyQjtBQUdELE9BUEQ7QUFRRDs7O21DQUVjO0FBQUE7O0FBQ2IsV0FBSyxlQUFMO0FBQ0EsV0FBSyxRQUFMLENBQWMsTUFBZCxDQUFxQixLQUFyQixDQUEyQixLQUEzQixHQUFzQyxLQUFLLFdBQUwsR0FBbUIsS0FBSyxzQkFBOUQ7QUFDQSxXQUFLLGNBQUwsQ0FBb0IsT0FBcEIsQ0FBNEIsVUFBQyxJQUFELEVBQVU7QUFDcEMsYUFBSyxLQUFMLENBQVcsS0FBWCxHQUFzQixPQUFLLFdBQTNCO0FBQ0QsT0FGRDtBQUdBLFdBQUssU0FBTCxDQUFlLE9BQWYsQ0FBdUIsVUFBQyxRQUFEO0FBQUEsZUFBYyxTQUFTLFFBQVQsRUFBZDtBQUFBLE9BQXZCO0FBQ0Q7OztzQ0FFaUI7QUFDaEIsVUFBTSxZQUFZO0FBQ2hCLGNBQU0sS0FBSyxXQURLO0FBRWhCLDRCQUFvQixLQUFLLGVBQUwsSUFBd0IsS0FBSyxXQUFMLEdBQW1CLENBQTNDO0FBRkosT0FBbEI7QUFJQSxXQUFLLHVCQUFMO0FBQ0EsVUFBTSxVQUFVLEtBQUssS0FBTCxDQUFXLFVBQVUsa0JBQVYsR0FBK0IsS0FBSyxlQUEvQyxJQUFrRSxDQUFsRjtBQUNBLFdBQUssVUFBTCxDQUFnQixPQUFoQixFQUF5QixDQUF6QjtBQUNBLFdBQUssS0FBTCxDQUFXLFlBQVgsQ0FBd0IsS0FBSyxvQkFBN0I7QUFDRDs7QUFFRDs7OztnQ0FFWSxRLEVBQWtDO0FBQUEsVUFBeEIsa0JBQXdCLHVFQUFILENBQUc7O0FBQzVDLFVBQU0sYUFBYSxNQUFNLFdBQVcsS0FBSyxXQUF0QixFQUFtQyxDQUFuQyxFQUFzQyxLQUFLLFVBQTNDLENBQW5CO0FBQ0EsV0FBSyxVQUFMLENBQWdCLFVBQWhCLEVBQTRCLGtCQUE1QjtBQUNEOzs7K0JBRVUsVSxFQUFZO0FBQ3JCLGFBQU8sS0FBSyxvQkFBTCxJQUE2QixhQUFhLENBQTFDLElBQStDLENBQUMsQ0FBdkQ7QUFDRDs7OytCQUVVLFUsRUFBb0M7QUFBQSxVQUF4QixrQkFBd0IsdUVBQUgsQ0FBRzs7QUFDN0MsVUFBTSxTQUFTLEtBQUssVUFBTCxDQUFnQixVQUFoQixDQUFmO0FBQ0EsV0FBSyxtQkFBTCxDQUF5QixNQUF6QjtBQUNBLFdBQUssMkJBQUwsQ0FBaUMsa0JBQWpDO0FBQ0EsV0FBSyxXQUFMLEdBQW1CLFVBQW5CO0FBQ0EsV0FBSyxTQUFMLENBQWUsT0FBZixDQUF1QixVQUFDLFFBQUQ7QUFBQSxlQUFjLFNBQVMsWUFBVCxFQUFkO0FBQUEsT0FBdkI7QUFDRDs7O3dCQXZJZ0I7QUFDZixhQUFPLEtBQUssSUFBTCxDQUFVLEtBQUssV0FBTCxHQUFtQixLQUFLLGVBQWxDLENBQVA7QUFDRDs7O3dCQUVpQjtBQUFBLGtDQUNRLEtBQUssb0JBQUwsRUFEUjtBQUFBLFVBQ1IsSUFEUSx5QkFDUixJQURRO0FBQUEsVUFDRixLQURFLHlCQUNGLEtBREU7O0FBRWhCLGFBQU8sS0FBSyxzQkFBTCxJQUErQixPQUFPLEtBQXRDLENBQVA7QUFDRDs7O3dCQUU0QjtBQUMzQixhQUFPLEtBQUssb0JBQUwsR0FBNEIsS0FBSyxlQUF4QztBQUNEOzs7d0JBRTBCO0FBQUEsbUNBSXJCLEtBQUssb0JBQUwsRUFKcUI7QUFBQSxVQUVoQiw0QkFGZ0IsMEJBRXZCLEtBRnVCO0FBQUEsVUFHakIsNEJBSGlCLDBCQUd2QixJQUh1Qjs7QUFLekIsYUFDRSxDQUFDLEtBQUssUUFBTCxDQUFjLGVBQWQsQ0FBOEIsV0FBOUIsSUFBNkMsS0FBSyxtQkFBbkQsSUFDQSw0QkFEQSxHQUVBLDRCQUhGO0FBS0Q7Ozt3QkFFb0I7QUFDbkIsYUFBTyxHQUFHLEtBQUgsQ0FBUyxJQUFULENBQWMsS0FBSyxRQUFMLENBQWMsTUFBZCxDQUFxQixzQkFBckIsQ0FBNEMsS0FBSyxXQUFqRCxDQUFkLENBQVA7QUFDRDs7Ozs7O2tCQStHWSxZOzs7Ozs7Ozs7Ozs7OztBQ2xRZixJQUFNLElBQUEsR0FBTyxTQUFQLElBQU8sQ0FBQyxDQUFELEVBQUE7RUFBQSxPQUFPLENBQUMsQ0FBQSxHQUFJLENBQUwsS0FBVyxDQUFBLEdBQUksQ0FBZixDQUFBLElBQXFCLENBQUMsQ0FBN0IsQ0FBQTtDQUFiLENBQUE7QUFDQSxJQUFBLENBQUssSUFBTCxHQUFZLElBQUEsQ0FBSyxJQUFMLElBQWEsSUFBekIsQ0FBQTs7SUFFYSwwQkFBQTtFQUNYLFNBQUEsZUFBQSxDQUFBLElBQUEsRUFPRztJQUFBLElBQUEsa0JBQUEsR0FBQSxJQUFBLENBTkQsYUFNQztRQU5ELGFBTUMsR0FBQSxrQkFBQSxLQUFBLFNBQUEsR0FOZSxJQU1mLEdBQUEsa0JBQUE7UUFBQSxjQUFBLEdBQUEsSUFBQSxDQUxELFNBS0M7UUFMRCxTQUtDLEdBQUEsY0FBQSxLQUFBLFNBQUEsR0FMVyxJQUtYLEdBQUEsY0FBQTtRQUFBLGdCQUFBLEdBQUEsSUFBQSxDQUpELFdBSUM7UUFKRCxXQUlDLEdBQUEsZ0JBQUEsS0FBQSxTQUFBLEdBSmEsRUFJYixHQUFBLGdCQUFBO1FBQUEscUJBQUEsR0FBQSxJQUFBLENBSEQsZ0JBR0M7UUFIRCxnQkFHQyxHQUFBLHFCQUFBLEtBQUEsU0FBQSxHQUhrQixZQUFNLEVBR3hCLEdBQUEscUJBQUE7UUFBQSxxQkFBQSxHQUFBLElBQUEsQ0FGRCxpQkFFQztRQUZELGlCQUVDLEdBQUEscUJBQUEsS0FBQSxTQUFBLEdBRm1CLFlBQU0sRUFFekIsR0FBQSxxQkFBQTtRQUFBLHFCQUFBLEdBQUEsSUFBQSxDQURELGtCQUNDO1FBREQsa0JBQ0MsR0FBQSxxQkFBQSxLQUFBLFNBQUEsR0FEb0IsWUFBTSxFQUMxQixHQUFBLHFCQUFBLENBQUE7O0lBQUEsZUFBQSxDQUFBLElBQUEsRUFBQSxlQUFBLENBQUEsQ0FBQTs7SUFDRCxJQUFBLENBQUssYUFBTCxHQUFxQixhQUFyQixDQUFBO0lBQ0EsSUFBQSxDQUFLLFNBQUwsR0FBaUIsU0FBakIsQ0FBQTtJQUNBLElBQUEsQ0FBSyxXQUFMLEdBQW1CLFdBQW5CLENBQUE7SUFDQSxJQUFBLENBQUssZ0JBQUwsR0FBd0IsZ0JBQXhCLENBQUE7SUFDQSxJQUFBLENBQUssaUJBQUwsR0FBeUIsaUJBQXpCLENBQUE7SUFDQSxJQUFBLENBQUssa0JBQUwsR0FBMEIsa0JBQTFCLENBQUE7SUFDQSxJQUFBLENBQUssUUFBTCxHQUFnQixDQUFoQixDQUFBO0lBQ0EsSUFBQSxDQUFLLGVBQUwsR0FBdUIsQ0FBdkIsQ0FBQTtJQUNBLElBQUEsQ0FBSyxjQUFMLEdBQXNCLENBQXRCLENBQUE7SUFDQSxJQUFBLENBQUssaUJBQUwsR0FBeUIsQ0FBekIsQ0FBQTtJQUNBLElBQUEsQ0FBSyxVQUFMLEdBQWtCLENBQWxCLENBQUE7SUFDQSxJQUFBLENBQUssVUFBTCxHQUFrQixNQUFsQixDQUFBO0lBQ0EsSUFBQSxDQUFLLGFBQUwsR0FBcUI7TUFDbkIsS0FBQSxFQUFPO1FBQ0wsQ0FBQSxFQUFHLENBREU7UUFFTCxDQUFBLEVBQUcsQ0FBQTtPQUhjO01BS25CLElBQUEsRUFBTTtRQUNKLENBQUEsRUFBRyxDQURDO1FBRUosQ0FBQSxFQUFHLENBQUE7T0FGQztLQUxSLENBQUE7SUFVQSxJQUFBLENBQUssYUFBTCxDQUFtQixLQUFuQixDQUF5QixVQUF6QixHQUFzQyxNQUF0QyxDQUFBO0lBQ0EsSUFBQSxDQUFLLGFBQUwsQ0FBbUIsS0FBbkIsQ0FBeUIsd0JBQXpCLEdBQW9ELE1BQXBELENBQUE7R0FDRDs7OztzQ0FFaUI7TUFDaEIsT0FBTztRQUNMLENBQUEsRUFBRyxJQUFBLENBQUssYUFBTCxDQUFtQixJQUFuQixDQUF3QixDQUF4QixHQUE0QixJQUFBLENBQUssYUFBTCxDQUFtQixLQUFuQixDQUF5QixDQURuRDtRQUVMLENBQUEsRUFBRyxJQUFBLENBQUssYUFBTCxDQUFtQixJQUFuQixDQUF3QixDQUF4QixHQUE0QixJQUFBLENBQUssYUFBTCxDQUFtQixLQUFuQixDQUF5QixDQUFBO09BRjFELENBQUE7S0FJRDs7O29DQUVlLGlCQUFpQjtNQUMvQixJQUFNLFFBQUEsR0FBVyxJQUFBLENBQUssZUFBTCxFQUFBLENBQXVCLENBQXZCLEdBQTJCLElBQUEsQ0FBSyxlQUFqRCxDQUFBO01BQ0EsSUFBTSxtQkFBQSxHQUFzQixJQUFBLENBQUssR0FBTCxDQUFTLFFBQVQsQ0FBQSxHQUFxQixJQUFBLENBQUssU0FBdEQsQ0FBQTtNQUNBLElBQU0sZUFBQSxHQUFrQixJQUFBLENBQUssSUFBTCxDQUFVLElBQUEsQ0FBSyxHQUFMLENBQVMsUUFBQSxHQUFXLElBQUEsQ0FBSyxTQUF6QixDQUFWLENBQUEsSUFBa0QsQ0FBMUUsQ0FBQTtNQUNBLElBQU0sZ0JBQUEsR0FBbUIsbUJBQUEsR0FBc0IsSUFBQSxDQUFLLFdBQXBELENBQUE7TUFDQSxPQUFPLGdCQUFBLElBQW9CLENBQUMsZUFBckIsR0FBdUMsZUFBdkMsR0FBeUQsZUFBQSxHQUFrQixDQUFsRixDQUFBO0tBQ0Q7OztpQ0FFWSxXQUFXO01BQ3RCLElBQUEsQ0FBSyxTQUFMLEdBQWlCLFNBQWpCLENBQUE7S0FDRDs7OzZCQUVRO01BQUEsSUFBQSxLQUFBLEdBQUEsSUFBQSxDQUFBOztNQUNQLElBQUEsQ0FBSyxhQUFMLENBQW1CLGdCQUFuQixDQUFvQyxZQUFwQyxFQUFrRCxVQUFDLEdBQUQsRUFBUztRQUN6RCxLQUFBLENBQUssY0FBTCxHQUFzQixJQUFJLElBQUosRUFBQSxDQUFXLE9BQVgsRUFBdEIsQ0FBQTtRQUNBLEtBQUEsQ0FBSyxhQUFMLENBQW1CLEtBQW5CLENBQXlCLENBQXpCLEdBQTZCLEdBQUEsQ0FBSSxjQUFKLENBQW1CLENBQW5CLENBQUEsQ0FBc0IsT0FBbkQsQ0FBQTtRQUNBLEtBQUEsQ0FBSyxhQUFMLENBQW1CLEtBQW5CLENBQXlCLENBQXpCLEdBQTZCLEdBQUEsQ0FBSSxjQUFKLENBQW1CLENBQW5CLENBQUEsQ0FBc0IsT0FBbkQsQ0FBQTtRQUNBLElBQU0sS0FBQSxHQUFRLE1BQUEsQ0FBTyxnQkFBUCxDQUF3QixLQUFBLENBQUssYUFBN0IsQ0FBZCxDQUFBO1FBQ0EsSUFBSSxVQUFBLEdBQWEsQ0FBakIsQ0FBQTtRQUNBLElBQUksTUFBQSxDQUFPLFNBQVgsRUFBc0I7VUFDcEIsSUFBTSxNQUFBLEdBQVMsSUFBSSxNQUFBLENBQU8sU0FBWCxDQUFxQixLQUFBLENBQU0sZUFBM0IsQ0FBZixDQUFBO1VBQ0EsVUFBQSxHQUFhLE1BQUEsQ0FBTyxHQUFwQixDQUFBO1VBQ0EsS0FBQSxDQUFLLFFBQUwsR0FBZ0IsSUFBQSxDQUFLLEtBQUwsQ0FBVyxVQUFBLEdBQWEsS0FBQSxDQUFLLFNBQTdCLENBQUEsR0FBMEMsS0FBQSxDQUFLLFNBQS9ELENBQUE7VUFDQSxLQUFBLENBQUssZUFBTCxHQUF1QixVQUFBLEdBQWEsS0FBQSxDQUFLLFFBQXpDLENBQUE7U0FDRDtRQUNELEtBQUEsQ0FBSyxVQUFMLEdBQWtCLE1BQWxCLENBQUE7OztRQUdBLElBQUksSUFBQSxDQUFLLEdBQUwsQ0FBUyxLQUFBLENBQUssZUFBZCxDQUFBLEdBQWlDLENBQXJDLEVBQXdDO1VBQ3RDLEdBQUEsQ0FBSSxjQUFKLEVBQUEsQ0FBQTtVQUNBLEtBQUEsQ0FBSyxVQUFMLEdBQWtCLEdBQWxCLENBQUE7U0FDRDtRQUNELEtBQUEsQ0FBSyxrQkFBTCxDQUF3QjtVQUN0QixVQUFBLEVBQUEsVUFEc0I7VUFFdEIsVUFBQSxFQUFZLElBQUEsQ0FBSyxHQUFMLENBQVMsS0FBQSxDQUFLLFFBQWQsQ0FBQSxHQUEwQixLQUFBLENBQUssU0FBL0IsR0FBMkMsQ0FBQTtTQUZ6RCxDQUFBLENBQUE7T0FuQkYsQ0FBQSxDQUFBOztNQXlCQSxJQUFBLENBQUssYUFBTCxDQUFtQixnQkFBbkIsQ0FBb0MsV0FBcEMsRUFBaUQsVUFBQyxHQUFELEVBQVM7UUFDeEQsS0FBQSxDQUFLLGFBQUwsQ0FBbUIsSUFBbkIsQ0FBd0IsQ0FBeEIsR0FBNEIsR0FBQSxDQUFJLGNBQUosQ0FBbUIsQ0FBbkIsQ0FBQSxDQUFzQixPQUFsRCxDQUFBO1FBQ0EsS0FBQSxDQUFLLGFBQUwsQ0FBbUIsSUFBbkIsQ0FBd0IsQ0FBeEIsR0FBNEIsR0FBQSxDQUFJLGNBQUosQ0FBbUIsQ0FBbkIsQ0FBQSxDQUFzQixPQUFsRCxDQUFBO1FBQ0EsSUFBTSxZQUFBLEdBQWUsS0FBQSxDQUFLLGVBQUwsRUFBckIsQ0FBQTtRQUNBLElBQUksS0FBQSxDQUFLLFVBQUwsS0FBb0IsTUFBeEIsRUFBZ0M7VUFDOUIsS0FBQSxDQUFLLFVBQUwsR0FBa0IsSUFBQSxDQUFLLEdBQUwsQ0FBUyxZQUFBLENBQWEsQ0FBdEIsQ0FBQSxJQUE0QixJQUFBLENBQUssR0FBTCxDQUFTLFlBQUEsQ0FBYSxDQUF0QixDQUE1QixHQUF1RCxHQUF2RCxHQUE2RCxHQUEvRSxDQUFBO1NBQ0Q7UUFDRCxJQUFJLEtBQUEsQ0FBSyxVQUFMLEtBQW9CLEdBQXhCLEVBQTZCO1VBQzNCLEdBQUEsQ0FBSSxjQUFKLEVBQUEsQ0FBQTtVQUNBLEtBQUEsQ0FBSyxVQUFMLEdBQWtCLFlBQUEsQ0FBYSxDQUFiLEdBQWlCLEtBQUEsQ0FBSyxpQkFBeEMsQ0FBQTtVQUNBLEtBQUEsQ0FBSyxpQkFBTCxHQUF5QixZQUFBLENBQWEsQ0FBdEMsQ0FBQTs7VUFFQSxLQUFBLENBQUssaUJBQUwsQ0FBdUI7WUFDckIsVUFBQSxFQUFZLFlBQUEsQ0FBYSxDQUFiLEdBQWlCLEtBQUEsQ0FBSyxlQUF0QixHQUF3QyxLQUFBLENBQUssUUFBQTtXQUQzRCxDQUFBLENBQUE7U0FHRDtPQWZILENBQUEsQ0FBQTs7TUFrQkEsSUFBQSxDQUFLLGFBQUwsQ0FBbUIsZ0JBQW5CLENBQW9DLFVBQXBDLEVBQWdELFlBQU07UUFDcEQsSUFBTSxZQUFBLEdBQWUsSUFBSSxJQUFKLEVBQUEsQ0FBVyxPQUFYLEVBQXJCLENBQUE7UUFDQSxJQUFNLFNBQUEsR0FBWSxDQUFDLFlBQUEsR0FBZSxLQUFBLENBQUssY0FBckIsSUFBdUMsSUFBekQsQ0FBQTtRQUNBLElBQU0sWUFBQSxHQUFlLEtBQUEsQ0FBSyxlQUFMLEVBQXJCLENBQUE7UUFDQSxJQUFNLFdBQUEsR0FBYyxJQUFBLENBQUssR0FBTCxDQUFTLFlBQUEsQ0FBYSxDQUF0QixDQUFBLEdBQTJCLFNBQS9DLENBQUE7UUFDQSxJQUFNLGtCQUFBLEdBQXFCLEtBQUEsQ0FBSyxTQUFMLEdBQWlCLFdBQTVDLENBQUE7UUFDQSxJQUFNLFVBQUEsR0FBYSxZQUFBLENBQWEsQ0FBYixHQUFpQixLQUFBLENBQUssZUFBdEIsR0FBd0MsS0FBQSxDQUFLLFFBQWhFLENBQUE7UUFDQSxJQUFNLGFBQUEsR0FBZ0IsSUFBQSxDQUFLLElBQUwsQ0FBVSxLQUFBLENBQUssUUFBTCxHQUFnQixVQUExQixDQUF0QixDQUFBO1FBQ0EsSUFBTSxlQUFBLEdBQWtCLElBQUEsQ0FBSyxJQUFMLENBQVUsS0FBQSxDQUFLLFVBQWYsQ0FBQSxLQUErQixhQUF2RCxDQUFBO1FBQ0EsSUFBTSxZQUFBLEdBQWUsS0FBQSxDQUFLLFVBQUwsS0FBb0IsR0FBcEIsR0FBMEIsS0FBQSxDQUFLLGVBQUwsQ0FBcUIsZUFBckIsQ0FBMUIsR0FBa0UsQ0FBdkYsQ0FBQTs7UUFFQSxLQUFBLENBQUssZ0JBQUwsQ0FBc0I7VUFDcEIsWUFBQSxFQUFjLFlBQUEsR0FBZSxhQURUO1VBRXBCLGtCQUFBLEVBQUEsa0JBQUE7U0FGRixDQUFBLENBQUE7T0FYRixDQUFBLENBQUE7S0FnQkQ7Ozs7Ozs7Ozs7Ozs7QUN0SEg7O0FBRUEsSUFBTSx1QkFBdUI7QUFDM0IsT0FBSyxTQURzQjtBQUUzQixPQUFLLFVBRnNCO0FBRzNCLE9BQUssT0FIc0I7QUFJM0IsT0FBSyxPQUpzQjtBQUszQixPQUFLLEtBTHNCO0FBTTNCLE9BQUssTUFOc0I7QUFPM0IsT0FBSyxNQVBzQjtBQVEzQixPQUFLLFFBUnNCO0FBUzNCLE9BQUssV0FUc0I7QUFVM0IsT0FBSyxTQVZzQjtBQVczQixRQUFNLFVBWHFCO0FBWTNCLFFBQU07QUFacUIsQ0FBN0I7O0FBZUEsSUFBTSxXQUFXLFNBQVgsUUFBVyxDQUFDLE1BQUQsRUFBUyxJQUFULEVBQWtCO0FBQ2pDLE1BQUksQ0FBQyxJQUFMLEVBQVc7QUFDVCxXQUFPLElBQVA7QUFDRDs7QUFFRCxNQUFNLGtCQUFrQixnQ0FBYSxNQUFiLENBQXhCO0FBQ0EsTUFBTSxhQUFhLEtBQUssS0FBTCxDQUFXLElBQVgsQ0FBbkI7QUFDQSxNQUFNLHFCQUFxQixJQUFJLElBQUosQ0FBUyxVQUFULENBQTNCO0FBQ0EsTUFBTSxNQUFNLElBQUksSUFBSixFQUFaO0FBQ0EsTUFBTSxVQUFVLEtBQUssS0FBTCxDQUFXLENBQUMsTUFBTSxVQUFQLElBQXFCLElBQWhDLENBQWhCO0FBQ0EsTUFBTSxVQUFVLGNBQWMsT0FBZCxFQUF1QixFQUF2QixDQUFoQjtBQUNBLE1BQU0sUUFBUSxjQUFjLE9BQWQsRUFBdUIsRUFBdkIsQ0FBZDtBQUNBLE1BQU0sT0FBTyxjQUFjLEtBQWQsRUFBcUIsRUFBckIsQ0FBYjs7QUFFQSxNQUFJLFFBQVEsQ0FBWixFQUFlO0FBQ2IsUUFBTSxRQUFRLG1CQUFtQixRQUFuQixFQUFkO0FBQ0EsUUFBTSxNQUFNLG1CQUFtQixPQUFuQixFQUFaO0FBQ0EsUUFBTSxZQUFZLHFCQUFxQixLQUFyQixDQUFsQjtBQUNBLFFBQU0sc0JBQXNCLDJEQUFzQyxTQUF0QyxFQUFtRCxlQUFuRCxDQUE1QjtBQUNBLFFBQU0saUJBQWlCLE9BQXZCOztBQUVBLFFBQUksb0JBQW9CLDJCQUF4QixFQUF1QztBQUNyQyxhQUFVLG1CQUFWLFNBQWlDLEdBQWpDO0FBQ0QsS0FGRCxNQUVPLElBQUksb0JBQW9CLGNBQXhCLEVBQXdDO0FBQzdDLGFBQVUsbUJBQVYsU0FBaUMsR0FBakM7QUFDRCxLQUZNLE1BRUE7QUFDTCxhQUFVLEdBQVYsU0FBaUIsbUJBQWpCO0FBQ0Q7QUFDRjs7QUFFRCxNQUFJLE9BQU8sQ0FBWCxFQUFjO0FBQ1osV0FBTyw2REFBd0MsaUJBQWlCLElBQWpCLENBQXhDLEVBQWtFLGVBQWxFLEVBQW1GLEVBQUMsV0FBVyxJQUFaLEVBQW5GLENBQVA7QUFDRDs7QUFFRCxNQUFJLFFBQVEsQ0FBWixFQUFlO0FBQ2IsV0FBTyw4REFBeUMsaUJBQWlCLEtBQWpCLENBQXpDLEVBQW9FLGVBQXBFLEVBQXFGLEVBQUMsV0FBVyxLQUFaLEVBQXJGLENBQVA7QUFDRDs7QUFFRCxNQUFJLFVBQVUsQ0FBZCxFQUFpQjtBQUNmLFdBQU8sZ0VBQTJDLGlCQUFpQixPQUFqQixDQUEzQyxFQUF3RSxlQUF4RSxFQUF5RixFQUFDLFdBQVcsT0FBWixFQUF6RixDQUFQO0FBQ0Q7O0FBRUQsTUFBSSxXQUFXLENBQWYsRUFBa0I7QUFDaEIsV0FBTyxnRUFBMkMsaUJBQWlCLE9BQWpCLENBQTNDLEVBQXdFLGVBQXhFLEVBQXlGLEVBQUMsV0FBVyxPQUFaLEVBQXpGLENBQVA7QUFDRDtBQUNGLENBN0NEOztBQStDQSxTQUFTLGFBQVQsQ0FBdUIsS0FBdkIsRUFBOEIsUUFBOUIsRUFBd0M7QUFDdEMsU0FBTywyQkFBMkIsS0FBM0IsRUFBa0MsUUFBbEMsSUFBOEMsS0FBSyxJQUFMLENBQVUsUUFBUSxRQUFsQixDQUE5QyxHQUE0RSxLQUFLLEtBQUwsQ0FBVyxRQUFRLFFBQW5CLENBQW5GO0FBQ0Q7O0FBRUQsU0FBUywwQkFBVCxDQUFvQyxLQUFwQyxFQUEyQyxRQUEzQyxFQUFxRDtBQUNuRCxTQUFRLFFBQVEsUUFBVCxJQUF1QixRQUFRLFFBQVIsSUFBb0IsV0FBVyxDQUE3RDtBQUNEOztBQUVELFNBQVMsZ0JBQVQsQ0FBMEIsS0FBMUIsRUFBaUM7QUFDL0IsU0FBTyxVQUFVLENBQVYsR0FBYyxVQUFkLEdBQTJCLFFBQWxDO0FBQ0Q7O2tCQUVjLFE7Ozs7Ozs7O0FDNUVmLFNBQVMsVUFBVCxDQUFvQixNQUFwQixFQUE0QjtFQUMxQixJQUFNLGlCQUFBLEdBQW9CO0lBQ3hCLEdBQUEsRUFBSyxNQURtQjtJQUV4QixHQUFBLEVBQUssTUFGbUI7SUFHeEIsR0FBQSxFQUFLLFFBSG1CO0lBSXhCLElBQUEsRUFBTSxRQUprQjtJQUt4QixHQUFBLEVBQUssT0FMbUI7SUFNeEIsR0FBQSxFQUFLLFVBTm1CO0lBT3hCLEdBQUEsRUFBSyxTQUFBO0dBUFAsQ0FBQTtFQVNBLE9BQU8sTUFBQSxDQUFPLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFVBQVUsQ0FBVixFQUFhO0lBQ2hELE9BQU8saUJBQUEsQ0FBa0IsQ0FBbEIsQ0FBUCxDQUFBO0dBREssQ0FBUCxDQUFBO0NBR0Q7O0FBRUQsU0FBUyxZQUFULENBQXNCLEtBQXRCLEVBQTZCLGFBQTdCLEVBQTRDO0VBQzFDLElBQUksS0FBQSxDQUFNLGFBQU4sQ0FBSixFQUEwQjtJQUN4QixPQUFPLEtBQVAsQ0FBQTtHQUNEO0VBQ0QsSUFBSSxhQUFBLElBQWlCLENBQXJCLEVBQXdCO0lBQ3RCLE9BQU8sRUFBUCxDQUFBO0dBQ0Q7RUFDRCxJQUFJLEtBQUEsSUFBUyxLQUFBLENBQU0sTUFBTixHQUFlLGFBQTVCLEVBQTJDO0lBQ3pDLEtBQUEsR0FBUSxLQUFBLENBQU0sU0FBTixDQUFnQixDQUFoQixFQUFtQixhQUFuQixDQUFSLENBQUE7SUFDQSxJQUFJLFFBQUEsR0FBVyxLQUFBLENBQU0sTUFBTixDQUFhLEtBQUEsQ0FBTSxNQUFOLEdBQWUsQ0FBNUIsQ0FBZixDQUFBO0lBQ0EsT0FBTyxRQUFBLEtBQWEsR0FBYixJQUFvQixRQUFBLEtBQWEsR0FBakMsSUFBd0MsUUFBQSxLQUFhLEdBQTVELEVBQWlFO01BQy9ELEtBQUEsR0FBUSxLQUFBLENBQU0sTUFBTixDQUFhLENBQWIsRUFBZ0IsS0FBQSxDQUFNLE1BQU4sR0FBZSxDQUEvQixDQUFSLENBQUE7TUFDQSxRQUFBLEdBQVcsS0FBQSxDQUFNLE1BQU4sQ0FBYSxLQUFBLENBQU0sTUFBTixHQUFlLENBQTVCLENBQVgsQ0FBQTtLQUNEO0lBQ0QsS0FBQSxJQUFTLEtBQVQsQ0FBQTtHQUNEO0VBQ0QsT0FBTyxVQUFBLENBQVcsS0FBWCxDQUFQLENBQUE7Q0FDRDs7UUFFUSxlQUFBO1FBQWMsYUFBQTs7O0FDbEN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FDbEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUMvTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24oKXtmdW5jdGlvbiByKGUsbix0KXtmdW5jdGlvbiBvKGksZil7aWYoIW5baV0pe2lmKCFlW2ldKXt2YXIgYz1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlO2lmKCFmJiZjKXJldHVybiBjKGksITApO2lmKHUpcmV0dXJuIHUoaSwhMCk7dmFyIGE9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitpK1wiJ1wiKTt0aHJvdyBhLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsYX12YXIgcD1uW2ldPXtleHBvcnRzOnt9fTtlW2ldWzBdLmNhbGwocC5leHBvcnRzLGZ1bmN0aW9uKHIpe3ZhciBuPWVbaV1bMV1bcl07cmV0dXJuIG8obnx8cil9LHAscC5leHBvcnRzLHIsZSxuLHQpfXJldHVybiBuW2ldLmV4cG9ydHN9Zm9yKHZhciB1PVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmUsaT0wO2k8dC5sZW5ndGg7aSsrKW8odFtpXSk7cmV0dXJuIG99cmV0dXJuIHJ9KSgpIiwiaW1wb3J0IHsgUmV2aWV3U2xpZGVyLCBBcnJvd0NvbnRyb2xzIH0gZnJvbSAnQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy9zbGlkZXInO1xuaW1wb3J0IHRyYWNraW5nIGZyb20gJ0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvaW1wcmVzc2lvbic7XG5pbXBvcnQgeyBmZXRjaFNlcnZpY2VSZXZpZXdEYXRhIH0gZnJvbSAnQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy9hcGknO1xuaW1wb3J0IHsgcG9wdWxhdGVFbGVtZW50cyB9IGZyb20gJ0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvZG9tJztcbmltcG9ydCB7XG4gIGluc2VydE51bWJlclNlcGFyYXRvcixcbiAgYWRkVXRtUGFyYW1zLFxuICBzZXRIdG1sQ29udGVudCxcbiAgc2V0Rm9udCxcbiAgc2V0VGV4dENvbG9yLFxuICBzZXRUZXh0Q29udGVudCxcbn0gZnJvbSAnQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy91dGlscyc7XG5pbXBvcnQgeyBnZXRBc09iamVjdCBhcyBnZXRRdWVyeVN0cmluZyB9IGZyb20gJ0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvcXVlcnlTdHJpbmcnO1xuaW1wb3J0IHJldmlld1RlbXBsYXRlIGZyb20gJ0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvdGVtcGxhdGVzL3Jldmlld3MnO1xuaW1wb3J0IHsgcG9wdWxhdGVMb2dvIH0gZnJvbSAnQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy90ZW1wbGF0ZXMvbG9nbyc7XG5pbXBvcnQgeyBta0VsZW1XaXRoU3ZnTG9va3VwIH0gZnJvbSAnQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy90ZW1wbGF0aW5nJztcbmltcG9ydCB7XG4gIG1ha2VFbXB0eVN1bW1hcnksXG4gIE9SSUVOVEFUSU9OLFxufSBmcm9tICdAdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3RlbXBsYXRlcy9zdW1tYXJ5JztcbmltcG9ydCBpbml0IGZyb20gJ0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvaW5pdCc7XG5pbXBvcnQgeyBjcmVhdGVQbGFjZWhvbGRlciB9IGZyb20gJy4vcGxhY2Vob2xkZXInO1xuaW1wb3J0IGdldFJldmlld0ZpbHRlclRleHQgZnJvbSAnQHRydXN0cGlsb3QvdHJ1c3Rib3gtZnJhbWV3b3JrLXZhbmlsbGEvbW9kdWxlcy9yZXZpZXdGaWx0ZXJUZXh0JztcblxudHJhY2tpbmcuYXR0YWNoSW1wcmVzc2lvbkhhbmRsZXIoKTtcblxuY29uc3Qge1xuICBidXNpbmVzc3VuaXRJZDogYnVzaW5lc3NVbml0SWQsXG4gIGxvY2FsZSxcbiAgdGhlbWUgPSAnbGlnaHQnLFxuICByZXZpZXdMYW5ndWFnZXMsXG4gIHN0YXJzOiByZXZpZXdTdGFycyxcbiAgdGFnczogcmV2aWV3VGFnVmFsdWUsXG4gIGxvY2F0aW9uLFxuICB0ZW1wbGF0ZUlkLFxuICBmb250RmFtaWx5LFxuICB0ZXh0Q29sb3IsXG59ID0gZ2V0UXVlcnlTdHJpbmcoKTtcblxuY29uc3QgYWRkVXRtID0gYWRkVXRtUGFyYW1zKCdTbGlkZXInKTtcbmNvbnN0IG1rVHJhY2tpbmcgPSAoc291cmNlKSA9PiAoKSA9PiB0cmFja2luZy5lbmdhZ2VtZW50KHsgc291cmNlIH0pO1xuXG5jb25zdCBwb3B1bGF0ZUVtcHR5U3VtbWFyeSA9ICh7IHRpdGxlLCB1cmwgfSkgPT4ge1xuICBjb25zdCB3aWRnZXRDb250ZW50RWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cC13aWRnZXQtd3JhcHBlcicpO1xuICBjb25zdCBvcHRpb25zID0geyB0aXRsZSwgdXJsLCBvcmllbnRhdGlvbjogT1JJRU5UQVRJT04uSE9SSVpPTlRBTCB9O1xuICBjb25zdCBlbXB0eVN1bW1hcnkgPSBtYWtlRW1wdHlTdW1tYXJ5KG9wdGlvbnMpO1xuICBzZXRIdG1sQ29udGVudCh3aWRnZXRDb250ZW50RWxlbWVudCwgZW1wdHlTdW1tYXJ5LCBmYWxzZSk7XG59O1xuXG5jb25zdCBwb3B1bGF0ZVNsaWRlciA9ICh7IGxvY2FsZSwgcmV2aWV3cyB9KSA9PiB7XG4gIGNvbnN0IHNsaWRlckVsZW1lbnRzID0ge1xuICAgIHNsaWRlcjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RwLXdpZGdldC1yZXZpZXdzJyksXG4gICAgc2xpZGVyQ29udGFpbmVyOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndHAtd2lkZ2V0LXJldmlld3Mtd3JhcHBlcicpLFxuICB9O1xuICBjb25zdCBzbGlkZXJBcnJvd3MgPSB7XG4gICAgcHJldkFycm93OiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmV2aWV3LWFycm93LWxlZnQnKSxcbiAgICBuZXh0QXJyb3c6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZXZpZXctYXJyb3ctcmlnaHQnKSxcbiAgfTtcbiAgY29uc3QgdGVtcGxhdGVPcHRpb25zID0ge1xuICAgIHJldmlld0xpbmtHZW5lcmF0b3I6IChyZXZpZXcpID0+IGFkZFV0bShyZXZpZXcucmV2aWV3VXJsKSxcbiAgfTtcbiAgY29uc3QgdGVtcGxhdGUgPSByZXZpZXdUZW1wbGF0ZShsb2NhbGUudG9Mb3dlckNhc2UoKSwgdGVtcGxhdGVPcHRpb25zKTtcbiAgY29uc3Qgc3ZnU2xpZGVyQXJyb3dzID0gW10uc2xpY2UuY2FsbChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdzdmctc2xpZGVyLWFycm93JykpO1xuICBzdmdTbGlkZXJBcnJvd3MuZm9yRWFjaCgoaXRlbSkgPT5cbiAgICBwb3B1bGF0ZUVsZW1lbnRzKFtcbiAgICAgIHtcbiAgICAgICAgZWxlbWVudDogaXRlbSxcbiAgICAgICAgc3RyaW5nOiBta0VsZW1XaXRoU3ZnTG9va3VwKCdhcnJvd1NsaWRlcicpLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgZWxlbWVudDogaXRlbSxcbiAgICAgICAgc3RyaW5nOiBta0VsZW1XaXRoU3ZnTG9va3VwKCdhcnJvd1NsaWRlcicpLFxuICAgICAgfSxcbiAgICBdKVxuICApO1xuXG4gIGNvbnN0IGNhbGxiYWNrcyA9IHtcbiAgICBwcmV2UGFnZTogbWtUcmFja2luZygnUHJldicpLFxuICAgIG5leHRQYWdlOiBta1RyYWNraW5nKCdOZXh0JyksXG4gIH07XG4gIGNvbnN0IGJyZWFrcG9pbnRzID0gW1xuICAgIHtcbiAgICAgIG1pbldpZHRoOiAxMjAwLFxuICAgICAgcmV2aWV3c0ZvcldpZHRoOiA1LFxuICAgIH0sXG4gICAge1xuICAgICAgbWluV2lkdGg6IDk4MCxcbiAgICAgIHJldmlld3NGb3JXaWR0aDogNCxcbiAgICB9LFxuICAgIHtcbiAgICAgIG1pbldpZHRoOiA3NjAsXG4gICAgICByZXZpZXdzRm9yV2lkdGg6IDMsXG4gICAgfSxcbiAgICB7XG4gICAgICBtaW5XaWR0aDogNTQwLFxuICAgICAgcmV2aWV3c0ZvcldpZHRoOiAyLFxuICAgIH0sXG4gICAge1xuICAgICAgbWluV2lkdGg6IDAsXG4gICAgICByZXZpZXdzRm9yV2lkdGg6IDEsXG4gICAgfSxcbiAgXTtcblxuICBjb25zdCBzbGlkZXJIYW5kbGVyID0gbmV3IFJldmlld1NsaWRlcihyZXZpZXdzLCBzbGlkZXJFbGVtZW50cywgdGVtcGxhdGUsIHtcbiAgICByZXZpZXdDbGFzczogJ3RwLXdpZGdldC1yZXZpZXcnLFxuICAgIHJldmlld3NQZXJQYWdlOiBicmVha3BvaW50cyxcbiAgfSk7XG4gIGNvbnN0IHNsaWRlckNvbnRyb2xzID0gbmV3IEFycm93Q29udHJvbHMoc2xpZGVySGFuZGxlciwgc2xpZGVyQXJyb3dzLCB7XG4gICAgY2FsbGJhY2tzLFxuICAgIGRpc2FibGVkQ2xhc3M6ICdkaXNwbGF5LW5vbmUnLFxuICB9KTtcbiAgc2xpZGVyQ29udHJvbHMuaW5pdGlhbGl6ZSgpO1xufTtcblxuY29uc3QgcG9wdWxhdGVGb290ZXIgPSAoe1xuICBsb2NhbGUsXG4gIGJhc2VEYXRhOiB7XG4gICAgYnVzaW5lc3NFbnRpdHk6IHtcbiAgICAgIG51bWJlck9mUmV2aWV3czogeyB0b3RhbDogbnVtYmVyT2ZSZXZpZXdzIH0sXG4gICAgICB0cnVzdFNjb3JlLFxuICAgIH0sXG4gICAgbGlua3M6IHsgcHJvZmlsZVVybCB9LFxuICAgIHRyYW5zbGF0aW9ucyxcbiAgfSxcbn0pID0+IHtcbiAgY29uc3QgcmF0aW5nRWxlbWVudExvbmcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmF0aW5nLWxvbmcnKTtcbiAgcG9wdWxhdGVFbGVtZW50cyhbXG4gICAge1xuICAgICAgZWxlbWVudDogcmF0aW5nRWxlbWVudExvbmcsXG4gICAgICBzdHJpbmc6IHRyYW5zbGF0aW9ucy5tYWluTG9uZyxcbiAgICAgIHN1YnN0aXR1dGlvbnM6IHtcbiAgICAgICAgJ1tSQVRJTkddJzogdHJ1c3RTY29yZS50b0ZpeGVkKDEpLFxuICAgICAgICAnW05PUkVWSUVXU10nOiBpbnNlcnROdW1iZXJTZXBhcmF0b3IobnVtYmVyT2ZSZXZpZXdzLCBsb2NhbGUpLFxuICAgICAgfSxcbiAgICB9LFxuICBdKTtcbiAgY29uc3QgbGlua0VsZW1lbnRMb25nID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3JhdGluZy1sb25nIGEnKTtcbiAgbGlua0VsZW1lbnRMb25nLmhyZWYgPSBhZGRVdG0ocHJvZmlsZVVybCk7XG5cbiAgY29uc3QgcmF0aW5nRWxlbWVudFNob3J0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JhdGluZy1zaG9ydCcpO1xuICBwb3B1bGF0ZUVsZW1lbnRzKFtcbiAgICB7XG4gICAgICBlbGVtZW50OiByYXRpbmdFbGVtZW50U2hvcnQsXG4gICAgICBzdHJpbmc6IHRyYW5zbGF0aW9ucy5tYWluU2hvcnQsXG4gICAgICBzdWJzdGl0dXRpb25zOiB7XG4gICAgICAgICdbUkFUSU5HXSc6IHRydXN0U2NvcmUudG9GaXhlZCgxKSxcbiAgICAgICAgJ1tOT1JFVklFV1NdJzogaW5zZXJ0TnVtYmVyU2VwYXJhdG9yKG51bWJlck9mUmV2aWV3cywgbG9jYWxlKSxcbiAgICAgIH0sXG4gICAgfSxcbiAgXSk7XG4gIGNvbnN0IGxpbmtFbGVtZW50U2hvcnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjcmF0aW5nLXNob3J0IGEnKTtcbiAgbGlua0VsZW1lbnRTaG9ydC5ocmVmID0gYWRkVXRtKHByb2ZpbGVVcmwpO1xuXG4gIGNvbnN0IHJldmlld3NGaWx0ZXJUZXh0RWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cC13aWRnZXQtcmV2aWV3cy1maWx0ZXItbGFiZWwnKTtcbiAgY29uc3QgcmV2aWV3c0ZpbHRlclRleHQgPSBnZXRSZXZpZXdGaWx0ZXJUZXh0KGxvY2FsZSwgcmV2aWV3U3RhcnMsIHJldmlld1RhZ1ZhbHVlKTtcbiAgc2V0VGV4dENvbnRlbnQocmV2aWV3c0ZpbHRlclRleHRFbGVtZW50LCByZXZpZXdzRmlsdGVyVGV4dCk7XG5cbiAgY29uc3QgcmV2aWV3c0ZpbHRlckRvdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cC13aWRnZXQtcmV2aWV3cy1maWx0ZXItZG90Jyk7XG4gIHBvcHVsYXRlRWxlbWVudHMoW1xuICAgIHtcbiAgICAgIGVsZW1lbnQ6IHJldmlld3NGaWx0ZXJEb3QsXG4gICAgICBzdHJpbmc6IHRyYW5zbGF0aW9ucy5kb3QsXG4gICAgfSxcbiAgXSk7XG5cbiAgY29uc3QgbG9nb0xpbmsgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndHAtd2lkZ2V0LWxvZ28nKTtcbiAgbG9nb0xpbmsuaHJlZiA9IGFkZFV0bShwcm9maWxlVXJsKTtcbiAgcG9wdWxhdGVMb2dvKCk7XG59O1xuXG5jb25zdCBhcHBseUN1c3RvbVN0eWxpbmcgPSAoKSA9PiB7XG4gIGlmIChmb250RmFtaWx5KSB7XG4gICAgc2V0Rm9udChmb250RmFtaWx5KTtcbiAgfVxuICBpZiAodGV4dENvbG9yKSB7XG4gICAgc2V0VGV4dENvbG9yKHRleHRDb2xvcik7XG4gIH1cbn07XG5cbmNvbnN0IGNvbnN0cnVjdFRydXN0Qm94ID0gKHsgYmFzZURhdGEsIGxvY2FsZSB9KSA9PiB7XG4gIGNvbnN0IG51bWJlck9mUmV2aWV3cyA9IGJhc2VEYXRhLmJ1c2luZXNzRW50aXR5Lm51bWJlck9mUmV2aWV3cy50b3RhbDtcbiAgaWYgKG51bWJlck9mUmV2aWV3cyA+IDApIHtcbiAgICBwb3B1bGF0ZVNsaWRlcih7IGxvY2FsZSwgcmV2aWV3czogYmFzZURhdGEucmV2aWV3cyB9KTtcbiAgICBwb3B1bGF0ZUZvb3Rlcih7IGxvY2FsZSwgYmFzZURhdGEgfSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgdXJsID0gYWRkVXRtKGJhc2VEYXRhLmxpbmtzLmV2YWx1YXRlVXJsKTtcbiAgICBjb25zdCB0aXRsZSA9IGJhc2VEYXRhLnRyYW5zbGF0aW9ucy5ub1Jldmlld3M7XG4gICAgcG9wdWxhdGVFbXB0eVN1bW1hcnkoeyB0aXRsZSwgdXJsIH0pO1xuICB9XG4gIGlmIChiYXNlRGF0YS5zZXR0aW5ncy5jdXN0b21TdHlsZXNBbGxvd2VkKSB7XG4gICAgYXBwbHlDdXN0b21TdHlsaW5nKCk7XG4gIH1cbn07XG5cbmNvbnN0IGZldGNoUGFyYW1zID0ge1xuICBidXNpbmVzc1VuaXRJZCxcbiAgbG9jYWxlLFxuICByZXZpZXdMYW5ndWFnZXMsXG4gIHJldmlld1N0YXJzLFxuICByZXZpZXdUYWdWYWx1ZSxcbiAgcmV2aWV3c1BlclBhZ2U6IDE1LFxuICB0aGVtZSxcbiAgbG9jYXRpb24sXG59O1xucG9wdWxhdGVFbGVtZW50cyhbXG4gIHtcbiAgICBlbGVtZW50OiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndHAtd2lkZ2V0LWxvYWRlcicpLFxuICAgIHN0cmluZzogY3JlYXRlUGxhY2Vob2xkZXIoKSxcbiAgfSxcbl0pO1xuXG5pbml0KCgpID0+IHtcbiAgZmV0Y2hTZXJ2aWNlUmV2aWV3RGF0YSh0ZW1wbGF0ZUlkKShmZXRjaFBhcmFtcywgY29uc3RydWN0VHJ1c3RCb3gpO1xufSk7XG4iLCJpbXBvcnQgeyBzZXRIdG1sQ29udGVudCwgbWFrZVRyYW5zbGF0aW9ucywgcmVtb3ZlRWxlbWVudCB9IGZyb20gJy4vdXRpbHMnO1xuXG5jb25zdCBoYXNDbGFzcyA9IChlbGVtLCBjbGFzc05hbWUpID0+IHtcbiAgaWYgKGVsZW0pIHtcbiAgICBjb25zdCBlbGVtQ2xhc3NMaXN0ID0gZWxlbS5nZXRBdHRyaWJ1dGUoJ2NsYXNzJyk7XG4gICAgY29uc3QgY2xhc3NOYW1lcyA9IGVsZW1DbGFzc0xpc3QgPyBlbGVtQ2xhc3NMaXN0LnNwbGl0KCcgJykgOiAnJztcbiAgICByZXR1cm4gY2xhc3NOYW1lcy5pbmRleE9mKGNsYXNzTmFtZSkgIT09IC0xO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn07XG5cbmNvbnN0IGFkZENsYXNzID0gKGVsZW0sIGZvckFkZGl0aW9uKSA9PiB7XG4gIGlmIChlbGVtKSB7XG4gICAgY29uc3QgZWxlbUNsYXNzTGlzdCA9IGVsZW0uZ2V0QXR0cmlidXRlKCdjbGFzcycpO1xuICAgIGNvbnN0IGNsYXNzTmFtZXMgPSBlbGVtQ2xhc3NMaXN0ID8gZWxlbUNsYXNzTGlzdC5zcGxpdCgnICcpIDogW107XG5cbiAgICBpZiAoIWhhc0NsYXNzKGVsZW0sIGZvckFkZGl0aW9uKSkge1xuICAgICAgY29uc3QgbmV3Q2xhc3NlcyA9IFsuLi5jbGFzc05hbWVzLCBmb3JBZGRpdGlvbl0uam9pbignICcpO1xuICAgICAgZWxlbS5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgbmV3Q2xhc3Nlcyk7XG4gICAgfVxuICB9XG59O1xuXG5jb25zdCByZW1vdmVDbGFzcyA9IChlbGVtLCBmb3JSZW1vdmFsKSA9PiB7XG4gIGlmIChlbGVtKSB7XG4gICAgY29uc3QgY2xhc3NOYW1lcyA9IGVsZW0uY2xhc3NOYW1lLnNwbGl0KCcgJyk7XG4gICAgZWxlbS5jbGFzc05hbWUgPSBjbGFzc05hbWVzLmZpbHRlcigobmFtZSkgPT4gbmFtZSAhPT0gZm9yUmVtb3ZhbCkuam9pbignICcpO1xuICB9XG59O1xuXG4vKipcbiAqIFBvcHVsYXRlcyBhIHNlcmllcyBvZiBlbGVtZW50cyB3aXRoIEhUTUwgY29udGVudC5cbiAqXG4gKiBGb3IgZWFjaCBvYmplY3QgaW4gYSBsaXN0LCBlaXRoZXIgYSBnaXZlbiBzdHJpbmcgdmFsdWUgaXMgdXNlZCB0byBwb3B1bGF0ZVxuICogdGhlIGdpdmVuIGVsZW1lbnQgKGluY2x1ZGluZyBvcHRpb25hbCBzdWJzdGl0dXRpb25zKTsgb3IsIHdoZXJlIG5vIHN0cmluZ1xuICogdmFsdWUgaXMgcHJvdmlkZWQsIHJlbW92ZSB0aGUgZ2l2ZW4gZWxlbWVudC5cbiAqL1xuY29uc3QgcG9wdWxhdGVFbGVtZW50cyA9IChlbGVtZW50cykgPT4ge1xuICBlbGVtZW50cy5mb3JFYWNoKCh7IGVsZW1lbnQsIHN0cmluZywgc3Vic3RpdHV0aW9ucyA9IHt9IH0pID0+IHtcbiAgICBpZiAoc3RyaW5nKSB7XG4gICAgICBzZXRIdG1sQ29udGVudChlbGVtZW50LCBtYWtlVHJhbnNsYXRpb25zKHN1YnN0aXR1dGlvbnMsIHN0cmluZyksIGZhbHNlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVtb3ZlRWxlbWVudChlbGVtZW50KTtcbiAgICB9XG4gIH0pO1xufTtcblxuZXhwb3J0IHsgYWRkQ2xhc3MsIHJlbW92ZUNsYXNzLCBoYXNDbGFzcywgcG9wdWxhdGVFbGVtZW50cyB9O1xuIiwiaW1wb3J0IHsgZ2V0QXNPYmplY3QgYXMgcXVlcnlTdHJpbmcgfSBmcm9tICcuL3F1ZXJ5U3RyaW5nJztcbmltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tICcuL3V0aWxzJztcbmltcG9ydCBnZXRXaWRnZXRSb290VXJpIGZyb20gJy4vcm9vdFVyaSc7XG5pbXBvcnQgeGhyIGZyb20gJy4veGhyJztcblxuZnVuY3Rpb24gc2V0Q29va2llKGNuYW1lLCBjdmFsdWUsIGV4cGlyZXMpIHtcbiAgY29uc3QgcGF0aCA9ICdwYXRoPS8nO1xuICBjb25zdCBkb21haW4gPSBgZG9tYWluPSR7d2luZG93LmxvY2F0aW9uLmhvc3RuYW1lLnJlcGxhY2UoL14uKlxcLihbXi5dK1xcLlteLl0rKS8sICckMScpfWA7XG4gIGNvbnN0IHNhbWVzaXRlID0gYHNhbWVzaXRlPW5vbmVgO1xuICBjb25zdCBzZWN1cmUgPSBgc2VjdXJlYDtcbiAgZG9jdW1lbnQuY29va2llID0gW2Ake2NuYW1lfT0ke2N2YWx1ZX1gLCBwYXRoLCBleHBpcmVzLCBkb21haW4sIHNhbWVzaXRlLCBzZWN1cmVdLmpvaW4oJzsgJyk7XG4gIGRvY3VtZW50LmNvb2tpZSA9IFtgJHtjbmFtZX0tbGVnYWN5PSR7Y3ZhbHVlfWAsIHBhdGgsIGV4cGlyZXMsIGRvbWFpbl0uam9pbignOyAnKTtcbn1cblxuZnVuY3Rpb24gbWFrZVRyYWNraW5nVXJsKGV2ZW50TmFtZSwgaW1wcmVzc2lvbkRhdGEpIHtcbiAgLy8gRGVzdHJ1Y3R1cmUgdGhlIGltcHJlc3Npb25EYXRhIGFuZCBxdWVyeSBwYXJhbXMgc28gdGhhdCB3ZSBvbmx5IHBhc3MgdGhlXG4gIC8vIGRlc2lyZWQgdmFsdWVzIGZvciBjb25zdHJ1Y3RpbmcgdGhlIHRyYWNraW5nIFVSTC5cbiAgY29uc3QgeyBhbm9ueW1vdXNJZDogdXNlcklkLCBzZXNzaW9uRXhwaXJ5OiBfLCAuLi5pbXByZXNzaW9uUGFyYW1zIH0gPSBpbXByZXNzaW9uRGF0YTtcbiAgY29uc3QgeyBidXNpbmVzc3VuaXRJZDogYnVzaW5lc3NVbml0SWQsIHRlbXBsYXRlSWQ6IHdpZGdldElkLCAuLi53aWRnZXRTZXR0aW5ncyB9ID0gcXVlcnlTdHJpbmcoKTtcblxuICBjb25zdCB1cmxQYXJhbXMgPSB7XG4gICAgLi4ud2lkZ2V0U2V0dGluZ3MsXG4gICAgLi4uaW1wcmVzc2lvblBhcmFtcyxcbiAgICAuLi4od2lkZ2V0U2V0dGluZ3MuZ3JvdXAgJiYgdXNlcklkID8geyB1c2VySWQgfSA6IHsgbm9zZXR0aW5nczogMSB9KSxcbiAgICBidXNpbmVzc1VuaXRJZCxcbiAgICB3aWRnZXRJZCxcbiAgfTtcbiAgY29uc3QgdXJsUGFyYW1zU3RyaW5nID0gT2JqZWN0LmtleXModXJsUGFyYW1zKVxuICAgIC5tYXAoKHByb3BlcnR5KSA9PiBgJHtwcm9wZXJ0eX09JHtlbmNvZGVVUklDb21wb25lbnQodXJsUGFyYW1zW3Byb3BlcnR5XSl9YClcbiAgICAuam9pbignJicpO1xuICByZXR1cm4gYCR7Z2V0V2lkZ2V0Um9vdFVyaSgpfS9zdGF0cy8ke2V2ZW50TmFtZX0/JHt1cmxQYXJhbXNTdHJpbmd9YDtcbn1cblxuZnVuY3Rpb24gc2V0VHJhY2tpbmdDb29raWVzKGV2ZW50TmFtZSwgeyBzZXNzaW9uLCB0ZXN0SWQsIHNlc3Npb25FeHBpcnkgfSkge1xuICBjb25zdCB7IGdyb3VwLCBidXNpbmVzc3VuaXRJZDogYnVzaW5lc3NVbml0SWQgfSA9IHF1ZXJ5U3RyaW5nKCk7XG4gIGlmICghZ3JvdXApIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoIXRlc3RJZCB8fCAhc2Vzc2lvbikge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgIGNvbnNvbGUud2FybihcbiAgICAgICdUcnVzdEJveCBPcHRpbWl6ZXIgdGVzdCBncm91cCBkZXRlY3RlZCBidXQgbm8gcnVubmluZyB0ZXN0IHNldHRpbmdzIGZvdW5kIScsXG4gICAgKTtcbiAgfVxuXG4gIGlmIChzZXNzaW9uRXhwaXJ5KSB7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSB7IGdyb3VwLCBzZXNzaW9uLCB0ZXN0SWQgfTtcbiAgICBzZXRDb29raWUoXG4gICAgICBgVHJ1c3Rib3hTcGxpdFRlc3RfJHtidXNpbmVzc1VuaXRJZH1gLFxuICAgICAgZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KHNldHRpbmdzKSksXG4gICAgICBzZXNzaW9uRXhwaXJ5XG4gICAgKTtcbiAgfVxufVxuXG5mdW5jdGlvbiB0cmFja0V2ZW50UmVxdWVzdChldmVudE5hbWUsIGltcHJlc3Npb25EYXRhKSB7XG4gIHNldFRyYWNraW5nQ29va2llcyhldmVudE5hbWUsIGltcHJlc3Npb25EYXRhKTtcbiAgY29uc3QgdXJsID0gbWFrZVRyYWNraW5nVXJsKGV2ZW50TmFtZSwgaW1wcmVzc2lvbkRhdGEpO1xuICB0cnkge1xuICAgIHhocih7IHVybCB9KTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIC8vIGRvIG5vdGhpbmdcbiAgfVxufVxuXG5jb25zdCB0cmFja0ltcHJlc3Npb24gPSBmdW5jdGlvbihkYXRhKSB7XG4gIHRyYWNrRXZlbnRSZXF1ZXN0KCdUcnVzdGJveEltcHJlc3Npb24nLCBkYXRhKTtcbn07XG5cbmNvbnN0IHRyYWNrVmlldyA9IGZ1bmN0aW9uKGRhdGEpIHtcbiAgdHJhY2tFdmVudFJlcXVlc3QoJ1RydXN0Ym94VmlldycsIGRhdGEpO1xufTtcblxuY29uc3QgdHJhY2tFbmdhZ2VtZW50ID0gZnVuY3Rpb24oZGF0YSkge1xuICB0cmFja0V2ZW50UmVxdWVzdCgnVHJ1c3Rib3hFbmdhZ2VtZW50JywgZGF0YSk7XG59O1xuXG5sZXQgaWQgPSBudWxsO1xuXG5jb25zdCBhdHRhY2hJbXByZXNzaW9uSGFuZGxlciA9IGZ1bmN0aW9uKCkge1xuICBhZGRFdmVudExpc3RlbmVyKHdpbmRvdywgJ21lc3NhZ2UnLCBmdW5jdGlvbihldmVudCkge1xuICAgIGlmICh0eXBlb2YgZXZlbnQuZGF0YSAhPT0gJ3N0cmluZycpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBsZXQgZTtcbiAgICB0cnkge1xuICAgICAgZSA9IHsgZGF0YTogSlNPTi5wYXJzZShldmVudC5kYXRhKSB9O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIHByb2JhYmx5IG5vdCBmb3IgdXNcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoZS5kYXRhLmNvbW1hbmQgPT09ICdzZXRJZCcpIHtcbiAgICAgIGlkID0gZS5kYXRhLndpZGdldElkO1xuICAgICAgd2luZG93LnBhcmVudC5wb3N0TWVzc2FnZShKU09OLnN0cmluZ2lmeSh7IGNvbW1hbmQ6ICdpbXByZXNzaW9uJywgd2lkZ2V0SWQ6IGlkIH0pLCAnKicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChlLmRhdGEuY29tbWFuZCA9PT0gJ2ltcHJlc3Npb24tcmVjZWl2ZWQnKSB7XG4gICAgICBkZWxldGUgZS5kYXRhLmNvbW1hbmQ7XG4gICAgICB0cmFja0ltcHJlc3Npb24oZS5kYXRhKTtcbiAgICB9XG5cbiAgICBpZiAoZS5kYXRhLmNvbW1hbmQgPT09ICd0cnVzdGJveC1pbi12aWV3cG9ydCcpIHtcbiAgICAgIGRlbGV0ZSBlLmRhdGEuY29tbWFuZDtcbiAgICAgIHRyYWNrVmlldyhlLmRhdGEpO1xuICAgIH1cbiAgfSk7XG59O1xuXG5jb25zdCB0cmFja2luZyA9IHtcbiAgZW5nYWdlbWVudDogdHJhY2tFbmdhZ2VtZW50LFxuICBhdHRhY2hJbXByZXNzaW9uSGFuZGxlcixcbn07XG5cbmV4cG9ydCBkZWZhdWx0IHRyYWNraW5nO1xuIiwiaW1wb3J0IHsgbWtFbGVtV2l0aFN2Z0xvb2t1cCB9IGZyb20gJy4uL3RlbXBsYXRpbmcnO1xuaW1wb3J0IHsgcG9wdWxhdGVFbGVtZW50cyB9IGZyb20gJy4uL2RvbSc7XG5cbmNvbnN0IG1ha2VMb2dvID0gKCkgPT4gbWtFbGVtV2l0aFN2Z0xvb2t1cCgnbG9nbycpO1xuXG5jb25zdCBwb3B1bGF0ZUxvZ28gPSAobG9nb0NvbnRhaW5lciA9ICd0cC13aWRnZXQtbG9nbycpID0+IHtcbiAgY29uc3QgY29udGFpbmVyID1cbiAgICB0eXBlb2YgbG9nb0NvbnRhaW5lciA9PT0gJ3N0cmluZycgPyBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChsb2dvQ29udGFpbmVyKSA6IGxvZ29Db250YWluZXI7XG5cbiAgcG9wdWxhdGVFbGVtZW50cyhbXG4gICAge1xuICAgICAgZWxlbWVudDogY29udGFpbmVyLFxuICAgICAgc3RyaW5nOiBtYWtlTG9nbygpLFxuICAgIH0sXG4gIF0pO1xufTtcblxuZXhwb3J0IHsgbWFrZUxvZ28sIHBvcHVsYXRlTG9nbyB9O1xuIiwiaW1wb3J0IHsgZGl2LCBzcGFuLCBhIH0gZnJvbSAnLi4vdGVtcGxhdGluZyc7XG5pbXBvcnQgeyBtYWtlU3RhcnMgfSBmcm9tICcuL3N0YXJzJztcbmltcG9ydCB7IG1ha2VMb2dvIH0gZnJvbSAnLi9sb2dvJztcbmltcG9ydCB7IG1ha2VUcmFuc2xhdGlvbnMgfSBmcm9tICcuLi91dGlscyc7XG5cbmNvbnN0IEhPUklaT05UQUwgPSAnaG9yaXpvbnRhbCc7XG5jb25zdCBWRVJUSUNBTCA9ICd2ZXJ0aWNhbCc7XG5jb25zdCBPUklFTlRBVElPTiA9IHtcbiAgSE9SSVpPTlRBTCxcbiAgVkVSVElDQUwsXG59O1xuXG5jb25zdCB1c2VOb2ZvbGxvdyA9IChub2ZvbGxvdykgPT4gKG5vZm9sbG93ID8geyByZWw6ICdub2ZvbGxvdycgfSA6IHt9KTtcblxuY29uc3QgcmVuZGVyU3VidGl0bGUgPSAob3B0aW9ucykgPT4ge1xuICBjb25zdCB7IHN1YnRpdGxlLCB1cmwsIGhhc0xvZ28sIG5vZm9sbG93IH0gPSBvcHRpb25zO1xuICBjb25zdCB0cmFuc2xhdGVkU3VidGl0bGUgPSBzdWJ0aXRsZSAmJiBtYWtlVHJhbnNsYXRpb25zKHt9LCBzdWJ0aXRsZSk7XG4gIGNvbnN0IGNoaWxkcmVuID0gW1xuICAgIHRyYW5zbGF0ZWRTdWJ0aXRsZSAmJiBzcGFuKHsgY2xhc3M6ICd0cC13aWRnZXQtZW1wdHktdmVydGljYWxfX3N1YnRpdGxlJyB9LCB0cmFuc2xhdGVkU3VidGl0bGUpLFxuICAgIHVybCAmJlxuICAgICAgYShcbiAgICAgICAge1xuICAgICAgICAgIGNsYXNzOiAndHAtd2lkZ2V0LWVtcHR5LXZlcnRpY2FsX19sb2dvJyxcbiAgICAgICAgICBocmVmOiB1cmwsXG4gICAgICAgICAgdGFyZ2V0OiAnX2JsYW5rJyxcbiAgICAgICAgICAuLi51c2VOb2ZvbGxvdyhub2ZvbGxvdyksXG4gICAgICAgIH0sXG4gICAgICAgIG1ha2VMb2dvKClcbiAgICAgICksXG4gICAgaGFzTG9nbyAmJiAhdXJsICYmIHNwYW4oeyBjbGFzczogJ3RwLXdpZGdldC1lbXB0eS12ZXJ0aWNhbF9fbG9nbycgfSwgbWFrZUxvZ28oKSksXG4gIF0uZmlsdGVyKEJvb2xlYW4pO1xuXG4gIHJldHVybiBkaXYoeyBjbGFzczogJ3RwLXdpZGdldC1lbXB0eS12ZXJ0aWNhbF9fc3VidGl0bGUtd3JhcHBlcicgfSwgLi4uY2hpbGRyZW4pO1xufTtcblxuY29uc3QgbWFrZUVtcHR5VmVydGljYWxTdW1tYXJ5ID0gKG9wdGlvbnMpID0+IHtcbiAgY29uc3QgdHJhbnNsYXRlZFRpdGxlID0gbWFrZVRyYW5zbGF0aW9ucyh7fSwgb3B0aW9ucy50aXRsZSk7XG4gIGNvbnN0IHN1YnRpdGxlRWxlbWVudCA9IHJlbmRlclN1YnRpdGxlKG9wdGlvbnMpO1xuICByZXR1cm4gZGl2KFxuICAgIHtcbiAgICAgIGNsYXNzOiAndHAtd2lkZ2V0LWVtcHR5LXZlcnRpY2FsJyxcbiAgICB9LFxuICAgIHNwYW4oeyBjbGFzczogJ3RwLXdpZGdldC1lbXB0eS12ZXJ0aWNhbF9fdGl0bGUnIH0sIHRyYW5zbGF0ZWRUaXRsZSksXG4gICAgbWFrZVN0YXJzKHsgbnVtOiAwLCB3cmFwcGVyQ2xhc3M6ICd0cC13aWRnZXQtZW1wdHktdmVydGljYWxfX3N0YXJzJyB9KSxcbiAgICBzdWJ0aXRsZUVsZW1lbnRcbiAgKTtcbn07XG5cbmNvbnN0IG1ha2VFbXB0eUhvcml6b250YWxTdW1tYXJ5ID0gKG9wdGlvbnMpID0+IHtcbiAgY29uc3QgeyB0aXRsZSwgdXJsLCBub2ZvbGxvdyB9ID0gb3B0aW9ucztcbiAgY29uc3QgdHJhbnNsYXRlZFRpdGxlID0gbWFrZVRyYW5zbGF0aW9ucyh7fSwgdGl0bGUpO1xuICByZXR1cm4gZGl2KFxuICAgIHsgY2xhc3M6ICd0cC13aWRnZXQtZW1wdHktaG9yaXpvbnRhbCcgfSxcbiAgICBzcGFuKHsgY2xhc3M6ICd0cC13aWRnZXQtZW1wdHktaG9yaXpvbnRhbF9fdGl0bGUnIH0sIHRyYW5zbGF0ZWRUaXRsZSksXG4gICAgYShcbiAgICAgIHtcbiAgICAgICAgY2xhc3M6ICd0cC13aWRnZXQtZW1wdHktaG9yaXpvbnRhbF9fbG9nbycsXG4gICAgICAgIGhyZWY6IHVybCxcbiAgICAgICAgdGFyZ2V0OiAnX2JsYW5rJyxcbiAgICAgICAgLi4udXNlTm9mb2xsb3cobm9mb2xsb3cpLFxuICAgICAgfSxcbiAgICAgIG1ha2VMb2dvKClcbiAgICApXG4gICk7XG59O1xuXG5jb25zdCBtYWtlRW1wdHlTdW1tYXJ5ID0gKG9wdGlvbnMpID0+IHtcbiAgcmV0dXJuIG9wdGlvbnMub3JpZW50YXRpb24gPT09IE9SSUVOVEFUSU9OLkhPUklaT05UQUxcbiAgICA/IG1ha2VFbXB0eUhvcml6b250YWxTdW1tYXJ5KG9wdGlvbnMpXG4gICAgOiBtYWtlRW1wdHlWZXJ0aWNhbFN1bW1hcnkob3B0aW9ucyk7XG59O1xuXG5leHBvcnQgeyBtYWtlRW1wdHlTdW1tYXJ5LCBPUklFTlRBVElPTiB9O1xuIiwiaW1wb3J0IHsgc3ZnTWFwIH0gZnJvbSAnLi9hc3NldHMvc3ZnJztcblxuY29uc3QgZmxhdHRlbiA9IChhcnJzKSA9PiBbXS5jb25jYXQuYXBwbHkoW10sIGFycnMpO1xuXG5jb25zdCBta1Byb3BzID0gKHByb3BzKSA9PlxuICBPYmplY3Qua2V5cyhwcm9wcylcbiAgICAubWFwKChrZXkpID0+IGAke2tleX09XCIke3Byb3BzW2tleV19XCJgKVxuICAgIC5qb2luKCcgJyk7XG5cbmNvbnN0IG1rRWxlbSA9ICh0YWcpID0+IChwcm9wcywgLi4uY2hpbGRyZW4pID0+XG4gIGA8JHt0YWd9ICR7bWtQcm9wcyhwcm9wcyl9PiR7ZmxhdHRlbihjaGlsZHJlbikuam9pbignXFxuJyl9PC8ke3RhZ30+YDtcblxuY29uc3QgbWtOb25DbG9zaW5nRWxlbSA9ICh0YWcpID0+IChwcm9wcykgPT4gYDwke3RhZ30gJHtta1Byb3BzKHByb3BzKX0+YDtcblxuY29uc3QgYSA9IG1rRWxlbSgnYScpO1xuY29uc3QgZGl2ID0gbWtFbGVtKCdkaXYnKTtcbmNvbnN0IGltZyA9IG1rRWxlbSgnaW1nJyk7XG5jb25zdCBsYWJlbCA9IG1rRWxlbSgnbGFiZWwnKTtcbmNvbnN0IHNwYW4gPSBta0VsZW0oJ3NwYW4nKTtcbmNvbnN0IGlucHV0ID0gbWtOb25DbG9zaW5nRWxlbSgnaW5wdXQnKTtcbmNvbnN0IGN1c3RvbUVsZW1lbnQgPSBta0VsZW07XG5cbmNvbnN0IG1rRWxlbVdpdGhTdmdMb29rdXAgPSAoc3ZnS2V5LCBjbGFzc05hbWUgPSAnJywgcHJvcHMpID0+XG4gIGRpdih7IGNsYXNzOiBjbGFzc05hbWUgfSwgc3ZnTWFwW3N2Z0tleV0ocHJvcHMpKTtcblxuZXhwb3J0IHsgYSwgZGl2LCBpbWcsIGxhYmVsLCBpbnB1dCwgc3BhbiwgbWtFbGVtV2l0aFN2Z0xvb2t1cCwgY3VzdG9tRWxlbWVudCB9O1xuIiwiaW1wb3J0IHsgcGluZywgb25Qb25nIH0gZnJvbSAnLi9jb21tdW5pY2F0aW9uJztcbmltcG9ydCB7IGVycm9yRmFsbGJhY2sgfSBmcm9tICcuL3RlbXBsYXRlcy9lcnJvckZhbGxiYWNrJztcblxuY29uc3QgRkFMTEJBQ0tfREVMQVkgPSA1MDA7XG5cbi8qKlxuICogTWFrZXMgc3VyZSB0aGF0IHRoZSB3aWRnZXQgaXMgaW5pdGlhbGl6ZWQgb25seSB3aGVuIHRoZSBib290c3RyYXBwZXIgaXMgcHJlc2VudC5cbiAqXG4gKiBTZW5kcyBhIFwicGluZ1wiIG1lc3NhZ2UgdG8gdGhlIGJvb3RzdHJhcHBlciBhbmQgd2FpdHMgZm9yIGEgXCJwb25nXCIgcmVwbHkgYmVmb3JlIGluaXRpYWxpemluZyB0aGUgd2lkZ2V0LlxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IG9uSW5pdCB0aGUgY2FsbGJhY2sgdG8gYmUgZXhlY3V0ZWQgd2hlbiB0aGUgaW5pdCBpcyBkb25lLlxuICovXG5jb25zdCBpbml0ID0gKG9uSW5pdCkgPT4ge1xuICBsZXQgaW5pdGlhbGl6ZWQgPSBmYWxzZTtcbiAgb25Qb25nKCgpID0+IHtcbiAgICBpbml0aWFsaXplZCA9IHRydWU7XG4gICAgaWYgKHR5cGVvZiBvbkluaXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIG9uSW5pdCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLndhcm4oJ2BvbkluaXRgIG5vdCBzdXBwbGllZCcpO1xuICAgIH1cbiAgfSk7XG5cbiAgcGluZygpO1xuXG4gIC8vIHdlIHdhbnQgdG8gYXZvaWQgcmVuZGVyaW5nIHRoZSBmYWxsYmFjayByaWdodCBhd2F5IGluIGNhc2UgdGhlIFwicG9uZ1wiIG1lc3NhZ2UgZnJvbSB0aGUgYm9vdHN0cmFwcGVyIGNvbWVzIGJhY2sgaW1tZWRpYXRlbHlcbiAgLy8gdGhpcyB3YXkgd2Ugd2lsbCBhdm9pZCBhIGZsaWNrZXIgZnJvbSBcImVtcHR5IHNjcmVlblwiIC0+IFwiZmFsbGJhY2tcIiAtPiBcIlRydXN0Qm94XCIgYW5kIGhhdmUgXCJlbXB0eSBzY3JlZW5cIiAtPiBcIlRydXN0Qm94XCJcbiAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgaWYgKCFpbml0aWFsaXplZCkge1xuICAgICAgZXJyb3JGYWxsYmFjaygpO1xuICAgIH1cbiAgfSwgRkFMTEJBQ0tfREVMQVkpO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgaW5pdDtcbiIsImltcG9ydCB7IGRpdiB9IGZyb20gJ0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvdGVtcGxhdGluZyc7XG5pbXBvcnQgeyBtYWtlU3RhcnMgfSBmcm9tICdAdHJ1c3RwaWxvdC90cnVzdGJveC1mcmFtZXdvcmstdmFuaWxsYS9tb2R1bGVzL3RlbXBsYXRlcy9zdGFycyc7XG5pbXBvcnQgeyByYW5nZSB9IGZyb20gJ0B0cnVzdHBpbG90L3RydXN0Ym94LWZyYW1ld29yay12YW5pbGxhL21vZHVsZXMvdXRpbHMnO1xuXG5jb25zdCBoaWRlUGxhY2Vob2xkZXJzID0gKCkgPT4ge1xuICBjb25zdCByZWFkeUVsZW1lbnRzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmhpZGRlbi1lbGVtZW50Jyk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcmVhZHlFbGVtZW50cy5sZW5ndGg7IGkrKykge1xuICAgIHJlYWR5RWxlbWVudHNbaV0uY2xhc3NMaXN0LmFkZCgnaGlkZGVuLWVsZW1lbnQtLWxvYWRlZCcpO1xuICB9XG5cbiAgY29uc3QgbG9hZGluZ0VsZW1lbnRzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLnRwLXdpZGdldC1yZXZpZXdzLS1wbGFjZWhvbGRlcicpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGxvYWRpbmdFbGVtZW50cy5sZW5ndGg7IGkrKykge1xuICAgIGxvYWRpbmdFbGVtZW50c1tpXS5jbGFzc0xpc3QuYWRkKCd0cC13aWRnZXQtcmV2aWV3cy0tcGxhY2Vob2xkZXItaGlkZScpO1xuICB9XG59O1xuXG5jb25zdCBjcmVhdGVQbGFjZWhvbGRlclBhcnQgPSAoKSA9PlxuICBkaXYoXG4gICAge1xuICAgICAgY2xhc3M6ICd0cC13aWRnZXQtcmV2aWV3IHRwLXdpZGdldC1yZXZpZXctLXBsYWNlaG9sZGVyJyxcbiAgICB9LFxuICAgIFtcbiAgICAgIG1ha2VTdGFycyh7IG51bTogMCB9KSxcbiAgICAgIGRpdih7IGNsYXNzOiAndHAtd2lkZ2V0LXJldmlld19fcGxhY2Vob2xkZXIgdHAtd2lkZ2V0LXJldmlld19fcGxhY2Vob2xkZXItLXNtYWxsJyB9KSxcbiAgICAgIC4uLnJhbmdlKDIpLm1hcCgoKSA9PlxuICAgICAgICBkaXYoeyBjbGFzczogJ3RwLXdpZGdldC1yZXZpZXdfX3BsYWNlaG9sZGVyIHRwLXdpZGdldC1yZXZpZXdfX3BsYWNlaG9sZGVyJyB9KVxuICAgICAgKSxcbiAgICBdXG4gICk7XG5cbmNvbnN0IGNyZWF0ZVBsYWNlaG9sZGVyID0gKCkgPT5cbiAgZGl2KFxuICAgIHtcbiAgICAgIGNsYXNzOiAndHAtd2lkZ2V0LXJldmlld3MgdHAtd2lkZ2V0LXJldmlld3MtLXBsYWNlaG9sZGVyJyxcbiAgICB9LFxuICAgIHJhbmdlKDUpLm1hcChjcmVhdGVQbGFjZWhvbGRlclBhcnQpXG4gICk7XG5cbmV4cG9ydCB7IGhpZGVQbGFjZWhvbGRlcnMsIGNyZWF0ZVBsYWNlaG9sZGVyIH07XG4iLCJpbXBvcnQgeyBkaXYsIGEgfSBmcm9tICcuLi90ZW1wbGF0aW5nJztcbmltcG9ydCBzbWFydEFnZSBmcm9tICcuLi9zbWFydEFnZSc7XG5pbXBvcnQgeyBtYWtlU3RhcnMgfSBmcm9tICcuL3N0YXJzJztcbmltcG9ydCB7IGVzY2FwZUh0bWwsIHRydW5jYXRlVGV4dCB9IGZyb20gJy4uL3RleHQnO1xuaW1wb3J0IHsgZ2V0RnJhbWV3b3JrVHJhbnNsYXRpb24sIGZvcm1hdExvY2FsZSB9IGZyb20gXCIuLi90cmFuc2xhdGlvbnNcIjtcblxuY29uc3QgcHJvY2Vzc09wdHMgPSAob3B0cykgPT4ge1xuICBjb25zdCBvcHRzSXNGdW5jdGlvbiA9IHR5cGVvZiBvcHRzID09PSAnZnVuY3Rpb24nO1xuICBjb25zdCBvcHRzSXNPYmplY3QgPSBvcHRzICE9PSBudWxsICYmIHR5cGVvZiBvcHRzID09PSAnb2JqZWN0JztcblxuICBjb25zdCByZXZpZXdMaW5rR2VuZXJhdG9yID0gb3B0c0lzRnVuY3Rpb25cbiAgICA/IG9wdHNcbiAgICA6IG9wdHNJc09iamVjdFxuICAgICAgPyBvcHRzLnJldmlld0xpbmtHZW5lcmF0b3JcbiAgICAgIDogbnVsbDtcbiAgY29uc3QgeyB0ZXh0TGVuZ3RoLCBzdGFyQ29sb3IsIGltcG9ydGVkUmV2aWV3cywgc2hvd1Jldmlld1NvdXJjZSB9ID0gb3B0c0lzT2JqZWN0ID8gb3B0cyA6IHt9O1xuICByZXR1cm4geyByZXZpZXdMaW5rR2VuZXJhdG9yLCB0ZXh0TGVuZ3RoLCBzdGFyQ29sb3IsIGltcG9ydGVkUmV2aWV3cywgc2hvd1Jldmlld1NvdXJjZSB9O1xufTtcblxuY29uc3QgbWFrZVZlcmlmaWNhdGlvbk1ldGhvZCA9IChsb2NhbGUsIHZlcmlmaWVkQnkpID0+IHtcbiAgaWYgKHZlcmlmaWVkQnkpIHtcbiAgICByZXR1cm4gZ2V0RnJhbWV3b3JrVHJhbnNsYXRpb24oXG4gICAgICBgcmV2aWV3cy5jb2xsZWN0ZWRWaWFgLFxuICAgICAgZm9ybWF0TG9jYWxlKGxvY2FsZSksXG4gICAgICB7XG4gICAgICAgICdbc291cmNlXSc6IHZlcmlmaWVkQnksXG4gICAgICB9XG4gICAgKVxuICB9XG4gIHJldHVybiBnZXRGcmFtZXdvcmtUcmFuc2xhdGlvbihcbiAgICBgcmV2aWV3cy52ZXJpZmllZFZpYWAsXG4gICAgZm9ybWF0TG9jYWxlKGxvY2FsZSksXG4gICAge1xuICAgICAgJ1tzb3VyY2VdJzogJ1RydXN0cGlsb3QnLFxuICAgIH1cbiAgKVxufTtcblxuLy8gVGVtcGxhdGUgZm9yIHJldmlld3MgZGlzcGxheWVkIHdpdGhpbiBDYXJvdXNlbCwgVGVzdGltb25pYWxTbGlkZXIsIFByb2R1Y3QgUmV2aWV3cyBDYXJvdXNlbCBUcnVzdEJveGVzLlxuY29uc3QgcmV2aWV3VGVtcGxhdGUgPSAobG9jYWxlLCBvcHRzID0ge30pID0+IChyZXZpZXcpID0+IHtcbiAgLy8gQ2hlY2sgaWYgb3B0cyBjb250YWluIG9ubHkgdGhlIHJldmlld0xpbmtHZW5lcmF0b3IuIFRoaXMgaXMgdG8gbWFpbnRhaW4gdGhlXG4gIC8vIG9sZCBBUEkgZm9yIHRoaXMgZnVuY3Rpb24sIHdoaWNoIG9ubHkgdG9vayBhIGxvY2FsZSBhbmQgYSByZXZpZXdMaW5rR2VuZXJhdG9yLlxuICBjb25zdCB7XG4gICAgcmV2aWV3TGlua0dlbmVyYXRvcixcbiAgICB0ZXh0TGVuZ3RoID0gODUsXG4gICAgc3RhckNvbG9yLFxuICAgIGltcG9ydGVkUmV2aWV3cyxcbiAgICBzaG93UmV2aWV3U291cmNlID0gZmFsc2UsXG4gIH0gPSBwcm9jZXNzT3B0cyhvcHRzKTtcblxuICBjb25zdCB3cmFwcGVkRGl2ID0gKC4uLmFyZ3MpID0+XG4gICAgcmV2aWV3TGlua0dlbmVyYXRvclxuICAgICAgPyBhKHsgaHJlZjogcmV2aWV3TGlua0dlbmVyYXRvcihyZXZpZXcpLCB0YXJnZXQ6ICdfYmxhbmsnLCByZWw6ICdub2ZvbGxvdycgfSwgZGl2KC4uLmFyZ3MpKVxuICAgICAgOiBkaXYoLi4uYXJncyk7XG5cbiAgcmV0dXJuIGRpdihcbiAgICB7IGNsYXNzOiBgdHAtd2lkZ2V0LXJldmlldyR7aW1wb3J0ZWRSZXZpZXdzID8gJyB0cC13aWRnZXQtcmV2aWV3LS1pbXBvcnRlZCcgOiAnJ31gIH0sXG4gICAgZGl2KHsgY2xhc3M6ICd0cC13aWRnZXQtc3RhcnMnIH0sIG1ha2VTdGFycyh7IG51bTogcmV2aWV3LnN0YXJzLCBjb2xvcjogc3RhckNvbG9yIH0pKSxcbiAgICBkaXYoeyBjbGFzczogJ2RhdGUgc2Vjb25kYXJ5LXRleHQnIH0sIHNtYXJ0QWdlKGxvY2FsZSwgcmV2aWV3LmNyZWF0ZWRBdCkpLFxuICAgIHJldmlldy50aXRsZSA/IHdyYXBwZWREaXYoeyBjbGFzczogJ2hlYWRlcicgfSwgZXNjYXBlSHRtbChyZXZpZXcudGl0bGUpKSA6ICcnLFxuICAgIC8vIHNlcnZpY2UgcmV2aWV3cyB1c2UgYHRleHRgIHdoaWxlIHByb2R1Y3QgcmV2aWV3cyB1c2UgYGNvbnRlbnRgXG4gICAgd3JhcHBlZERpdih7IGNsYXNzOiAndGV4dCcgfSwgdHJ1bmNhdGVUZXh0KHJldmlldy50ZXh0IHx8IHJldmlldy5jb250ZW50LCB0ZXh0TGVuZ3RoKSksXG4gICAgd3JhcHBlZERpdih7IGNsYXNzOiAnbmFtZSBzZWNvbmRhcnktdGV4dCcgfSwgcmV2aWV3LmNvbnN1bWVyLmRpc3BsYXlOYW1lKSxcbiAgICBzaG93UmV2aWV3U291cmNlID8gZGl2KHsgY2xhc3M6ICd0cC13aWRnZXQtcmV2aWV3X19zb3VyY2UnIH0sIFtcbiAgICAgIG1ha2VWZXJpZmljYXRpb25NZXRob2QobG9jYWxlLCByZXZpZXcudmVyaWZpZWRCeSksXG4gICAgXSkgOiBudWxsXG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCByZXZpZXdUZW1wbGF0ZTtcbiIsImltcG9ydCBSZXZpZXdTbGlkZXIgZnJvbSAnLi9yZXZpZXdTbGlkZXInO1xuaW1wb3J0IEFycm93Q29udHJvbHMgZnJvbSAnLi9hcnJvd0NvbnRyb2xzJztcbmltcG9ydCBQYWdpbmF0aW9uQ29udHJvbHMgZnJvbSAnLi9wYWdpbmF0aW9uQ29udHJvbHMnO1xuXG5leHBvcnQgeyBSZXZpZXdTbGlkZXIsIEFycm93Q29udHJvbHMsIFBhZ2luYXRpb25Db250cm9scyB9O1xuIiwiaW1wb3J0IHsgY29tcG9zZSwgcGFpcnNUb09iamVjdCB9IGZyb20gJy4vZm4nO1xuXG4vKipcbiAqIENvbnZlcnQgYSBwYXJhbWV0ZXIgc3RyaW5nIHRvIGFuIG9iamVjdC5cbiAqL1xuZnVuY3Rpb24gcGFyYW1zVG9PYmplY3QocGFyYW1TdHJpbmcpIHtcbiAgY29uc3QgdG9rZW5zID0gWyc/JywgJyMnXTtcbiAgY29uc3QgZHJvcEZpcnN0SWZUb2tlbiA9IChzdHIpID0+ICh0b2tlbnMuaW5kZXhPZihzdHJbMF0pICE9PSAtMSA/IHN0ci5zdWJzdHJpbmcoMSkgOiBzdHIpO1xuICBjb25zdCB0b1BhaXJzID0gKHN0cikgPT5cbiAgICBzdHJcbiAgICAgIC5zcGxpdCgnJicpXG4gICAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgICAubWFwKChwYWlyU3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IFtrZXksIHZhbHVlXSA9IHBhaXJTdHJpbmcuc3BsaXQoJz0nKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBkS2V5ID0gZGVjb2RlVVJJQ29tcG9uZW50KGtleSk7XG4gICAgICAgICAgY29uc3QgZFZhbHVlID0gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgICAgICAgICByZXR1cm4gW2RLZXksIGRWYWx1ZV07XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hpbGUgZGVjb2RpbmcgVVJJLCBza2lwcGluZyBwYXJhbWV0ZXInKTtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIC5maWx0ZXIoQm9vbGVhbik7XG4gIGNvbnN0IG1rT2JqZWN0ID0gY29tcG9zZShcbiAgICBwYWlyc1RvT2JqZWN0LFxuICAgIHRvUGFpcnMsXG4gICAgZHJvcEZpcnN0SWZUb2tlblxuICApO1xuICByZXR1cm4gbWtPYmplY3QocGFyYW1TdHJpbmcpO1xufVxuXG4vKipcbiAqIEdldCBhbGwgcGFyYW1zIGZyb20gdGhlIFRydXN0Qm94J3MgVVJMLlxuICpcbiAqIFRoZSBvbmx5IHF1ZXJ5IHBhcmFtZXRlcnMgcmVxdWlyZWQgdG8gcnVuIHRoZSBpbml0aWFsIGxvYWQgb2YgYSBUcnVzdEJveCBhcmVcbiAqIGJ1c2luZXNzVW5pdElkIGFuZCB0ZW1wbGF0ZUlkLiBUaGUgcmVzdCBhcmUgb25seSB1c2VkIHdpdGhpbiB0aGUgVHJ1c3RCb3ggdG9cbiAqIG1ha2UgdGhlIGRhdGEgY2FsbChzKSBhbmQgc2V0IG9wdGlvbnMuIFRoZXNlIGFyZSBwYXNzZWQgYXMgcGFydCBvZiB0aGUgaGFzaFxuICogdG8gZW5zdXJlIHRoYXQgd2UgY2FuIHByb3Blcmx5IHV0aWxpc2UgYnJvd3NlciBjYWNoaW5nLlxuICpcbiAqIE5vdGU6IHRoaXMgb25seSBjYXB0dXJlcyBzaW5nbGUgb2NjdXJlbmNlcyBvZiB2YWx1ZXMgaW4gdGhlIFVSTC5cbiAqXG4gKiBAcGFyYW0ge0xvY2F0aW9ufSBsb2NhdGlvbiAtIEEgbG9jYXRpb24gb2JqZWN0IGZvciB3aGljaCB0byBnZXQgcXVlcnkgcGFyYW1zLlxuICogQHJldHVybiB7T2JqZWN0fSAtIEFsbCBxdWVyeSBwYXJhbXMgZm9yIHRoZSBnaXZlbiBsb2NhdGlvbi5cbiAqL1xuZnVuY3Rpb24gZ2V0UXVlcnlQYXJhbXMobG9jYXRpb24gPSB3aW5kb3cubG9jYXRpb24pIHtcbiAgY29uc3QgcXVlcnlQYXJhbXMgPSBwYXJhbXNUb09iamVjdChsb2NhdGlvbi5zZWFyY2gpO1xuICBjb25zdCBoYXNoUGFyYW1zID0gcGFyYW1zVG9PYmplY3QobG9jYXRpb24uaGFzaCk7XG4gIHJldHVybiB7IC4uLnF1ZXJ5UGFyYW1zLCAuLi5oYXNoUGFyYW1zIH07XG59XG5cbmV4cG9ydCB7XG4gIGdldFF1ZXJ5UGFyYW1zLFxuICBnZXRRdWVyeVBhcmFtcyBhcyBnZXRBc09iamVjdCwgLy8gRm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5IHdpdGggVEJzXG59O1xuIiwiaW1wb3J0IHsgZm9ybWF0TG9jYWxlLCBnZXRGcmFtZXdvcmtUcmFuc2xhdGlvbiB9IGZyb20gXCIuL3RyYW5zbGF0aW9uc1wiO1xuXG5jb25zdCByZXZpZXdGaWx0ZXJUZXh0ID0gKGxvY2FsZSwgcmV2aWV3U3RhcnMsIHJldmlld1RhZ1ZhbHVlKSA9PiB7XG4gIGNvbnN0IGZvcm1hdHRlZExvY2FsZSA9IGZvcm1hdExvY2FsZShsb2NhbGUpO1xuICBpZiAocmV2aWV3VGFnVmFsdWUpIHtcbiAgICByZXR1cm4gZ2V0RnJhbWV3b3JrVHJhbnNsYXRpb24oXG4gICAgICBgcmV2aWV3RmlsdGVycy5ieUZhdm9yaXRlT3JUYWdgLFxuICAgICAgZm9ybWF0dGVkTG9jYWxlXG4gICAgKTtcbiAgfVxuXG4gIGlmIChcbiAgICByZXZpZXdTdGFycyAmJlxuICAgICFbXCIxXCIsIFwiMlwiLCBcIjNcIiwgXCI0XCIsIFwiNVwiXS5ldmVyeShcbiAgICAgIChzdGFyKSA9PiByZXZpZXdTdGFycy5zcGxpdChcIixcIikuaW5kZXhPZihzdGFyKSA+IC0xXG4gICAgKVxuICApIHtcbiAgICByZXR1cm4gZ2VuZXJhdGVTdGFyc1N0cmluZyhsb2NhbGUsIHJldmlld1N0YXJzLnNwbGl0KFwiLFwiKS5zb3J0KCkpO1xuICB9XG5cbiAgcmV0dXJuIGdldEZyYW1ld29ya1RyYW5zbGF0aW9uKGByZXZpZXdGaWx0ZXJzLmJ5TGF0ZXN0YCwgZm9ybWF0dGVkTG9jYWxlKTtcbn07XG5cbmNvbnN0IGdlbmVyYXRlU3RhcnNTdHJpbmcgPSAobG9jYWxlLCBzdGFycykgPT4ge1xuICBsZXQgaWQgPSBcInJldmlld0ZpbHRlcnMuYnlMYXRlc3RcIjtcbiAgY29uc3QgaW50ZXJwb2xhdGlvbnMgPSB7fTtcbiAgY29uc3QgZm9ybWF0dGVkTG9jYWxlID0gZm9ybWF0TG9jYWxlKGxvY2FsZSk7XG5cbiAgc3dpdGNoIChzdGFycy5sZW5ndGgpIHtcbiAgICBjYXNlIDQ6XG4gICAgICBpZCA9IFwicmV2aWV3RmlsdGVycy5ieVN0YXJzNFwiO1xuICAgICAgaW50ZXJwb2xhdGlvbnNbJ1tzdGFyMV0nXSA9IHN0YXJzWzBdO1xuICAgICAgaW50ZXJwb2xhdGlvbnNbJ1tzdGFyMl0nXSA9IHN0YXJzWzFdO1xuICAgICAgaW50ZXJwb2xhdGlvbnNbJ1tzdGFyM10nXSA9IHN0YXJzWzJdO1xuICAgICAgaW50ZXJwb2xhdGlvbnNbJ1tzdGFyNF0nXSA9IHN0YXJzWzNdO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAzOlxuICAgICAgaWQgPSBcInJldmlld0ZpbHRlcnMuYnlTdGFyczNcIjtcbiAgICAgIGludGVycG9sYXRpb25zWydbc3RhcjFdJ10gPSBzdGFyc1swXTtcbiAgICAgIGludGVycG9sYXRpb25zW1wiW3N0YXIyXVwiXSA9IHN0YXJzWzFdO1xuICAgICAgaW50ZXJwb2xhdGlvbnNbXCJbc3RhcjNdXCJdID0gc3RhcnNbMl07XG4gICAgICBicmVhaztcbiAgICBjYXNlIDI6XG4gICAgICBpZCA9IFwicmV2aWV3RmlsdGVycy5ieVN0YXJzMlwiO1xuICAgICAgaW50ZXJwb2xhdGlvbnNbXCJbc3RhcjFdXCJdID0gc3RhcnNbMF07XG4gICAgICBpbnRlcnBvbGF0aW9uc1tcIltzdGFyMl1cIl0gPSBzdGFyc1sxXTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgMTpcbiAgICAgIGlkID0gXCJyZXZpZXdGaWx0ZXJzLmJ5U3RhcnMxXCI7XG4gICAgICBpbnRlcnBvbGF0aW9uc1tcIltzdGFyMV1cIl0gPSBzdGFyc1swXTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiBnZXRGcmFtZXdvcmtUcmFuc2xhdGlvbihpZCwgZm9ybWF0dGVkTG9jYWxlLCBpbnRlcnBvbGF0aW9ucyk7O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgcmV2aWV3RmlsdGVyVGV4dDtcbiIsImltcG9ydCBQcm9taXNlIGZyb20gJ3Byb21pc2UnO1xuaW1wb3J0IHsgYWRkQ2xhc3MgfSBmcm9tICcuL2RvbSc7XG5cbmZ1bmN0aW9uIGFkZEV2ZW50TGlzdGVuZXIoZWxlbWVudCwgdHlwZSwgbGlzdGVuZXIpIHtcbiAgaWYgKGVsZW1lbnQpIHtcbiAgICBpZiAoZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKSB7XG4gICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIodHlwZSwgbGlzdGVuZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBlbGVtZW50LmF0dGFjaEV2ZW50KGBvbiR7dHlwZX1gLCBmdW5jdGlvbihlKSB7XG4gICAgICAgIGUgPSBlIHx8IHdpbmRvdy5ldmVudDtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCA9XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCB8fFxuICAgICAgICAgIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgZS5yZXR1cm5WYWx1ZSA9IGZhbHNlO1xuICAgICAgICAgIH07XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uID1cbiAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbiB8fFxuICAgICAgICAgIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgZS5jYW5jZWxCdWJibGUgPSB0cnVlO1xuICAgICAgICAgIH07XG4gICAgICAgIGxpc3RlbmVyLmNhbGwoZWxlbWVudCwgZSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0T25QYWdlUmVhZHkoKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXNvbHZlKSB7XG4gICAgY29uc3QgcmVzb2x2ZVdpdGhUaW1lb3V0ID0gZnVuY3Rpb24oKSB7XG4gICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9LCAwKTtcbiAgICB9O1xuICAgIGlmIChkb2N1bWVudC5yZWFkeVN0YXRlID09PSAnY29tcGxldGUnKSB7XG4gICAgICByZXNvbHZlV2l0aFRpbWVvdXQoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYWRkRXZlbnRMaXN0ZW5lcih3aW5kb3csICdsb2FkJywgZnVuY3Rpb24oKSB7XG4gICAgICAgIHJlc29sdmVXaXRoVGltZW91dCgpO1xuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gaW5zZXJ0TnVtYmVyU2VwYXJhdG9yKGlucHV0LCBsb2NhbGUpIHtcbiAgdHJ5IHtcbiAgICBpbnB1dC50b0xvY2FsZVN0cmluZygpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGlucHV0O1xuICB9XG4gIHJldHVybiBpbnB1dC50b0xvY2FsZVN0cmluZyhsb2NhbGUgfHwgJ2VuLVVTJyk7XG59XG5cbmZ1bmN0aW9uIHNldFRleHRDb250ZW50KGVsZW1lbnQsIGNvbnRlbnQpIHtcbiAgaWYgKCFlbGVtZW50KSB7XG4gICAgY29uc29sZS5sb2coJ0F0dGVtcHRpbmcgdG8gc2V0IGNvbnRlbnQgb24gbWlzc2luZyBlbGVtZW50Jyk7XG4gIH0gZWxzZSBpZiAoJ2lubmVyVGV4dCcgaW4gZWxlbWVudCkge1xuICAgIC8vIElFOFxuICAgIGVsZW1lbnQuaW5uZXJUZXh0ID0gY29udGVudDtcbiAgfSBlbHNlIHtcbiAgICBlbGVtZW50LnRleHRDb250ZW50ID0gY29udGVudDtcbiAgfVxufVxuXG5jb25zdCBzYW5pdGl6ZUh0bWwgPSAoc3RyaW5nKSA9PiB7XG4gIGlmICh0eXBlb2Ygc3RyaW5nICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBzdHJpbmc7XG4gIH1cbiAgLy8gVE9ETzogR2V0IHJpZCBvZiA8YT4gdGFncyBpbiB0cmFuc2xhdGlvbnNcbiAgLy8gUmVtb3ZlIGh0bWwgdGFncywgZXhjZXB0IDxwPiA8Yj4gPGk+IDxsaT4gPHVsPiA8YT4gPHN0cm9uZz5cbiAgLy8gQnJlYWtkb3duOlxuICAvLyAgKDxcXC8/KD86cHxifGl8bGl8dWx8YXxzdHJvbmcpXFwvPz4pIOKAlCAxc3QgY2FwdHVyaW5nIGdyb3VwLCBzZWxlY3RzIGFsbG93ZWQgdGFncyAob3BlbmluZyBhbmQgY2xvc2luZylcbiAgLy8gICg/OjxcXC8/Lio/XFwvPz4pIOKAlCBub24tY2FwdHVyaW5nIGdyb3VwICg/OiksIG1hdGNoZXMgYWxsIGh0bWwgdGFnc1xuICAvLyAgJDEg4oCUIGtlZXAgbWF0Y2hlcyBmcm9tIDFzdCBjYXB0dXJpbmcgZ3JvdXAgYXMgaXMsIG1hdGNoZXMgZnJvbSBub24tY2FwdHVyaW5nIGdyb3VwIHdpbGwgYmUgb21pdHRlZFxuICAvLyAgL2dpIOKAlCBnbG9iYWwgKG1hdGNoZXMgYWxsIG9jY3VycmVuY2VzKSBhbmQgY2FzZS1pbnNlbnNpdGl2ZVxuICAvLyBUZXN0OiBodHRwczovL3JlZ2V4MTAxLmNvbS9yL2NEYThqci8xXG4gIHJldHVybiBzdHJpbmcucmVwbGFjZSgvKDxcXC8/KD86cHxifGl8bGl8dWx8YXxzdHJvbmcpXFwvPz4pfCg/OjxcXC8/Lio/XFwvPz4pL2dpLCAnJDEnKTtcbn07XG5cbi8qKlxuICogU2FmZWx5IHNldHMgaW5uZXJIVE1MIHRvIERPTSBlbGVtZW50LiBBbHdheXMgdXNlIGl0IGluc3RlYWQgb2Ygc2V0dGluZyAuaW5uZXJIVE1MIGRpcmVjdGx5IG9uIGVsZW1lbnQuXG4gKiBTYW5pdGl6ZXMgSFRNTCBieSBkZWZhdWx0LiBVc2Ugc2FuaXRpemUgZmxhZyB0byBjb250cm9sIHRoaXMgYmVoYXZpb3VyLlxuICpcbiAqIEBwYXJhbSBlbGVtZW50XG4gKiBAcGFyYW0gY29udGVudFxuICogQHBhcmFtIHNhbml0aXplXG4gKi9cbmZ1bmN0aW9uIHNldEh0bWxDb250ZW50KGVsZW1lbnQsIGNvbnRlbnQsIHNhbml0aXplID0gdHJ1ZSkge1xuICBpZiAoIWVsZW1lbnQpIHtcbiAgICBjb25zb2xlLmxvZygnQXR0ZW1wdGluZyB0byBzZXQgSFRNTCBjb250ZW50IG9uIG1pc3NpbmcgZWxlbWVudCcpO1xuICB9IGVsc2Uge1xuICAgIGVsZW1lbnQuaW5uZXJIVE1MID0gc2FuaXRpemUgPyBzYW5pdGl6ZUh0bWwoY29udGVudCkgOiBjb250ZW50O1xuICB9XG59XG5cbmZ1bmN0aW9uIG1ha2VUcmFuc2xhdGlvbnModHJhbnNsYXRpb25zLCBzdHJpbmcpIHtcbiAgaWYgKCFzdHJpbmcpIHtcbiAgICBjb25zb2xlLmxvZygnTWlzc2luZyB0cmFuc2xhdGlvbiBzdHJpbmcnKTtcbiAgICByZXR1cm4gJyc7XG4gIH1cbiAgcmV0dXJuIE9iamVjdC5rZXlzKHRyYW5zbGF0aW9ucykucmVkdWNlKFxuICAgIChyZXN1bHQsIGtleSkgPT4gcmVzdWx0LnNwbGl0KGtleSkuam9pbih0cmFuc2xhdGlvbnNba2V5XSksXG4gICAgc3RyaW5nXG4gICk7XG59XG5cbmZ1bmN0aW9uIHJlbW92ZUVsZW1lbnQoZWxlbWVudCkge1xuICBpZiAoIWVsZW1lbnQgfHwgIWVsZW1lbnQucGFyZW50Tm9kZSkge1xuICAgIGNvbnNvbGUubG9nKCdBdHRlbXB0aW5nIHRvIHJlbW92ZSBhIG5vbi1leGlzdGluZyBlbGVtZW50Jyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHJldHVybiBlbGVtZW50LnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoZWxlbWVudCk7XG59XG5cbmNvbnN0IHNob3dUcnVzdEJveCA9ICh0aGVtZSwgaGFzUmV2aWV3cykgPT4ge1xuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2JvZHknKVswXTtcbiAgY29uc3Qgd3JhcHBlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0cC13aWRnZXQtd3JhcHBlcicpO1xuXG4gIGFkZENsYXNzKGJvZHksIHRoZW1lKTtcbiAgYWRkQ2xhc3Mod3JhcHBlciwgJ3Zpc2libGUnKTtcblxuICBpZiAoIWhhc1Jldmlld3MpIHtcbiAgICBhZGRDbGFzcyhib2R5LCAnZmlyc3QtcmV2aWV3ZXInKTtcbiAgfVxufTtcblxuLy8gdXJsIGNhbiBhbHJlYWR5IGhhdmUgcXVlcnkgcGFyYW1zIGluIGl0XG5jb25zdCB2ZXJpZnlRdWVyeVBhcmFtU2VwYXJhdG9yID0gKHVybCkgPT4gYCR7dXJsfSR7dXJsLmluZGV4T2YoJz8nKSA9PT0gLTEgPyAnPycgOiAnJid9YDtcblxuY29uc3QgYWRkVXRtUGFyYW1zID0gKHRydXN0Qm94TmFtZSkgPT4gKHVybCkgPT5cbiAgYCR7dmVyaWZ5UXVlcnlQYXJhbVNlcGFyYXRvcih1cmwpfXV0bV9tZWRpdW09dHJ1c3Rib3gmdXRtX3NvdXJjZT0ke3RydXN0Qm94TmFtZX1gO1xuXG5jb25zdCByZWd1bGF0ZUZvbGxvd0ZvckxvY2F0aW9uID0gKGxvY2F0aW9uKSA9PiAoZWxlbWVudCkgPT4ge1xuICBpZiAobG9jYXRpb24gJiYgZWxlbWVudCkge1xuICAgIGVsZW1lbnQucmVsID0gJ25vZm9sbG93JztcbiAgfVxufTtcblxuY29uc3QgaW5qZWN0V2lkZ2V0TGlua3MgPSAoYmFzZURhdGEsIHV0bVRydXN0Qm94SWQsIGxpbmtzQ2xhc3MgPSAncHJvZmlsZS11cmwnKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBidXNpbmVzc0VudGl0eToge1xuICAgICAgbnVtYmVyT2ZSZXZpZXdzOiB7IHRvdGFsOiBudW1iZXJPZlJldmlld3MgfSxcbiAgICB9LFxuICAgIGxpbmtzLFxuICB9ID0gYmFzZURhdGE7XG4gIGNvbnN0IGl0ZW1zID0gW10uc2xpY2UuY2FsbChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKGxpbmtzQ2xhc3MpKTtcbiAgY29uc3QgYmFzZVVybCA9IG51bWJlck9mUmV2aWV3cyA/IGxpbmtzLnByb2ZpbGVVcmwgOiBsaW5rcy5ldmFsdWF0ZVVybDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtcy5sZW5ndGg7IGkrKykge1xuICAgIGl0ZW1zW2ldLmhyZWYgPSBhZGRVdG1QYXJhbXModXRtVHJ1c3RCb3hJZCkoYmFzZVVybCk7XG4gIH1cbn07XG5cbi8vIENyZWF0ZSBhIHJhbmdlIG9mIG51bWJlcnMsIHVwIHRvIChidXQgZXhjbHVkaW5nKSB0aGUgYXJndW1lbnQuXG4vLyBXcml0dGVuIHRvIHN1cHBvcnQgSUUxMS5cbmNvbnN0IHJhbmdlID0gKG51bSkgPT4ge1xuICBjb25zdCByZXN1bHQgPSBbXTtcbiAgd2hpbGUgKG51bSA+IDApIHtcbiAgICByZXN1bHQucHVzaChyZXN1bHQubGVuZ3RoKTtcbiAgICBudW0tLTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufTtcblxuLy8gU2hpZnRzIHRoZSBnaXZlbiBjb2xvciB0byBlaXRoZXIgbGlnaHRlciBvciBkYXJrZXIgYmFzZWQgb24gdGhlIGJhc2UgdmFsdWUgZ2l2ZW4uXG4vLyBQb3NpdGl2ZSB2YWx1ZXMgZ2l2ZSB5b3UgbGlnaHRlciBjb2xvciwgbmVnYXRpdmUgZGFya2VyLlxuY29uc3QgY29sb3JTaGlmdCA9IChjb2wsIGFtdCkgPT4ge1xuICBjb25zdCB2YWxpZGF0ZUJvdW5kcyA9ICh2KSA9PiB2ID4gMjU1ID8gMjU1IDogdiA8IDAgPyAwIDogdjtcbiAgbGV0IHVzZVBvdW5kID0gZmFsc2U7XG5cbiAgaWYgKGNvbFswXSA9PT0gXCIjXCIpIHtcbiAgICBjb2wgPSBjb2wuc2xpY2UoMSk7XG4gICAgdXNlUG91bmQgPSB0cnVlO1xuICB9XG5cbiAgY29uc3QgbnVtID0gcGFyc2VJbnQoY29sLCAxNik7XG4gIGlmICghbnVtKSB7XG4gICAgcmV0dXJuIGNvbDtcbiAgfVxuXG4gIGxldCByID0gKG51bSA+PiAxNikgKyBhbXQ7XG4gIHIgPSB2YWxpZGF0ZUJvdW5kcyhyKVxuXG4gIGxldCBnID0gKChudW0gPj4gOCkgJiAweDAwRkYpICsgYW10O1xuICBnID0gdmFsaWRhdGVCb3VuZHMoZyk7XG5cbiAgbGV0IGIgPSAobnVtICYgMHgwMDAwRkYpICsgYW10O1xuICBiID0gdmFsaWRhdGVCb3VuZHMoYik7XG5cbiAgW3IsIGcsIGJdID0gW3IsIGcsIGJdLm1hcChjb2xvciA9PiBjb2xvciA8PSAxNSA/IGAwJHtjb2xvci50b1N0cmluZygxNil9YCA6IGNvbG9yLnRvU3RyaW5nKDE2KSk7XG4gIHJldHVybiAodXNlUG91bmQgPyBcIiNcIiA6IFwiXCIpICsgciArIGcgKyBiO1xufTtcblxuY29uc3QgaGV4VG9SR0JBID0gKGhleCwgYWxwaGEgPSAxKSA9PiB7XG4gIGNvbnN0IG51bSA9IGhleFswXSA9PT0gJyMnID8gcGFyc2VJbnQoaGV4LnNsaWNlKDEpLCAxNikgOiBwYXJzZUludChoZXgsIDE2KTtcbiAgY29uc3QgcmVkID0gKG51bSA+PiAxNik7XG4gIGNvbnN0IGdyZWVuID0gKChudW0gPj4gOCkgJiAweDAwRkYpO1xuICBjb25zdCBibHVlID0gKG51bSAmIDB4MDAwMEZGKTtcbiAgcmV0dXJuIGByZ2JhKCR7cmVkfSwke2dyZWVufSwke2JsdWV9LCR7YWxwaGF9KWA7XG59O1xuXG5jb25zdCBzZXRUZXh0Q29sb3IgPSAodGV4dENvbG9yKSA9PiB7XG4gIGNvbnN0IHRleHRDb2xvclN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbiAgdGV4dENvbG9yU3R5bGUuYXBwZW5kQ2hpbGQoXG4gICAgZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoYFxuICAgICAgKiB7XG4gICAgICAgIGNvbG9yOiBpbmhlcml0ICFpbXBvcnRhbnQ7XG4gICAgICB9XG4gICAgICBib2R5IHtcbiAgICAgICAgY29sb3I6ICR7dGV4dENvbG9yfSAhaW1wb3J0YW50O1xuICAgICAgfVxuICAgICAgLmJvbGQtdW5kZXJsaW5lIHtcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1jb2xvcjogJHt0ZXh0Q29sb3J9ICFpbXBvcnRhbnQ7XG4gICAgICB9XG4gICAgICAuYm9sZC11bmRlcmxpbmU6aG92ZXIge1xuICAgICAgICBib3JkZXItY29sb3I6ICR7Y29sb3JTaGlmdCh0ZXh0Q29sb3IsIC0zMCl9ICFpbXBvcnRhbnQ7XG4gICAgICB9XG4gICAgICAuc2Vjb25kYXJ5LXRleHQge1xuICAgICAgICBjb2xvcjogJHtoZXhUb1JHQkEodGV4dENvbG9yLCAwLjYpfSAhaW1wb3J0YW50O1xuICAgICAgfVxuICAgICAgLnNlY29uZGFyeS10ZXh0LWFycm93IHtcbiAgICAgICAgYm9yZGVyLWNvbG9yOiAke2hleFRvUkdCQSh0ZXh0Q29sb3IsIDAuNil9IHRyYW5zcGFyZW50IHRyYW5zcGFyZW50IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gICAgICB9XG4gICAgICAucmVhZC1tb3JlIHtcbiAgICAgICAgY29sb3I6ICR7dGV4dENvbG9yfSAhaW1wb3J0YW50O1xuICAgICAgfVxuICAgIGApXG4gICk7XG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQodGV4dENvbG9yU3R5bGUpO1xufTtcblxuY29uc3Qgc2V0Qm9yZGVyQ29sb3IgPSAoYm9yZGVyQ29sb3IpID0+IHtcbiAgY29uc3QgYm9yZGVyQ29sb3JTdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG4gIGJvcmRlckNvbG9yU3R5bGUuYXBwZW5kQ2hpbGQoXG4gICAgZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoYFxuICAgICAqIHtcbiAgICAgICAgYm9yZGVyLWNvbG9yOiAke2JvcmRlckNvbG9yfSAhaW1wb3J0YW50O1xuICAgICAgfVxuICAgIGApXG4gICk7XG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoYm9yZGVyQ29sb3JTdHlsZSk7XG59O1xuXG5jb25zdCBzZXRGb250ID0gKGZvbnRGYW1pbHkpID0+IHtcbiAgY29uc3QgZm9udExpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJyk7XG4gIGZvbnRMaW5rLnJlbCA9ICdzdHlsZXNoZWV0JztcbiAgLy8gd2UgYXJlIHVzaW5nIHRoZSBmb2xsb3dpbmcgdGhyZWUgd2VpZ2h0cyBpbiBtb3N0IG9mIG91ciBUcnVzdEJveGVzXG4gIC8vIGluIGZ1dHVyZSBpdGVyYXRpb25zLCB3ZSBjYW4gb3B0aW1pemUgdGhlIGJ5dGVzIHRyYW5zZmVycmVkIGJ5IGhhdmluZyBhIGxpc3Qgb2Ygd2VpZ2h0cyBwZXIgVHJ1c3RCb3hcbiAgZm9udExpbmsuaHJlZiA9IGBodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9JHtmb250RmFtaWx5fTp3Z2h0QDQwMCw1MDAsNzAwYDtcbiAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChmb250TGluayk7XG5cbiAgY29uc3QgY2xlYW5Gb250TmFtZSA9IGZvbnRGYW1pbHkucmVwbGFjZSgvXFwrL2csICcgJyk7XG4gIGNvbnN0IGZvbnRTdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG4gIGZvbnRTdHlsZS5hcHBlbmRDaGlsZChcbiAgICBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShgXG4gICAgKiB7XG4gICAgICBmb250LWZhbWlseTogaW5oZXJpdCAhaW1wb3J0YW50O1xuICAgIH1cbiAgICBib2R5IHtcbiAgICAgIGZvbnQtZmFtaWx5OiBcIiR7Y2xlYW5Gb250TmFtZX1cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIH1cbiAgICBgKVxuICApO1xuICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGZvbnRTdHlsZSk7XG59O1xuXG5jb25zdCBzZXRIdG1sTGFuZ3VhZ2UgPSAobGFuZ3VhZ2UpID0+IHtcbiAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNldEF0dHJpYnV0ZSgnbGFuZycsIGxhbmd1YWdlKTtcbn07XG5cbmNvbnN0IHNhbml0aXplQ29sb3IgPSAoY29sb3IpID0+IHtcbiAgY29uc3QgaGV4UmVnRXhwID0gL14jKD86W1xcZGEtZkEtRl17M30pezEsMn0kLztcbiAgcmV0dXJuICh0eXBlb2YgY29sb3IgPT09ICdzdHJpbmcnICYmIGhleFJlZ0V4cC50ZXN0KGNvbG9yKSkgPyBjb2xvciA6IG51bGw7XG59O1xuXG5leHBvcnQge1xuICBpbnNlcnROdW1iZXJTZXBhcmF0b3IsXG4gIHNldFRleHRDb250ZW50LFxuICBzZXRIdG1sQ29udGVudCxcbiAgYWRkRXZlbnRMaXN0ZW5lcixcbiAgZ2V0T25QYWdlUmVhZHksXG4gIG1ha2VUcmFuc2xhdGlvbnMsXG4gIHJlbW92ZUVsZW1lbnQsXG4gIHNob3dUcnVzdEJveCxcbiAgYWRkVXRtUGFyYW1zLFxuICByZWd1bGF0ZUZvbGxvd0ZvckxvY2F0aW9uLFxuICBpbmplY3RXaWRnZXRMaW5rcyxcbiAgcmFuZ2UsXG4gIHNldFRleHRDb2xvcixcbiAgc2V0Qm9yZGVyQ29sb3IsXG4gIHNldEZvbnQsXG4gIHNldEh0bWxMYW5ndWFnZSxcbiAgc2FuaXRpemVIdG1sLFxuICBzYW5pdGl6ZUNvbG9yLFxufTtcbiIsImltcG9ydCB7XG4gIGZldGNoRGF0YSxcbiAgbXVsdGlGZXRjaERhdGEsXG4gIGNvbnN0cnVjdFRydXN0Qm94QW5kQ29tcGxldGUsXG4gIGhhc1NlcnZpY2VSZXZpZXdzLFxuICBoYXNTZXJ2aWNlUmV2aWV3c011bHRpRmV0Y2gsXG59IGZyb20gJy4vZmV0Y2hEYXRhJztcbmltcG9ydCB7XG4gIGZldGNoUHJvZHVjdERhdGEsXG4gIGZldGNoUHJvZHVjdFJldmlld1xufSBmcm9tICcuL3Byb2R1Y3RSZXZpZXdzJztcblxuY29uc3QgZmV0Y2hTZXJ2aWNlUmV2aWV3RGF0YSA9ICh0ZW1wbGF0ZUlkKSA9PiAoZmV0Y2hQYXJhbXMsIGNvbnN0cnVjdFRydXN0Qm94LCBwYXNzVG9Qb3B1cCkgPT4ge1xuICBmZXRjaERhdGEoYC90cnVzdGJveC1kYXRhLyR7dGVtcGxhdGVJZH1gKShcbiAgICBmZXRjaFBhcmFtcyxcbiAgICBjb25zdHJ1Y3RUcnVzdEJveCxcbiAgICBwYXNzVG9Qb3B1cCxcbiAgICBoYXNTZXJ2aWNlUmV2aWV3c1xuICApO1xufTtcblxuY29uc3QgZmV0Y2hTZXJ2aWNlUmV2aWVNdWx0aXBsZURhdGEgPSAodGVtcGxhdGVJZCkgPT4gKFxuICBmZXRjaFBhcmFtcyxcbiAgY29uc3RydWN0VHJ1c3RCb3gsXG4gIHBhc3NUb1BvcHVwXG4pID0+IHtcbiAgbXVsdGlGZXRjaERhdGEoYC90cnVzdGJveC1kYXRhLyR7dGVtcGxhdGVJZH1gKShcbiAgICBmZXRjaFBhcmFtcyxcbiAgICBjb25zdHJ1Y3RUcnVzdEJveCxcbiAgICBwYXNzVG9Qb3B1cCxcbiAgICBoYXNTZXJ2aWNlUmV2aWV3c011bHRpRmV0Y2hcbiAgKTtcbn07XG5cbmV4cG9ydCB7XG4gIGZldGNoUHJvZHVjdERhdGEsXG4gIGZldGNoUHJvZHVjdFJldmlldyxcbiAgY29uc3RydWN0VHJ1c3RCb3hBbmRDb21wbGV0ZSxcbiAgZmV0Y2hTZXJ2aWNlUmV2aWV3RGF0YSxcbiAgZmV0Y2hTZXJ2aWNlUmV2aWVNdWx0aXBsZURhdGEsXG59O1xuIiwiaW1wb3J0IHsgZGl2LCBta0VsZW1XaXRoU3ZnTG9va3VwIH0gZnJvbSAnLi4vdGVtcGxhdGluZyc7XG5pbXBvcnQgeyBwb3B1bGF0ZUVsZW1lbnRzIH0gZnJvbSAnLi4vZG9tJztcbmltcG9ydCB7IHNhbml0aXplQ29sb3IgfSBmcm9tICcuLi91dGlscyc7XG5cbmNvbnN0IG1ha2VTdGFycyA9ICh7IG51bSwgdHJ1c3RTY29yZSA9IG51bGwsIHdyYXBwZXJDbGFzcyA9ICcnLCBjb2xvciB9KSA9PiB7XG4gIGNvbnN0IGZ1bGxQYXJ0ID0gTWF0aC5mbG9vcihudW0pO1xuICBjb25zdCBoYWxmUGFydCA9IG51bSA9PT0gZnVsbFBhcnQgPyAnJyA6IGAgdHAtc3RhcnMtLSR7ZnVsbFBhcnR9LS1oYWxmYDtcbiAgY29uc3Qgc2FuaXRpemVkQ29sb3IgPSBzYW5pdGl6ZUNvbG9yKGNvbG9yKTtcbiAgcmV0dXJuIGRpdihcbiAgICB7IGNsYXNzOiB3cmFwcGVyQ2xhc3MgfSxcbiAgICAvLyBhZGQgYSBkaWZmZXJlbnQgY2xhc3Mgc28gdGhhdCBzdHlsZXMgZnJvbSB3aWRnZXRzLXN0eWxlZ3VpZGUgZG8gbm90IGFwcGx5XG4gICAgbWtFbGVtV2l0aFN2Z0xvb2t1cChcbiAgICAgICdzdGFycycsXG4gICAgICBgJHtcbiAgICAgICAgc2FuaXRpemVkQ29sb3JcbiAgICAgICAgICA/ICd0cC1zdGFycy1jdXN0b20tY29sb3InXG4gICAgICAgICAgOiBgdHAtc3RhcnMgdHAtc3RhcnMtLSR7ZnVsbFBhcnR9JHtoYWxmUGFydH1gXG4gICAgICB9YCxcbiAgICAgIHsgcmF0aW5nOiBudW0sIHRydXN0U2NvcmU6IHRydXN0U2NvcmUgfHwgbnVtLCBjb2xvcjogc2FuaXRpemVkQ29sb3IgfVxuICAgIClcbiAgKTtcbn07XG5cbmNvbnN0IHBvcHVsYXRlU3RhcnMgPSAoXG4gIHtcbiAgICBidXNpbmVzc0VudGl0eToge1xuICAgICAgc3RhcnMsXG4gICAgICB0cnVzdFNjb3JlLFxuICAgICAgbnVtYmVyT2ZSZXZpZXdzOiB7IHRvdGFsIH0sXG4gICAgfSxcbiAgfSxcbiAgc3RhcnNDb250YWluZXIgPSAndHAtd2lkZ2V0LXN0YXJzJyxcbiAgc3RhcnNDb2xvclxuKSA9PiB7XG4gIGNvbnN0IHNhbml0aXplZENvbG9yID0gc2FuaXRpemVDb2xvcihzdGFyc0NvbG9yKTtcbiAgY29uc3QgY29udGFpbmVyID1cbiAgICB0eXBlb2Ygc3RhcnNDb250YWluZXIgPT09ICdzdHJpbmcnID8gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoc3RhcnNDb250YWluZXIpIDogc3RhcnNDb250YWluZXI7XG5cbiAgLy8gRW5zdXJlIHdlIHByb3Blcmx5IGhhbmRsZSBlbXB0eSByZXZpZXcgc3RhdGUgLSB3ZSBzb21ldGltZXMgZ2V0IGEgcmF0aW5nXG4gIC8vIGJhY2sgZnJvbSB0aGUgQVBJIGV2ZW4gd2hlcmUgd2UgaGF2ZSBubyByZXZpZXdzLCBzbyBleHBsaWNpdGx5IGNoZWNrLlxuICBjb25zdCBkaXNwbGF5ZWRTdGFycyA9IHRvdGFsID8gc3RhcnMgOiAwO1xuXG4gIHBvcHVsYXRlRWxlbWVudHMoW1xuICAgIHtcbiAgICAgIGVsZW1lbnQ6IGNvbnRhaW5lcixcbiAgICAgIHN0cmluZzogbWFrZVN0YXJzKHsgbnVtOiBkaXNwbGF5ZWRTdGFycywgdHJ1c3RTY29yZSwgY29sb3I6IHNhbml0aXplZENvbG9yIH0pLFxuICAgIH0sXG4gIF0pO1xufTtcblxuZXhwb3J0IHsgbWFrZVN0YXJzLCBwb3B1bGF0ZVN0YXJzIH07XG4iLCJtb2R1bGUuZXhwb3J0cz17XG4gIFwicmV2aWV3c1wiOiB7XG4gICAgXCJzaW5ndWxhclwiOiBcImFubWVsZGVsc2VcIixcbiAgICBcInBsdXJhbFwiOiBcImFubWVsZGVsc2VyXCIsXG4gICAgXCJjb2xsZWN0ZWRWaWFcIjogXCJJbmRzYW1sZXQgdmlhIFtzb3VyY2VdXCIsXG4gICAgXCJ2ZXJpZmllZFZpYVwiOiBcIlZlcmlmaWNlcmV0IOKAkyBpbmRzYW1sZXQgdmlhIFtzb3VyY2VdXCJcbiAgfSxcbiAgXCJtb250aE5hbWVzXCI6IHtcbiAgICBcImphbnVhcnlcIjogXCJqYW51YXJcIixcbiAgICBcImZlYnJ1YXJ5XCI6IFwiZmVicnVhclwiLFxuICAgIFwibWFyY2hcIjogXCJtYXJ0c1wiLFxuICAgIFwiYXByaWxcIjogXCJhcHJpbFwiLFxuICAgIFwibWF5XCI6IFwibWFqXCIsXG4gICAgXCJqdW5lXCI6IFwianVuaVwiLFxuICAgIFwianVseVwiOiBcImp1bGlcIixcbiAgICBcImF1Z3VzdFwiOiBcImF1Z3VzdFwiLFxuICAgIFwic2VwdGVtYmVyXCI6IFwic2VwdGVtYmVyXCIsXG4gICAgXCJvY3RvYmVyXCI6IFwib2t0b2JlclwiLFxuICAgIFwibm92ZW1iZXJcIjogXCJub3ZlbWJlclwiLFxuICAgIFwiZGVjZW1iZXJcIjogXCJkZWNlbWJlclwiXG4gIH0sXG4gIFwidGltZUFnb1wiOiB7XG4gICAgXCJkYXlzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJGb3IgW2NvdW50XSBkYWcgc2lkZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiRm9yIFtjb3VudF0gZGFnZSBzaWRlblwiXG4gICAgfSxcbiAgICBcImhvdXJzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJGb3IgW2NvdW50XSB0aW1lIHNpZGVuXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIkZvciBbY291bnRdIHRpbWVyIHNpZGVuXCJcbiAgICB9LFxuICAgIFwibWludXRlc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiRm9yIFtjb3VudF0gbWludXQgc2lkZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiRm9yIFtjb3VudF0gbWludXR0ZXIgc2lkZW5cIlxuICAgIH0sXG4gICAgXCJzZWNvbmRzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJGb3IgW2NvdW50XSBzZWt1bmQgc2lkZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiRm9yIFtjb3VudF0gc2VrdW5kZXIgc2lkZW5cIlxuICAgIH1cbiAgfSxcbiAgXCJyZXZpZXdGaWx0ZXJzXCI6IHtcbiAgICBcImJ5U3RhcnMxXCI6IFwiVmlzZXIgdm9yZXMgW3N0YXIxXS1zdGplcm5lZGUgYW5tZWxkZWxzZXJcIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiVmlzZXIgdm9yZXMgW3N0YXIxXS0gb2cgW3N0YXIyXS1zdGplcm5lZGUgYW5tZWxkZWxzZXJcIixcbiAgICBcImJ5U3RhcnMzXCI6IFwiVmlzZXIgdm9yZXMgW3N0YXIxXS0sIFtzdGFyMl0tIG9nIFtzdGFyM10tc3RqZXJuZWRlIGFubWVsZGVsc2VyXCIsXG4gICAgXCJieVN0YXJzNFwiOiBcIlZpc2VyIHZvcmVzIFtzdGFyMV0tLCBbc3RhcjJdLSwgW3N0YXIzXS0gb2cgW3N0YXI0XS1zdGplcm5lZGUgYW5tZWxkZWxzZXJcIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiVmlzZXIgdm9yZXMgc2VuZXN0ZSBhbm1lbGRlbHNlclwiLFxuICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwiVmlzZXIgdm9yZXMgeW5kbGluZ3Nhbm1lbGRlbHNlclwiXG4gIH1cbn0iLCJtb2R1bGUuZXhwb3J0cz17XG4gIFwicmV2aWV3c1wiOiB7XG4gICAgXCJzaW5ndWxhclwiOiBcIkJld2VydHVuZ1wiLFxuICAgIFwicGx1cmFsXCI6IFwiQmV3ZXJ0dW5nZW5cIixcbiAgICBcImNvbGxlY3RlZFZpYVwiOiBcIkdlc2FtbWVsdCDDvGJlciBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCJWZXJpZml6aWVydCwgZ2VzYW1tZWx0IMO8YmVyIFtzb3VyY2VdXCJcbiAgfSxcbiAgXCJtb250aE5hbWVzXCI6IHtcbiAgICBcImphbnVhcnlcIjogXCJKYW51YXJcIixcbiAgICBcImZlYnJ1YXJ5XCI6IFwiRmVicnVhclwiLFxuICAgIFwibWFyY2hcIjogXCJNw6RyelwiLFxuICAgIFwiYXByaWxcIjogXCJBcHJpbFwiLFxuICAgIFwibWF5XCI6IFwiTWFpXCIsXG4gICAgXCJqdW5lXCI6IFwiSnVuaVwiLFxuICAgIFwianVseVwiOiBcIkp1bGlcIixcbiAgICBcImF1Z3VzdFwiOiBcIkF1Z3VzdFwiLFxuICAgIFwic2VwdGVtYmVyXCI6IFwiU2VwdGVtYmVyXCIsXG4gICAgXCJvY3RvYmVyXCI6IFwiT2t0b2JlclwiLFxuICAgIFwibm92ZW1iZXJcIjogXCJOb3ZlbWJlclwiLFxuICAgIFwiZGVjZW1iZXJcIjogXCJEZXplbWJlclwiXG4gIH0sXG4gIFwidGltZUFnb1wiOiB7XG4gICAgXCJkYXlzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJ2b3IgW2NvdW50XSBUYWdcIixcbiAgICAgIFwicGx1cmFsXCI6IFwidm9yIFtjb3VudF0gVGFnZW5cIlxuICAgIH0sXG4gICAgXCJob3Vyc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwidm9yIFtjb3VudF0gU3R1bmRlXCIsXG4gICAgICBcInBsdXJhbFwiOiBcInZvciBbY291bnRdIFN0dW5kZW5cIlxuICAgIH0sXG4gICAgXCJtaW51dGVzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJ2b3IgW2NvdW50XSBNaW51dGVcIixcbiAgICAgIFwicGx1cmFsXCI6IFwidm9yIFtjb3VudF0gTWludXRlblwiXG4gICAgfSxcbiAgICBcInNlY29uZHNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcInZvciBbY291bnRdIFNla3VuZGVcIixcbiAgICAgIFwicGx1cmFsXCI6IFwidm9yIFtjb3VudF0gU2VrdW5kZW5cIlxuICAgIH1cbiAgfSxcbiAgXCJyZXZpZXdGaWx0ZXJzXCI6IHtcbiAgICBcImJ5U3RhcnMxXCI6IFwiRWluaWdlIHVuc2VyZXIgW3N0YXIxXS1TdGVybmUtQmV3ZXJ0dW5nZW5cIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiRWluaWdlIHVuc2VyZXIgW3N0YXIxXS0gJiBbc3RhcjJdLVN0ZXJuZS1CZXdlcnR1bmdlblwiLFxuICAgIFwiYnlTdGFyczNcIjogXCJFaW5pZ2UgdW5zZXJlciBbc3RhcjFdLSwgW3N0YXIyXS0gJiBbc3RhcjNdLVN0ZXJuZS1CZXdlcnR1bmdlblwiLFxuICAgIFwiYnlTdGFyczRcIjogXCJFaW5pZ2UgdW5zZXJlciBbc3RhcjFdLSwgW3N0YXIyXS0sIFtzdGFyM10tICYgW3N0YXI0XS1TdGVybmUtQmV3ZXJ0dW5nZW5cIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiVW5zZXJlIG5ldWVzdGVuIEJld2VydHVuZ2VuXCIsXG4gICAgXCJieUZhdm9yaXRlT3JUYWdcIjogXCJVbnNlcmUgTGllYmxpbmdzYmV3ZXJ0dW5nZW5cIlxuICB9XG59IiwibW9kdWxlLmV4cG9ydHM9e1xuICBcInJldmlld3NcIjoge1xuICAgIFwic2luZ3VsYXJcIjogXCJyZXZpZXdcIixcbiAgICBcInBsdXJhbFwiOiBcInJldmlld3NcIixcbiAgICBcImNvbGxlY3RlZFZpYVwiOiBcIkNvbGxlY3RlZCB2aWEgW3NvdXJjZV1cIixcbiAgICBcInZlcmlmaWVkVmlhXCI6IFwiVmVyaWZpZWQsIGNvbGxlY3RlZCB2aWEgW3NvdXJjZV1cIlxuICB9LFxuICBcIm1vbnRoTmFtZXNcIjoge1xuICAgIFwiamFudWFyeVwiOiBcIkphbnVhcnlcIixcbiAgICBcImZlYnJ1YXJ5XCI6IFwiRmVicnVhcnlcIixcbiAgICBcIm1hcmNoXCI6IFwiTWFyY2hcIixcbiAgICBcImFwcmlsXCI6IFwiQXByaWxcIixcbiAgICBcIm1heVwiOiBcIk1heVwiLFxuICAgIFwianVuZVwiOiBcIkp1bmVcIixcbiAgICBcImp1bHlcIjogXCJKdWx5XCIsXG4gICAgXCJhdWd1c3RcIjogXCJBdWd1c3RcIixcbiAgICBcInNlcHRlbWJlclwiOiBcIlNlcHRlbWJlclwiLFxuICAgIFwib2N0b2JlclwiOiBcIk9jdG9iZXJcIixcbiAgICBcIm5vdmVtYmVyXCI6IFwiTm92ZW1iZXJcIixcbiAgICBcImRlY2VtYmVyXCI6IFwiRGVjZW1iZXJcIlxuICB9LFxuICBcInRpbWVBZ29cIjoge1xuICAgIFwiZGF5c1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBkYXkgYWdvXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gZGF5cyBhZ29cIlxuICAgIH0sXG4gICAgXCJob3Vyc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBob3VyIGFnb1wiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIGhvdXJzIGFnb1wiXG4gICAgfSxcbiAgICBcIm1pbnV0ZXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gbWludXRlIGFnb1wiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIG1pbnV0ZXMgYWdvXCJcbiAgICB9LFxuICAgIFwic2Vjb25kc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBzZWNvbmQgYWdvXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gc2Vjb25kcyBhZ29cIlxuICAgIH1cbiAgfSxcbiAgXCJyZXZpZXdGaWx0ZXJzXCI6IHtcbiAgICBcImJ5U3RhcnMxXCI6IFwiU2hvd2luZyBvdXIgW3N0YXIxXSBzdGFyIHJldmlld3NcIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiU2hvd2luZyBvdXIgW3N0YXIxXSAmIFtzdGFyMl0gc3RhciByZXZpZXdzXCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIlNob3dpbmcgb3VyIFtzdGFyMV0sIFtzdGFyMl0gJiBbc3RhcjNdIHN0YXIgcmV2aWV3c1wiLFxuICAgIFwiYnlTdGFyczRcIjogXCJTaG93aW5nIG91ciBbc3RhcjFdLCBbc3RhcjJdLCBbc3RhcjNdICYgW3N0YXI0XSBzdGFyIHJldmlld3NcIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiU2hvd2luZyBvdXIgbGF0ZXN0IHJldmlld3NcIixcbiAgICBcImJ5RmF2b3JpdGVPclRhZ1wiOiBcIlNob3dpbmcgb3VyIGZhdm91cml0ZSByZXZpZXdzXCJcbiAgfVxufSIsIm1vZHVsZS5leHBvcnRzPXtcbiAgXCJyZXZpZXdzXCI6IHtcbiAgICBcInNpbmd1bGFyXCI6IFwicmV2aWV3XCIsXG4gICAgXCJwbHVyYWxcIjogXCJyZXZpZXdzXCIsXG4gICAgXCJjb2xsZWN0ZWRWaWFcIjogXCJDb2xsZWN0ZWQgdmlhIFtzb3VyY2VdXCIsXG4gICAgXCJ2ZXJpZmllZFZpYVwiOiBcIlZlcmlmaWVkLCBjb2xsZWN0ZWQgdmlhIFtzb3VyY2VdXCJcbiAgfSxcbiAgXCJtb250aE5hbWVzXCI6IHtcbiAgICBcImphbnVhcnlcIjogXCJKYW51YXJ5XCIsXG4gICAgXCJmZWJydWFyeVwiOiBcIkZlYnJ1YXJ5XCIsXG4gICAgXCJtYXJjaFwiOiBcIk1hcmNoXCIsXG4gICAgXCJhcHJpbFwiOiBcIkFwcmlsXCIsXG4gICAgXCJtYXlcIjogXCJNYXlcIixcbiAgICBcImp1bmVcIjogXCJKdW5lXCIsXG4gICAgXCJqdWx5XCI6IFwiSnVseVwiLFxuICAgIFwiYXVndXN0XCI6IFwiQXVndXN0XCIsXG4gICAgXCJzZXB0ZW1iZXJcIjogXCJTZXB0ZW1iZXJcIixcbiAgICBcIm9jdG9iZXJcIjogXCJPY3RvYmVyXCIsXG4gICAgXCJub3ZlbWJlclwiOiBcIk5vdmVtYmVyXCIsXG4gICAgXCJkZWNlbWJlclwiOiBcIkRlY2VtYmVyXCJcbiAgfSxcbiAgXCJ0aW1lQWdvXCI6IHtcbiAgICBcImRheXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gZGF5IGFnb1wiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIGRheXMgYWdvXCJcbiAgICB9LFxuICAgIFwiaG91cnNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gaG91ciBhZ29cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBob3VycyBhZ29cIlxuICAgIH0sXG4gICAgXCJtaW51dGVzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIG1pbnV0ZSBhZ29cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBtaW51dGVzIGFnb1wiXG4gICAgfSxcbiAgICBcInNlY29uZHNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gc2Vjb25kIGFnb1wiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIHNlY29uZHMgYWdvXCJcbiAgICB9XG4gIH0sXG4gIFwicmV2aWV3RmlsdGVyc1wiOiB7XG4gICAgXCJieVN0YXJzMVwiOiBcIlNob3dpbmcgb3VyIFtzdGFyMV0gc3RhciByZXZpZXdzXCIsXG4gICAgXCJieVN0YXJzMlwiOiBcIlNob3dpbmcgb3VyIFtzdGFyMV0gJiBbc3RhcjJdIHN0YXIgcmV2aWV3c1wiLFxuICAgIFwiYnlTdGFyczNcIjogXCJTaG93aW5nIG91ciBbc3RhcjFdLCBbc3RhcjJdICYgW3N0YXIzXSBzdGFyIHJldmlld3NcIixcbiAgICBcImJ5U3RhcnM0XCI6IFwiU2hvd2luZyBvdXIgW3N0YXIxXSwgW3N0YXIyXSwgW3N0YXIzXSAmIFtzdGFyNF0gc3RhciByZXZpZXdzXCIsXG4gICAgXCJieUxhdGVzdFwiOiBcIlNob3dpbmcgb3VyIGxhdGVzdCByZXZpZXdzXCIsXG4gICAgXCJieUZhdm9yaXRlT3JUYWdcIjogXCJTaG93aW5nIG91ciBmYXZvcml0ZSByZXZpZXdzXCJcbiAgfVxufSIsIm1vZHVsZS5leHBvcnRzPXtcbiAgXCJyZXZpZXdzXCI6IHtcbiAgICBcInNpbmd1bGFyXCI6IFwib3BpbmnDs25cIixcbiAgICBcInBsdXJhbFwiOiBcIm9waW5pb25lc1wiLFxuICAgIFwiY29sbGVjdGVkVmlhXCI6IFwiRnVlbnRlOiBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCJWZXJpZmljYWRhLCByZWNvcGlsYWRhIHbDrWEgW3NvdXJjZV1cIlxuICB9LFxuICBcIm1vbnRoTmFtZXNcIjoge1xuICAgIFwiamFudWFyeVwiOiBcImVuZXJvXCIsXG4gICAgXCJmZWJydWFyeVwiOiBcImZlYnJlcm9cIixcbiAgICBcIm1hcmNoXCI6IFwibWFyem9cIixcbiAgICBcImFwcmlsXCI6IFwiYWJyaWxcIixcbiAgICBcIm1heVwiOiBcIm1heW9cIixcbiAgICBcImp1bmVcIjogXCJqdW5pb1wiLFxuICAgIFwianVseVwiOiBcImp1bGlvXCIsXG4gICAgXCJhdWd1c3RcIjogXCJhZ29zdG9cIixcbiAgICBcInNlcHRlbWJlclwiOiBcInNlcHRpZW1icmVcIixcbiAgICBcIm9jdG9iZXJcIjogXCJvY3R1YnJlXCIsXG4gICAgXCJub3ZlbWJlclwiOiBcIm5vdmllbWJyZVwiLFxuICAgIFwiZGVjZW1iZXJcIjogXCJkaWNpZW1icmVcIlxuICB9LFxuICBcInRpbWVBZ29cIjoge1xuICAgIFwiZGF5c1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiSGFjZSBbY291bnRdIGTDrWFcIixcbiAgICAgIFwicGx1cmFsXCI6IFwiSGFjZSBbY291bnRdIGTDrWFzXCJcbiAgICB9LFxuICAgIFwiaG91cnNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIkhhY2UgW2NvdW50XSBob3JhXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIkhhY2UgW2NvdW50XSBob3Jhc1wiXG4gICAgfSxcbiAgICBcIm1pbnV0ZXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIkhhY2UgW2NvdW50XSBtaW51dG9cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiSGFjZSBbY291bnRdIG1pbnV0b3NcIlxuICAgIH0sXG4gICAgXCJzZWNvbmRzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJIYWNlIFtjb3VudF0gc2VndW5kb1wiLFxuICAgICAgXCJwbHVyYWxcIjogXCJIYWNlIFtjb3VudF0gc2VndW5kb3NcIlxuICAgIH1cbiAgfSxcbiAgXCJyZXZpZXdGaWx0ZXJzXCI6IHtcbiAgICBcImJ5U3RhcnMxXCI6IFwiTnVlc3RyYXMgb3BpbmlvbmVzIGRlIFtzdGFyMV0gZXN0cmVsbGFzXCIsXG4gICAgXCJieVN0YXJzMlwiOiBcIk51ZXN0cmFzIG9waW5pb25lcyBkZSBbc3RhcjFdIHkgW3N0YXIyXSBlc3RyZWxsYXNcIixcbiAgICBcImJ5U3RhcnMzXCI6IFwiTnVlc3RyYXMgb3BpbmlvbmVzIGRlIFtzdGFyMV0sIFtzdGFyMl0geSBbc3RhcjNdIGVzdHJlbGxhc1wiLFxuICAgIFwiYnlTdGFyczRcIjogXCJOdWVzdHJhcyBvcGluaW9uZXMgZGUgW3N0YXIxXSwgW3N0YXIyXSwgW3N0YXIzXSB5IFtzdGFyNF0gZXN0cmVsbGFzXCIsXG4gICAgXCJieUxhdGVzdFwiOiBcIk51ZXN0cmFzIG9waW5pb25lcyBtw6FzIHJlY2llbnRlc1wiLFxuICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwiTnVlc3RyYXMgb3BpbmlvbmVzIHByZWZlcmlkYXNcIlxuICB9XG59IiwibW9kdWxlLmV4cG9ydHM9e1xuICBcInJldmlld3NcIjoge1xuICAgIFwic2luZ3VsYXJcIjogXCJhcnZvc3RlbHVcIixcbiAgICBcInBsdXJhbFwiOiBcImFydm9zdGVsdWFcIixcbiAgICBcImNvbGxlY3RlZFZpYVwiOiBcIkFydm9zdGVsdW4gbMOkaGRlOiBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCJWYXJtZW5uZXR0dSwgbMOkaGRlOiBbc291cmNlXVwiXG4gIH0sXG4gIFwibW9udGhOYW1lc1wiOiB7XG4gICAgXCJqYW51YXJ5XCI6IFwidGFtbWlrdXV0YVwiLFxuICAgIFwiZmVicnVhcnlcIjogXCJoZWxtaWt1dXRhXCIsXG4gICAgXCJtYXJjaFwiOiBcIm1hYWxpc2t1dXRhXCIsXG4gICAgXCJhcHJpbFwiOiBcImh1aHRpa3V1dGFcIixcbiAgICBcIm1heVwiOiBcInRvdWtva3V1dGFcIixcbiAgICBcImp1bmVcIjogXCJrZXPDpGt1dXRhXCIsXG4gICAgXCJqdWx5XCI6IFwiaGVpbsOka3V1dGFcIixcbiAgICBcImF1Z3VzdFwiOiBcImVsb2t1dXRhXCIsXG4gICAgXCJzZXB0ZW1iZXJcIjogXCJzeXlza3V1dGFcIixcbiAgICBcIm9jdG9iZXJcIjogXCJsb2tha3V1dGFcIixcbiAgICBcIm5vdmVtYmVyXCI6IFwibWFycmFza3V1dGFcIixcbiAgICBcImRlY2VtYmVyXCI6IFwiam91bHVrdXV0YVwiXG4gIH0sXG4gIFwidGltZUFnb1wiOiB7XG4gICAgXCJkYXlzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIHDDpGl2w6TDpCBzaXR0ZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBww6RpdsOkw6Qgc2l0dGVuXCJcbiAgICB9LFxuICAgIFwiaG91cnNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gdHVudGlhIHNpdHRlblwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIHR1bnRpYSBzaXR0ZW5cIlxuICAgIH0sXG4gICAgXCJtaW51dGVzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIG1pbnV1dHRpYSBzaXR0ZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBtaW51dXR0aWEgc2l0dGVuXCJcbiAgICB9LFxuICAgIFwic2Vjb25kc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBzZWt1bnRpYSBzaXR0ZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBzZWt1bnRpYSBzaXR0ZW5cIlxuICAgIH1cbiAgfSxcbiAgXCJyZXZpZXdGaWx0ZXJzXCI6IHtcbiAgICBcImJ5U3RhcnMxXCI6IFwiTsOkeXRldMOkw6RuIFtzdGFyMV0gdMOkaGRlbiBhcnZvc3RlbHVtbWVcIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiTsOkeXRldMOkw6RuIFtzdGFyMV0gJiBbc3RhcjJdIHTDpGhkZW4gYXJ2b3N0ZWx1bW1lXCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIk7DpHl0ZXTDpMOkbiBbc3RhcjFdLCBbc3RhcjJdICYgW3N0YXIzXSB0w6RoZGVuIGFydm9zdGVsdW1tZVwiLFxuICAgIFwiYnlTdGFyczRcIjogXCJOw6R5dGV0w6TDpG4gW3N0YXIxXSwgW3N0YXIyXSwgW3N0YXIzXSAmIFtzdGFyNF0gdMOkaGRlbiBhcnZvc3RlbHVtbWVcIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiTsOkeXRldMOkw6RuIHZpaW1laXNpbW3DpHQgYXJ2b3N0ZWx1bW1lXCIsXG4gICAgXCJieUZhdm9yaXRlT3JUYWdcIjogXCJOw6R5dGV0w6TDpG4gc3Vvc2lra2lhcnZvc3RlbHVtbWVcIlxuICB9XG59IiwibW9kdWxlLmV4cG9ydHM9e1xuICBcInJldmlld3NcIjoge1xuICAgIFwic2luZ3VsYXJcIjogXCJhdmlzXCIsXG4gICAgXCJwbHVyYWxcIjogXCJhdmlzXCIsXG4gICAgXCJjb2xsZWN0ZWRWaWFcIjogXCJDb2xsZWN0w6kgdmlhIFtzb3VyY2VdXCIsXG4gICAgXCJ2ZXJpZmllZFZpYVwiOiBcIlbDqXJpZmnDqSwgY29sbGVjdMOpIHZpYSBbc291cmNlXVwiXG4gIH0sXG4gIFwibW9udGhOYW1lc1wiOiB7XG4gICAgXCJqYW51YXJ5XCI6IFwiamFudmllclwiLFxuICAgIFwiZmVicnVhcnlcIjogXCJmw6l2cmllclwiLFxuICAgIFwibWFyY2hcIjogXCJtYXJzXCIsXG4gICAgXCJhcHJpbFwiOiBcImF2cmlsXCIsXG4gICAgXCJtYXlcIjogXCJtYWlcIixcbiAgICBcImp1bmVcIjogXCJqdWluXCIsXG4gICAgXCJqdWx5XCI6IFwianVpbGxldFwiLFxuICAgIFwiYXVndXN0XCI6IFwiYW/Du3RcIixcbiAgICBcInNlcHRlbWJlclwiOiBcInNlcHRlbWJyZVwiLFxuICAgIFwib2N0b2JlclwiOiBcIm9jdG9icmVcIixcbiAgICBcIm5vdmVtYmVyXCI6IFwibm92ZW1icmVcIixcbiAgICBcImRlY2VtYmVyXCI6IFwiZMOpY2VtYnJlXCJcbiAgfSxcbiAgXCJ0aW1lQWdvXCI6IHtcbiAgICBcImRheXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcImxsIHkgYSBbY291bnRdIGpvdXJcIixcbiAgICAgIFwicGx1cmFsXCI6IFwiSWwgeSBhIFtjb3VudF0gam91cnNcIlxuICAgIH0sXG4gICAgXCJob3Vyc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiSWwgeSBhIFtjb3VudF0gaGV1cmVcIixcbiAgICAgIFwicGx1cmFsXCI6IFwiSWwgeSBhIFtjb3VudF0gaGV1cmVzXCJcbiAgICB9LFxuICAgIFwibWludXRlc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiSWwgeSBhIFtjb3VudF0gbWludXRlXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIklsIHkgYSBbY291bnRdIG1pbnV0ZXNcIlxuICAgIH0sXG4gICAgXCJzZWNvbmRzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJJbCB5IGEgW2NvdW50XSBzZWNvbmRlXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIklsIHkgYSBbY291bnRdIHNlY29uZGVzXCJcbiAgICB9XG4gIH0sXG4gIFwicmV2aWV3RmlsdGVyc1wiOiB7XG4gICAgXCJieVN0YXJzMVwiOiBcIk5vcyBhdmlzIFtzdGFyMV0gw6l0b2lsZXNcIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiTm9zIGF2aXMgW3N0YXIxXSBldCBbc3RhcjJdIMOpdG9pbGVzXCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIk5vcyBhdmlzIFtzdGFyMV0sIFtzdGFyMl0gZXQgW3N0YXIzXSDDqXRvaWxlc1wiLFxuICAgIFwiYnlTdGFyczRcIjogXCJOb3MgYXZpcyBbc3RhcjFdLCBbc3RhcjJdLCBbc3RhcjNdIGV0IFtzdGFyNF0gw6l0b2lsZXNcIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiTm9zIGRlcm5pZXJzIGF2aXNcIixcbiAgICBcImJ5RmF2b3JpdGVPclRhZ1wiOiBcIk5vcyBhdmlzIHByw6lmw6lyw6lzXCJcbiAgfVxufSIsImltcG9ydCAqIGFzIGRrIGZyb20gJy4vZGEtREsvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGF0IGZyb20gJy4vZGUtQVQvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGNoIGZyb20gJy4vZGUtQ0gvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGRlIGZyb20gJy4vZGUtREUvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGF1IGZyb20gJy4vZW4tQVUvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGNhIGZyb20gJy4vZW4tQ0Evc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGdiIGZyb20gJy4vZW4tR0Ivc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGllIGZyb20gJy4vZW4tSUUvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIG56IGZyb20gJy4vZW4tTlovc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIHVzIGZyb20gJy4vZW4tVVMvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGVzIGZyb20gJy4vZXMtRVMvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGZpIGZyb20gJy4vZmktRkkvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGJlIGZyb20gJy4vZnItQkUvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGZyIGZyb20gJy4vZnItRlIvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGl0IGZyb20gJy4vaXQtSVQvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGpwIGZyb20gJy4vamEtSlAvc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIG5vIGZyb20gJy4vbmItTk8vc3RyaW5ncy5qc29uJztcbmltcG9ydCAqIGFzIGJlTmwgZnJvbSAnLi9ubC1CRS9zdHJpbmdzLmpzb24nO1xuaW1wb3J0ICogYXMgbmwgZnJvbSAnLi9ubC1OTC9zdHJpbmdzLmpzb24nO1xuaW1wb3J0ICogYXMgcGwgZnJvbSAnLi9wbC1QTC9zdHJpbmdzLmpzb24nO1xuaW1wb3J0ICogYXMgYnIgZnJvbSAnLi9wdC1CUi9zdHJpbmdzLmpzb24nO1xuaW1wb3J0ICogYXMgcHQgZnJvbSAnLi9wdC1QVC9zdHJpbmdzLmpzb24nO1xuaW1wb3J0ICogYXMgcnUgZnJvbSAnLi9ydS1SVS9zdHJpbmdzLmpzb24nO1xuaW1wb3J0ICogYXMgc2UgZnJvbSAnLi9zdi1TRS9zdHJpbmdzLmpzb24nO1xuaW1wb3J0ICogYXMgY24gZnJvbSAnLi96aC1DTi9zdHJpbmdzLmpzb24nO1xuXG5jb25zdCBsb2NhbGVzID0ge1xuICAnZGEtREsnOiBkayxcbiAgJ2RlLUFUJzogYXQsXG4gICdkZS1DSCc6IGNoLFxuICAnZGUtREUnOiBkZSxcbiAgJ2VuLUFVJzogYXUsXG4gICdlbi1DQSc6IGNhLFxuICAnZW4tR0InOiBnYixcbiAgJ2VuLUlFJzogaWUsXG4gICdlbi1OWic6IG56LFxuICAnZW4tVVMnOiB1cyxcbiAgJ2VzLUVTJzogZXMsXG4gICdmaS1GSSc6IGZpLFxuICAnZnItQkUnOiBiZSxcbiAgJ2ZyLUZSJzogZnIsXG4gICdpdC1JVCc6IGl0LFxuICAnamEtSlAnOiBqcCxcbiAgJ25iLU5PJzogbm8sXG4gICdubC1CRSc6IGJlTmwsXG4gICdubC1OTCc6IG5sLFxuICAncGwtUEwnOiBwbCxcbiAgJ3B0LUJSJzogYnIsXG4gICdwdC1QVCc6IHB0LFxuICAncnUtUlUnOiBydSxcbiAgJ3N2LVNFJzogc2UsXG4gICd6aC1DTic6IGNuLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgbG9jYWxlcztcbiIsIm1vZHVsZS5leHBvcnRzPXtcbiAgXCJyZXZpZXdzXCI6IHtcbiAgICBcInNpbmd1bGFyXCI6IFwicmVjZW5zaW9uZVwiLFxuICAgIFwicGx1cmFsXCI6IFwicmVjZW5zaW9uaVwiLFxuICAgIFwiY29sbGVjdGVkVmlhXCI6IFwiUmFjY29sdGEgdHJhbWl0ZSBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCJWZXJpZmljYXRhLCByYWNjb2x0YSBkYSBbc291cmNlXVwiXG4gIH0sXG4gIFwibW9udGhOYW1lc1wiOiB7XG4gICAgXCJqYW51YXJ5XCI6IFwiZ2VubmFpb1wiLFxuICAgIFwiZmVicnVhcnlcIjogXCJmZWJicmFpb1wiLFxuICAgIFwibWFyY2hcIjogXCJtYXJ6b1wiLFxuICAgIFwiYXByaWxcIjogXCJhcHJpbGVcIixcbiAgICBcIm1heVwiOiBcIm1hZ2dpb1wiLFxuICAgIFwianVuZVwiOiBcImdpdWdub1wiLFxuICAgIFwianVseVwiOiBcImx1Z2xpb1wiLFxuICAgIFwiYXVndXN0XCI6IFwiYWdvc3RvXCIsXG4gICAgXCJzZXB0ZW1iZXJcIjogXCJzZXR0ZW1icmVcIixcbiAgICBcIm9jdG9iZXJcIjogXCJvdHRvYnJlXCIsXG4gICAgXCJub3ZlbWJlclwiOiBcIm5vdmVtYnJlXCIsXG4gICAgXCJkZWNlbWJlclwiOiBcImRpY2VtYnJlXCJcbiAgfSxcbiAgXCJ0aW1lQWdvXCI6IHtcbiAgICBcImRheXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gZ2lvcm5vIGZhXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gZ2lvcm5pIGZhXCJcbiAgICB9LFxuICAgIFwiaG91cnNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gb3JhIGZhXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gb3JlIGZhXCJcbiAgICB9LFxuICAgIFwibWludXRlc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBtaW51dG8gZmFcIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBtaW51dGkgZmFcIlxuICAgIH0sXG4gICAgXCJzZWNvbmRzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIHNlY29uZG8gZmFcIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBzZWNvbmRpIGZhXCJcbiAgICB9XG4gIH0sXG4gIFwicmV2aWV3RmlsdGVyc1wiOiB7XG4gICAgXCJieVN0YXJzMVwiOiBcIkxlIG5vc3RyZSByZWNlbnNpb25pIGEgW3N0YXIxXSBzdGVsbGVcIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiTGUgbm9zdHJlIHJlY2Vuc2lvbmkgYSBbc3RhcjFdIGUgYSBbc3RhcjJdIHN0ZWxsZVwiLFxuICAgIFwiYnlTdGFyczNcIjogXCJMZSBub3N0cmUgcmVjZW5zaW9uaSBhIFtzdGFyMV0sIGEgW3N0YXIyXSBlIGEgW3N0YXIzXSBzdGVsbGVcIixcbiAgICBcImJ5U3RhcnM0XCI6IFwiTGUgbm9zdHJlIHJlY2Vuc2lvbmkgYSBbc3RhcjFdLCBhIFtzdGFyMl0sIGEgW3N0YXIzXSBlIGEgW3N0YXI0XSBzdGVsbGVcIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiTGUgbm9zdHJlIHVsdGltZSByZWNlbnNpb25pXCIsXG4gICAgXCJieUZhdm9yaXRlT3JUYWdcIjogXCJMZSBub3N0cmUgcmVjZW5zaW9uaSBwcmVmZXJpdGVcIlxuICB9XG59IiwibW9kdWxlLmV4cG9ydHM9e1xuICBcInJldmlld3NcIjoge1xuICAgIFwic2luZ3VsYXJcIjogXCLjg6zjg5Pjg6Xjg7xcIixcbiAgICBcInBsdXJhbFwiOiBcIuODrOODk+ODpeODvFwiLFxuICAgIFwiY29sbGVjdGVkVmlhXCI6IFwiW3NvdXJjZV0g44Gr44KI44Gj44Gm5Y+O6ZuGXCIsXG4gICAgXCJ2ZXJpZmllZFZpYVwiOiBcIltzb3VyY2VdIOOBq+OCiOOBo+OBpueiuuiqjeODu+WPjumbhlwiXG4gIH0sXG4gIFwibW9udGhOYW1lc1wiOiB7XG4gICAgXCJqYW51YXJ5XCI6IFwiMeaciFwiLFxuICAgIFwiZmVicnVhcnlcIjogXCIy5pyIXCIsXG4gICAgXCJtYXJjaFwiOiBcIjPmnIhcIixcbiAgICBcImFwcmlsXCI6IFwiNOaciFwiLFxuICAgIFwibWF5XCI6IFwiNeaciFwiLFxuICAgIFwianVuZVwiOiBcIjbmnIhcIixcbiAgICBcImp1bHlcIjogXCI35pyIXCIsXG4gICAgXCJhdWd1c3RcIjogXCI45pyIXCIsXG4gICAgXCJzZXB0ZW1iZXJcIjogXCI55pyIXCIsXG4gICAgXCJvY3RvYmVyXCI6IFwiMTDmnIhcIixcbiAgICBcIm5vdmVtYmVyXCI6IFwiMTHmnIhcIixcbiAgICBcImRlY2VtYmVyXCI6IFwiMTLmnIhcIlxuICB9LFxuICBcInRpbWVBZ29cIjoge1xuICAgIFwiZGF5c1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XeaXpeWJjVwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRd5pel5YmNXCJcbiAgICB9LFxuICAgIFwiaG91cnNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF3mmYLplpPliY1cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XeaZgumWk+WJjVwiXG4gICAgfSxcbiAgICBcIm1pbnV0ZXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF3liIbliY1cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XeWIhuWJjVwiXG4gICAgfSxcbiAgICBcInNlY29uZHNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF3np5LliY1cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XeenkuWJjVwiXG4gICAgfVxuICB9LFxuICBcInJldmlld0ZpbHRlcnNcIjoge1xuICAgIFwiYnlTdGFyczFcIjogXCJbc3RhcjFd44Gk5pif44Gu44Os44OT44Ol44O844KS6KGo56S6XCIsXG4gICAgXCJieVN0YXJzMlwiOiBcIltzdGFyMV3jgaTmmJ/jgahbc3RhcjJd44Gk5pif44Gu44Os44OT44Ol44O844KS6KGo56S6XCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIltzdGFyMV3jgaTmmJ/jgIFbc3RhcjJd44Gk5pif44CBW3N0YXIzXeOBpOaYn+OBruODrOODk+ODpeODvOOCkuihqOekulwiLFxuICAgIFwiYnlTdGFyczRcIjogXCJbc3RhcjFd44Gk5pif44CBW3N0YXIyXeOBpOaYn+OAgVtzdGFyM13jgaTmmJ/jgIFbc3RhcjRd44Gk5pif44Gu44Os44OT44Ol44O844KS6KGo56S6XCIsXG4gICAgXCJieUxhdGVzdFwiOiBcIuacgOaWsOOBruODrOODk+ODpeODvOOCkuihqOekulwiLFxuICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwi44GK5rCX44Gr5YWl44KK44Gu44Os44OT44Ol44O844KS6KGo56S6XCJcbiAgfVxufSIsIm1vZHVsZS5leHBvcnRzPXtcbiAgXCJyZXZpZXdzXCI6IHtcbiAgICBcInNpbmd1bGFyXCI6IFwiYW5tZWxkZWxzZVwiLFxuICAgIFwicGx1cmFsXCI6IFwiYW5tZWxkZWxzZXJcIixcbiAgICBcImNvbGxlY3RlZFZpYVwiOiBcIlNhbWxldCBpbm4gZ2plbm5vbSBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCJCZWtyZWZ0ZXQg4oCTIHNhbWxldCBpbm4gdmlhIFtzb3VyY2VdXCJcbiAgfSxcbiAgXCJtb250aE5hbWVzXCI6IHtcbiAgICBcImphbnVhcnlcIjogXCJqYW51YXJcIixcbiAgICBcImZlYnJ1YXJ5XCI6IFwiZmVicnVhclwiLFxuICAgIFwibWFyY2hcIjogXCJtYXJzXCIsXG4gICAgXCJhcHJpbFwiOiBcImFwcmlsXCIsXG4gICAgXCJtYXlcIjogXCJtYWlcIixcbiAgICBcImp1bmVcIjogXCJqdW5pXCIsXG4gICAgXCJqdWx5XCI6IFwianVsaVwiLFxuICAgIFwiYXVndXN0XCI6IFwiYXVndXN0XCIsXG4gICAgXCJzZXB0ZW1iZXJcIjogXCJzZXB0ZW1iZXJcIixcbiAgICBcIm9jdG9iZXJcIjogXCJva3RvYmVyXCIsXG4gICAgXCJub3ZlbWJlclwiOiBcIm5vdmVtYmVyXCIsXG4gICAgXCJkZWNlbWJlclwiOiBcImRlc2VtYmVyXCJcbiAgfSxcbiAgXCJ0aW1lQWdvXCI6IHtcbiAgICBcImRheXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIkZvciBbY291bnRdIGRhZyBzaWRlblwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJGb3IgW2NvdW50XSBkYWdlciBzaWRlblwiXG4gICAgfSxcbiAgICBcImhvdXJzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJGb3IgW2NvdW50XSB0aW1lIHNpZGVuXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIkZvciBbY291bnRdIHRpbWVyIHNpZGVuXCJcbiAgICB9LFxuICAgIFwibWludXRlc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiRm9yIFtjb3VudF0gbWludXR0IHNpZGVuXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIkZvciBbY291bnRdIG1pbnV0dGVyIHNpZGVuXCJcbiAgICB9LFxuICAgIFwic2Vjb25kc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiRm9yIFtjb3VudF0gc2VrdW5kIHNpZGVuXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIkZvciBbY291bnRdIHNla3VuZGVyIHNpZGVuXCJcbiAgICB9XG4gIH0sXG4gIFwicmV2aWV3RmlsdGVyc1wiOiB7XG4gICAgXCJieVN0YXJzMVwiOiBcIlZpc2VyIFtzdGFyMV0tc3RqZXJuZXJzYW5tZWxkZWxzZW5lXCIsXG4gICAgXCJieVN0YXJzMlwiOiBcIlZpc2VyIFtzdGFyMV0tIG9nIFtzdGFyMl0tc3RqZXJuZXJzYW5tZWxkZWxzZW5lXCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIlZpc2VyIFtzdGFyMV0tLCBbc3RhcjJdLSBvZyBbc3RhcjNdLXN0amVybmVyc2FubWVsZGVsc2VuZVwiLFxuICAgIFwiYnlTdGFyczRcIjogXCJWaXNlciBbc3RhcjFdLSwgW3N0YXIyXS0sIFtzdGFyM10tIG9nIFtzdGFyNF0tc3RqZXJuZXJzYW5tZWxkZWxzZW5lXCIsXG4gICAgXCJieUxhdGVzdFwiOiBcIlZpc2VyIGRlIG55ZXN0ZSBhbm1lbGRlbHNlbmVcIixcbiAgICBcImJ5RmF2b3JpdGVPclRhZ1wiOiBcIlZpc2VyIGZhdm9yaXR0ZW5lIHbDpXJlXCJcbiAgfVxufSIsIm1vZHVsZS5leHBvcnRzPXtcbiAgXCJyZXZpZXdzXCI6IHtcbiAgICBcInNpbmd1bGFyXCI6IFwicmV2aWV3XCIsXG4gICAgXCJwbHVyYWxcIjogXCJyZXZpZXdzXCIsXG4gICAgXCJjb2xsZWN0ZWRWaWFcIjogXCJWZXJ6YW1lbGQgdmlhIFtzb3VyY2VdXCIsXG4gICAgXCJ2ZXJpZmllZFZpYVwiOiBcIkdldmVyaWZpZWVyZCDigJQgdmVyemFtZWxkIHZpYSBbc291cmNlXVwiXG4gIH0sXG4gIFwibW9udGhOYW1lc1wiOiB7XG4gICAgXCJqYW51YXJ5XCI6IFwiamFudWFyaVwiLFxuICAgIFwiZmVicnVhcnlcIjogXCJmZWJydWFyaVwiLFxuICAgIFwibWFyY2hcIjogXCJtYWFydFwiLFxuICAgIFwiYXByaWxcIjogXCJhcHJpbFwiLFxuICAgIFwibWF5XCI6IFwibWVpXCIsXG4gICAgXCJqdW5lXCI6IFwianVuaVwiLFxuICAgIFwianVseVwiOiBcImp1bGlcIixcbiAgICBcImF1Z3VzdFwiOiBcImF1Z3VzdHVzXCIsXG4gICAgXCJzZXB0ZW1iZXJcIjogXCJzZXB0ZW1iZXJcIixcbiAgICBcIm9jdG9iZXJcIjogXCJva3RvYmVyXCIsXG4gICAgXCJub3ZlbWJlclwiOiBcIm5vdmVtYmVyXCIsXG4gICAgXCJkZWNlbWJlclwiOiBcIkRlY2VtYmVyXCJcbiAgfSxcbiAgXCJ0aW1lQWdvXCI6IHtcbiAgICBcImRheXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gZGFnIGdlbGVkZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBkYWdlbiBnZWxlZGVuXCJcbiAgICB9LFxuICAgIFwiaG91cnNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gdXVyIGdlbGVkZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSB1dXIgZ2VsZWRlblwiXG4gICAgfSxcbiAgICBcIm1pbnV0ZXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gbWludXV0IGdlbGVkZW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBtaW51dGVuIGdlbGVkZW5cIlxuICAgIH0sXG4gICAgXCJzZWNvbmRzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIHNlY29uZGUgZ2VsZWRlblwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIHNlY29uZGVuIGdlbGVkZW5cIlxuICAgIH1cbiAgfSxcbiAgXCJyZXZpZXdGaWx0ZXJzXCI6IHtcbiAgICBcImJ5U3RhcnMxXCI6IFwiT256ZSByZXZpZXdzIG1ldCBbc3RhcjFdIHN0ZXJyZW5cIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiT256ZSByZXZpZXdzIG1ldCBbc3RhcjFdIGVuIFtzdGFyMl0gc3RlcnJlblwiLFxuICAgIFwiYnlTdGFyczNcIjogXCJPbnplIHJldmlld3MgbWV0IFtzdGFyMV0sIFtzdGFyMl0gZW4gW3N0YXIzXSBzdGVycmVuXCIsXG4gICAgXCJieVN0YXJzNFwiOiBcIk9uemUgcmV2aWV3cyBtZXQgW3N0YXIxXSwgW3N0YXIyXSwgW3N0YXIzXSBlbiBbc3RhcjRdIHN0ZXJyZW5cIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiT256ZSBtZWVzdCByZWNlbnRlIHJldmlld3NcIixcbiAgICBcImJ5RmF2b3JpdGVPclRhZ1wiOiBcIk9uemUgZmF2b3JpZXRlIHJldmlld3NcIlxuICB9XG59IiwibW9kdWxlLmV4cG9ydHM9e1xuICBcInJldmlld3NcIjoge1xuICAgIFwic2luZ3VsYXJcIjogXCJyZXZpZXdcIixcbiAgICBcInBsdXJhbFwiOiBcInJldmlld3NcIixcbiAgICBcImNvbGxlY3RlZFZpYVwiOiBcIlZlcnphbWVsZCB2aWEgW3NvdXJjZV1cIixcbiAgICBcInZlcmlmaWVkVmlhXCI6IFwiR2V2ZXJpZmllZXJkIOKAlCB2ZXJ6YW1lbGQgdmlhIFtzb3VyY2VdXCJcbiAgfSxcbiAgXCJtb250aE5hbWVzXCI6IHtcbiAgICBcImphbnVhcnlcIjogXCJqYW51YXJpXCIsXG4gICAgXCJmZWJydWFyeVwiOiBcImZlYnJ1YXJpXCIsXG4gICAgXCJtYXJjaFwiOiBcIm1hYXJ0XCIsXG4gICAgXCJhcHJpbFwiOiBcImFwcmlsXCIsXG4gICAgXCJtYXlcIjogXCJtZWlcIixcbiAgICBcImp1bmVcIjogXCJqdW5pXCIsXG4gICAgXCJqdWx5XCI6IFwianVsaVwiLFxuICAgIFwiYXVndXN0XCI6IFwiYXVndXN0dXNcIixcbiAgICBcInNlcHRlbWJlclwiOiBcInNlcHRlbWJlclwiLFxuICAgIFwib2N0b2JlclwiOiBcIm9rdG9iZXJcIixcbiAgICBcIm5vdmVtYmVyXCI6IFwibm92ZW1iZXJcIixcbiAgICBcImRlY2VtYmVyXCI6IFwiZGVjZW1iZXJcIlxuICB9LFxuICBcInRpbWVBZ29cIjoge1xuICAgIFwiZGF5c1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBkYWcgZ2VsZWRlblwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIGRhZ2VuIGdlbGVkZW5cIlxuICAgIH0sXG4gICAgXCJob3Vyc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSB1dXIgZ2VsZWRlblwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIHV1ciBnZWxlZGVuXCJcbiAgICB9LFxuICAgIFwibWludXRlc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBtaW51dXQgZ2VsZWRlblwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIG1pbnV0ZW4gZ2VsZWRlblwiXG4gICAgfSxcbiAgICBcInNlY29uZHNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gc2Vjb25kZSBnZWxlZGVuXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gc2Vjb25kZW4gZ2VsZWRlblwiXG4gICAgfVxuICB9LFxuICBcInJldmlld0ZpbHRlcnNcIjoge1xuICAgIFwiYnlTdGFyczFcIjogXCJPbnplIHJldmlld3MgbWV0IFtzdGFyMV0gc3RlcnJlblwiLFxuICAgIFwiYnlTdGFyczJcIjogXCJPbnplIHJldmlld3MgbWV0IFtzdGFyMV0gZW4gW3N0YXIyXSBzdGVycmVuXCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIk9uemUgcmV2aWV3cyBtZXQgW3N0YXIxXSwgW3N0YXIyXSBlbiBbc3RhcjNdIHN0ZXJyZW5cIixcbiAgICBcImJ5U3RhcnM0XCI6IFwiT256ZSByZXZpZXdzIG1ldCBbc3RhcjFdLCBbc3RhcjJdLCBbc3RhcjNdIGVuIFtzdGFyNF0gc3RlcnJlblwiLFxuICAgIFwiYnlMYXRlc3RcIjogXCJPbnplIG1lZXN0IHJlY2VudGUgcmV2aWV3c1wiLFxuICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwiT256ZSBmYXZvcmlldGUgcmV2aWV3c1wiXG4gIH1cbn0iLCJtb2R1bGUuZXhwb3J0cz17XG4gIFwicmV2aWV3c1wiOiB7XG4gICAgXCJzaW5ndWxhclwiOiBcInJlY2VuemphXCIsXG4gICAgXCJwbHVyYWxcIjogXCJyZWNlbnpqaVwiLFxuICAgIFwiY29sbGVjdGVkVmlhXCI6IFwiWmVicmFuZSBwcnpleiBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCJad2VyeWZpa293YW5vIGkgemVicmFubyBwcnpleiBbc291cmNlXVwiXG4gIH0sXG4gIFwibW9udGhOYW1lc1wiOiB7XG4gICAgXCJqYW51YXJ5XCI6IFwic3R5Y3puaWFcIixcbiAgICBcImZlYnJ1YXJ5XCI6IFwibHV0ZWdvXCIsXG4gICAgXCJtYXJjaFwiOiBcIm1hcmNhXCIsXG4gICAgXCJhcHJpbFwiOiBcImt3aWV0bmlhXCIsXG4gICAgXCJtYXlcIjogXCJtYWphXCIsXG4gICAgXCJqdW5lXCI6IFwiY3plcndjYVwiLFxuICAgIFwianVseVwiOiBcImxpcGNhXCIsXG4gICAgXCJhdWd1c3RcIjogXCJzaWVycG5pYVwiLFxuICAgIFwic2VwdGVtYmVyXCI6IFwid3J6ZcWbbmlhXCIsXG4gICAgXCJvY3RvYmVyXCI6IFwicGHFumR6aWVybmlrYVwiLFxuICAgIFwibm92ZW1iZXJcIjogXCJsaXN0b3BhZGFcIixcbiAgICBcImRlY2VtYmVyXCI6IFwiZ3J1ZG5pYVwiXG4gIH0sXG4gIFwidGltZUFnb1wiOiB7XG4gICAgXCJkYXlzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIGR6aWXFhCB0ZW11XCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gZG5pIHRlbXVcIlxuICAgIH0sXG4gICAgXCJob3Vyc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBnb2R6aW7EmSB0ZW11XCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gZ29kei4gdGVtdVwiXG4gICAgfSxcbiAgICBcIm1pbnV0ZXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gbWludXTEmSB0ZW11XCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gbWluLiB0ZW11XCJcbiAgICB9LFxuICAgIFwic2Vjb25kc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBzZWt1bmTEmSB0ZW11XCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gc2VrLiB0ZW11XCJcbiAgICB9XG4gIH0sXG4gIFwicmV2aWV3RmlsdGVyc1wiOiB7XG4gICAgXCJieVN0YXJzMVwiOiBcIld5xZt3aWV0bGFteSBuYXN6ZSBbc3RhcjFdLWd3aWF6ZGtvd2UgcmVjZW56amVcIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiV3nFm3dpZXRsYW15IG5hc3plIFtzdGFyMV0tIGkgW3N0YXIyXS1nd2lhemRrb3dlIHJlY2VuemplXCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIld5xZt3aWV0bGFteSBuYXN6ZSBbc3RhcjFdLSwgW3N0YXIyXS0gaSBbc3RhcjNdLWd3aWF6ZGtvd2UgcmVjZW56amVcIixcbiAgICBcImJ5U3RhcnM0XCI6IFwiV3nFm3dpZXRsYW15IG5hc3plIFtzdGFyMV0tLCBbc3RhcjJdLSwgW3N0YXIzXS0gaSBbc3RhcjRdLWd3aWF6ZGtvd2UgcmVjZW56amVcIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiV3nFm3dpZXRsYW15IG5ham5vd3N6ZSByZWNlbnpqZVwiLFxuICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwiV3nFm3dpZXRsYW15IG5hc3plIHVsdWJpb25lIHJlY2VuemplXCJcbiAgfVxufSIsIm1vZHVsZS5leHBvcnRzPXtcbiAgXCJyZXZpZXdzXCI6IHtcbiAgICBcInNpbmd1bGFyXCI6IFwiYXZhbGlhw6fDo29cIixcbiAgICBcInBsdXJhbFwiOiBcImF2YWxpYcOnw7Vlc1wiLFxuICAgIFwiY29sbGVjdGVkVmlhXCI6IFwiUmVjb2xoaWRhIHZpYSBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCJWZXJpZmljYWRhLCByZWNvbGhpZGEgdmlhIFtzb3VyY2VdXCJcbiAgfSxcbiAgXCJtb250aE5hbWVzXCI6IHtcbiAgICBcImphbnVhcnlcIjogXCJKYW5laXJvXCIsXG4gICAgXCJmZWJydWFyeVwiOiBcIkZldmVyZWlyb1wiLFxuICAgIFwibWFyY2hcIjogXCJNYXLDp29cIixcbiAgICBcImFwcmlsXCI6IFwiQWJyaWxcIixcbiAgICBcIm1heVwiOiBcIk1haW9cIixcbiAgICBcImp1bmVcIjogXCJKdW5ob1wiLFxuICAgIFwianVseVwiOiBcIkp1bGhvXCIsXG4gICAgXCJhdWd1c3RcIjogXCJBZ29zdG9cIixcbiAgICBcInNlcHRlbWJlclwiOiBcIlNldGVtYnJvXCIsXG4gICAgXCJvY3RvYmVyXCI6IFwiT3V0dWJyb1wiLFxuICAgIFwibm92ZW1iZXJcIjogXCJOb3ZlbWJyb1wiLFxuICAgIFwiZGVjZW1iZXJcIjogXCJEZXplbWJyb1wiXG4gIH0sXG4gIFwidGltZUFnb1wiOiB7XG4gICAgXCJkYXlzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJow6EgW2NvdW50XSBkaWFcIixcbiAgICAgIFwicGx1cmFsXCI6IFwiaMOhIFtjb3VudF0gZGlhc1wiXG4gICAgfSxcbiAgICBcImhvdXJzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJow6EgW2NvdW50XSBob3JhXCIsXG4gICAgICBcInBsdXJhbFwiOiBcImjDoSBbY291bnRdIGhvcmFzXCJcbiAgICB9LFxuICAgIFwibWludXRlc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiaMOhIFtjb3VudF0gbWludXRvXCIsXG4gICAgICBcInBsdXJhbFwiOiBcImjDoSBbY291bnRdIG1pbnV0b3NcIlxuICAgIH0sXG4gICAgXCJzZWNvbmRzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJow6EgW2NvdW50XSBzZWd1bmRvXCIsXG4gICAgICBcInBsdXJhbFwiOiBcImjDoSBbY291bnRdIHNlZ3VuZG9zXCJcbiAgICB9XG4gIH0sXG4gIFwicmV2aWV3RmlsdGVyc1wiOiB7XG4gICAgXCJieVN0YXJzMVwiOiBcIk5vc3NhcyBhdmFsaWHDp8O1ZXMgY29tIFtzdGFyMV0gZXN0cmVsYShzKVwiLFxuICAgIFwiYnlTdGFyczJcIjogXCJOb3NzYXMgYXZhbGlhw6fDtWVzIGNvbSBbc3RhcjFdICYgW3N0YXIyXSBlc3RyZWxhc1wiLFxuICAgIFwiYnlTdGFyczNcIjogXCJOb3NzYXMgYXZhbGlhw6fDtWVzIGNvbSBbc3RhcjFdLCBbc3RhcjJdICYgW3N0YXIzXSBlc3RyZWxhc1wiLFxuICAgIFwiYnlTdGFyczRcIjogXCJOb3NzYXMgYXZhbGlhw6fDtWVzIGNvbSBbc3RhcjFdLCBbc3RhcjJdLCBbc3RhcjNdICYgW3N0YXI0XSBlc3RyZWxhc1wiLFxuICAgIFwiYnlMYXRlc3RcIjogXCJNb3N0cmFuZG8gbm9zc2FzIGF2YWxpYcOnw7VlcyBtYWlzIHJlY2VudGVzXCIsXG4gICAgXCJieUZhdm9yaXRlT3JUYWdcIjogXCJNb3N0cmFuZG8gbm9zc2FzIGF2YWxpYcOnw7VlcyBmYXZvcml0YXNcIlxuICB9XG59IiwibW9kdWxlLmV4cG9ydHM9e1xuICBcInJldmlld3NcIjoge1xuICAgIFwic2luZ3VsYXJcIjogXCJvcGluacOjb1wiLFxuICAgIFwicGx1cmFsXCI6IFwib3BpbmnDtWVzXCIsXG4gICAgXCJjb2xsZWN0ZWRWaWFcIjogXCJSZWNvbGhpZGEgdmlhIFtzb3VyY2VdXCIsXG4gICAgXCJ2ZXJpZmllZFZpYVwiOiBcIlZlcmlmaWNhZGEsIHJlY29saGlkYSB2aWEgW3NvdXJjZV1cIlxuICB9LFxuICBcIm1vbnRoTmFtZXNcIjoge1xuICAgIFwiamFudWFyeVwiOiBcIkphbmVpcm9cIixcbiAgICBcImZlYnJ1YXJ5XCI6IFwiRmV2ZXJlaXJvXCIsXG4gICAgXCJtYXJjaFwiOiBcIk1hcsOnb1wiLFxuICAgIFwiYXByaWxcIjogXCJBYnJpbFwiLFxuICAgIFwibWF5XCI6IFwiTWFpb1wiLFxuICAgIFwianVuZVwiOiBcIkp1bmhvXCIsXG4gICAgXCJqdWx5XCI6IFwiSnVsaG9cIixcbiAgICBcImF1Z3VzdFwiOiBcIkFnb3N0b1wiLFxuICAgIFwic2VwdGVtYmVyXCI6IFwiU2V0ZW1icm9cIixcbiAgICBcIm9jdG9iZXJcIjogXCJPdXR1YnJvXCIsXG4gICAgXCJub3ZlbWJlclwiOiBcIk5vdmVtYnJvXCIsXG4gICAgXCJkZWNlbWJlclwiOiBcIkRlemVtYnJvXCJcbiAgfSxcbiAgXCJ0aW1lQWdvXCI6IHtcbiAgICBcImRheXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcImjDoSBbY291bnRdIGRpYVwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJow6EgW2NvdW50XSBkaWFzXCJcbiAgICB9LFxuICAgIFwiaG91cnNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcImjDoSBbY291bnRdIGhvcmFcIixcbiAgICAgIFwicGx1cmFsXCI6IFwiaMOhIFtjb3VudF0gaG9yYXNcIlxuICAgIH0sXG4gICAgXCJtaW51dGVzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJow6EgW2NvdW50XSBtaW51dG9cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiaMOhIFtjb3VudF0gbWludXRvc1wiXG4gICAgfSxcbiAgICBcInNlY29uZHNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcImjDoSBbY291bnRdIHNlZ3VuZG9cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiaMOhIFtjb3VudF0gc2VndW5kb3NcIlxuICAgIH1cbiAgfSxcbiAgXCJyZXZpZXdGaWx0ZXJzXCI6IHtcbiAgICBcImJ5U3RhcnMxXCI6IFwiQXMgbm9zc2FzIG9waW5pw7VlcyBjb20gW3N0YXIxXSBlc3RyZWxhKHMpXCIsXG4gICAgXCJieVN0YXJzMlwiOiBcIkFzIG5vc3NhcyBvcGluacO1ZXMgY29tIFtzdGFyMV0gZSBbc3RhcjJdIGVzdHJlbGFzXCIsXG4gICAgXCJieVN0YXJzM1wiOiBcIkFzIG5vc3NhcyBvcGluacO1ZXMgY29tIFtzdGFyMV0sIFtzdGFyMl0gZSBbc3RhcjNdIGVzdHJlbGFzXCIsXG4gICAgXCJieVN0YXJzNFwiOiBcIkFzIG5vc3NhcyBvcGluacO1ZXMgY29tIFtzdGFyMV0sIFtzdGFyMl0sIFtzdGFyM10gZSBbc3RhcjRdIGVzdHJlbGFzXCIsXG4gICAgXCJieUxhdGVzdFwiOiBcIkFzIG5vc3NhcyBvcGluacO1ZXMgbWFpcyByZWNlbnRlc1wiLFxuICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwiQXMgbm9zc2FzIG9waW5pw7VlcyBmYXZvcml0YXNcIlxuICB9XG59IiwibW9kdWxlLmV4cG9ydHM9e1xuICBcInJldmlld3NcIjoge1xuICAgIFwic2luZ3VsYXJcIjogXCLQvtGC0LfRi9CyXCIsXG4gICAgXCJwbHVyYWxcIjogXCLQvtGC0LfRi9Cy0L7QslwiLFxuICAgIFwiY29sbGVjdGVkVmlhXCI6IFwi0KHQvtCx0YDQsNC90L4g0YfQtdGA0LXQtyBbc291cmNlXVwiLFxuICAgIFwidmVyaWZpZWRWaWFcIjogXCLQn9C+0LTRgtCy0LXRgNC20LTQtdC90L4sINGB0L7QsdGA0LDQvdC+INGH0LXRgNC10LcgW3NvdXJjZV1cIlxuICB9LFxuICBcIm1vbnRoTmFtZXNcIjoge1xuICAgIFwiamFudWFyeVwiOiBcItGP0L3QstCw0YDRj1wiLFxuICAgIFwiZmVicnVhcnlcIjogXCLRhNC10LLRgNCw0LvRj1wiLFxuICAgIFwibWFyY2hcIjogXCLQvNCw0YDRgtCwXCIsXG4gICAgXCJhcHJpbFwiOiBcItCw0L/RgNC10LvRj1wiLFxuICAgIFwibWF5XCI6IFwi0LzQsNGPXCIsXG4gICAgXCJqdW5lXCI6IFwi0LjRjtC90Y9cIixcbiAgICBcImp1bHlcIjogXCLQmNGO0LvRjFwiLFxuICAgIFwiYXVndXN0XCI6IFwi0LDQstCz0YPRgdGC0LBcIixcbiAgICBcInNlcHRlbWJlclwiOiBcItGB0LXQvdGC0Y/QsdGA0Y9cIixcbiAgICBcIm9jdG9iZXJcIjogXCLQntC60YLRj9Cx0YDRjFwiLFxuICAgIFwibm92ZW1iZXJcIjogXCLQvdC+0Y/QsdGA0Y9cIixcbiAgICBcImRlY2VtYmVyXCI6IFwi0JTQtdC60LDQsdGA0YxcIlxuICB9LFxuICBcInRpbWVBZ29cIjoge1xuICAgIFwiZGF5c1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSDQtNC10L3RjCDQvdCw0LfQsNC0XCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0g0LTQvdC10Lkg0L3QsNC30LDQtFwiXG4gICAgfSxcbiAgICBcImhvdXJzXCI6IHtcbiAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdINGH0LDRgSDQvdCw0LfQsNC0XCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0g0YfQsNGB0L7QsiDQvdCw0LfQsNC0XCJcbiAgICB9LFxuICAgIFwibWludXRlc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSDQvNC40L3Rg9GC0YMg0L3QsNC30LDQtFwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdINC80LjQvdGD0YIg0L3QsNC30LDQtFwiXG4gICAgfSxcbiAgICBcInNlY29uZHNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0g0YHQtdC60YPQvdC00YMg0L3QsNC30LDQtFwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdINGB0LXQutGD0L3QtCDQvdCw0LfQsNC0XCJcbiAgICB9XG4gIH0sXG4gIFwicmV2aWV3RmlsdGVyc1wiOiB7XG4gICAgXCJieVN0YXJzMVwiOiBcItCd0LDRiNC4INC+0YLQt9GL0LLRiyBbc3RhcjFdINC30LLQtdC30LRcIixcbiAgICBcImJ5U3RhcnMyXCI6IFwi0J3QsNGI0Lgg0L7RgtC30YvQstGLIFtzdGFyMV0g0LggW3N0YXIyXSDQt9Cy0LXQt9C0XCIsXG4gICAgXCJieVN0YXJzM1wiOiBcItCd0LDRiNC4INC+0YLQt9GL0LLRiyBbc3RhcjFdLCBbc3RhcjJdINC4IFtzdGFyM10g0LfQstC10LfQtFwiLFxuICAgIFwiYnlTdGFyczRcIjogXCLQndCw0YjQuCDQvtGC0LfRi9Cy0YsgW3N0YXIxXSwgW3N0YXIyXSwgW3N0YXIzXSDQuCBbc3RhcjRdINC30LLQtdC30LRcIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwi0J3QsNGI0Lgg0L3QtdC00LDQstC90LjQtSDQvtGC0LfRi9Cy0YtcIixcbiAgICBcImJ5RmF2b3JpdGVPclRhZ1wiOiBcItCd0LDRiNC4INC70Y7QsdC40LzRi9C1INC+0YLQt9GL0LLRi1wiXG4gIH1cbn0iLCJtb2R1bGUuZXhwb3J0cz17XG4gIFwicmV2aWV3c1wiOiB7XG4gICAgXCJzaW5ndWxhclwiOiBcIm9tZMO2bWVcIixcbiAgICBcInBsdXJhbFwiOiBcIm9tZMO2bWVuXCIsXG4gICAgXCJjb2xsZWN0ZWRWaWFcIjogXCJJbnNhbWxhdCB2aWEgW3NvdXJjZV1cIixcbiAgICBcInZlcmlmaWVkVmlhXCI6IFwiVmVyaWZpZXJhdCDigJMgaW5zYW1sYXQgdmlhIFtzb3VyY2VdXCJcbiAgfSxcbiAgXCJtb250aE5hbWVzXCI6IHtcbiAgICBcImphbnVhcnlcIjogXCJqYW51YXJpXCIsXG4gICAgXCJmZWJydWFyeVwiOiBcImZlYnJ1YXJpXCIsXG4gICAgXCJtYXJjaFwiOiBcIm1hcnNcIixcbiAgICBcImFwcmlsXCI6IFwiYXByaWxcIixcbiAgICBcIm1heVwiOiBcIm1halwiLFxuICAgIFwianVuZVwiOiBcImp1bmlcIixcbiAgICBcImp1bHlcIjogXCJqdWxpXCIsXG4gICAgXCJhdWd1c3RcIjogXCJhdWd1c3RpXCIsXG4gICAgXCJzZXB0ZW1iZXJcIjogXCJzZXB0ZW1iZXJcIixcbiAgICBcIm9jdG9iZXJcIjogXCJva3RvYmVyXCIsXG4gICAgXCJub3ZlbWJlclwiOiBcIm5vdmVtYmVyXCIsXG4gICAgXCJkZWNlbWJlclwiOiBcImRlY2VtYmVyXCJcbiAgfSxcbiAgXCJ0aW1lQWdvXCI6IHtcbiAgICBcImRheXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gZGFnIHNlZGFuXCIsXG4gICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gZGFnYXIgc2VkYW5cIlxuICAgIH0sXG4gICAgXCJob3Vyc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSB0aW1tZSBzZWRhblwiLFxuICAgICAgXCJwbHVyYWxcIjogXCJbY291bnRdIHRpbW1hciBzZWRhblwiXG4gICAgfSxcbiAgICBcIm1pbnV0ZXNcIjoge1xuICAgICAgXCJzaW5ndWxhclwiOiBcIltjb3VudF0gbWludXQgc2VkYW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBtaW51dGVyIHNlZGFuXCJcbiAgICB9LFxuICAgIFwic2Vjb25kc1wiOiB7XG4gICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBzZWt1bmQgc2VkYW5cIixcbiAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBzZWt1bmRlciBzZWRhblwiXG4gICAgfVxuICB9LFxuICBcInJldmlld0ZpbHRlcnNcIjoge1xuICAgIFwiYnlTdGFyczFcIjogXCJWaXNhciB2w6VyYSBbc3RhcjFdLXN0asOkcm5pZ2Egb21kw7ZtZW5cIixcbiAgICBcImJ5U3RhcnMyXCI6IFwiVmlzYXIgdsOlcmEgW3N0YXIxXS0gb2NoIFtzdGFyMl0tc3Rqw6RybmlnYSBvbWTDtm1lblwiLFxuICAgIFwiYnlTdGFyczNcIjogXCJWaXNhciB2w6VyYSBbc3RhcjFdLSwgW3N0YXIyXS0gb2NoIFtzdGFyM10tc3Rqw6RybmlnYSBvbWTDtm1lblwiLFxuICAgIFwiYnlTdGFyczRcIjogXCJWaXNhciB2w6VyYSBbc3RhcjFdLSwgW3N0YXIyXS0sIFtzdGFyM10tIG9jaCBbc3RhcjRdLXN0asOkcm5pZ2Egb21kw7ZtZW5cIixcbiAgICBcImJ5TGF0ZXN0XCI6IFwiVmlzYXIgdsOlcmEgc2VuYXN0ZSBvbWTDtm1lblwiLFxuICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwiVmlzYXIgdsOlcmEgZmF2b3JpdG9tZMO2bWVuXCJcbiAgfVxufSIsIm1vZHVsZS5leHBvcnRzPXtcbiAgICBcInJldmlld3NcIjoge1xuICAgICAgICBcInNpbmd1bGFyXCI6IFwi5p2h6K+E6K66XCIsXG4gICAgICAgIFwicGx1cmFsXCI6IFwi5p2h54K56K+ELFwiXG4gICAgfSxcbiAgICBcIm1vbnRoTmFtZXNcIjoge1xuICAgICAgICBcImphbnVhcnlcIjogXCLkuIDmnIhcIixcbiAgICAgICAgXCJmZWJydWFyeVwiOiBcIuS6jOaciFwiLFxuICAgICAgICBcIm1hcmNoXCI6IFwi5LiJ5pyIXCIsXG4gICAgICAgIFwiYXByaWxcIjogXCLlm5vmnIhcIixcbiAgICAgICAgXCJtYXlcIjogXCLkupTmnIhcIixcbiAgICAgICAgXCJqdW5lXCI6IFwi5YWt5pyIXCIsXG4gICAgICAgIFwianVseVwiOiBcIuS4g+aciFwiLFxuICAgICAgICBcImF1Z3VzdFwiOiBcIuWFq+aciFwiLFxuICAgICAgICBcInNlcHRlbWJlclwiOiBcIuS5neaciFwiLFxuICAgICAgICBcIm9jdG9iZXJcIjogXCLljYHmnIhcIixcbiAgICAgICAgXCJub3ZlbWJlclwiOiBcIuWNgeS4gOaciFwiLFxuICAgICAgICBcImRlY2VtYmVyXCI6IFwi5Y2B5LqM5pyIXCJcbiAgICB9LFxuICAgIFwidGltZUFnb1wiOiB7XG4gICAgICAgIFwiZGF5c1wiOiB7XG4gICAgICAgICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBkYXkgYWdvXCIsXG4gICAgICAgICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gZGF5cyBhZ29cIlxuICAgICAgICB9LFxuICAgICAgICBcImhvdXJzXCI6IHtcbiAgICAgICAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIGhvdXIgYWdvXCIsXG4gICAgICAgICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gaG91cnMgYWdvXCJcbiAgICAgICAgfSxcbiAgICAgICAgXCJtaW51dGVzXCI6IHtcbiAgICAgICAgICAgIFwic2luZ3VsYXJcIjogXCJbY291bnRdIG1pbnV0ZSBhZ29cIixcbiAgICAgICAgICAgIFwicGx1cmFsXCI6IFwiW2NvdW50XSBtaW51dGVzIGFnb1wiXG4gICAgICAgIH0sXG4gICAgICAgIFwic2Vjb25kc1wiOiB7XG4gICAgICAgICAgICBcInNpbmd1bGFyXCI6IFwiW2NvdW50XSBzZWNvbmQgYWdvXCIsXG4gICAgICAgICAgICBcInBsdXJhbFwiOiBcIltjb3VudF0gc2Vjb25kcyBhZ29cIlxuICAgICAgICB9XG4gICAgfSxcbiAgICBcInJldmlld0ZpbHRlcnNcIjoge1xuICAgICAgICBcImJ5U3RhcnMxXCI6IFwiU2hvd2luZyBvdXIgW3N0YXIxXSBzdGFyIHJldmlld3NcIixcbiAgICAgICAgXCJieVN0YXJzMlwiOiBcIlNob3dpbmcgb3VyIFtzdGFyMV0gJiBbc3RhcjJdIHN0YXIgcmV2aWV3c1wiLFxuICAgICAgICBcImJ5U3RhcnMzXCI6IFwiU2hvd2luZyBvdXIgW3N0YXIxXSwgW3N0YXIyXSAmIFtzdGFyM10gc3RhciByZXZpZXdzXCIsXG4gICAgICAgIFwiYnlTdGFyczRcIjogXCJTaG93aW5nIG91ciBbc3RhcjFdLCBbc3RhcjJdLCBbc3RhcjNdICYgW3N0YXI0XSBzdGFyIHJldmlld3NcIixcbiAgICAgICAgXCJieUxhdGVzdFwiOiBcIlNob3dpbmcgb3VyIGxhdGVzdCByZXZpZXdzXCIsXG4gICAgICAgIFwiYnlGYXZvcml0ZU9yVGFnXCI6IFwiU2hvd2luZyBvdXIgZmF2b3JpdGUgcmV2aWV3c1wiXG4gICAgfVxufSIsImltcG9ydCBQcm9taXNlIGZyb20gJ3Byb21pc2UnO1xuaW1wb3J0IHhociBmcm9tICcuLi94aHInO1xuaW1wb3J0IHsgZ2V0QXNPYmplY3QgYXMgZ2V0UXVlcnlzdHJpbmdBc09iamVjdCB9IGZyb20gJy4uL3F1ZXJ5U3RyaW5nJztcbmltcG9ydCBnZXRXaWRnZXRSb290VXJpIGZyb20gJy4uL3Jvb3RVcmknO1xuXG4vLyBNYWtlIGEgcmFuZG9tIElEIHdoZXJlIGFuIGFwaUNhbGwgcmVxdWlyZXMgb25lLlxuY29uc3QgbWFrZUlkID0gKG51bU9mQ2hhcnMpID0+IHtcbiAgbGV0IHRleHQgPSAnJztcbiAgY29uc3QgcG9zc2libGUgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODknO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG51bU9mQ2hhcnM7IGkrKykge1xuICAgIHRleHQgKz0gcG9zc2libGUuY2hhckF0KE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIHBvc3NpYmxlLmxlbmd0aCkpO1xuICB9XG4gIHJldHVybiB0ZXh0O1xufTtcblxuLyogZXNsaW50LWRpc2FibGUgY29tcGF0L2NvbXBhdCAqL1xuY29uc3QgYXBpQ2FsbCA9ICh1cmksIHBhcmFtcykgPT5cbiAgbmV3IFByb21pc2UoKHJlc29sdmUsIGZhaWwpID0+IHtcbiAgICBsZXQgdmFsdWVzO1xuICAgIGxldCB1cmw7XG5cbiAgICBpZiAodXJpLmluZGV4T2YoJy8nKSA9PT0gMCkge1xuICAgICAgdmFsdWVzID0gcGFyYW1zIHx8IHt9O1xuICAgICAgY29uc3QgeyB0b2tlbiB9ID0gZ2V0UXVlcnlzdHJpbmdBc09iamVjdCgpO1xuICAgICAgaWYgKHRva2VuKSB7XG4gICAgICAgIHZhbHVlcy5yYW5kb20gPSBtYWtlSWQoMjApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh1cmkuaW5kZXhPZignaHR0cCcpID09PSAwKSB7XG4gICAgICAvLyBpcyBhIGZ1bGwgdXJsIGZyb20gYSBwYWdpbmcgbGluaywgZW5zdXJlIGh0dHBzXG4gICAgICB1cmwgPSB1cmkucmVwbGFjZSgvXmh0dHBzPzovLCAnaHR0cHM6Jyk7XG4gICAgfSBlbHNlIGlmICh1cmkuaW5kZXhPZignLycpID09PSAwKSB7XG4gICAgICAvLyBpcyBhIHJlZ3VsYXIgXCIvdjEvLi4uXCIgYWRkIGRvbWFpbiBmb3IgbG9jYWwgdGVzdGluZyAodmFsdWUgaXMgZW1wdHkgaW4gcHJvZClcbiAgICAgIHVybCA9IGdldFdpZGdldFJvb3RVcmkoKSArIHVyaTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gd2VpcmQvYnJva2VuIHVybFxuICAgICAgcmV0dXJuIGZhaWwoKTtcbiAgICB9XG5cbiAgICByZXR1cm4geGhyKHtcbiAgICAgIHVybCxcbiAgICAgIGRhdGE6IHZhbHVlcyxcbiAgICAgIHN1Y2Nlc3M6IHJlc29sdmUsXG4gICAgICBlcnJvcjogZmFpbCxcbiAgICB9KTtcbiAgfSk7XG5cbmV4cG9ydCB7IGFwaUNhbGwgfTtcbi8qIGVzbGludC1lbmFibGUgY29tcGF0L2NvbXBhdCAqL1xuIiwiLyogZ2xvYmFsIEFjdGl2ZVhPYmplY3QgKi9cblxuZnVuY3Rpb24gaXNJRSgpIHtcbiAgY29uc3QgbXlOYXYgPSBuYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCk7XG4gIHJldHVybiBteU5hdi5pbmRleE9mKCdtc2llJykgIT0gLTEgPyBwYXJzZUludChteU5hdi5zcGxpdCgnbXNpZScpWzFdKSA6IGZhbHNlO1xufVxuXG4vLyBhZGFwdGVkIChzdG9sZW4pIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL3RvZGRtb3R0by9hdG9taWNcblxuZnVuY3Rpb24gcGFyc2UocmVxKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UocmVxLnJlc3BvbnNlVGV4dCk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZXR1cm4gcmVxLnJlc3BvbnNlVGV4dDtcbiAgfVxufVxuXG4vLyBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8xNzE0ODk5XG5mdW5jdGlvbiB0b1F1ZXJ5U3RyaW5nKG9iaikge1xuICBjb25zdCBzdHIgPSBbXTtcbiAgZm9yIChjb25zdCBwIGluIG9iaikge1xuICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkocCkpIHtcbiAgICAgIHN0ci5wdXNoKGAke2VuY29kZVVSSUNvbXBvbmVudChwKX09JHtlbmNvZGVVUklDb21wb25lbnQob2JqW3BdKX1gKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0ci5qb2luKCcmJyk7XG59XG5cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5mdW5jdGlvbiBtYWtlUmVxdWVzdChwYXJhbXMpIHtcbiAgY29uc3QgWE1MSHR0cFJlcXVlc3QgPSB3aW5kb3cuWE1MSHR0cFJlcXVlc3QgfHwgQWN0aXZlWE9iamVjdDtcbiAgY29uc3QgcmVxdWVzdCA9IG5ldyBYTUxIdHRwUmVxdWVzdCgnTVNYTUwyLlhNTEhUVFAuMy4wJyk7XG4gIHJlcXVlc3Qub3BlbihwYXJhbXMudHlwZSwgcGFyYW1zLnVybCwgdHJ1ZSk7XG4gIHJlcXVlc3Quc2V0UmVxdWVzdEhlYWRlcignQ29udGVudC10eXBlJywgJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcpO1xuICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAocmVxdWVzdC5yZWFkeVN0YXRlID09PSA0KSB7XG4gICAgICBpZiAocmVxdWVzdC5zdGF0dXMgPj0gMjAwICYmIHJlcXVlc3Quc3RhdHVzIDwgMzAwKSB7XG4gICAgICAgIHBhcmFtcy5zdWNjZXNzKHBhcnNlKHJlcXVlc3QpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBhcmFtcy5lcnJvcihwYXJzZShyZXF1ZXN0KSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIHJlcXVlc3Quc2VuZChwYXJhbXMuZGF0YSk7XG59XG5cbi8qIElFOS1jb21wYXRpYmxlIHJlcXVlc3QgZnVuY3Rpb24uXG5cbklFOSBkb2VzIG5vdCBwZXJtaXQgY3Jvc3Mtb3JpZ2luIEhUVFAgcmVxdWVzdHMgaW4gdGhlIHVzdWFsIHdheS4gSXQgYWxzbyBkb2VzXG5ub3QgcGVybWl0IGEgcmVxdWVzdCB0byBiZSBtYWRlIHRvIGEgVVJJIHdpdGggYSBkaWZmZXJlbnQgcHJvdG9jb2wgZnJvbSB0aGF0XG5vZiB0aGUgcGFnZSwgZS5nLiBhbiBIVFRQUyByZXF1ZXN0IGZyb20gYW4gSFRUUCBwYWdlLlxuXG5UaGlzIGZ1bmN0aW9uIG1ha2VzIHJlcXVlc3RzIGluIGEgbWFubmVyIGNvbXBhdGlibGUgd2l0aCBJRTkncyBsaW1pdGF0aW9ucy5cbiovXG5mdW5jdGlvbiBtYWtlUmVxdWVzdElFKHBhcmFtcykge1xuICBjb25zdCByZXF1ZXN0ID0gbmV3IHdpbmRvdy5YRG9tYWluUmVxdWVzdCgpO1xuICBjb25zdCBwcm90b2NvbCA9IHdpbmRvdy5sb2NhdGlvbi5wcm90b2NvbDtcbiAgcGFyYW1zLnVybCA9IHBhcmFtcy51cmwucmVwbGFjZSgvaHR0cHM/Oi8sIHByb3RvY29sKTtcbiAgcmVxdWVzdC5vcGVuKHBhcmFtcy50eXBlLCBwYXJhbXMudXJsKTtcbiAgcmVxdWVzdC5vbmxvYWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgcGFyYW1zLnN1Y2Nlc3MocGFyc2UocmVxdWVzdCkpO1xuICB9O1xuICByZXF1ZXN0Lm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgcGFyYW1zLmVycm9yKHBhcnNlKHJlcXVlc3QpKTtcbiAgfTtcblxuICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICByZXF1ZXN0LnNlbmQocGFyYW1zLmRhdGEpO1xuICB9LCAwKTtcbn1cblxuZnVuY3Rpb24geGhyKG9wdGlvbnMpIHtcbiAgY29uc3QgcGFyYW1zID0ge1xuICAgIHR5cGU6IG9wdGlvbnMudHlwZSB8fCAnR0VUJyxcbiAgICBlcnJvcjogb3B0aW9ucy5lcnJvciB8fCBub29wLFxuICAgIHN1Y2Nlc3M6IG9wdGlvbnMuc3VjY2VzcyB8fCBub29wLFxuICAgIGRhdGE6IG9wdGlvbnMuZGF0YSxcbiAgICB1cmw6IG9wdGlvbnMudXJsIHx8ICcnLFxuICB9O1xuXG4gIGlmIChwYXJhbXMudHlwZSA9PT0gJ0dFVCcgJiYgcGFyYW1zLmRhdGEpIHtcbiAgICBwYXJhbXMudXJsID0gYCR7cGFyYW1zLnVybH0/JHt0b1F1ZXJ5U3RyaW5nKHBhcmFtcy5kYXRhKX1gO1xuICAgIGRlbGV0ZSBwYXJhbXMuZGF0YTtcbiAgfVxuXG4gIGlmIChpc0lFKCkgJiYgaXNJRSgpIDw9IDkpIHtcbiAgICBtYWtlUmVxdWVzdElFKHBhcmFtcyk7XG4gIH0gZWxzZSB7XG4gICAgbWFrZVJlcXVlc3QocGFyYW1zKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCB4aHI7XG4iLCIvLyBUaGlzIHdpbGwgYmUgc3Vic3RpdHV0ZWQgd2l0aGluIHRoZSBidWlsZHNjcmlwdHMsIHNvIGRvbid0IGNoYW5nZSB0aGlzIVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKCkge1xuICBjb25zdCBob3N0ID0gJyN7V2lkZ2V0QXBpLkhvc3R9JztcbiAgcmV0dXJuIGhvc3QuaW5kZXhPZignIycpID09PSAwID8gJ2h0dHBzOi8vd2lkZ2V0LnRwLXN0YWdpbmcuY29tJyA6IGhvc3Q7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9saWInKVxuIiwiaW1wb3J0IFByb21pc2UgZnJvbSAncHJvbWlzZSc7XG5pbXBvcnQgeyBhcGlDYWxsIH0gZnJvbSAnLi9jYWxsJztcbmltcG9ydCB7IGdldE9uUGFnZVJlYWR5LCBzaG93VHJ1c3RCb3ggfSBmcm9tICcuLi91dGlscyc7XG5pbXBvcnQgeyB3aXRoTG9hZGVyIH0gZnJvbSAnLi4vdGVtcGxhdGVzL2xvYWRlcic7XG5pbXBvcnQgeyBlcnJvckZhbGxiYWNrLCByZW1vdmVFcnJvckZhbGxiYWNrIH0gZnJvbSAnLi4vdGVtcGxhdGVzL2Vycm9yRmFsbGJhY2snO1xuaW1wb3J0IHsgc2V0TGlzdGVuZXIsIGlzTG9hZGVkTWVzc2FnZSwgc2VuZEFQSURhdGFNZXNzYWdlIH0gZnJvbSAnLi4vY29tbXVuaWNhdGlvbic7XG5pbXBvcnQgeyBtYXBPYmplY3QsIHByb21pc2VBbGxPYmplY3QsIHJlamVjdE51bGxhcnlWYWx1ZXMgfSBmcm9tICcuLi9mbic7XG5cbi8qKlxuICogRGVmaW5lIGEgdW5pcXVlIHNpbmdsZSBmZXRjaCBvYmplY3Qga2V5LCBhbGxvd2luZyB1cyB0byBmbGF0dGVuIGJhY2sgdG8gYVxuICogc2luZ2xlIHNldCBvZiBiYXNlIGRhdGEuIFRoaXMgaXMgYXJiaXRyYXJ5LCBhbmQgaGFzIGJlZW4gc2VsZWN0ZWQgdG8gZW5zdXJlXG4gKiBpdCB3aWxsIG5vdCBiZSBhY2NpZGVudGFsbHkgdXNlZCBpbiBhIGZldGNoUGFyYW1zT2JqZWN0LlxuICovXG5jb25zdCBzaW5nbGVGZXRjaE9iamVjdEtleSA9ICdkZWZhdWx0X3NpbmdsZUZldGNoX2Y5OGFjNzdiJztcblxuLyoqXG4gKiBGbGF0dGVuIGEgZmV0Y2hQYXJhbXNPYmplY3QgdmFsdWUgdG8gb25lIHNpbmdsZSBzZXQgb2YgZmV0Y2hQYXJhbXMsIHdoZXJlXG4gKiB0aGF0IG9iamVjdCBjb250YWlucyBvbmx5IG9uZSB2YWx1ZSwgYW5kIGl0IGlzIGluZGV4ZWQgYnlcbiAqIHNpbmdsZUZldGNoT2JqZWN0S2V5LlxuICovXG5jb25zdCBmbGF0dGVuU2luZ2xlUGFyYW1zID0gKGZldGNoUGFyYW1zT2JqZWN0KSA9PiB7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhmZXRjaFBhcmFtc09iamVjdCk7XG4gIHJldHVybiBzaW5nbGVGZXRjaE9iamVjdEtleSBpbiBmZXRjaFBhcmFtc09iamVjdCAmJiBrZXlzLmxlbmd0aCA9PT0gMVxuICAgID8gZmV0Y2hQYXJhbXNPYmplY3Rbc2luZ2xlRmV0Y2hPYmplY3RLZXldXG4gICAgOiBmZXRjaFBhcmFtc09iamVjdDtcbn07XG5cbi8qKlxuICogQ2hlY2sgaWYgYnVzaW5lc3MgaGFzIHNlcnZpY2UgcmV2aWV3c1xuICovXG5jb25zdCBoYXNTZXJ2aWNlUmV2aWV3cyA9ICh7XG4gIGJ1c2luZXNzRW50aXR5OiB7XG4gICAgbnVtYmVyT2ZSZXZpZXdzOiB7IHRvdGFsIH0sXG4gIH0sXG59KSA9PiB0b3RhbCA+IDA7XG5cbi8qKlxuICogQ2hlY2sgaWYgYSBidXNpbmVzcyBoYXMgc2VydmljZSByZXZpZXdzIHVzaW5nIG11bHRpLWZldGNoLlxuICpcbiAqIFRoaXMgY2hlY2tzIHRoYXQgYW55IG9mIHRoZSBiYXNlIGRhdGEgc2V0cyBoYXMgc2VydmljZSByZXZpZXdzIHByZXNlbnRcbiAqIHdpdGhpbiBpdC5cbiAqL1xuY29uc3QgaGFzU2VydmljZVJldmlld3NNdWx0aUZldGNoID0gKGJhc2VEYXRhKSA9PiB7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhiYXNlRGF0YSk7XG4gIHJldHVybiBrZXlzLnNvbWUoKGspID0+IGhhc1NlcnZpY2VSZXZpZXdzKGJhc2VEYXRhW2tdKSk7XG59O1xuXG4vKipcbiAqIENoZWNrIGlmIGJ1c2luZXNzIGhhcyBpbXBvcnRlZCBvciByZWd1bGFyIHByb2R1Y3QgcmV2aWV3c1xuICovXG5jb25zdCBoYXNQcm9kdWN0UmV2aWV3cyA9ICh7IHByb2R1Y3RSZXZpZXdzU3VtbWFyeSwgaW1wb3J0ZWRQcm9kdWN0UmV2aWV3c1N1bW1hcnkgfSkgPT4ge1xuICBjb25zdCB0b3RhbFByb2R1Y3RSZXZpZXdzID0gcHJvZHVjdFJldmlld3NTdW1tYXJ5XG4gICAgPyBwcm9kdWN0UmV2aWV3c1N1bW1hcnkubnVtYmVyT2ZSZXZpZXdzLnRvdGFsXG4gICAgOiAwO1xuICBjb25zdCB0b3RhbEltcG9ydGVkUHJvZHVjdFJldmlld3MgPSBpbXBvcnRlZFByb2R1Y3RSZXZpZXdzU3VtbWFyeVxuICAgID8gaW1wb3J0ZWRQcm9kdWN0UmV2aWV3c1N1bW1hcnkubnVtYmVyT2ZSZXZpZXdzLnRvdGFsXG4gICAgOiAwO1xuXG4gIHJldHVybiB0b3RhbFByb2R1Y3RSZXZpZXdzICsgdG90YWxJbXBvcnRlZFByb2R1Y3RSZXZpZXdzID4gMDtcbn07XG5cbi8vIENvbnN0cnVjdCBhIGJhc2UgZGF0YSBjYWxsIHByb21pc2UuXG5jb25zdCBiYXNlRGF0YUNhbGwgPSAodXJpKSA9PiAoeyBidXNpbmVzc1VuaXRJZCwgbG9jYWxlLCAuLi5vcHRzIH0pID0+IHtcbiAgY29uc3QgYmFzZURhdGFQYXJhbXMgPSByZWplY3ROdWxsYXJ5VmFsdWVzKHtcbiAgICBidXNpbmVzc1VuaXRJZCxcbiAgICBsb2NhbGUsXG4gICAgLi4ub3B0cyxcbiAgICB0aGVtZTogbnVsbCwgLy8gRm9yY2UgcmVqZWN0aW9uIG9mIHRoZSB0aGVtZSBwYXJhbVxuICB9KTtcbiAgcmV0dXJuIGFwaUNhbGwodXJpLCBiYXNlRGF0YVBhcmFtcyk7XG59O1xuXG4vKipcbiAqIENhbGwgYSBjb25zdHJ1Y3RUcnVzdEJveCBjYWxsYmFjaywgYW5kIHRoZW4gY29tcGxldGUgdGhlIGxvYWRpbmcgcHJvY2Vzc1xuICogZm9yIHRoZSBUcnVzdEJveC5cbiAqL1xuY29uc3QgY29uc3RydWN0VHJ1c3RCb3hBbmRDb21wbGV0ZSA9IChcbiAgY29uc3RydWN0VHJ1c3RCb3gsXG4gIHBhc3NUb1BvcHVwID0gZmFsc2UsXG4gIGhhc1Jldmlld3NGcm9tQmFzZURhdGEgPSBoYXNTZXJ2aWNlUmV2aWV3c1xuKSA9PiAoeyBiYXNlRGF0YSwgbG9jYWxlLCB0aGVtZSwgaGFzTW9yZVJldmlld3MsIGxvYWRNb3JlUmV2aWV3cyB9KSA9PiB7XG4gIGNvbnN0IGhhc1Jldmlld3MgPSBoYXNSZXZpZXdzRnJvbUJhc2VEYXRhKGJhc2VEYXRhKTtcblxuICBjb25zdHJ1Y3RUcnVzdEJveCh7XG4gICAgYmFzZURhdGEsXG4gICAgbG9jYWxlLFxuICAgIGhhc01vcmVSZXZpZXdzLFxuICAgIGxvYWRNb3JlUmV2aWV3cyxcbiAgfSk7XG5cbiAgLy8gQ29uZGl0aW9uYWxseSBzZW5kIHRvIHBvcHVwXG4gIGNvbnN0IHNlbmRPblBvcHVwTG9hZCA9ICh7IGRhdGE6IGV2ZW50IH0pID0+IHtcbiAgICBpZiAoaXNMb2FkZWRNZXNzYWdlKGV2ZW50KSkge1xuICAgICAgc2VuZEFQSURhdGFNZXNzYWdlKHtcbiAgICAgICAgYmFzZURhdGEsXG4gICAgICAgIGxvY2FsZSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbiAgaWYgKHBhc3NUb1BvcHVwKSB7XG4gICAgc2V0TGlzdGVuZXIoc2VuZE9uUG9wdXBMb2FkKTtcbiAgfVxuXG4gIHNob3dUcnVzdEJveCh0aGVtZSwgaGFzUmV2aWV3cyk7XG4gIHJlbW92ZUVycm9yRmFsbGJhY2soKTtcbn07XG5cbi8qKlxuICogRmV0Y2ggZGF0YSBmcm9tIHRoZSBkYXRhIEFQSSwgbWFraW5nIHplcm8gb3IgbW9yZSByZXF1ZXN0cy5cbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIGFjY2VwdHMgYW4gb2JqZWN0IHdpdGggYXJiaXRyYXJ5IGtleXMsIGFuZCB2YWx1ZXMgd2hpY2ggYXJlXG4gKiBlYWNoIGFuIG9iamVjdCBjb250YWluaW5nIHF1ZXJ5IHBhcmFtcyBmb3Igb25lIHJlcXVlc3QuIEEgcmVxdWVzdCBpcyBtYWRlXG4gKiBmb3IgZWFjaCBxdWVyeSBwYXJhbSBvYmplY3QsIGFuZCB0aGUgcmVzdWx0IGlzIHdyYXBwZWQgd2l0aGluIGFuIG9iamVjdFxuICogaW5kZXhlZCBieSB0aGUga2V5cyBvZiB0aGUgb3JpZ2luYWwgYXJndW1lbnQgb2JqZWN0LlxuICpcbiAqIFRoZXNlIGRhdGEsIHRvZ2V0aGVyIHdpdGggbG9jYWxlIGRhdGEsIGFyZSBwYXNzZWQgdG8gdGhlXG4gKiBjb25zdHJ1Y3RUcnVzdEJveCBjYWxsYmFjay5cbiAqXG4gKiBBbiBvcHRpb25hbCBhcmd1bWVudCwgcGFzc1RvUG9wdXAsIGNhbiBiZSBwcm92aWRlZCB0byB0aGlzIGZ1bmN0aW9uLiBJZiBzZXRcbiAqIHRvIGEgdHJ1dGh5IHZhbHVlLCB0aGlzIGZ1bmN0aW9uIHdpbGwgYXR0ZW1wdCB0byBwYXNzIHRoZSBkYXRhIG9idGFpbmVkIHRvXG4gKiBhbnkgcG9wdXAgaWZyYW1lLlxuICovXG5jb25zdCBtdWx0aUZldGNoRGF0YSA9ICh1cmkpID0+IChcbiAgZmV0Y2hQYXJhbXNPYmplY3QsXG4gIGNvbnN0cnVjdFRydXN0Qm94LFxuICBwYXNzVG9Qb3B1cCxcbiAgaGFzUmV2aWV3c0Zyb21CYXNlRGF0YVxuKSA9PiB7XG4gIGNvbnN0IGZpcnN0RmV0Y2hQYXJhbXMgPSBmZXRjaFBhcmFtc09iamVjdFtPYmplY3Qua2V5cyhmZXRjaFBhcmFtc09iamVjdClbMF1dO1xuICBjb25zdCB7IGxvY2FsZSwgdGhlbWUgPSAnbGlnaHQnIH0gPSBmaXJzdEZldGNoUGFyYW1zO1xuXG4gIGNvbnN0IGJhc2VEYXRhUHJvbWlzZXMgPSBwcm9taXNlQWxsT2JqZWN0KG1hcE9iamVjdChiYXNlRGF0YUNhbGwodXJpKSwgZmV0Y2hQYXJhbXNPYmplY3QpKTtcbiAgY29uc3QgcmVhZHlQcm9taXNlID0gZ2V0T25QYWdlUmVhZHkoKTtcblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29tcGF0L2NvbXBhdFxuICBjb25zdCBmZXRjaFByb21pc2UgPSBQcm9taXNlLmFsbChbYmFzZURhdGFQcm9taXNlcywgcmVhZHlQcm9taXNlXSlcbiAgICAudGhlbigoW29yaWdpbmFsQmFzZURhdGFdKSA9PiB7XG4gICAgICBjb25zdCBiYXNlRGF0YSA9IGZsYXR0ZW5TaW5nbGVQYXJhbXMob3JpZ2luYWxCYXNlRGF0YSk7XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGJhc2VEYXRhLFxuICAgICAgICBsb2NhbGUsXG4gICAgICAgIHRoZW1lLFxuICAgICAgfTtcbiAgICB9KVxuICAgIC50aGVuKGNvbnN0cnVjdFRydXN0Qm94QW5kQ29tcGxldGUoY29uc3RydWN0VHJ1c3RCb3gsIHBhc3NUb1BvcHVwLCBoYXNSZXZpZXdzRnJvbUJhc2VEYXRhKSlcbiAgICAuY2F0Y2goKGUpID0+IHtcbiAgICAgIGlmIChlICYmIGUuRmFsbGJhY2tMb2dvKSB7XG4gICAgICAgIC8vIHJlbmRlciBmYWxsYmFjayBvbmx5IGlmIGFsbG93ZWQsIGJhc2VkIG9uIHRoZSByZXNwb25zZVxuICAgICAgICByZXR1cm4gZXJyb3JGYWxsYmFjaygpO1xuICAgICAgfVxuICAgICAgLy8gZG8gbm90aGluZ1xuICAgIH0pO1xuXG4gIHdpdGhMb2FkZXIoZmV0Y2hQcm9taXNlKTtcbn07XG5cbi8vIEZldGNoIGFuZCBzdHJ1Y3R1cmUgQVBJIGRhdGEuXG5jb25zdCBmZXRjaERhdGEgPSAodXJpKSA9PiAoXG4gIGZldGNoUGFyYW1zLFxuICBjb25zdHJ1Y3RUcnVzdEJveCxcbiAgcGFzc1RvUG9wdXAsXG4gIGhhc1Jldmlld3NGcm9tQmFzZURhdGFcbikgPT4ge1xuICBjb25zdCBmZXRjaFBhcmFtc09iamVjdCA9IHsgW3NpbmdsZUZldGNoT2JqZWN0S2V5XTogZmV0Y2hQYXJhbXMgfTtcbiAgbXVsdGlGZXRjaERhdGEodXJpKShmZXRjaFBhcmFtc09iamVjdCwgY29uc3RydWN0VHJ1c3RCb3gsIHBhc3NUb1BvcHVwLCBoYXNSZXZpZXdzRnJvbUJhc2VEYXRhKTtcbn07XG5cbmV4cG9ydCB7XG4gIGZldGNoRGF0YSxcbiAgbXVsdGlGZXRjaERhdGEsXG4gIGNvbnN0cnVjdFRydXN0Qm94QW5kQ29tcGxldGUsXG4gIGhhc1NlcnZpY2VSZXZpZXdzLFxuICBoYXNTZXJ2aWNlUmV2aWV3c011bHRpRmV0Y2gsXG4gIGhhc1Byb2R1Y3RSZXZpZXdzLFxufTtcbiIsImltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tICcuL3V0aWxzLmpzJztcblxuY29uc3Qgd3BhcmVudCA9IHdpbmRvdy5wYXJlbnQ7XG5jb25zdCBtZXNzYWdlUXVldWUgPSBbXTtcbmNvbnN0IGRlZmF1bHRPcHRpb25zID0ge1xuICBjb21tYW5kOiAnY3JlYXRlSUZyYW1lJyxcbiAgcG9zaXRpb246ICdjZW50ZXIgdG9wJyxcbiAgc2hvdzogZmFsc2UsXG4gIHNvdXJjZTogJ3BvcHVwLmh0bWwnLFxuICBxdWVyeVN0cmluZzogJycsXG59O1xuY29uc3QgcG9wdXBPcHRpb25zID0ge1xuICBuYW1lOiAncG9wdXAnLFxuICBtb2RhbDogZmFsc2UsXG4gIHN0eWxlczoge1xuICAgIGhlaWdodDogJzMwMHB4JyxcbiAgICB3aWR0aDogJycsXG4gIH0sXG59O1xuY29uc3QgbW9kYWxPcHRpb25zID0ge1xuICBuYW1lOiAnbW9kYWwnLFxuICBtb2RhbDogdHJ1ZSxcbiAgc3R5bGVzOiB7XG4gICAgd2lkdGg6ICcxMDAlJyxcbiAgICBoZWlnaHQ6ICcxMDAlJyxcbiAgICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgICBsZWZ0OiAnMCcsXG4gICAgcmlnaHQ6ICcwJyxcbiAgICB0b3A6ICcwJyxcbiAgICBib3R0b206ICcwJyxcbiAgICBtYXJnaW46ICcwIGF1dG8nLFxuICAgIHppbmRleDogOTksXG4gIH0sXG59O1xuXG5sZXQgaWQgPSBudWxsO1xuY29uc3QgbGlzdGVuZXJDYWxsYmFja3MgPSBbXTtcblxuZnVuY3Rpb24gc2VuZE1lc3NhZ2UobWVzc2FnZSkge1xuICBpZiAoaWQpIHtcbiAgICBtZXNzYWdlLndpZGdldElkID0gaWQ7XG4gICAgbWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KG1lc3NhZ2UpOyAvLyBUaGlzIGlzIHRvIG1ha2UgaXQgSUU4IGNvbXBhdGlibGVcbiAgICB3cGFyZW50LnBvc3RNZXNzYWdlKG1lc3NhZ2UsICcqJyk7XG4gIH0gZWxzZSB7XG4gICAgbWVzc2FnZVF1ZXVlLnB1c2gobWVzc2FnZSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc2VuZE1lc3NhZ2VUbyh0YXJnZXQpIHtcbiAgcmV0dXJuIChtZXNzYWdlLCBwYXlsb2FkID0ge30pID0+XG4gICAgc2VuZE1lc3NhZ2Uoe1xuICAgICAgLi4ucGF5bG9hZCxcbiAgICAgIG1lc3NhZ2UsXG4gICAgICBjb21tYW5kOiAnbWVzc2FnZScsXG4gICAgICBuYW1lOiB0YXJnZXQsXG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIHNlbmRRdWV1ZSgpIHtcbiAgd2hpbGUgKG1lc3NhZ2VRdWV1ZS5sZW5ndGgpIHtcbiAgICBzZW5kTWVzc2FnZShtZXNzYWdlUXVldWUucG9wKCkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVBvcHVwSWZyYW1lKG9wdGlvbnMpIHtcbiAgc2VuZE1lc3NhZ2Uoe1xuICAgIC4uLmRlZmF1bHRPcHRpb25zLFxuICAgIC4uLnBvcHVwT3B0aW9ucyxcbiAgICAuLi5vcHRpb25zLFxuICB9KTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlTW9kYWxJZnJhbWUob3B0aW9ucykge1xuICBzZW5kTWVzc2FnZSh7XG4gICAgLi4uZGVmYXVsdE9wdGlvbnMsXG4gICAgLi4ubW9kYWxPcHRpb25zLFxuICAgIC4uLm9wdGlvbnMsXG4gIH0pO1xufVxuXG5mdW5jdGlvbiBzZXRTdHlsZXMoc3R5bGVzLCBvcHRpb25hbElmcmFtZU5hbWUpIHtcbiAgc2VuZE1lc3NhZ2UoeyBjb21tYW5kOiAnc2V0U3R5bGUnLCBuYW1lOiBvcHRpb25hbElmcmFtZU5hbWUsIHN0eWxlOiBzdHlsZXMgfSk7XG59XG5cbmZ1bmN0aW9uIHNob3dJZnJhbWUoaWZyYW1lTmFtZSkge1xuICBzZW5kTWVzc2FnZSh7IGNvbW1hbmQ6ICdzaG93JywgbmFtZTogaWZyYW1lTmFtZSB9KTtcbiAgc2VuZE1lc3NhZ2VUbygnbWFpbicpKGAke2lmcmFtZU5hbWV9IHRvZ2dsZWRgLCB7IHZpc2libGU6IHRydWUgfSk7XG59XG5cbmZ1bmN0aW9uIGhpZGVJZnJhbWUoaWZyYW1lTmFtZSkge1xuICBzZW5kTWVzc2FnZSh7IGNvbW1hbmQ6ICdoaWRlJywgbmFtZTogaWZyYW1lTmFtZSB9KTtcbiAgc2VuZE1lc3NhZ2VUbygnbWFpbicpKGAke2lmcmFtZU5hbWV9IHRvZ2dsZWRgLCB7IHZpc2libGU6IGZhbHNlIH0pO1xufVxuXG5mdW5jdGlvbiBmb2N1c0lmcmFtZShpZnJhbWVOYW1lKSB7XG4gIHNlbmRNZXNzYWdlKHsgY29tbWFuZDogJ2ZvY3VzJywgbmFtZTogaWZyYW1lTmFtZSB9KTtcbn1cblxuZnVuY3Rpb24gc2VuZExvYWRlZE1lc3NhZ2UoKSB7XG4gIHNlbmRNZXNzYWdlKHsgY29tbWFuZDogJ2xvYWRlZCcgfSk7XG59XG5cbmZ1bmN0aW9uIGlzTG9hZGVkTWVzc2FnZShtZXNzYWdlKSB7XG4gIHJldHVybiBtZXNzYWdlID09PSAnbG9hZGVkJztcbn1cblxuLyoqXG4gKiBTZW5kIGRhdGEgb2J0YWluZWQgZnJvbSBhbiBBUEkgY2FsbCB0byBhIHBvcHVwIGlmcmFtZS5cbiAqL1xuZnVuY3Rpb24gc2VuZEFQSURhdGFNZXNzYWdlKGRhdGEpIHtcbiAgc2VuZE1lc3NhZ2VUbygncG9wdXAnKSgnQVBJIGRhdGEnLCBkYXRhKTtcbn1cblxuLyoqXG4gKiBUZXN0IGlmIHR3byBtZXNzYWdlcyBhcmUgb2YgdGhlIHNhbWUgdHlwZS5cbiAqXG4gKiBJZ25vcmVzIGFueSBhZGRpdGlvbmFsIGRhdGEgY29udGFpbmVkIHdpdGhpbiB0aGUgbWVzc2FnZS5cbiAqL1xuZnVuY3Rpb24gYXJlTWF0Y2hpbmdNZXNzYWdlcyhtZXNzYWdlLCBvdGhlck1lc3NhZ2UpIHtcbiAgcmV0dXJuIFsnbWVzc2FnZScsICdjb21tYW5kJywgJ25hbWUnXS5ldmVyeShcbiAgICAoa2V5KSA9PiBtZXNzYWdlW2tleV0gJiYgb3RoZXJNZXNzYWdlW2tleV0gJiYgbWVzc2FnZVtrZXldID09PSBvdGhlck1lc3NhZ2Vba2V5XVxuICApO1xufVxuXG5mdW5jdGlvbiBpc0FQSURhdGFNZXNzYWdlKG1lc3NhZ2UpIHtcbiAgcmV0dXJuIGFyZU1hdGNoaW5nTWVzc2FnZXMobWVzc2FnZSwge1xuICAgIGNvbW1hbmQ6ICdtZXNzYWdlJyxcbiAgICBuYW1lOiAncG9wdXAnLFxuICAgIG1lc3NhZ2U6ICdBUEkgZGF0YScsXG4gIH0pO1xufVxuXG5mdW5jdGlvbiBpc1BvcHVwVG9nZ2xlTWVzc2FnZShtZXNzYWdlKSB7XG4gIHJldHVybiBhcmVNYXRjaGluZ01lc3NhZ2VzKG1lc3NhZ2UsIHtcbiAgICBjb21tYW5kOiAnbWVzc2FnZScsXG4gICAgbmFtZTogJ21haW4nLFxuICAgIG1lc3NhZ2U6ICdwb3B1cCB0b2dnbGVkJyxcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGFkZENhbGxiYWNrRnVuY3Rpb24oZnVuYykge1xuICBsaXN0ZW5lckNhbGxiYWNrcy5wdXNoKGZ1bmMpO1xufVxuXG5mdW5jdGlvbiBoaWRlTWFpbklmcmFtZSgpIHtcbiAgaGlkZUlmcmFtZSgnbWFpbicpO1xufVxuXG5mdW5jdGlvbiBzaG93UG9wdXBJZnJhbWUoKSB7XG4gIHNob3dJZnJhbWUoJ3BvcHVwJyk7XG59XG5cbmZ1bmN0aW9uIGhpZGVQb3B1cElmcmFtZSgpIHtcbiAgaGlkZUlmcmFtZSgncG9wdXAnKTtcbn1cblxuZnVuY3Rpb24gZm9jdXNQb3B1cElmcmFtZSgpIHtcbiAgZm9jdXNJZnJhbWUoJ3BvcHVwJyk7XG59XG5cbmZ1bmN0aW9uIHNob3dNb2RhbElmcmFtZSgpIHtcbiAgc2hvd0lmcmFtZSgnbW9kYWwnKTtcbn1cblxuZnVuY3Rpb24gaGlkZU1vZGFsSWZyYW1lKCkge1xuICBoaWRlSWZyYW1lKCdtb2RhbCcpO1xufVxuXG5mdW5jdGlvbiBmb2N1c01vZGFsSWZyYW1lKCkge1xuICBmb2N1c0lmcmFtZSgnbW9kYWwnKTtcbn1cblxuY29uc3Qgc2VuZFBpbmcgPSAoKSA9PiBzZW5kTWVzc2FnZSh7IGNvbW1hbmQ6ICdwaW5nJyB9KTtcblxuY29uc3Qgb25Qb25nID0gKGNiKSA9PiB7XG4gIGNvbnN0IHBvbmcgPSAoZXZlbnQpID0+IHtcbiAgICBpZiAoZXZlbnQuZGF0YS5jb21tYW5kID09PSAncG9uZycpIHtcbiAgICAgIGNiKGV2ZW50KTtcbiAgICB9XG4gIH07XG4gIGFkZENhbGxiYWNrRnVuY3Rpb24ocG9uZyk7XG59O1xuXG5mdW5jdGlvbiByZXNpemVIZWlnaHQob3B0aW9uYWxIZWlnaHQsIG9wdGlvbmFsSWZyYW1lTmFtZSkge1xuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2JvZHknKVswXTtcbiAgc2VuZE1lc3NhZ2Uoe1xuICAgIGNvbW1hbmQ6ICdyZXNpemUtaGVpZ2h0JyxcbiAgICBuYW1lOiBvcHRpb25hbElmcmFtZU5hbWUsXG4gICAgaGVpZ2h0OiBvcHRpb25hbEhlaWdodCB8fCBib2R5Lm9mZnNldEhlaWdodCxcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHNjcm9sbFRvVHJ1c3RCb3godGFyZ2V0cykge1xuICBzZW5kTWVzc2FnZSh7XG4gICAgY29tbWFuZDogJ3Njcm9sbFRvJyxcbiAgICB0YXJnZXRzLFxuICB9KTtcbn1cblxuYWRkRXZlbnRMaXN0ZW5lcih3aW5kb3csICdtZXNzYWdlJywgZnVuY3Rpb24oZXZlbnQpIHtcbiAgaWYgKHR5cGVvZiBldmVudC5kYXRhICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGxldCBlO1xuICB0cnkge1xuICAgIGUgPSB7IGRhdGE6IEpTT04ucGFyc2UoZXZlbnQuZGF0YSkgfTsgLy8gVGhpcyBpcyB0byBtYWtlIGl0IElFOCBjb21wYXRpYmxlXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZXR1cm47IC8vIHByb2JhYmx5IG5vdCBmb3IgdXNcbiAgfVxuXG4gIGlmIChlLmRhdGEuY29tbWFuZCA9PT0gJ3NldElkJykge1xuICAgIGlkID0gZS5kYXRhLndpZGdldElkO1xuICAgIHNlbmRRdWV1ZSgpO1xuICB9IGVsc2Uge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGlzdGVuZXJDYWxsYmFja3MubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGNhbGxiYWNrID0gbGlzdGVuZXJDYWxsYmFja3NbaV07XG4gICAgICBjYWxsYmFjayhlKTtcbiAgICB9XG4gIH1cbn0pO1xuXG5leHBvcnQge1xuICBzZW5kTWVzc2FnZSBhcyBzZW5kLFxuICBjcmVhdGVQb3B1cElmcmFtZSBhcyBjcmVhdGVQb3B1cCxcbiAgY3JlYXRlTW9kYWxJZnJhbWUgYXMgY3JlYXRlTW9kYWwsXG4gIGhpZGVNYWluSWZyYW1lIGFzIGhpZGVUcnVzdEJveCxcbiAgc2hvd1BvcHVwSWZyYW1lIGFzIHNob3dQb3B1cCxcbiAgaGlkZVBvcHVwSWZyYW1lIGFzIGhpZGVQb3B1cCxcbiAgZm9jdXNQb3B1cElmcmFtZSBhcyBmb2N1c1BvcHVwLFxuICBzaG93TW9kYWxJZnJhbWUgYXMgc2hvd01vZGFsLFxuICBoaWRlTW9kYWxJZnJhbWUgYXMgaGlkZU1vZGFsLFxuICBmb2N1c01vZGFsSWZyYW1lIGFzIGZvY3VzTW9kYWwsXG4gIHNlbmRMb2FkZWRNZXNzYWdlIGFzIGxvYWRlZCxcbiAgc2V0U3R5bGVzLFxuICByZXNpemVIZWlnaHQsXG4gIGFkZENhbGxiYWNrRnVuY3Rpb24gYXMgc2V0TGlzdGVuZXIsXG4gIGlzTG9hZGVkTWVzc2FnZSxcbiAgc2VuZEFQSURhdGFNZXNzYWdlLFxuICBpc0FQSURhdGFNZXNzYWdlLFxuICBpc1BvcHVwVG9nZ2xlTWVzc2FnZSxcbiAgc2VuZFBpbmcgYXMgcGluZyxcbiAgb25Qb25nLFxuICBzY3JvbGxUb1RydXN0Qm94LFxufTtcbiIsImltcG9ydCBQcm9taXNlIGZyb20gJ3Byb21pc2UnO1xuXG4vLyBDb252ZXJ0IHJlZHVjZSBtZXRob2QgaW50byBhIGZ1bmN0aW9uXG5jb25zdCByZWR1Y2UgPSAoZikgPT4gKGluaXQpID0+ICh4cykgPT4geHMucmVkdWNlKGYsIGluaXQpO1xuXG4vLyBDb252ZXJ0IGZpbHRlciBtZXRob2QgaW50byBhIGZ1bmN0aW9uXG5jb25zdCBmaWx0ZXIgPSAocCkgPT4gKHhzKSA9PiB4cy5maWx0ZXIocCk7XG5cbi8vIENvbnZlcnQgbWFwIG1ldGhvZCBpbnRvIGEgZnVuY3Rpb25cbmNvbnN0IG1hcCA9IChmKSA9PiAoeHMpID0+IHhzLm1hcChmKTtcblxuLy8gSW1wbGVtZW50YXRpb24gb2YgbWFwLCBidXQgZm9yIGFuIG9iamVjdC4gVmFsdWVzIGFyZSByZXBsYWNlZCB3aXRoIHRoZSByZXN1bHRcbi8vIG9mIGNhbGxpbmcgdGhlIHBhc3NlZCBmdW5jdGlvbiBvZiB0aGVtOyBrZXlzIHJlbWFpbiB1bmNoYW5nZWQuXG5jb25zdCBtYXBPYmplY3QgPSAoZiwgb2JqKSA9PiBPYmplY3Qua2V5cyhvYmopLnJlZHVjZSgoYWxsLCBrKSA9PiAoeyAuLi5hbGwsIFtrXTogZihvYmpba10pIH0pLCB7fSk7XG5cbi8vIFRyYW5zZm9ybXMgYW4gb2JqZWN0IGNvbnRhaW5pbmcgYXJiaXRyYXJ5IGtleXMsIGFuZCBwcm9taXNlIHZhbHVlcywgaW50byBhXG4vLyBwcm9taXNlLXdyYXBwZWQgb2JqZWN0LCB3aXRoIHRoZSBzYW1lIGtleXMgYW5kIHRoZSByZXN1bHQgb2YgcmVzb2x2aW5nIGVhY2hcbi8vIHByb21pc2UgYXMgdmFsdWVzLlxuY29uc3QgcHJvbWlzZUFsbE9iamVjdCA9IChvYmopID0+IHtcbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG9iaik7XG4gIGNvbnN0IHZhbHVlcyA9IGtleXMubWFwKChrKSA9PiBvYmpba10pO1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29tcGF0L2NvbXBhdFxuICByZXR1cm4gUHJvbWlzZS5hbGwodmFsdWVzKS50aGVuKChwcm9taXNlcykgPT5cbiAgICBwcm9taXNlcy5yZWR1Y2UoKGFsbCwgcHJvbWlzZSwgaWR4KSA9PiAoeyAuLi5hbGwsIFtrZXlzW2lkeF1dOiBwcm9taXNlIH0pLCB7fSlcbiAgKTtcbn07XG5cbi8qKlxuICogQ29udmVydCBhbiBhcnJheSBjb250YWluaW5nIHBhaXJzIG9mIHZhbHVlcyBpbnRvIGFuIG9iamVjdC5cbiAqXG4gKiAgIFtbazEsIHYxXSwgW2syLCB2Ml0sIC4uLiBdIC0+IHsgW2sxXTogdjEsIFtrMl06IHYyLCAuLi4gfVxuICovXG5jb25zdCBwYWlyc1RvT2JqZWN0ID0gKHBhaXJzKSA9PiBwYWlycy5yZWR1Y2UoKG9iaiwgW2ssIHZdKSA9PiAoeyAuLi5vYmosIFtrXTogdiB9KSwge30pO1xuXG5jb25zdCBpc051bGxhcnkgPSAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdmFsdWUgPT09IG51bGw7XG5cbmNvbnN0IGlzTnVsbGFyeU9yRmFsc2UgPSAodmFsdWUpID0+IGlzTnVsbGFyeSh2YWx1ZSkgfHwgdmFsdWUgPT09IGZhbHNlO1xuXG4vLyBGaWx0ZXIgb3V0IGFsbCBudWxsIG9yIHVuZGVmaW5lZCB2YWx1ZXMgZnJvbSBhbiBvYmplY3QuXG5jb25zdCByZWplY3ROdWxsYXJ5VmFsdWVzID0gKG9iaikgPT4ge1xuICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5yZWR1Y2UoXG4gICAgKG5ld09iaiwga2V5KSA9PiAoe1xuICAgICAgLi4ubmV3T2JqLFxuICAgICAgLi4uKGlzTnVsbGFyeShvYmpba2V5XSkgPyB7fSA6IHsgW2tleV06IG9ialtrZXldIH0pLFxuICAgIH0pLFxuICAgIHt9XG4gICk7XG59O1xuXG4vKipcbiAqIFNwbGl0IGFuIGFycmF5IG9mIHZhbHVlcyBpbnRvIGNodW5rcyBvZiBhIGdpdmVuIHNpemUuXG4gKlxuICogSWYgdGhlIG51bWJlciBvZiB2YWx1ZXMgZG9lcyBub3QgZGl2aWRlIGV2ZW5seSBpbnRvIHRoZSBjaHVuayBzaXplLCB0aGVcbiAqIGZpbmFsIGNodW5rIHdpbGwgYmUgc21hbGxlciB0aGFuIGNodW5rU2l6ZS5cbiAqXG4gKiAgIGNodW5rIDIgW2EsIGIsIGMsIGQsIGUsIGYsIGddIC0+IFtbYSwgYl0sIFtjLCBkXSwgW2UsIGZdLCBbZ11dXG4gKi9cbmNvbnN0IGNodW5rID0gKGNodW5rU2l6ZSkgPT5cbiAgcmVkdWNlKChjaHVua3MsIHZhbCwgaWR4KSA9PiB7XG4gICAgY29uc3QgbGFzdENodW5rID0gY2h1bmtzW2NodW5rcy5sZW5ndGggLSAxXTtcbiAgICBjb25zdCBpc05ld0NodW5rID0gaWR4ICUgY2h1bmtTaXplID09PSAwO1xuICAgIGNvbnN0IG5ld0NodW5rID0gaXNOZXdDaHVuayA/IFt2YWxdIDogWy4uLmxhc3RDaHVuaywgdmFsXTtcbiAgICByZXR1cm4gWy4uLmNodW5rcy5zbGljZSgwLCBjaHVua3MubGVuZ3RoIC0gKGlzTmV3Q2h1bmsgPyAwIDogMSkpLCBuZXdDaHVua107XG4gIH0pKFtdKTtcblxuLyoqXG4gKiBTcGxpdCBhbiBhcnJheSBvZiB2YWx1ZXMgaW50byBjaHVua3Mgb2YgYSBnaXZlbiBzaXplLCBhbmQgdGhlbiB0cmFuc3Bvc2UgdmFsdWVzLlxuICpcbiAqIFRoaXMgaXMgZXF1aXZhbGVudCB0byB7QGxpbmsgJ2NodW5rJ30sIGJ1dCB3aXRoIHRoZSB2YWx1ZXMgdHJhbnNwb3NlZDpcbiAqXG4gKiAgIGNodW5rVHJhbnNwb3NlIDIgW2EsIGIsIGMsIGQsIGUsIGYsIGddIC0+IFtbYSwgYywgZSwgZ10sIFtiLCBkLCBmXV1cbiAqXG4gKiBUaGUgdHJhbnNwb3NpdGlvbiBoYXMgdGhlIGVmZmVjdCBvZiB0dXJuaW5nIGFuIGFycmF5IG9mIHggY2h1bmtzIG9mIHNpemUgbixcbiAqIGludG8gYW4gYXJyYXkgb2YgbiBjaHVua3Mgb2Ygc2l6ZSB4LlxuICovXG5jb25zdCBjaHVua1RyYW5zcG9zZSA9IChjaHVua1NpemUpID0+XG4gIHJlZHVjZSgoY2h1bmtzLCB2YWwsIGlkeCkgPT4ge1xuICAgIGNvbnN0IGNodW5rSWR4ID0gaWR4ICUgY2h1bmtTaXplO1xuICAgIGNvbnN0IG5ld0NodW5rID0gWy4uLihjaHVua3NbY2h1bmtJZHhdIHx8IFtdKSwgdmFsXTtcbiAgICByZXR1cm4gWy4uLmNodW5rcy5zbGljZSgwLCBjaHVua0lkeCksIG5ld0NodW5rLCAuLi5jaHVua3Muc2xpY2UoY2h1bmtJZHggKyAxKV07XG4gIH0pKFtdKTtcblxuLyoqXG4gKiBDb21wb3NlIGEgc2VyaWVzIG9mIGZ1bmN0aW9ucyB0b2dldGhlci5cbiAqXG4gKiBFcXVpdmFsZW50IHRvIGFwcGx5aW5nIGFuIGFycmF5IG9mIGZ1bmN0aW9ucyB0byBhIHZhbHVlLCByaWdodCB0byBsZWZ0LlxuICpcbiAqICAgY29tcG9zZShmLCBnLCBoKSh4KSA9PT0gZihnKGgoeCkpKVxuICpcbiAqL1xuY29uc3QgY29tcG9zZSA9ICguLi5mcykgPT4gKHgpID0+IGZzLnJlZHVjZVJpZ2h0KCh2YWwsIGYpID0+IGYodmFsKSwgeCk7XG5cbi8vIFBpcGUgYSB2YWx1ZSB0aHJvdWdoIGEgc2VyaWVzIG9mIGZ1bmN0aW9ucyB3aGljaCB0ZXJtaW5hdGVzIGltbWVkaWF0ZWx5IG9uXG4vLyByZWNlaXZpbmcgYSBudWxsYXJ5IHZhbHVlLlxuY29uc3QgcGlwZU1heWJlID0gKC4uLmZzKSA9PiAoeCkgPT4gZnMucmVkdWNlKCh2YWwsIGYpID0+IChpc051bGxhcnkodmFsKSA/IHZhbCA6IGYodmFsKSksIHgpO1xuXG4vLyBHZXQgZmlyc3QgdmFsdWUgZnJvbSBhbiBhcnJheVxuY29uc3QgZmlyc3QgPSAoW3hdKSA9PiB4O1xuXG4vLyBGaXJzdCBmaXJzdCB2YWx1ZSBtYXRjaGluZyBwcmVkaWNhdGUgcCBpbiBhbiBhcnJheSBvZiB2YWx1ZXMuXG5jb25zdCBmaW5kID0gKHApID0+IHBpcGVNYXliZShmaWx0ZXIocCksIGZpcnN0KTtcblxuLy8gR2V0IGEgdmFsdWUgZnJvbSBhbiBvYmplY3QgYXQgYSBnaXZlbiBrZXkuXG5jb25zdCBwcm9wID0gKGspID0+IChvYmogPSB7fSkgPT4gb2JqW2tdO1xuXG4vLyBHZXQgYSB2YWx1ZSBmcm9tIGFuIG9iamVjdCBhdCBhIGdpdmVuIGtleSBpZiBpdCBleGlzdHMuXHRcbmNvbnN0IHByb3BNYXliZSA9IChrKSA9PiAob2JqID0ge30pID0+IG9ialtrXSB8fCBvYmo7XG5cbi8vIFRlc3QgaWYgYSB2YWx1ZSBpcyBmYWxzZSBvciBudWxsYXJ5LCByZXR1cm5pbmcgbnVsbCBpZiB0cnVlLCBvciBhIHNlY29uZCB2YWx1ZSBpZiBmYWxzZS5cbi8vIEludGVuZGVkIGZvciB1c2Ugd2l0aGluIGEgcGlwZU1heWJlIHdoZXJlIHlvdSB3YW50IHRvIHRlcm1pbmF0ZSBleGVjdXRpb24gd2hlcmVcbi8vIGFuIGFyYml0cmFyeSB2YWx1ZSBpcyBudWxsLlxuY29uc3QgZ3VhcmQgPSAocCkgPT4gKHgpID0+IChpc051bGxhcnlPckZhbHNlKHApID8gbnVsbCA6IHgpO1xuXG5leHBvcnQge1xuICBjaHVuayxcbiAgY2h1bmtUcmFuc3Bvc2UsXG4gIGNvbXBvc2UsXG4gIGZpbHRlcixcbiAgZmluZCxcbiAgZmlyc3QsXG4gIGd1YXJkLFxuICBtYXAsXG4gIG1hcE9iamVjdCxcbiAgcGFpcnNUb09iamVjdCxcbiAgcGlwZU1heWJlLFxuICBwcm9taXNlQWxsT2JqZWN0LFxuICBwcm9wLFxuICBwcm9wTWF5YmUsXG4gIHJlamVjdE51bGxhcnlWYWx1ZXMsXG59O1xuIiwiaW1wb3J0IHsgcG9wdWxhdGVFbGVtZW50cyB9IGZyb20gJy4uL2RvbSc7XG5pbXBvcnQgeyBta0VsZW1XaXRoU3ZnTG9va3VwLCBhIH0gZnJvbSAnLi4vdGVtcGxhdGluZyc7XG5pbXBvcnQgeyByZW1vdmVFbGVtZW50IH0gZnJvbSAnLi4vdXRpbHMnO1xuXG5jb25zdCBlcnJvckZhbGxiYWNrID0gKGNvbnRhaW5lckVsZW1lbnQgPSAndHAtd2lkZ2V0LWZhbGxiYWNrJykgPT4ge1xuICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChjb250YWluZXJFbGVtZW50KTtcblxuICBwb3B1bGF0ZUVsZW1lbnRzKFtcbiAgICB7XG4gICAgICBlbGVtZW50OiBjb250YWluZXIsXG4gICAgICBzdHJpbmc6IGEoXG4gICAgICAgIHtcbiAgICAgICAgICBocmVmOiAnaHR0cHM6Ly93d3cudHJ1c3RwaWxvdC5jb20/dXRtX21lZGl1bT10cnVzdGJveGZhbGxiYWNrJyxcbiAgICAgICAgICB0YXJnZXQ6ICdfYmxhbmsnLFxuICAgICAgICAgIHJlbDogJ25vb3BlbmVyIG5vcmVmZXJyZXInLFxuICAgICAgICB9LFxuICAgICAgICBta0VsZW1XaXRoU3ZnTG9va3VwKCdsb2dvJywgJ2ZhbGxiYWNrLWxvZ28nKVxuICAgICAgKSxcbiAgICB9LFxuICBdKTtcbn07XG5cbmNvbnN0IHJlbW92ZUVycm9yRmFsbGJhY2sgPSAoY29udGFpbmVyRWxlbWVudCA9ICd0cC13aWRnZXQtZmFsbGJhY2snKSA9PiB7XG4gIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGNvbnRhaW5lckVsZW1lbnQpO1xuICByZW1vdmVFbGVtZW50KGNvbnRhaW5lcik7XG59O1xuXG5leHBvcnQgeyBlcnJvckZhbGxiYWNrLCByZW1vdmVFcnJvckZhbGxiYWNrIH07XG4iLCJpbXBvcnQgeyBhZGRDbGFzcywgcG9wdWxhdGVFbGVtZW50cyB9IGZyb20gJy4uL2RvbSc7XG5pbXBvcnQgeyByZW1vdmVFbGVtZW50IH0gZnJvbSAnLi4vdXRpbHMnO1xuaW1wb3J0IHsgbWtFbGVtV2l0aFN2Z0xvb2t1cCB9IGZyb20gJy4uL3RlbXBsYXRpbmcnO1xuXG5jb25zdCBkZWZhdWx0TG9hZGVyQ29udGFpbmVyID0gJ3RwLXdpZGdldC1sb2FkZXInO1xuXG5jb25zdCBhZGRMb2FkZXIgPSAobG9hZGVyRWxlbWVudCkgPT4ge1xuICBjb25zdCBsb2FkZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChsb2FkZXJFbGVtZW50KTtcblxuICBwb3B1bGF0ZUVsZW1lbnRzKFtcbiAgICB7XG4gICAgICBlbGVtZW50OiBsb2FkZXIsXG4gICAgICBzdHJpbmc6IG1rRWxlbVdpdGhTdmdMb29rdXAoJ2xvZ28nKSxcbiAgICB9LFxuICBdKTtcbn07XG5cbmNvbnN0IHJlbW92ZUxvYWRlciA9IChsb2FkZXJFbGVtZW50KSA9PiB7XG4gIGNvbnN0IGxvYWRlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGxvYWRlckVsZW1lbnQpO1xuICBjb25zdCBsb2FkZXJMb2FkZWRDbGFzcyA9IGAke2xvYWRlckVsZW1lbnR9LS1sb2FkZWRgO1xuICBhZGRDbGFzcyhsb2FkZXIsIGxvYWRlckxvYWRlZENsYXNzKTtcblxuICAvLyBSZW1vdmUgbG9hZGVyIGFmdGVyIGNvbXBsZXRpb24gb2YgYW5pbWF0aW9uLlxuICBpZiAobG9hZGVyKSB7XG4gICAgbG9hZGVyLmFkZEV2ZW50TGlzdGVuZXIoJ2FuaW1hdGlvbmVuZCcsICgpID0+IHJlbW92ZUVsZW1lbnQobG9hZGVyKSk7XG4gICAgbG9hZGVyLmFkZEV2ZW50TGlzdGVuZXIoJ3dlYmtpdEFuaW1hdGlvbkVuZCcsICgpID0+IHJlbW92ZUVsZW1lbnQobG9hZGVyKSk7XG4gICAgbG9hZGVyLmFkZEV2ZW50TGlzdGVuZXIoJ29hbmltYXRpb25lbmQnLCAoKSA9PiByZW1vdmVFbGVtZW50KGxvYWRlcikpO1xuICB9XG59O1xuXG4vLyBDcmVhdGVzIGEgbG9hZGVyIGVsZW1lbnQgaW4gdGhlIERPTSwgdGhlbiByZXNvbHZlcyBhIHBhc3NlZCBwcm9taXNlIGFuZCByZW1vdmVzXG4vLyB0aGUgbG9hZGVyIG9uY2UgY29tcGxldGUuIFRoZSBsb2FkZXIgaXMgZGlzcGxheWVkIG9ubHkgYWZ0ZXIgdGhlIHBhc3NlZCBkZWxheVxuLy8gaGFzIGVsYXBzZWQuXG5jb25zdCB3aXRoTG9hZGVyID0gKHByb21pc2UsIHsgbG9hZGVyRWxlbWVudCA9IGRlZmF1bHRMb2FkZXJDb250YWluZXIsIGRlbGF5ID0gMTAwMCB9ID0ge30pID0+IHtcbiAgY29uc3QgbG9hZGVyVGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBhZGRMb2FkZXIobG9hZGVyRWxlbWVudCksIGRlbGF5KTtcbiAgcmV0dXJuIHByb21pc2UuZmluYWxseSgoKSA9PiB7XG4gICAgY2xlYXJUaW1lb3V0KGxvYWRlclRpbWVvdXRJZCk7XG4gICAgcmVtb3ZlTG9hZGVyKGxvYWRlckVsZW1lbnQpO1xuICB9KTtcbn07XG5cbmV4cG9ydCB7IHdpdGhMb2FkZXIgfTtcbiIsImltcG9ydCB7IGZldGNoRGF0YSwgaGFzUHJvZHVjdFJldmlld3MgfSBmcm9tICcuL2ZldGNoRGF0YSc7XG5pbXBvcnQgeyBhcGlDYWxsIH0gZnJvbSAnLi9jYWxsJztcbmltcG9ydCBSZXZpZXdGZXRjaGVyIGZyb20gJy4vcmV2aWV3RmV0Y2hlcic7XG5cbi8qKlxuICogRmV0Y2hlcyBkYXRhIGZvciBhIHByb2R1Y3QgYXR0cmlidXRlIFRydXN0Qm94LlxuICpcbiAqIFRoaXMgdXNlcyBhIFwibmV3LXN0eWxlXCIgZW5kcG9pbnQsIHdoaWNoIHRha2VzIGEgdGVtcGxhdGVJZCBhbmQgc3VwcGxpZXMgZGF0YVxuICogYmFzZWQgb24gdGhhdC5cbiAqL1xuY29uc3QgZmV0Y2hQcm9kdWN0RGF0YSA9ICh0ZW1wbGF0ZUlkKSA9PiAoXG4gIGZldGNoUGFyYW1zLFxuICBjb25zdHJ1Y3RUcnVzdEJveCxcbiAgcGFzc1RvUG9wdXAgPSBmYWxzZSxcbiAgaW5jbHVkZUltcG9ydGVkUmV2aWV3cyA9IGZhbHNlXG4pID0+IHtcbiAgLy8gQWRkIGV4dHJhIGRhdGEgdG8gdGhlIGNvbnN0cnVjdFRydXN0Qm94IGNhbGxiYWNrLCB3aGVyZSB3ZSBhcmUgZmV0Y2hpbmcgcmV2aWV3c1xuICBjb25zdCB3cmFwcGVkQ29uc3RydWN0ID0gKHsgYmFzZURhdGEsIGxvY2FsZSwgLi4uYXJncyB9KSA9PiB7XG4gICAgY29uc3QgZmV0Y2hlciA9IG5ldyBSZXZpZXdGZXRjaGVyKHtcbiAgICAgIGJhc2VEYXRhLFxuICAgICAgaW5jbHVkZUltcG9ydGVkUmV2aWV3cyxcbiAgICAgIHJldmlld3NQZXJQYWdlOiBwYXJzZUludChmZXRjaFBhcmFtcy5yZXZpZXdzUGVyUGFnZSksXG4gICAgICBsb2NhbGUsXG4gICAgICAuLi5hcmdzLFxuICAgIH0pO1xuICAgIHJldHVybiBmZXRjaGVyLmNvbnN1bWVSZXZpZXdzKGNvbnN0cnVjdFRydXN0Qm94KSgpO1xuICB9O1xuXG4gIGNvbnN0IGNvbnN0cnVjdCA9IGZldGNoUGFyYW1zLnJldmlld3NQZXJQYWdlID4gMCA/IHdyYXBwZWRDb25zdHJ1Y3QgOiBjb25zdHJ1Y3RUcnVzdEJveDtcbiAgZmV0Y2hEYXRhKGAvdHJ1c3Rib3gtZGF0YS8ke3RlbXBsYXRlSWR9YCkoZmV0Y2hQYXJhbXMsIGNvbnN0cnVjdCwgcGFzc1RvUG9wdXAsIGhhc1Byb2R1Y3RSZXZpZXdzKTtcbn07XG5cbi8qKlxuICogRmV0Y2hlcyBwcm9kdWN0IHJldmlldyBkYXRhIGdpdmVuIGFuIElEIGFuZCBhIGxvY2FsZS5cbiAqL1xuY29uc3QgZmV0Y2hQcm9kdWN0UmV2aWV3ID0gKFxuICBwcm9kdWN0UmV2aWV3SWQsXG4gIGxvY2FsZSxcbiAgY2FsbGJhY2tcbikgPT4ge1xuICBhcGlDYWxsKGAvcHJvZHVjdC1yZXZpZXdzLyR7cHJvZHVjdFJldmlld0lkfWAsIHsgbG9jYWxlIH0pLnRoZW4oY2FsbGJhY2spO1xufVxuXG5leHBvcnQge1xuICBmZXRjaFByb2R1Y3REYXRhLFxuICBmZXRjaFByb2R1Y3RSZXZpZXdcbn07XG4iLCIvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbmltcG9ydCBQcm9taXNlIGZyb20gJ3Byb21pc2UnO1xuXG5pbXBvcnQgeyBtYXBPYmplY3QsIHBpcGVNYXliZSwgcHJvbWlzZUFsbE9iamVjdCwgcHJvcCB9IGZyb20gJy4uLy4uL2ZuJztcbmltcG9ydCB7IGFwaUNhbGwgfSBmcm9tICcuLi9jYWxsJztcbmltcG9ydCB7IGdldE5leHRQYWdlTGlua3MgfSBmcm9tICcuL3V0aWwnO1xuaW1wb3J0IFJlc3BvbnNlUHJvY2Vzc29yIGZyb20gJy4vcmVzcG9uc2VQcm9jZXNzb3InO1xuXG5jb25zdCBOT19SRVZJRVdTX0VSUk9SID0gJ05vIHJldmlld3MgYXZhaWxhYmxlJztcblxuLyoqXG4gKiBUaGlzIGNsYXNzIHByb3ZpZGVzIHJldmlld3Mgb24gcmVxdWVzdCBvZiBhIGNvbnN1bWVyLiBJdCBjb2xsZWN0cyByZXZpZXdzXG4gKiB0aHJvdWdoIHBhZ2luYXRlZCBBUEkgY2FsbHMsIGFuZCB0aGVuIHByb3ZpZGVzIG9uZSBwYWdlIG9mIHJldmlld3Mgb24gcmVxdWVzdFxuICogZnJvbSB0aGUgY29uc3VtZXIuXG4gKlxuICogVGhyZWUgbWV0aG9kcyBhcmUgZXhwb3NlZCBhcyBpbnRlbmRlZCBmb3IgdXNlOiB7QGxpbmsgUmV2aWV3RmV0Y2hlciNjb25zdW1lUmV2aWV3c30sXG4gKiB7QGxpbmsgUmV2aWV3RmV0Y2hlciNwcm9kdWNlUmV2aWV3c30sIGFuZCB7QGxpbmsgUmV2aWV3RmV0Y2hlciNoYXNNb3JlUmV2aWV3c30uIE90aGVyXG4gKiBtZXRob2RzIHNob3VsZCBiZSBjb25zaWRlcmVkIHByaXZhdGUuXG4gKi9cbmNsYXNzIFJldmlld0ZldGNoZXIge1xuICAvKipcbiAgICogQ29uc3RydWN0IGEgUmV2aWV3RmV0Y2hlci5cbiAgICpcbiAgICogVGhlIGNvbnN0cnVjdG9yIHRha2VzIGFuIG9iamVjdCBjb250YWluaW5nIG9wdGlvbnMgYW5kIGRhdGEgcmVxdWlyZWQgdG9cbiAgICogb2J0YWluIGFuZCBwcm9kdWNlIHJldmlld3MgZm9yIGNvbnN1bXB0aW9uLlxuICAgKlxuICAgKiBAcGFyYW0ge09iamVjdH0gYXJncyAtIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSBhcmd1bWVudHMgYmVsb3cuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBhcmdzLnJldmlld3NQZXJQYWdlIC0gVGhlIG51bWJlciBvZiByZXZpZXdzIHRvIHByb3ZpZGUgcGVyXG4gICAqIHJlcXVlc3QuXG4gICAqIEBwYXJhbSB7Ym9vbGVhbn0gYXJncy5pbmNsdWRlSW1wb3J0ZWRSZXZpZXdzIC0gV2hldGhlciB0byBpbmNsdWRlIGltcG9ydGVkXG4gICAqIHJldmlld3MgaW4gdGhlIHJldmlld3MgcHJvdmlkZWQuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBhcmdzLmJhc2VEYXRhIC0gVGhlIGJhc2VEYXRhIHJlc3BvbnNlIHJlY2VpdmVkIGZyb20gYSBiYXNlLWRhdGFcbiAgICogY2FsbC5cbiAgICogQHBhcmFtIHsuLi5PYmplY3R9IGFyZ3Mud3JhcEFyZ3MgLSBBbiBhcmJpdHJhcnkgc2V0IG9mIGFyZ3VtZW50cyB0byBhZGQgdG9cbiAgICogdGhlIGRhdGEgcHJvdmlkZWQgdG8gdGhlIGNhbGxiYWNrIGluIHtAbGluayBSZXZpZXdGZXRjaGVyI2NvbnN1bWVSZXZpZXdzfS5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHsgcmV2aWV3c1BlclBhZ2UsIGluY2x1ZGVJbXBvcnRlZFJldmlld3MsIGJhc2VEYXRhLCAuLi53cmFwQXJncyB9KSB7XG4gICAgLy8gR2V0IG5leHQgcGFnZSBsaW5rcyBmcm9tIGEgYmFzZSBkYXRhIHJlc3BvbnNlLlxuICAgIGNvbnN0IGdldEJhc2VEYXRhTmV4dFBhZ2VMaW5rcyA9IGdldE5leHRQYWdlTGlua3MoKHJlc3BvbnNlS2V5KSA9PlxuICAgICAgcGlwZU1heWJlKHByb3AocmVzcG9uc2VLZXkpLCBwcm9wKCdsaW5rcycpLCBwcm9wKCduZXh0UGFnZScpKVxuICAgICk7XG5cbiAgICB0aGlzLnJldmlld3NQZXJQYWdlID0gcmV2aWV3c1BlclBhZ2U7XG4gICAgdGhpcy5pbmNsdWRlSW1wb3J0ZWRSZXZpZXdzID0gaW5jbHVkZUltcG9ydGVkUmV2aWV3cztcbiAgICB0aGlzLmJhc2VEYXRhID0gYmFzZURhdGE7XG4gICAgdGhpcy5uZXh0UGFnZSA9IGdldEJhc2VEYXRhTmV4dFBhZ2VMaW5rcyhiYXNlRGF0YSwgaW5jbHVkZUltcG9ydGVkUmV2aWV3cyk7XG4gICAgdGhpcy53cmFwQXJncyA9IHdyYXBBcmdzO1xuXG4gICAgdGhpcy5yZXZpZXdzID0gdGhpcy5fbWFrZVJlc3BvbnNlUHJvY2Vzc29yKGJhc2VEYXRhKS5nZXRSZXZpZXdzKCk7XG4gIH1cblxuICAvKipcbiAgICogQ29uc3VtZSBhIG51bWJlciBvZiByZXZpZXdzIHVzaW5nIGEgY2FsbGJhY2sgZnVuY3Rpb24uXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIGdldHMgb25lIHBhZ2Ugb2YgcmV2aWV3cywgYW5kIGNvbWJpbmVzIHRoaXMgd2l0aCB0aGUgZGF0YSBpblxuICAgKiB0aGUgd3JhcEFyZ3MgZmllbGQgYW5kIHBhc3NlcyBpdCBhbGwgdG8gYSBjYWxsYmFjay4gVGhlIHJldHVybiB2YWx1ZSBpc1xuICAgKiB3cmFwcGVkIGluIGFuIGFub255bW91cyBmdW5jdGlvbiB0byBtYWtlIGl0IHN1aXRhYmxlIGZvciB1c2Ugd2l0aGluIGV2ZW50XG4gICAqIGhhbmRsZXJzLlxuICAgKlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayAtIEEgZnVuY3Rpb24gdG8gY2FsbCB3aXRoIGEgc2V0IG9mIHJldmlldyBkYXRhLlxuICAgKi9cbiAgY29uc3VtZVJldmlld3MoY2FsbGJhY2spIHtcbiAgICByZXR1cm4gKCkgPT5cbiAgICAgIHRoaXMucHJvZHVjZVJldmlld3MoKVxuICAgICAgICAudGhlbigocmV2aWV3cykgPT5cbiAgICAgICAgICBjYWxsYmFjayh7XG4gICAgICAgICAgICAuLi50aGlzLndyYXBBcmdzLFxuICAgICAgICAgICAgYmFzZURhdGE6IHRoaXMuYmFzZURhdGEsXG4gICAgICAgICAgICByZXZpZXdzLFxuICAgICAgICAgICAgaGFzTW9yZVJldmlld3M6IHRoaXMuaGFzTW9yZVJldmlld3MsXG4gICAgICAgICAgICBsb2FkTW9yZVJldmlld3M6IHRoaXMuY29uc3VtZVJldmlld3MuYmluZCh0aGlzKSxcbiAgICAgICAgICB9KVxuICAgICAgICApXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgaWYgKGVyciA9PT0gTk9fUkVWSUVXU19FUlJPUikge1xuICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgLi4udGhpcy53cmFwQXJncyxcbiAgICAgICAgICAgICAgYmFzZURhdGE6IHRoaXMuYmFzZURhdGEsXG4gICAgICAgICAgICAgIHJldmlld3M6IFtdLFxuICAgICAgICAgICAgICBoYXNNb3JlUmV2aWV3czogZmFsc2UsXG4gICAgICAgICAgICAgIGxvYWRNb3JlUmV2aWV3czogdGhpcy5jb25zdW1lUmV2aWV3cy5iaW5kKHRoaXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIFJldGhyb3cgZXJyb3Igd2hpY2ggaXMgdW5leHBlY3RlZFxuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUHJvZHVjZSBhIG51bWJlciBvZiByZXZpZXdzLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBwcm9kdWNlcyBvbmUgcGFnZSBvZiByZXZpZXdzLiBJdCBtYXkgcmVxdWlyZSB0byBmZXRjaCBhZGRpdGlvbmFsXG4gICAqIHJldmlld3MgZnJvbSBhbiBBUEkgaWYgdGhlcmUgYXJlIGluc3VmZmljZW50IHJldmlld3MgYXZhaWxhYmxlIGxvY2FsbHkuIFRoZVxuICAgKiByZXZpZXdzIGFyZSB0aHVzIHJldHVybmVkIHdyYXBwZWQgaW4gYSBQcm9taXNlLlxuICAgKi9cbiAgcHJvZHVjZVJldmlld3MoKSB7XG4gICAgY29uc3QgcHJvY2Vzc1Jlc3BvbnNlID0gKHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCByZXNwb25zZVByb2Nlc3NvciA9IHRoaXMuX21ha2VSZXNwb25zZVByb2Nlc3NvcihyZXNwb25zZSk7XG4gICAgICB0aGlzLm5leHRQYWdlID0gcmVzcG9uc2VQcm9jZXNzb3IuZ2V0TmV4dFBhZ2VMaW5rcygpO1xuICAgICAgdGhpcy5yZXZpZXdzLnB1c2goLi4ucmVzcG9uc2VQcm9jZXNzb3IuZ2V0UmV2aWV3cygpKTtcbiAgICAgIHJldHVybiB0aGlzLl90YWtlUmV2aWV3cygpO1xuICAgIH07XG5cbiAgICBpZiAodGhpcy5yZXZpZXdzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbXBhdC9jb21wYXRcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChOT19SRVZJRVdTX0VSUk9SKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucmV2aWV3c1BlclBhZ2UgPj0gdGhpcy5yZXZpZXdzLmxlbmd0aFxuICAgICAgPyB0aGlzLl9mZXRjaFJldmlld3MoKS50aGVuKHByb2Nlc3NSZXNwb25zZSlcbiAgICAgIDogLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbXBhdC9jb21wYXRcbiAgICAgICAgUHJvbWlzZS5yZXNvbHZlKHRoaXMuX3Rha2VSZXZpZXdzKCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIEZsYWcgd2hldGhlciBtb3JlIHJldmlld3MgYXJlIGF2YWlsYWJsZSBmb3IgY29uc3VtcHRpb24uXG4gICAqXG4gICAqIFdoZXJlIHRydWUsIHRoaXMgbWVhbnMgaXQgaXMgcG9zc2libGUgdG8gbG9hZCBtb3JlIHJldmlld3MuIElmIGZhbHNlLCBub1xuICAgKiBtb3JlIHJldmlld3MgYXJlIGF2YWlsYWJsZS5cbiAgICovXG4gIGdldCBoYXNNb3JlUmV2aWV3cygpIHtcbiAgICByZXR1cm4gdGhpcy5yZXZpZXdzLmxlbmd0aCA+IDA7XG4gIH1cblxuICAvLyBQcml2YXRlIE1ldGhvZHMgLy9cblxuICAvKipcbiAgICogVGFrZSBhIHBhZ2Ugb2YgcmV2aWV3cyBmcm9tIGludGVybmFsIGNhY2hlIG9mIHJldmlld3MsIHJlbW92aW5nIHRoZXNlIGFuZFxuICAgKiByZXR1cm5pbmcgdGhlbSBmcm9tIHRoZSBtZXRob2QuXG4gICAqL1xuICBfdGFrZVJldmlld3MoKSB7XG4gICAgcmV0dXJuIHRoaXMucmV2aWV3cy5zcGxpY2UoMCwgdGhpcy5yZXZpZXdzUGVyUGFnZSk7XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggbW9yZSByZXZpZXdzIGZyb20gdGhlIEFQSS5cbiAgICovXG4gIF9mZXRjaFJldmlld3MoKSB7XG4gICAgcmV0dXJuIHByb21pc2VBbGxPYmplY3QobWFwT2JqZWN0KGFwaUNhbGwsIHRoaXMubmV4dFBhZ2UpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb25zdHJ1Y3QgYSB7QGxpbmsgUmVzcG9uc2VQcm9jZXNzb3J9IGluc3RhbmNlIHVzaW5nIHByb3BlcnRpZXMgZnJvbSB0aGlzIGluc3RhbmNlLlxuICAgKi9cbiAgX21ha2VSZXNwb25zZVByb2Nlc3NvcihyZXNwb25zZSkge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2VQcm9jZXNzb3IocmVzcG9uc2UsIHtcbiAgICAgIGluY2x1ZGVJbXBvcnRlZFJldmlld3M6IHRoaXMuaW5jbHVkZUltcG9ydGVkUmV2aWV3cyxcbiAgICAgIGRpc3BsYXlOYW1lOiB0aGlzLmJhc2VEYXRhLmJ1c2luZXNzRW50aXR5LmRpc3BsYXlOYW1lLFxuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJldmlld0ZldGNoZXI7XG4iLCJpbXBvcnQgeyBndWFyZCwgcGlwZU1heWJlLCByZWplY3ROdWxsYXJ5VmFsdWVzIH0gZnJvbSAnLi4vLi4vZm4nO1xuXG4vKipcbiAqIEdldCBuZXh0IHBhZ2UgbGlua3MgZnJvbSBhIHJlc3BvbnNlLlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gdGFrZSBhIGdldHRlciBmdW5jdGlvbiwgdXNlZCB0byBleHRyYWN0IGEgcGFydGljdWxhciB0eXBlIG9mIGxpbmssXG4gKiBlaXRoZXIgZm9yIHByb2R1Y3RSZXZpZXdzIG9yIGltcG9ydGVkUHJvZHVjdFJldmlld3MuIEl0IHJldHVybnMgYSBmdW5jdGlvbiB3aGljaFxuICogdGFrZSBhIHJlc3BvbnNlIGFuZCBhIGZsYWcgdG8gaW5kaWNhdGUgd2hldGhlciB0byBpbmNsdWRlIGltcG9ydGVkIHJldmlld3MuIFRoaXNcbiAqIGNhbiB0aGVuIGJlIGNhbGxlZCB0byBvYnRhaW4gYXZhaWxhYmxlIG5leHQgcGFnZSBsaW5rcy5cbiAqL1xuY29uc3QgZ2V0TmV4dFBhZ2VMaW5rcyA9IChnZXR0ZXIpID0+IChyZXNwb25zZSwgaW5jbHVkZUltcG9ydGVkUmV2aWV3cyA9IGZhbHNlKSA9PiB7XG4gIGNvbnN0IHByb2R1Y3RSZXZpZXdzID0gZ2V0dGVyKCdwcm9kdWN0UmV2aWV3cycpKHJlc3BvbnNlKTtcbiAgY29uc3QgaW1wb3J0ZWRQcm9kdWN0UmV2aWV3cyA9IHBpcGVNYXliZShcbiAgICBndWFyZChpbmNsdWRlSW1wb3J0ZWRSZXZpZXdzKSxcbiAgICBnZXR0ZXIoJ2ltcG9ydGVkUHJvZHVjdFJldmlld3MnKVxuICApKHJlc3BvbnNlKTtcbiAgcmV0dXJuIHJlamVjdE51bGxhcnlWYWx1ZXMoe1xuICAgIHByb2R1Y3RSZXZpZXdzLFxuICAgIGltcG9ydGVkUHJvZHVjdFJldmlld3MsXG4gIH0pO1xufTtcblxuZXhwb3J0IHsgZ2V0TmV4dFBhZ2VMaW5rcyB9O1xuIiwiaW1wb3J0IHsgZmluZCwgZ3VhcmQsIG1hcCwgcGlwZU1heWJlLCBwcm9wLCBwcm9wTWF5YmUgfSBmcm9tICcuLi8uLi9mbic7XG5pbXBvcnQgeyBnZXROZXh0UGFnZUxpbmtzIH0gZnJvbSAnLi91dGlsJztcblxuLyoqXG4gKiBUaGlzIGNsYXNzIHByb2Nlc3NlcyBhbiBBUEkgcmVzcG9uc2UgY29udGFpbmluZyByZXZpZXdzIGFuZCBwYWdpbmF0aW9uXG4gKiBkYXRhLlxuICovXG5jbGFzcyBSZXZpZXdSZXNwb25zZVByb2Nlc3NvciB7XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBSZXZpZXdSZXNwb25zZVByb2Nlc3NvciBpbnN0YW5jZS5cbiAgICpcbiAgICogVGFrZXMgYW4gQVBJIHJlc3BvbnNlIG9iamVjdCBmb3IgcHJvY2Vzc2luZywgdG9nZXRoZXIgd2l0aCBhIHNob3J0IGxpc3RcbiAgICogb2Ygb3B0aW9ucyBmb3IgcHJvY2Vzc2luZyBhbmQgYW5ub3RhdGluZyByZXZpZXdzLlxuICAgKi9cbiAgY29uc3RydWN0b3IocmVzcG9uc2UsIHsgaW5jbHVkZUltcG9ydGVkUmV2aWV3cywgZGlzcGxheU5hbWUgfSkge1xuICAgIHRoaXMucmVzcG9uc2UgPSByZXNwb25zZTtcbiAgICB0aGlzLmluY2x1ZGVJbXBvcnRlZFJldmlld3MgPSBpbmNsdWRlSW1wb3J0ZWRSZXZpZXdzO1xuICAgIHRoaXMuZGlzcGxheU5hbWUgPSBkaXNwbGF5TmFtZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgYSBjb21iaW5lZCBsaXN0IG9mIHJldmlld3MgZnJvbSB0aGUgQVBJIHJlc3BvbnNlLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBleHRyYWN0cyBhbGwgcmV2aWV3cyBmcm9tIHRoZSByZXNwb25zZSwgaW5jbHVkaW5nIG9wdGlvbmFsbHlcbiAgICogaW1wb3J0ZWQgcmV2aWV3cywgYW5kIHRoZW4gY29tYmluZXMgYW5kIHNvcnRzIHRoZXNlIGJ5IGRhdGUsIGRlc2NlbmRpbmcuXG4gICAqL1xuICBnZXRSZXZpZXdzKCkge1xuICAgIGNvbnN0IHsgcHJvZHVjdFJldmlld3MsIGltcG9ydGVkUHJvZHVjdFJldmlld3MgfSA9IHRoaXMucmVzcG9uc2U7XG4gICAgY29uc3Qgb3JkZXJCeUNyZWF0ZWRBdERlc2MgPSAoeyBjcmVhdGVkQXQ6IGMxIH0sIHsgY3JlYXRlZEF0OiBjMiB9KSA9PlxuICAgICAgbmV3IERhdGUoYzIpIC0gbmV3IERhdGUoYzEpO1xuICAgIGNvbnN0IHByb2R1Y3RSZXZpZXdzTGlzdCA9XG4gICAgICBwaXBlTWF5YmUocHJvcE1heWJlKCdwcm9kdWN0UmV2aWV3cycpLCBwcm9wTWF5YmUoJ3Jldmlld3MnKSkocHJvZHVjdFJldmlld3MpIHx8IFtdO1xuXG4gICAgY29uc3QgaW1wb3J0ZWRSZXZpZXdzTGlzdCA9XG4gICAgICBwaXBlTWF5YmUoXG4gICAgICAgIGd1YXJkKHRoaXMuaW5jbHVkZUltcG9ydGVkUmV2aWV3cyksXG4gICAgICAgIHByb3BNYXliZSgnaW1wb3J0ZWRQcm9kdWN0UmV2aWV3cycpLFxuICAgICAgICBwcm9wTWF5YmUoJ3Byb2R1Y3RSZXZpZXdzJyksXG4gICAgICAgIG1hcCgocmV2aWV3KSA9PiAoe1xuICAgICAgICAgIC4uLnJldmlldyxcbiAgICAgICAgICB2ZXJpZmllZEJ5OiByZXZpZXcudHlwZSA9PT0gJ0V4dGVybmFsJ1xuICAgICAgICAgICAgPyAhIXJldmlldy5zb3VyY2VcbiAgICAgICAgICAgICAgPyByZXZpZXcuc291cmNlLm5hbWVcbiAgICAgICAgICAgICAgOiB0aGlzLmRpc3BsYXlOYW1lXG4gICAgICAgICAgICA6IHRoaXMuZGlzcGxheU5hbWUsXG4gICAgICAgIH0pKSxcbiAgICAgICkoaW1wb3J0ZWRQcm9kdWN0UmV2aWV3cykgfHwgW107XG5cbiAgICByZXR1cm4gWy4uLnByb2R1Y3RSZXZpZXdzTGlzdCwgLi4uaW1wb3J0ZWRSZXZpZXdzTGlzdF0uc29ydChvcmRlckJ5Q3JlYXRlZEF0RGVzYyk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGFuIG9iamVjdCBjb250YWluaW5nIGxpbmtzIHRvIHRoZSBuZXh0IHBhZ2UgVVJJcyBjb250YWluZWQgd2l0aGluIHRoZVxuICAgKiBBUEkgcmVzcG9uc2UuXG4gICAqL1xuICBnZXROZXh0UGFnZUxpbmtzKCkge1xuICAgIC8vIEdldCBuZXh0IHBhZ2UgbGlua3MgZnJvbSBhIHBhZ2luYXRpb24gcmVzcG9uc2UuXG4gICAgY29uc3QgZ2V0T2xkUGFnaW5hdGlvbk5leHRQYWdlTGlua3MgPSBnZXROZXh0UGFnZUxpbmtzKChyZXNwb25zZUtleSkgPT5cbiAgICAgIHBpcGVNYXliZShcbiAgICAgICAgcHJvcChyZXNwb25zZUtleSksXG4gICAgICAgIHByb3AoJ2xpbmtzJyksXG4gICAgICAgIGZpbmQoKGxpbmspID0+IGxpbmsucmVsID09PSAnbmV4dC1wYWdlJyksXG4gICAgICAgIHByb3AoJ2hyZWYnKSxcbiAgICAgICksXG4gICAgKTtcblxuICAgIGNvbnN0IGdldE5ld1BhZ2luYXRpb25OZXh0UGFnZUxpbmtzID0gZ2V0TmV4dFBhZ2VMaW5rcygocmVzcG9uc2VLZXkpID0+XG4gICAgICBwaXBlTWF5YmUocHJvcChyZXNwb25zZUtleSksIHByb3AocmVzcG9uc2VLZXkpLCBwcm9wKCdsaW5rcycpLCBwcm9wKCduZXh0UGFnZScpKSxcbiAgICApO1xuXG4gICAgY29uc3QgbmV3TGlua3MgPSBnZXROZXdQYWdpbmF0aW9uTmV4dFBhZ2VMaW5rcyh0aGlzLnJlc3BvbnNlLCB0aGlzLmluY2x1ZGVJbXBvcnRlZFJldmlld3MpO1xuICAgIGNvbnN0IG9sZExpbmtzID0gZ2V0T2xkUGFnaW5hdGlvbk5leHRQYWdlTGlua3ModGhpcy5yZXNwb25zZSwgdGhpcy5pbmNsdWRlSW1wb3J0ZWRSZXZpZXdzKTtcblxuICAgIHJldHVybiB7IC4uLm9sZExpbmtzLCAuLi5uZXdMaW5rcyB9O1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJldmlld1Jlc3BvbnNlUHJvY2Vzc29yO1xuIiwiLyogVGhpcyBtb2R1bGUgZGVmaW5lcyBhIG51bWJlciBvZiBTVkcgZWxlbWVudHMuXG4gKlxuICogSUUxMSBkb2VzIG5vdCBwcm9wZXJseSBkaXNwbGF5IFNWRyB0YWdzLCBleGNlcHQgdXNpbmcgb25lIG9mIHNldmVyYWwgaGFja3MuXG4gKiBTbywgd2UgdXNlIG9uZSBiZWxvdzogd2Ugd3JhcCBlYWNoIFNWRyBpbiBhIGRpdiBlbGVtZW50LCB3aXRoIHBhcnRpY3VsYXJcbiAqIHN0eWxpbmcgYXR0YWNoZWQuIFdlIGRvIHRoaXMgZm9sbG93aW5nIE9wdGlvbiA0IGluIHRoZSBhcnRpY2xlIGF0XG4gKiBodHRwczovL2Nzcy10cmlja3MuY29tL3NjYWxlLXN2Zy8uXG4gKi9cblxuaW1wb3J0IHsgc2FuaXRpemVIdG1sLCBzYW5pdGl6ZUNvbG9yIH0gZnJvbSBcIi4uL3V0aWxzXCI7XG5cbmNvbnN0IHN2Z1NjYWxpbmdTdHlsZSA9ICdzdHlsZT1cInBvc2l0aW9uOiBhYnNvbHV0ZTsgaGVpZ2h0OiAxMDAlOyB3aWR0aDogMTAwJTsgbGVmdDogMDsgdG9wOiAwO1wiJztcblxuY29uc3Qgd3JhcFN2ZyA9IChkaW1lbnNpb25zLCBpbm5lciwgcHJvcHMgPSB7fSkgPT4ge1xuICBjb25zdCBzYW5pdGl6ZWRQcm9wcyA9IE9iamVjdC5rZXlzKHByb3BzKS5yZWR1Y2UoKGFjYywgY3VyKSA9PiB7XG4gICAgYWNjW2N1cl0gPSBzYW5pdGl6ZUh0bWwocHJvcHNbY3VyXSk7XG4gICAgaWYgKGN1ciA9PT0gJ2NvbG9yJykge1xuICAgICAgYWNjW2N1cl0gPSBzYW5pdGl6ZUNvbG9yKGFjY1tjdXJdKTtcbiAgICB9XG4gICAgcmV0dXJuIGFjYztcbiAgfSwge30pO1xuICByZXR1cm4gYFxuICAgIDxkaXYgc3R5bGU9XCJwb3NpdGlvbjogcmVsYXRpdmU7IGhlaWdodDogMDsgd2lkdGg6IDEwMCU7IHBhZGRpbmc6IDA7IHBhZGRpbmctYm90dG9tOiAkeyhkaW1lbnNpb25zLmhlaWdodCAvXG4gICAgICBkaW1lbnNpb25zLndpZHRoKSAqXG4gICAgMTAwfSU7XCI+XG4gICAgICAke2lubmVyKGRpbWVuc2lvbnMsIHNhbml0aXplZFByb3BzKX1cbiAgICA8L2Rpdj5cbiAgYDtcbn07XG5cbmNvbnN0IGVtcHR5U3RhckNvbG9yID0gJyNkY2RjZTYnO1xuY29uc3Qgc3RhcnMgPSAoZGltZW5zaW9ucywgeyByYXRpbmcsIHRydXN0U2NvcmUsIGNvbG9yIH0pID0+ICBgXG4gIDxzdmcgcm9sZT1cImltZ1wiIGFyaWEtbGFiZWxsZWRieT1cInN0YXJSYXRpbmdcIiB2aWV3Qm94PVwiMCAwICR7ZGltZW5zaW9ucy53aWR0aH0gJHtcbiAgZGltZW5zaW9ucy5oZWlnaHRcbn1cIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgJHtzdmdTY2FsaW5nU3R5bGV9PlxuICAgICAgPHRpdGxlIGlkPVwic3RhclJhdGluZ1wiIGxhbmc9XCJlblwiPiR7dHJ1c3RTY29yZX0gb3V0IG9mIGZpdmUgc3RhciByYXRpbmcgb24gVHJ1c3RwaWxvdDwvdGl0bGU+XG4gICAgICA8ZyBjbGFzcz1cInRwLXN0YXJcIj5cbiAgICAgICAgICA8cGF0aCBjbGFzcz1cInRwLXN0YXJfX2NhbnZhc1wiIGZpbGw9XCIke3JhdGluZyA+PSAxICYmIGNvbG9yID8gY29sb3IgOiBlbXB0eVN0YXJDb2xvcn1cIiBkPVwiTTAgNDYuMzMwMDAyaDQ2LjM3NTU4NlYwSDB6XCIvPlxuICAgICAgICAgIDxwYXRoIGNsYXNzPVwidHAtc3Rhcl9fc2hhcGVcIiBkPVwiTTM5LjUzMzkzNiAxOS43MTE0MzNMMTMuMjMwMjM5IDM4LjgwMDY1bDMuODM4MjE2LTExLjc5NzgyN0w3LjAyMTE1IDE5LjcxMTQzM2gxMi40MTg5NzVsMy44Mzc0MTctMTEuNzk4NjI0IDMuODM3NDE4IDExLjc5ODYyNGgxMi40MTg5NzV6TTIzLjI3ODUgMzEuNTEwMDc1bDcuMTgzNTk1LTEuNTA5NTc2IDIuODYyMTE0IDguODAwMTUyTDIzLjI3ODUgMzEuNTEwMDc1elwiIGZpbGw9XCIjRkZGXCIvPlxuICAgICAgPC9nPlxuICAgICAgPGcgY2xhc3M9XCJ0cC1zdGFyXCI+XG4gICAgICAgICAgPHBhdGggY2xhc3M9XCJ0cC1zdGFyX19jYW52YXNcIiBmaWxsPVwiJHtyYXRpbmcgPj0gMiAmJiBjb2xvciA/IGNvbG9yIDogZW1wdHlTdGFyQ29sb3J9XCIgZD1cIk01MS4yNDgxNiA0Ni4zMzAwMDJoNDYuMzc1NTg3VjBINTEuMjQ4MTYxelwiLz5cbiAgICAgICAgICA8cGF0aCBjbGFzcz1cInRwLXN0YXJfX2NhbnZhcy0taGFsZlwiIGZpbGw9XCIke3JhdGluZyA+PSAxLjUgJiYgY29sb3IgPyBjb2xvciA6IGVtcHR5U3RhckNvbG9yfVwiIGQ9XCJNNTEuMjQ4MTYgNDYuMzMwMDAyaDIzLjE4Nzc5M1YwSDUxLjI0ODE2MXpcIi8+XG4gICAgICAgICAgPHBhdGggY2xhc3M9XCJ0cC1zdGFyX19zaGFwZVwiIGQ9XCJNNzQuOTkwOTc4IDMxLjMyOTkxTDgxLjE1MDkwOCAzMCA4NCAzOWwtOS42NjAyMDYtNy4yMDI3ODZMNjQuMzAyNzkgMzlsMy44OTU2MzYtMTEuODQwNjY2TDU4IDE5Ljg0MTQ2NmgxMi42MDU1NzdMNzQuNDk5NTk1IDhsMy44OTU2MzcgMTEuODQxNDY2SDkxTDc0Ljk5MDk3OCAzMS4zMjk5MDl6XCIgZmlsbD1cIiNGRkZcIi8+XG4gICAgICA8L2c+XG4gICAgICA8ZyBjbGFzcz1cInRwLXN0YXJcIj5cbiAgICAgICAgICA8cGF0aCBjbGFzcz1cInRwLXN0YXJfX2NhbnZhc1wiIGZpbGw9XCIke3JhdGluZyA+PSAzICYmIGNvbG9yID8gY29sb3IgOiBlbXB0eVN0YXJDb2xvcn1cIiBkPVwiTTEwMi41MzIyMDkgNDYuMzMwMDAyaDQ2LjM3NTU4NlYwaC00Ni4zNzU1ODZ6XCIvPlxuICAgICAgICAgIDxwYXRoIGNsYXNzPVwidHAtc3Rhcl9fY2FudmFzLS1oYWxmXCIgZmlsbD1cIiR7cmF0aW5nID49IDIuNSAmJiBjb2xvciA/IGNvbG9yIDogZW1wdHlTdGFyQ29sb3J9XCIgZD1cIk0xMDIuNTMyMjA5IDQ2LjMzMDAwMmgyMy4xODc3OTNWMGgtMjMuMTg3NzkzelwiLz5cbiAgICAgICAgICA8cGF0aCBjbGFzcz1cInRwLXN0YXJfX3NoYXBlXCIgZD1cIk0xNDIuMDY2OTk0IDE5LjcxMTQzM0wxMTUuNzYzMjk4IDM4LjgwMDY1bDMuODM4MjE1LTExLjc5NzgyNy0xMC4wNDczMDQtNy4yOTEzOTFoMTIuNDE4OTc1bDMuODM3NDE4LTExLjc5ODYyNCAzLjgzNzQxNyAxMS43OTg2MjRoMTIuNDE4OTc1ek0xMjUuODExNTYgMzEuNTEwMDc1bDcuMTgzNTk1LTEuNTA5NTc2IDIuODYyMTEzIDguODAwMTUyLTEwLjA0NTcwOC03LjI5MDU3NnpcIiBmaWxsPVwiI0ZGRlwiLz5cbiAgICAgIDwvZz5cbiAgICAgIDxnIGNsYXNzPVwidHAtc3RhclwiPlxuICAgICAgICAgIDxwYXRoIGNsYXNzPVwidHAtc3Rhcl9fY2FudmFzXCIgZmlsbD1cIiR7cmF0aW5nID49IDQgJiYgY29sb3IgPyBjb2xvciA6IGVtcHR5U3RhckNvbG9yfVwiIGQ9XCJNMTUzLjgxNTQ1OCA0Ni4zMzAwMDJoNDYuMzc1NTg2VjBoLTQ2LjM3NTU4NnpcIi8+XG4gICAgICAgICAgPHBhdGggY2xhc3M9XCJ0cC1zdGFyX19jYW52YXMtLWhhbGZcIiBmaWxsPVwiJHtyYXRpbmcgPj0gMy41ICYmIGNvbG9yID8gY29sb3IgOiBlbXB0eVN0YXJDb2xvcn1cIiBkPVwiTTE1My44MTU0NTggNDYuMzMwMDAyaDIzLjE4Nzc5M1YwaC0yMy4xODc3OTN6XCIvPlxuICAgICAgICAgIDxwYXRoIGNsYXNzPVwidHAtc3Rhcl9fc2hhcGVcIiBkPVwiTTE5My4zNDgzNTUgMTkuNzExNDMzTDE2Ny4wNDU0NTcgMzguODAwNjVsMy44Mzc0MTctMTEuNzk3ODI3LTEwLjA0NzMwMy03LjI5MTM5MWgxMi40MTg5NzRsMy44Mzc0MTgtMTEuNzk4NjI0IDMuODM3NDE4IDExLjc5ODYyNGgxMi40MTg5NzR6TTE3Ny4wOTI5MiAzMS41MTAwNzVsNy4xODM1OTUtMS41MDk1NzYgMi44NjIxMTQgOC44MDAxNTItMTAuMDQ1NzA5LTcuMjkwNTc2elwiIGZpbGw9XCIjRkZGXCIvPlxuICAgICAgPC9nPlxuICAgICAgPGcgY2xhc3M9XCJ0cC1zdGFyXCI+XG4gICAgICAgICAgPHBhdGggY2xhc3M9XCJ0cC1zdGFyX19jYW52YXNcIiBmaWxsPVwiJHtyYXRpbmcgPT09IDUgJiYgY29sb3IgPyBjb2xvciA6IGVtcHR5U3RhckNvbG9yfVwiIGQ9XCJNMjA1LjA2NDQxNiA0Ni4zMzAwMDJoNDYuMzc1NTg3VjBoLTQ2LjM3NTU4N3pcIi8+XG4gICAgICAgICAgPHBhdGggY2xhc3M9XCJ0cC1zdGFyX19jYW52YXMtLWhhbGZcIiBmaWxsPVwiJHtyYXRpbmcgPj0gNC41ICYmIGNvbG9yID8gY29sb3IgOiBlbXB0eVN0YXJDb2xvcn1cIiBkPVwiTTIwNS4wNjQ0MTYgNDYuMzMwMDAyaDIzLjE4Nzc5M1YwaC0yMy4xODc3OTN6XCIvPlxuICAgICAgICAgIDxwYXRoIGNsYXNzPVwidHAtc3Rhcl9fc2hhcGVcIiBkPVwiTTI0NC41OTcwMjIgMTkuNzExNDMzbC0yNi4zMDI5IDE5LjA4OTIxOCAzLjgzNzQxOS0xMS43OTc4MjctMTAuMDQ3MzA0LTcuMjkxMzkxaDEyLjQxODk3NGwzLjgzNzQxOC0xMS43OTg2MjQgMy44Mzc0MTggMTEuNzk4NjI0aDEyLjQxODk3NXptLTE2LjI1NTQzNiAxMS43OTg2NDJsNy4xODM1OTUtMS41MDk1NzYgMi44NjIxMTQgOC44MDAxNTItMTAuMDQ1NzA5LTcuMjkwNTc2elwiIGZpbGw9XCIjRkZGXCIvPlxuICAgICAgPC9nPlxuICA8L3N2Zz5gO1xuXG5jb25zdCBsb2dvID0gKGRpbWVuc2lvbnMpID0+IGBcbiAgPHN2ZyByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbGxlZGJ5PVwidHJ1c3RwaWxvdExvZ29cIiB2aWV3Qm94PVwiMCAwICR7ZGltZW5zaW9ucy53aWR0aH0gJHtcbiAgZGltZW5zaW9ucy5oZWlnaHRcbn1cIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgJHtzdmdTY2FsaW5nU3R5bGV9PlxuICAgICAgPHRpdGxlIGlkPVwidHJ1c3RwaWxvdExvZ29cIj5UcnVzdHBpbG90PC90aXRsZT5cbiAgICAgIDxwYXRoIGNsYXNzPVwidHAtbG9nb19fdGV4dFwiIGQ9XCJNMzMuMDc0Nzc0IDExLjA3MDA1SDQ1LjgxODA2djIuMzY0MTk2aC01LjAxMDY1NnYxMy4yOTAzMTZoLTIuNzU1MzA2VjEzLjQzNDI0NmgtNC45ODg0MzVWMTEuMDcwMDVoLjAxMTExem0xMi4xOTg4OTIgNC4zMTk2MjloMi4zNTUzNDF2Mi4xODc0MzNoLjA0NDQ0Yy4wNzc3NzEtLjMwOTMzNC4yMjIyMDMtLjYwNzYyLjQzMzI5NS0uODk0ODU5LjIxMTA5Mi0uMjg3MjM5LjQ2NjYyNC0uNTYzNDMuNzY2NTk3LS43OTU0My4yOTk5NzItLjI0MzA0OC42MzMyNzYtLjQzMDg1OC45OTk5MDktLjU4NTUyNS4zNjY2MzMtLjE0MzYyLjc0NDM3Ny0uMjIwOTUzIDEuMTIyMTItLjIyMDk1My4yODg4NjMgMCAuNDk5OTU1LjAxMTA0Ny42MTEwNTYuMDIyMDk1LjExMTEuMDExMDQ4LjIyMjIwMi4wMzMxNDMuMzQ0NDEzLjA0NDE5djIuNDA4Mzg3Yy0uMTc3NzYyLS4wMzMxNDMtLjM1NTUyMy0uMDU1MjM4LS41NDQzOTUtLjA3NzMzMy0uMTg4ODcyLS4wMjIwOTYtLjM2NjYzMy0uMDMzMTQzLS41NDQzOTUtLjAzMzE0My0uNDIyMTg0IDAtLjgyMjE0OC4wODgzOC0xLjE5OTg5MS4yNTQwOTYtLjM3Nzc0NC4xNjU3MTQtLjY5OTkzNi40MTk4MS0uOTc3Njg5Ljc0MDE5Mi0uMjc3NzUzLjMzMTQyOS0uNDk5OTU1LjcyOTE0NC0uNjY2NjA2IDEuMjE1MjQtLjE2NjY1Mi40ODYwOTctLjI0NDQyMiAxLjAzODQ4LS4yNDQ0MjIgMS42NjgxOTV2NS4zOTEyNWgtMi41MTA4ODNWMTUuMzg5NjhoLjAxMTExem0xOC4yMjA1NjcgMTEuMzM0ODgzSDYxLjAyNzc5di0xLjU3OTgxM2gtLjA0NDQ0Yy0uMzExMDgzLjU3NDQ3Ny0uNzY2NTk3IDEuMDI3NDMtMS4zNzc2NTMgMS4zNjk5MDgtLjYxMTA1NS4zNDI0NzctMS4yMzMyMjEuNTE5MjQtMS44NjY0OTcuNTE5MjQtMS40OTk4NjQgMC0yLjU4ODY1NC0uMzY0NTczLTMuMjU1MjYtMS4xMDQ3NjUtLjY2NjYwNi0uNzQwMTkzLS45OTk5MDktMS44NTYwMDUtLjk5OTkwOS0zLjM0NzQzN1YxNS4zODk2OGgyLjUxMDg4M3Y2Ljk0ODk2OGMwIC45OTQyODguMTg4ODcyIDEuNzAxMzM3LjU3NzcyNSAyLjExMDEuMzc3NzQ0LjQwODc2My45MjIxMzkuNjE4NjY4IDEuNjEwOTY1LjYxODY2OC41MzMyODUgMCAuOTY2NTgtLjA3NzMzMyAxLjMyMjEwMi0uMjQzMDQ4LjM1NTUyNC0uMTY1NzE0LjY0NDM4Ni0uMzc1NjIuODU1NDc4LS42NTE4MS4yMjIyMDItLjI2NTE0NC4zNzc3NDQtLjU5NjU3NC40Nzc3MzUtLjk3MjE5NC4wOTk5OS0uMzc1NjIuMTQ0NDMxLS43ODQzODIuMTQ0NDMxLTEuMjI2Mjg4di02LjU3MzM0OWgyLjUxMDg4M3YxMS4zMjM4MzZ6bTQuMjc3MzktMy42MzQ2NzVjLjA3Nzc3LjcyOTE0NC4zNTU1MjIgMS4yMzczMzYuODMzMjU3IDEuNTM1NjIzLjQ4ODg0NC4yODcyMzggMS4wNjY1Ny40NDE5MDUgMS43NDQyODYuNDQxOTA1LjIzMzMxMiAwIC40OTk5NTQtLjAyMjA5NS43OTk5MjctLjA1NTIzOC4yOTk5NzMtLjAzMzE0My41ODg4MzYtLjExMDQ3Ni44NDQzNjgtLjIwOTkwNS4yNjY2NDItLjA5OTQyOS40Nzc3MzQtLjI1NDA5Ni42NTU0OTYtLjQ1Mjk1NC4xNjY2NTItLjE5ODg1Ny4yNDQ0MjItLjQ1Mjk1My4yMzMzMTItLjc3MzMzNS0uMDExMTEtLjMyMDM4MS0uMTMzMzIxLS41ODU1MjUtLjM1NTUyMy0uNzg0MzgyLS4yMjIyMDItLjIwOTkwNi0uNDk5OTU1LS4zNjQ1NzMtLjg0NDM2OC0uNDk3MTQ0LS4zNDQ0MTMtLjEyMTUyNS0uNzMzMjY3LS4yMzItMS4xNzc2Ny0uMzIwMzgyLS40NDQ0MDUtLjA4ODM4MS0uODg4ODA5LS4xODc4MS0xLjM0NDMyMy0uMjg3MjM5LS40NjY2MjQtLjA5OTQyOS0uOTIyMTM4LS4yMzItMS4zNTU0MzItLjM3NTYyLS40MzMyOTQtLjE0MzYyLS44MjIxNDgtLjM0MjQ3Ny0xLjE2NjU2MS0uNTk2NTczLS4zNDQ0MTMtLjI0MzA0OC0uNjIyMTY2LS41NjM0My0uODIyMTQ4LS45NTAwOTctLjIxMTA5Mi0uMzg2NjY4LS4zMTEwODMtLjg2MTcxNi0uMzExMDgzLTEuNDM2MTk0IDAtLjYxODY2OC4xNTU1NDItMS4xMjY4Ni40NTU1MTUtMS41NDY2Ny4yOTk5NzItLjQxOTgxLjY4ODgyNi0uNzUxMjQgMS4xNDQzNC0xLjAwNTMzNi40NjY2MjQtLjI1NDA5NS45Nzc2OS0uNDMwODU4IDEuNTQ0MzA0LS41NDEzMzQuNTY2NjE1LS4wOTk0MjkgMS4xMTEwMS0uMTU0NjY3IDEuNjIyMDc1LS4xNTQ2NjcuNTg4ODM2IDAgMS4xNTU0NS4wNjYyODYgMS42ODg3MzYuMTg3ODEuNTMzMjg1LjEyMTUyNCAxLjAyMjEzLjMyMDM4MSAxLjQ1NTQyMy42MDc2Mi40MzMyOTQuMjc2MTkxLjc4ODgxNy42NDA3NjQgMS4wNzc2OCAxLjA4MjY3LjI4ODg2My40NDE5MDUuNDY2NjI0Ljk4MzI0LjU0NDM5NSAxLjYxMjk1NWgtMi42MjE5ODRjLS4xMjIyMTEtLjU5NjU3Mi0uMzg4ODU0LTEuMDA1MzM1LS44MjIxNDgtMS4yMDQxOTMtLjQzMzI5NC0uMjA5OTA1LS45MzMyNDgtLjMwOTMzNC0xLjQ4ODc1My0uMzA5MzM0LS4xNzc3NjIgMC0uMzg4ODU0LjAxMTA0OC0uNjMzMjc2LjA0NDE5LS4yNDQ0MjIuMDMzMTQ0LS40NjY2MjQuMDg4MzgyLS42ODg4MjYuMTY1NzE1LS4yMTEwOTIuMDc3MzM0LS4zODg4NTQuMTk4ODU4LS41NDQzOTUuMzUzNTI1LS4xNDQ0MzIuMTU0NjY3LS4yMjIyMDMuMzUzNTI1LS4yMjIyMDMuNjA3NjIgMCAuMzA5MzM1LjExMTEwMS41NTIzODMuMzIyMTkzLjc0MDE5My4yMTEwOTIuMTg3ODEuNDg4ODQ1LjM0MjQ3Ny44MzMyNTguNDc1MDQ4LjM0NDQxMy4xMjE1MjQuNzMzMjY3LjIzMiAxLjE3NzY3MS4zMjAzODIuNDQ0NDA0LjA4ODM4MS44OTk5MTguMTg3ODEgMS4zNjY1NDIuMjg3MjM5LjQ1NTUxNS4wOTk0MjkuODk5OTE5LjIzMiAxLjM0NDMyMy4zNzU2Mi40NDQ0MDQuMTQzNjIuODMzMjU3LjM0MjQ3NyAxLjE3NzY3LjU5NjU3My4zNDQ0MTQuMjU0MDk1LjYyMjE2Ni41NjM0My44MzMyNTguOTM5MDUuMjExMDkyLjM3NTYyLjMyMjE5My44NTA2NjguMzIyMTkzIDEuNDAzMDUgMCAuNjczOTA2LS4xNTU1NDEgMS4yMzczMzYtLjQ2NjYyNCAxLjcxMjM4NS0uMzExMDgzLjQ2NDAwMS0uNzExMDQ3Ljg1MDY2OS0xLjE5OTg5MSAxLjEzNzkwNy0uNDg4ODQ1LjI4NzI0LTEuMDQ0MzUuNTA4MTkyLTEuNjQ0Mjk1LjY0MDc2NC0uNTk5OTQ2LjEzMjU3Mi0xLjE5OTg5MS4xOTg4NTctMS43ODg3MjcuMTk4ODU3LS43MjIxNTYgMC0xLjM4ODc2Mi0uMDc3MzMzLTEuOTk5ODE4LS4yNDMwNDgtLjYxMTA1Ni0uMTY1NzE0LTEuMTQ0MzQtLjQwODc2My0xLjU4ODc0NS0uNzI5MTQ0LS40NDQ0MDQtLjMzMTQzLS43OTk5MjctLjc0MDE5Mi0xLjA1NTQ2LTEuMjI2Mjg5LS4yNTU1MzItLjQ4NjA5Ni0uMzg4ODUzLTEuMDcxNjIxLS40MTEwNzMtMS43NDU1MjhoMi41MzMxMDN2LS4wMjIwOTV6bTguMjg4MTM1LTcuNzAwMjA4aDEuODk5ODI4di0zLjQwMjY3NWgyLjUxMDg4M3YzLjQwMjY3NWgyLjI2NjQ2djEuODY3MDUyaC0yLjI2NjQ2djYuMDU0MTA5YzAgLjI2NTE0My4wMTExMS40ODYwOTYuMDMzMzMuNjg0OTU0LjAyMjIyLjE4NzgxLjA3Nzc3LjM1MzUyNC4xNTU1NDIuNDg2MDk2LjA3Nzc3LjEzMjU3Mi4xOTk5ODEuMjMyLjM2NjYzMy4yOTgyODcuMTY2NjUxLjA2NjI4NS4zNzc3NDMuMDk5NDI4LjY2NjYwNi4wOTk0MjguMTc3NzYyIDAgLjM1NTUyMyAwIC41MzMyODUtLjAxMTA0Ny4xNzc3NjItLjAxMTA0OC4zNTU1MjMtLjAzMzE0My41MzMyODUtLjA3NzMzNHYxLjkzMzMzOGMtLjI3Nzc1My4wMzMxNDMtLjU1NTUwNS4wNTUyMzgtLjgxMTAzOC4wODgzODEtLjI2NjY0Mi4wMzMxNDMtLjUzMzI4NS4wNDQxOS0uODExMDM3LjA0NDE5LS42NjY2MDYgMC0xLjE5OTg5MS0uMDY2Mjg1LTEuNTk5ODU1LS4xODc4MS0uMzk5OTYzLS4xMjE1MjMtLjcyMjE1Ni0uMzA5MzMzLS45NDQzNTgtLjU1MjM4MS0uMjMzMzEzLS4yNDMwNDktLjM3Nzc0NC0uNTQxMzM1LS40NjY2MjUtLjkwNTkwNy0uMDc3NzctLjM2NDU3My0uMTMzMzItLjc4NDM4My0uMTQ0NDMxLTEuMjQ4Mzg0di02LjY4MzgyNWgtMS44OTk4Mjd2LTEuODg5MTQ3aC0uMDIyMjJ6bTguNDU0Nzg4IDBoMi4zNzc1NjJWMTYuOTI1M2guMDQ0NDRjLjM1NTUyMy0uNjYyODU4Ljg0NDM2OC0xLjEyNjg2IDEuNDc3NjQ0LTEuNDE0MDk4LjYzMzI3Ni0uMjg3MjM5IDEuMzEwOTkyLS40MzA4NTggMi4wNTUzNjktLjQzMDg1OC44OTk5MTggMCAxLjY3NzYyNS4xNTQ2NjcgMi4zNDQyMzEuNDc1MDQ4LjY2NjYwNi4zMDkzMzUgMS4yMjIxMTEuNzQwMTkzIDEuNjY2NTE1IDEuMjkyNTc1LjQ0NDQwNS41NTIzODIuNzY2NTk3IDEuMTkzMTQ1Ljk4ODggMS45MjIyOS4yMjIyMDIuNzI5MTQ1LjMzMzMwMyAxLjUxMzUyNy4zMzMzMDMgMi4zNDIxIDAgLjc2MjI4OC0uMDk5OTkxIDEuNTAyNDgtLjI5OTk3MyAyLjIwOTUzLS4xOTk5ODIuNzE4MDk2LS40OTk5NTUgMS4zNDc4MTItLjg5OTkxOCAxLjkwMDE5NC0uMzk5OTY0LjU1MjM4My0uOTExMDI5Ljk4MzI0LTEuNTMzMTk0IDEuMzE0NjctLjYyMjE2Ni4zMzE0My0xLjM0NDMyMy40OTcxNDQtMi4xODg2OS40OTcxNDQtLjM2NjYzNCAwLS43MzMyNjctLjAzMzE0My0xLjA5OTktLjA5OTQyOS0uMzY2NjM0LS4wNjYyODYtLjcyMjE1Ny0uMTc2NzYyLTEuMDU1NDYtLjMyMDM4MS0uMzMzMzAzLS4xNDM2Mi0uNjU1NDk2LS4zMzE0My0uOTMzMjQ5LS41NjM0My0uMjg4ODYzLS4yMzItLjUyMjE3NS0uNDk3MTQ0LS43MjIxNTctLjc5NTQzaC0uMDQ0NDR2NS42NTYzOTNoLTIuNTEwODgzVjE1LjM4OTY4em04Ljc3Njk4IDUuNjc4NDljMC0uNTA4MTkzLS4wNjY2Ni0xLjAwNTMzNy0uMTk5OTgxLTEuNDkxNDMzLS4xMzMzMjEtLjQ4NjA5Ni0uMzMzMzAzLS45MDU5MDctLjU5OTk0Ni0xLjI4MTUyNy0uMjY2NjQyLS4zNzU2Mi0uNTk5OTQ1LS42NzM5MDYtLjk4ODc5OS0uODk0ODU5LS4zOTk5NjMtLjIyMDk1My0uODU1NDc4LS4zNDI0NzctMS4zNjY1NDItLjM0MjQ3Ny0xLjA1NTQ2IDAtMS44NTUzODcuMzY0NTcyLTIuMzg4NjcyIDEuMDkzNzE3LS41MzMyODUuNzI5MTQ0LS43OTk5MjggMS43MDEzMzctLjc5OTkyOCAyLjkxNjU3OCAwIC41NzQ0NzguMDY2NjYxIDEuMTA0NzY0LjIxMTA5MiAxLjU5MDg2LjE0NDQzMi40ODYwOTcuMzQ0NDE0LjkwNTkwOC42MzMyNzYgMS4yNTk0MzIuMjc3NzUzLjM1MzUyNS42MTEwNTYuNjI5NzE2Ljk5OTkxLjgyODU3NC4zODg4NTMuMjA5OTA1Ljg0NDM2Ny4zMDkzMzQgMS4zNTU0MzIuMzA5MzM0LjU3NzcyNSAwIDEuMDU1NDYtLjEyMTUyNCAxLjQ1NTQyMy0uMzUzNTI1LjM5OTk2NC0uMjMyLjcyMjE1Ny0uNTQxMzM1Ljk3NzY5LS45MDU5MDcuMjU1NTMxLS4zNzU2Mi40NDQ0MDMtLjc5NTQzLjU1NTUwNC0xLjI3MDQ3OS4wOTk5OTEtLjQ3NTA0OS4xNTU1NDItLjk2MTE0NS4xNTU1NDItMS40NTgyODl6bTQuNDMyOTMxLTkuOTk4MTJoMi41MTA4ODN2Mi4zNjQxOTdoLTIuNTEwODgzVjExLjA3MDA1em0wIDQuMzE5NjNoMi41MTA4ODN2MTEuMzM0ODgzaC0yLjUxMDg4M1YxNS4zODk2Nzl6bTQuNzU1MTI0LTQuMzE5NjNoMi41MTA4ODN2MTUuNjU0NTEzaC0yLjUxMDg4M1YxMS4wNzAwNXptMTAuMjEwMTg0IDE1Ljk2Mzg0N2MtLjkxMTAyOSAwLTEuNzIyMDY2LS4xNTQ2NjctMi40MzMxMTMtLjQ1Mjk1My0uNzExMDQ2LS4yOTgyODctMS4zMTA5OTItLjcxODA5Ny0xLjgxMDk0Ni0xLjIzNzMzNy0uNDg4ODQ1LS41MzAyODctLjg2NjU4OC0xLjE2MDAwMi0xLjEyMjEyLTEuODg5MTQ3LS4yNTU1MzMtLjcyOTE0NC0uMzg4ODU0LTEuNTM1NjIyLS4zODg4NTQtMi40MDgzODYgMC0uODYxNzE2LjEzMzMyMS0xLjY1NzE0Ny4zODg4NTMtMi4zODYyOTEuMjU1NTMzLS43MjkxNDUuNjMzMjc2LTEuMzU4ODYgMS4xMjIxMi0xLjg4OTE0OC40ODg4NDUtLjUzMDI4NyAxLjA5OTktLjkzOTA1IDEuODEwOTQ3LTEuMjM3MzM2LjcxMTA0Ny0uMjk4Mjg2IDEuNTIyMDg0LS40NTI5NTMgMi40MzMxMTMtLjQ1Mjk1My45MTEwMjggMCAxLjcyMjA2Ni4xNTQ2NjcgMi40MzMxMTIuNDUyOTUzLjcxMTA0Ny4yOTgyODcgMS4zMTA5OTIuNzE4MDk3IDEuODEwOTQ3IDEuMjM3MzM2LjQ4ODg0NC41MzAyODcuODY2NTg4IDEuMTYwMDAzIDEuMTIyMTIgMS44ODkxNDguMjU1NTMyLjcyOTE0NC4zODg4NTQgMS41MjQ1NzUuMzg4ODU0IDIuMzg2MjkgMCAuODcyNzY1LS4xMzMzMjIgMS42NzkyNDMtLjM4ODg1NCAyLjQwODM4Ny0uMjU1NTMyLjcyOTE0NS0uNjMzMjc2IDEuMzU4ODYtMS4xMjIxMiAxLjg4OTE0Ny0uNDg4ODQ1LjUzMDI4Ny0xLjA5OTkuOTM5MDUtMS44MTA5NDcgMS4yMzczMzctLjcxMTA0Ni4yOTgyODYtMS41MjIwODQuNDUyOTUzLTIuNDMzMTEyLjQ1Mjk1M3ptMC0xLjk3NzUyOGMuNTU1NTA1IDAgMS4wNDQzNS0uMTIxNTI0IDEuNDU1NDIzLS4zNTM1MjUuNDExMDc0LS4yMzIuNzQ0Mzc3LS41NDEzMzUgMS4wMTEwMi0uOTE2OTU0LjI2NjY0Mi0uMzc1NjIuNDU1NTEzLS44MDY0NzguNTg4ODM1LTEuMjgxNTI3LjEyMjIxLS40NzUwNDkuMTg4ODcyLS45NjExNDUuMTg4ODcyLTEuNDU4MjkgMC0uNDg2MDk2LS4wNjY2NjEtLjk2MTE0NC0uMTg4ODcyLTEuNDQ3MjQtLjEyMjIxMS0uNDg2MDk3LS4zMjIxOTMtLjkwNTkwNy0uNTg4ODM2LTEuMjgxNTI3LS4yNjY2NDItLjM3NTYyLS41OTk5NDUtLjY3MzkwNy0xLjAxMTAxOS0uOTA1OTA3LS40MTEwNzQtLjIzMi0uODk5OTE4LS4zNTM1MjUtMS40NTU0MjMtLjM1MzUyNS0uNTU1NTA1IDAtMS4wNDQzNS4xMjE1MjQtMS40NTU0MjQuMzUzNTI1LS40MTEwNzMuMjMyLS43NDQzNzYuNTQxMzM0LTEuMDExMDE5LjkwNTkwNy0uMjY2NjQyLjM3NTYyLS40NTU1MTQuNzk1NDMtLjU4ODgzNSAxLjI4MTUyNi0uMTIyMjExLjQ4NjA5Ny0uMTg4ODcyLjk2MTE0NS0uMTg4ODcyIDEuNDQ3MjQyIDAgLjQ5NzE0NC4wNjY2Ni45ODMyNC4xODg4NzIgMS40NTgyODkuMTIyMjEuNDc1MDQ5LjMyMjE5My45MDU5MDcuNTg4ODM1IDEuMjgxNTI3LjI2NjY0My4zNzU2Mi41OTk5NDYuNjg0OTU0IDEuMDExMDIuOTE2OTU0LjQxMTA3My4yNDMwNDguODk5OTE4LjM1MzUyNSAxLjQ1NTQyMy4zNTM1MjV6bTYuNDg4My05LjY2NjY5aDEuODk5ODI3di0zLjQwMjY3NGgyLjUxMDg4M3YzLjQwMjY3NWgyLjI2NjQ2djEuODY3MDUyaC0yLjI2NjQ2djYuMDU0MTA5YzAgLjI2NTE0My4wMTExMS40ODYwOTYuMDMzMzMuNjg0OTU0LjAyMjIyLjE4NzgxLjA3Nzc3LjM1MzUyNC4xNTU1NDEuNDg2MDk2LjA3Nzc3MS4xMzI1NzIuMTk5OTgyLjIzMi4zNjY2MzQuMjk4Mjg3LjE2NjY1MS4wNjYyODUuMzc3NzQzLjA5OTQyOC42NjY2MDYuMDk5NDI4LjE3Nzc2MiAwIC4zNTU1MjMgMCAuNTMzMjg1LS4wMTEwNDcuMTc3NzYyLS4wMTEwNDguMzU1NTIzLS4wMzMxNDMuNTMzMjg1LS4wNzczMzR2MS45MzMzMzhjLS4yNzc3NTMuMDMzMTQzLS41NTU1MDUuMDU1MjM4LS44MTEwMzguMDg4MzgxLS4yNjY2NDIuMDMzMTQzLS41MzMyODUuMDQ0MTktLjgxMTAzNy4wNDQxOS0uNjY2NjA2IDAtMS4xOTk4OTEtLjA2NjI4NS0xLjU5OTg1NS0uMTg3ODEtLjM5OTk2My0uMTIxNTIzLS43MjIxNTYtLjMwOTMzMy0uOTQ0MzU4LS41NTIzODEtLjIzMzMxMy0uMjQzMDQ5LS4zNzc3NDQtLjU0MTMzNS0uNDY2NjI1LS45MDU5MDctLjA3Nzc3LS4zNjQ1NzMtLjEzMzMyMS0uNzg0MzgzLS4xNDQ0MzEtMS4yNDgzODR2LTYuNjgzODI1aC0xLjg5OTgyN3YtMS44ODkxNDdoLS4wMjIyMnpcIiBmaWxsPVwiIzE5MTkxOVwiLz5cbiAgICAgIDxwYXRoIGNsYXNzPVwidHAtbG9nb19fc3RhclwiIGZpbGw9XCIjMDBCNjdBXCIgZD1cIk0zMC4xNDE3MDcgMTEuMDcwMDVIMTguNjMxNjRMMTUuMDc2NDA4LjE3NzA3MWwtMy41NjYzNDIgMTAuODkyOTc3TDAgMTEuMDU5MDAybDkuMzIxMzc2IDYuNzM5MDYzLTMuNTY2MzQzIDEwLjg4MTkzIDkuMzIxMzc1LTYuNzI4MDE2IDkuMzEwMjY2IDYuNzI4MDE2LTMuNTU1MjMzLTEwLjg4MTkzIDkuMzEwMjY2LTYuNzI4MDE2elwiLz5cbiAgICAgIDxwYXRoIGNsYXNzPVwidHAtbG9nb19fc3Rhci1ub3RjaFwiIGZpbGw9XCIjMDA1MTI4XCIgZD1cIk0yMS42MzEzNjkgMjAuMjYxNjlsLS43OTk5MjgtMi40NjM2MjUtNS43NTUwMzMgNC4xNTM5MTR6XCIvPlxuICA8L3N2Zz5gO1xuXG5jb25zdCBhcnJvd1NsaWRlciA9IChkaW1lbnNpb25zKSA9PiBgXG4gIDxzdmcgdmlld0JveD1cIjAgMCAke2RpbWVuc2lvbnMud2lkdGh9ICR7XG4gIGRpbWVuc2lvbnMuaGVpZ2h0XG59XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiICR7c3ZnU2NhbGluZ1N0eWxlfT5cbiAgICAgIDxjaXJjbGUgY2xhc3M9XCJhcnJvdy1zbGlkZXItY2lyY2xlXCIgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiMTEuNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiIzhDOEM4Q1wiLz5cbiAgICAgIDxwYXRoIGNsYXNzPVwiYXJyb3ctc2xpZGVyLXNoYXBlXCIgZmlsbD1cIiM4QzhDOENcIiBkPVwiTTEwLjUwODg4MzUgMTJsMy4zMDgwNTgyLTMuMDI0NTEwNDFjLjI0NDA3NzctLjIyMzE1Njc0LjI0NDA3NzctLjU4NDk2NTMgMC0uODA4MTIyMDQtLjI0NDA3NzYtLjIyMzE1NjczLS42Mzk4MDU4LS4yMjMxNTY3My0uODgzODgzNCAwTDkuMTgzMDU4MjYgMTEuNTk1OTM5Yy0uMjQ0MDc3NjguMjIzMTU2Ny0uMjQ0MDc3NjguNTg0OTY1MyAwIC44MDgxMjJsMy43NTAwMDAwNCAzLjQyODU3MTRjLjI0NDA3NzYuMjIzMTU2OC42Mzk4MDU4LjIyMzE1NjguODgzODgzNCAwIC4yNDQwNzc3LS4yMjMxNTY3LjI0NDA3NzctLjU4NDk2NTMgMC0uODA4MTIyTDEwLjUwODg4MzUgMTJ6XCIvPlxuICA8L3N2Zz5cbmA7XG5cbmNvbnN0IHJlcGx5QXJyb3cgPSAoZGltZW5zaW9ucywgeyBlbGVtZW50Q29sb3IgfSkgPT4gYFxuPHN2ZyB2aWV3Qm94PVwiMCAwICR7ZGltZW5zaW9ucy53aWR0aH0gJHtkaW1lbnNpb25zLmhlaWdodH1cIiB4bWxucz3igJxodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z+KAnCAke3N2Z1NjYWxpbmdTdHlsZX0+XG4gIDxwYXRoIGQ9XCJNNS4yNDA0MDUyNiA4LjYwNzcwNjQ1YzAgLjQwMjc1MDA3LS4yNTU3NjM4Ny41MTMwMDAwOC0uNTcwMDMwOTIuMjQ4MjUwMDRMLjIzNjEzMzggNC45ODUyMDU4M0MuMDg3MTg0MSA0Ljg2OTg2Mzc1IDAgNC42OTIwODY3NyAwIDQuNTAzNzA1NzVzLjA4NzE4NDEtLjM2NjE1OC4yMzYxMzM4LS40ODE1MDAwOEw0LjY3MDM3NDM0LjE0NDcwNTAxYy4zMTUwMTcwOS0uMjY2MjUwMDQuNTcwMDMwOTItLjE1NDUwMDAzLjU3MDAzMDkyLjI0ODI1MDA0VjIuOTk5MjA1NWguNzUwMDQwNjljMi44NjUxNTU0MSAwIDUuMzE1NTM4MzMgMi4zNzQ1MDA0IDUuOTEyNTcwNzIgNC45Mzk1MDA4M2E0LjMzODUzNDggNC4zMzg1MzQ4IDAgMCAxIC4wOTM3NTUwOC41NzgyNTAxYy4wMjI1MDEyMy4yMDAyNTAwNC0uMDc1MDA0MDYuMjQ0NTAwMDQtLjIxODI2MTg0LjEwMzUwMDAyIDAgMC0uMDQwNTAyMi0uMDM2LS4wNzUwMDQwNi0uMDc1MDAwMDFDMTAuMTg2NzM2OTkgNy4wMDc2NjM5OCA4LjE0NjU1NTc5IDYuMDk3Mjc2NjYgNS45ODg5NDU4NiA1Ljk5NTQ1NmgtLjc1MDA0MDY4bC4wMDE1MDAwOCAyLjYxMjI1MDQ1elwiIGZpbGw9XCIke2VsZW1lbnRDb2xvciB8fCAnIzAwQjY3QSd9XCIgZmlsbC1ydWxlPVwiZXZlbm9kZFwiLz5cbjwvc3ZnPlxuYDtcbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiAqL1xuXG4vLyBEZWZpbmUgYSBzZXJpZXMgb2Ygb2JqZWN0cyBjb250YWluaW5nIHdpZHRoIGFuZCBoZWlnaHQgdmFsdWVzLiBUaGVzZSBhcmVcbi8vIHVzZWQgaW4gc2V0dGluZyB0aGUgc3R5bGluZyBvZiB0aGUgU1ZHLCBhbmQgY3JlYXRpbmcgdGhlIGRpdiB3cmFwcGVyIGZvclxuLy8gSUUxMSBzdXBwb3J0LlxuY29uc3Qgc3RhcnNEaW1lbnNpb25zID0geyB3aWR0aDogMjUxLCBoZWlnaHQ6IDQ2IH07XG5jb25zdCBsb2dvRGltZW5zaW9ucyA9IHsgd2lkdGg6IDEyNiwgaGVpZ2h0OiAzMSB9O1xuY29uc3QgYXJyb3dTbGlkZXJEaW1lbnNpb25zID0geyB3aWR0aDogMjQsIGhlaWdodDogMjQgfTtcbmNvbnN0IHJlcGx5QXJyb3dEaW1lbnNpb25zID0geyB3aWR0aDogMTIsIGhlaWdodDogOSB9O1xuXG5jb25zdCBzdmdNYXAgPSB7XG4gIHN0YXJzOiAocHJvcHMpID0+IHdyYXBTdmcoc3RhcnNEaW1lbnNpb25zLCBzdGFycywgcHJvcHMpLFxuICBsb2dvOiAoKSA9PiB3cmFwU3ZnKGxvZ29EaW1lbnNpb25zLCBsb2dvKSxcbiAgYXJyb3dTbGlkZXI6ICgpID0+IHdyYXBTdmcoYXJyb3dTbGlkZXJEaW1lbnNpb25zLCBhcnJvd1NsaWRlciksXG4gIHJlcGx5QXJyb3c6IChwcm9wcykgPT4gd3JhcFN2ZyhyZXBseUFycm93RGltZW5zaW9ucywgcmVwbHlBcnJvdywgcHJvcHMpLFxufTtcblxuZXhwb3J0IHsgc3ZnTWFwIH07XG4iLCJpbXBvcnQgbG9jYWxlcyBmcm9tICcuLi9sb2NhbGl6YXRpb24nO1xuXG5jb25zdCBkZWZhdWx0TG9jYWxlID0gJ2VuLVVTJztcblxuY29uc3QgTE9DQUxFX0RJVklERVIgPSAnLSc7XG5cbmNvbnN0IGxhbmd1YWdlVG9Db3VudHJ5TWFwID0ge1xuICAnZGEnOiAnREsnLFxuICAnZW4nOiAnVVMnLFxuICAnamEnOiAnSlAnLFxuICAnbmInOiAnTk8nLFxuICAnc3YnOiAnU0UnLFxuICAvLyBvdGhlciBsYW5ndWFnZXMgYXNzdW1lZCB0byBoYXZlIHRoZSBzYW1lIGNvdW50cnkgY29kZSBhcyB0aGUgbGFuZ3VhZ2UgY29kZSBpdHNlbGZcbn07XG5cbi8qKlxuICogVHJpZXMgdG8gZmluZCB0aGUgY291bnRyeSBmb3IgdGhlIGdpdmVuIGxhbmd1YWdlLlxuICogSWYgbm8gY291bnRyeSBpcyBmb3VuZCwgdGhlIGxhbmd1YWdlIGl0c2VsZiBpcyByZXR1cm5lZC5cbiAqIEFjdHMgYXMgYSBzYWZldHkgbWVjaGFuaXNtIGZvciB0cmFuc2xhdGlvbnMgd2hlbiBvbmx5IHRoZSBsYW5ndWFnZSBwYXJ0IGlzIHByZXNlbnQgaW4gdGhlIGdpdmVuIGxvY2FsZS5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gbGFuZ3VhZ2UgdGhlIGxhbmd1YWdlIGZvciB3aGljaCB0aGUgY291bnRyeSBzaG91bGQgYmUgZm91bmQuXG4gKi9cbmNvbnN0IHRyeUdldENvdW50cnlGb3JMYW5ndWFnZSA9IChsYW5ndWFnZSkgPT4ge1xuICBjb25zdCBjb3VudHJ5ID0gbGFuZ3VhZ2VUb0NvdW50cnlNYXBbbGFuZ3VhZ2VdIHx8IGxhbmd1YWdlO1xuICByZXR1cm4gY291bnRyeTtcbn07XG5cbmNvbnN0IGZvcm1hdExvY2FsZSA9IChsb2NhbGUpID0+IHtcbiAgY29uc3QgbG9jYWxlUGFydHMgPSBsb2NhbGUuc3BsaXQoTE9DQUxFX0RJVklERVIpO1xuICBjb25zdCBsYW5ndWFnZSA9IGxvY2FsZVBhcnRzWzBdO1xuICBsZXQgY291bnRyeSA9IGxvY2FsZVBhcnRzWzFdO1xuXG4gIGlmICghY291bnRyeSkge1xuICAgIGNvdW50cnkgPSB0cnlHZXRDb3VudHJ5Rm9yTGFuZ3VhZ2UobGFuZ3VhZ2UpO1xuICB9XG5cbiAgcmV0dXJuIGxhbmd1YWdlICYmIGNvdW50cnlcbiAgICA/IGAke2xhbmd1YWdlfSR7TE9DQUxFX0RJVklERVJ9JHtjb3VudHJ5LnRvVXBwZXJDYXNlKCl9YFxuICAgIDogZGVmYXVsdExvY2FsZTtcbn07XG5cbmNvbnN0IGdldEZyYW1ld29ya1RyYW5zbGF0aW9uID0gKGtleSwgbG9jYWxlID0gZGVmYXVsdExvY2FsZSwgaW50ZXJwb2xhdGlvbnMgPSB7fSkgPT4ge1xuICBjb25zdCB0cmFuc2xhdGlvblRhYmxlID0gbG9jYWxlc1tmb3JtYXRMb2NhbGUobG9jYWxlKV0gfHwgbG9jYWxlc1tkZWZhdWx0TG9jYWxlXTtcbiAgY29uc3QgcmF3VHJhbnNsYXRpb24gPSBrZXkuc3BsaXQoJy4nKS5yZWR1Y2UoKGEsIGIpID0+IGFbYl0sIHRyYW5zbGF0aW9uVGFibGUpO1xuICBjb25zdCB0cmFuc2xhdGlvbiA9IE9iamVjdC5rZXlzKGludGVycG9sYXRpb25zKS5yZWR1Y2UoXG4gICAgKHZhbHVlLCBrZXkpID0+IHZhbHVlLnJlcGxhY2Uoa2V5LCBpbnRlcnBvbGF0aW9uc1trZXldKSxcbiAgICByYXdUcmFuc2xhdGlvblxuICApO1xuXG4gIHJldHVybiB0cmFuc2xhdGlvbjtcbn07XG5cbmV4cG9ydCB7IGRlZmF1bHRMb2NhbGUsIGZvcm1hdExvY2FsZSwgZ2V0RnJhbWV3b3JrVHJhbnNsYXRpb24gfTtcbiIsImltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tICcuLi91dGlscyc7XG5pbXBvcnQgeyBhZGRDbGFzcywgcmVtb3ZlQ2xhc3MgfSBmcm9tICcuLi9kb20nO1xuaW1wb3J0IENvbnRyb2xzIGZyb20gJy4vY29udHJvbHMnO1xuXG4vKipcbiAqIFRoZSBBcnJvd0NvbnRyb2xzIGNsYXNzIHByb3ZpZGVzIGxvZ2ljIGZvciBjb250cm9sbGluZyBhIHNsaWRpbmcgcmV2aWV3XG4gKiBjYXJvdXNlbCB3aXRoIHByZXZpb3VzL25leHQgcGFnZSBidXR0b25zLlxuICpcbiAqIFRvIHVzZSBBcnJvd0NvbnRyb2xzLCBjb25zdHJ1Y3QgYW4gaW5zdGFuY2Ugb2YgaXQgYW5kIHRoZW4gY2FsbFxuICoge0BsaW5rIEFycm93Q29udHJvbHMjaW5pdGlhbGl6ZX0uXG4gKi9cbmNsYXNzIEFycm93Q29udHJvbHMgZXh0ZW5kcyBDb250cm9scyB7XG4gIC8qKlxuICAgKiBDcmVhdGUgYW4gQXJyb3dDb250cm9scyBpbnN0YW5jZS5cbiAgICpcbiAgICogQHBhcmFtIHtSZXZpZXdTbGlkZXJ9IHNsaWRlciAtIFRoZSBSZXZpZXdTbGlkZXIgdG8gd2hpY2ggdG8gYXR0YWNoIGNvbnRyb2xzLlxuICAgKiBAcGFyYW0ge09iamVjdH0gZWxlbWVudHMgLSBET00gZWxlbWVudHMgZm9yIHRoZSBjb250cm9scy5cbiAgICogQHBhcmFtIHtIVE1MRWxlbWVudH0gZWxlbWVudHMucHJldkFycm93IC0gVGhlIHByZXZpb3VzIGFycm93IGVsZW1lbnQuXG4gICAqIEBwYXJhbSB7SFRNTEVsZW1lbnR9IGVsZW1lbnRzLm5leHRBcnJvdyAtIFRoZSBuZXh0IGFycm93IGVsZW1lbnQuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucz17fV0gLSBPcHRpb25zIGZvciB0aGUgY29udHJvbHMuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucy5jYWxsYmFja3NdIC0gQ2FsbGJhY2tzIHRvIHRyaWdnZXIgYWZ0ZXIgY2xpY2tpbmcgYSBjb250cm9sLlxuICAgKiBAcGFyYW0ge2NhbGxiYWNrfSBbb3B0aW9ucy5jYWxsYmFja3MucHJldlBhZ2VdIC0gQ2FsbGJhY2sgdG8gdHJpZ2dlciBvbiBjbGlja2luZ1xuICAgKiB0aGUgcHJldmlvdXMgYXJyb3cuXG4gICAqIEBwYXJhbSB7Y2FsbGJhY2t9IFtvcHRpb25zLmNhbGxiYWNrcy5uZXh0UGFnZV0gLSBDYWxsYmFjayB0byB0cmlnZ2VyIG9uIGNsaWNraW5nXG4gICAqIHRoZSBuZXh0IGFycm93LlxuICAgKiBAcGFyYW0ge3N0cmluZ30gW29wdGlvbnMuZGlzYWJsZWRDbGFzc10gLSBUaGUgY2xhc3MgdG8gc2V0IG9uIGRpc2FibGVkIGNvbnRyb2xzLlxuICAgKi9cbiAgY29uc3RydWN0b3Ioc2xpZGVyLCBlbGVtZW50cywgb3B0aW9ucyA9IHt9KSB7XG4gICAgc3VwZXIoc2xpZGVyLCBlbGVtZW50cyk7XG4gICAgdGhpcy5jYWxsYmFja3MgPSBvcHRpb25zLmNhbGxiYWNrcyB8fCB7fTtcbiAgICB0aGlzLmRpc2FibGVkQ2xhc3MgPSBvcHRpb25zLmRpc2FibGVkQ2xhc3M7XG4gIH1cblxuICBhdHRhY2hMaXN0ZW5lcnMoKSB7XG4gICAgY29uc3Qgbm9PcCA9ICgpID0+IHt9O1xuICAgIGNvbnN0IHsgcHJldkFycm93LCBuZXh0QXJyb3cgfSA9IHRoaXMuZWxlbWVudHM7XG4gICAgY29uc3QgeyBwcmV2UGFnZSA9IG5vT3AsIG5leHRQYWdlID0gbm9PcCB9ID0gdGhpcy5jYWxsYmFja3M7XG4gICAgYWRkRXZlbnRMaXN0ZW5lcihwcmV2QXJyb3csICdjbGljaycsICgpID0+IHtcbiAgICAgIHRoaXMuc2xpZGVyLm1vdmVDb250ZW50KC0xKTtcbiAgICAgIHByZXZQYWdlKCk7XG4gICAgfSk7XG4gICAgYWRkRXZlbnRMaXN0ZW5lcihuZXh0QXJyb3csICdjbGljaycsICgpID0+IHtcbiAgICAgIHRoaXMuc2xpZGVyLm1vdmVDb250ZW50KDEpO1xuICAgICAgbmV4dFBhZ2UoKTtcbiAgICB9KTtcbiAgfVxuXG4gIHN0eWxlQXJyb3coZWxlbSwgaXNEaXNhYmxlZCkge1xuICAgIGNvbnN0IGRpc2FibGVkQ2xhc3MgPSB0aGlzLmRpc2FibGVkQ2xhc3M7XG4gICAgaWYgKGlzRGlzYWJsZWQpIHtcbiAgICAgIGFkZENsYXNzKGVsZW0sIGRpc2FibGVkQ2xhc3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZW1vdmVDbGFzcyhlbGVtLCBkaXNhYmxlZENsYXNzKTtcbiAgICB9XG4gIH1cblxuICBzdHlsZUFycm93cygpIHtcbiAgICBjb25zdCB7IHByZXZBcnJvdywgbmV4dEFycm93IH0gPSB0aGlzLmVsZW1lbnRzO1xuICAgIHRoaXMuc3R5bGVBcnJvdyhwcmV2QXJyb3csIHRoaXMuc2xpZGVyLmlzQXRGaXJzdFBhZ2UoKSk7XG4gICAgdGhpcy5zdHlsZUFycm93KG5leHRBcnJvdywgdGhpcy5zbGlkZXIuaXNBdExhc3RQYWdlKCkpO1xuICB9XG5cbiAgb25VcGRhdGUoKSB7XG4gICAgdGhpcy5zdHlsZUFycm93cygpO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFycm93Q29udHJvbHM7XG4iLCIvKipcbiAqIFRoZSBDb250cm9scyBjbGFzcyBpcyBhbiBhYnN0cmFjdCBiYXNlIGNsYXNzIGZvciBjb25jcmV0ZSBjb250cm9scyB0byB1c2UuXG4gKlxuICogQSBudW1iZXIgb2YgcmVxdWlyZWQgbWV0aG9kcyBhcmUgZGVmaW5lZCwgdG9nZXRoZXIgd2l0aCBhIGRlZmF1bHRcbiAqIGltcGxlbWVudGF0b24gb2YgdGhlIHtAbGluayBDb250cm9scyNpbml0aWFsaXplfSBtZXRob2QuIFRoZXNlIHJlcXVpcmVkIG1ldGhvZHNcbiAqIGFyZSB1c2VkIHRvIHVwZGF0ZSB0aGUgY29udHJvbHMgb24gYSBjaGFuZ2UgdGFraW5nIHBsYWNlIHdpdGhpbiB0aGUgc2xpZGVyLFxuICogYW5kIG11c3QgYmUgaW1wbGVtZW50ZWQuIEJ5IGRlZmF1bHQsIHRoZSBwYWdlIGNoYW5nZSBhbmQgcmVzaXplIGV2ZW50cyBhcmVcbiAqIGJvdGggaGFuZGxlZCBieSB0aGUge0BsaW5rIENvbnRyb2xzI29uVXBkYXRlfSBtZXRob2QuXG4gKi9cbmNsYXNzIENvbnRyb2xzIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIENvbnRyb2xzIGluc3RhbmNlLlxuICAgKlxuICAgKiBAcGFyYW0ge1Jldmlld1NsaWRlcn0gc2xpZGVyIC0gVGhlIFJldmlld1NsaWRlciB0byB3aGljaCB0byBhdHRhY2ggY29udHJvbHMuXG4gICAqIEBwYXJhbSB7T2JqZWN0fEFycmF5fSBlbGVtZW50cyAtIERPTSBlbGVtZW50cyBmb3IgdGhlIGNvbnRyb2xzLlxuICAgKi9cbiAgY29uc3RydWN0b3Ioc2xpZGVyLCBlbGVtZW50cykge1xuICAgIHRoaXMuc2xpZGVyID0gc2xpZGVyO1xuICAgIHRoaXMuZWxlbWVudHMgPSBlbGVtZW50cztcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplIHRoaXMgQ29udHJvbHMgaW5zdGFuY2UuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIGF0dGFjaGVzIGxpc3RlbmVyIGNhbGxiYWNrcyB0byB0aGUgY29udHJvbCBlbGVtZW50cyBhbmRcbiAgICogYXR0YWNoZXMgdGhlIGNvbnRyb2xzIHRoZW1zZWx2ZXMgdG8gdGhlIHNsaWRlciBhbmQgaW5pdGlhbGl6ZXMgdGhhdC5cbiAgICovXG4gIGluaXRpYWxpemUoKSB7XG4gICAgdGhpcy5hdHRhY2hMaXN0ZW5lcnMoKTtcbiAgICB0aGlzLnNsaWRlci5hdHRhY2hPYnNlcnZlcih0aGlzKTtcbiAgICB0aGlzLnNsaWRlci5pbml0aWFsaXplKCk7XG4gICAgdGhpcy5vblVwZGF0ZSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIEludGVuZGVkIHRvIGJlIHVzZWQgdG8gYXR0YWNoIGNhbGxiYWNrcyB0byBldmVudHMgb24gdGhlIGFzc29jaWF0ZWQgY29udHJvbFxuICAgKiBlbGVtZW50cy5cbiAgICovXG4gIGF0dGFjaExpc3RlbmVycygpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ2F0dGFjaExpc3RlbmVycyBtZXRob2Qgbm90IHlldCBpbXBsZW1lbnRlZCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGxlZCB1cG9uIGluaXRpYWxpemF0aW9uLCBhbmQgd2hlcmUgYSBwYWdlIGNoYW5nZSBvciByZXNpemUgZXZlbnQgb2NjdXJzXG4gICAqIGluIHRoZSBzbGlkZXIuXG4gICAqL1xuICBvblVwZGF0ZSgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ29uVXBkYXRlIG1ldGhvZCBub3QgeWV0IGltcGxlbWVudGVkJyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbGVkIGJ5IHRoZSBhc3NvY2lhdGVkIHNsaWRlciB3aGVuIGl0IGVuY291bnRlcnMgYSBwYWdlIGNoYW5nZSBldmVudC5cbiAgICovXG4gIG9uUGFnZUNoYW5nZSgpIHtcbiAgICB0aGlzLm9uVXBkYXRlKCk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbGVkIGJ5IHRoZSBhc3NvY2lhdGVkIHNsaWRlciB3aGVuIGl0IGVuY291bnRlcnMgYSByZXNpemUgZXZlbnQuXG4gICAqL1xuICBvblJlc2l6ZSgpIHtcbiAgICB0aGlzLm9uVXBkYXRlKCk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQ29udHJvbHM7XG4iLCJpbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnLi4vdXRpbHMnO1xuaW1wb3J0IHsgYWRkQ2xhc3MsIHJlbW92ZUNsYXNzIH0gZnJvbSAnLi4vZG9tJztcbmltcG9ydCBDb250cm9scyBmcm9tICcuL2NvbnRyb2xzJztcblxuLyoqXG4gKiBUaGUgUGFnaW5hdGlvbkNvbnRyb2xzIGNsYXNzIHByb3ZpZGVzIGxvZ2ljIGZvciBjb250cm9sbGluZyBhIHNsaWRpbmcgcmV2aWV3XG4gKiBjYXJvdXNlbCB3aXRoIHBhZ2Ugc2VsZWN0aW9uIGJ1dHRvbnMuXG4gKlxuICogVG8gdXNlIFBhZ2luYXRpb25Db250cm9scywgY29uc3RydWN0IGFuIGluc3RhbmNlIG9mIGl0IGFuZCB0aGVuIGNhbGxcbiAqIHtAbGluayBQYWdpbmF0aW9uQ29udHJvbHMjaW5pdGlhbGl6ZX0uXG4gKi9cbmNsYXNzIFBhZ2luYXRpb25Db250cm9scyBleHRlbmRzIENvbnRyb2xzIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhbiBQYWdpbmF0aW9uQ29udHJvbHMgaW5zdGFuY2UuXG4gICAqXG4gICAqIEFuIGFycmF5IG9mIGVsZW1lbnRzIGlzIHJlcXVpcmVkLCB3aXRoIGVsZW1lbnQgeCB0cmlnZ2VyaW5nIGEgcGFnZSBjaGFuZ2VcbiAgICogdG8gcGFnZSB4KzEuIEFuIGFycmF5IG9mIGNhbGxiYWNrcyBpcyBvcHRpb25hbCwgZWFjaCBvZiB3aGljaCBjb3JyZXNwb25kXG4gICAqIHRvIGFuIGVsZW1lbnQgb24gdGhlIHBhZ2UsIGkuZS4gY2FsbGJhY2sgeCBpcyB0cmlnZ2VyIGJ5IGNsaWNraW5nIGVsZW1lbnRcbiAgICogeC5cbiAgICpcbiAgICogQHBhcmFtIHtSZXZpZXdTbGlkZXJ9IHNsaWRlciAtIFRoZSBSZXZpZXdTbGlkZXIgdG8gd2hpY2ggdG8gYXR0YWNoIGNvbnRyb2xzLlxuICAgKiBAcGFyYW0ge09iamVjdFtdfSBlbGVtZW50cyAtIERPTSBlbGVtZW50cyBmb3IgdGhlIGNvbnRyb2xzLlxuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnM9e31dIC0gT3B0aW9ucyBmb3IgdGhlIGNvbnRyb2xzLlxuICAgKiBAcGFyYW0ge0FycmF5fSBbb3B0aW9ucy5jYWxsYmFja3NdIC0gQ2FsbGJhY2tzIHRvIHRyaWdnZXIgYWZ0ZXIgY2xpY2tpbmcgYSBjb250cm9sLlxuICAgKiBAcGFyYW0ge3N0cmluZ30gW29wdGlvbnMuYWN0aXZlQ2xhc3NdIC0gVGhlIGNsYXNzIHRvIHNldCBvbiB0aGUgYWN0aXZlIGNvbnRyb2wuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihzbGlkZXIsIGVsZW1lbnRzLCBvcHRpb25zID0ge30pIHtcbiAgICBzdXBlcihzbGlkZXIsIGVsZW1lbnRzKTtcbiAgICB0aGlzLmNhbGxiYWNrcyA9IG9wdGlvbnMuY2FsbGJhY2tzIHx8IFtdO1xuICAgIHRoaXMuYWN0aXZlQ2xhc3MgPSBvcHRpb25zLmFjdGl2ZUNsYXNzO1xuICB9XG5cbiAgYXR0YWNoTGlzdGVuZXJzKCkge1xuICAgIGNvbnN0IHBhZ2luYXRpb24gPSB0aGlzLmVsZW1lbnRzO1xuICAgIGNvbnN0IG5vT3AgPSAoKSA9PiB7fTtcbiAgICBwYWdpbmF0aW9uLmZvckVhY2goKGVsZW0sIGluZGV4KSA9PiB7XG4gICAgICBpZiAoaW5kZXggPT09IDApIHtcbiAgICAgICAgYWRkQ2xhc3MoZWxlbSwgdGhpcy5hY3RpdmVDbGFzcyk7XG4gICAgICB9XG4gICAgICBhZGRFdmVudExpc3RlbmVyKGVsZW0sICdjbGljaycsICgpID0+IHtcbiAgICAgICAgdGhpcy5zbGlkZXIuanVtcFRvUGFnZShpbmRleCArIDEpO1xuICAgICAgICBjb25zdCBjYWxsYmFjayA9IHRoaXMuY2FsbGJhY2tzW2luZGV4XSB8fCBub09wO1xuICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICBvblVwZGF0ZSgpIHtcbiAgICBjb25zdCBwYWdpbmF0aW9uID0gdGhpcy5lbGVtZW50cztcbiAgICBwYWdpbmF0aW9uLmZvckVhY2goKGVsZW0sIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBpc0FjdGl2ZSA9IHRoaXMuc2xpZGVyLmN1cnJlbnRQYWdlID09PSBpbmRleCArIDE7XG4gICAgICBpZiAoaXNBY3RpdmUpIHtcbiAgICAgICAgYWRkQ2xhc3MoZWxlbSwgdGhpcy5hY3RpdmVDbGFzcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZW1vdmVDbGFzcyhlbGVtLCB0aGlzLmFjdGl2ZUNsYXNzKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBQYWdpbmF0aW9uQ29udHJvbHM7XG4iLCJpbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnLi4vdXRpbHMnO1xuaW1wb3J0IHsgVHJ1c3RCb3hlc1RvdWNoIH0gZnJvbSAnLi4vdG91Y2gnO1xuY29uc3QgY2xhbXAgPSAodmFsLCBtaW4sIG1heCkgPT4gTWF0aC5tYXgoTWF0aC5taW4odmFsLCBtYXgpLCBtaW4pO1xuLyoqXG4gKiBUaGUgUmV2aWV3U2xpZGVyIGNsYXNzIHByb3ZpZGVzIGxvZ2ljIGZvciBoYW5kbGluZyBzbGlkaW5nIHJldmlldyBjYXJvdXNlbFxuICogZWxlbWVudHMuXG4gKlxuICogQSByZXZpZXcgY2Fyb3VzZWwgaXMgYSBzZXJpZXMgb2YgSFRNTCBlbGVtZW50cyB1c2VkIHRvIGNvbnRhaW4gYW5kIGRpc3BsYXlcbiAqIHJldmlld3Mgd2l0aGluIGEgVHJ1c3RCb3guIEEgUmV2aWV3U2xpZGVyIGluc3RhbmNlIGV4cGVjdHMgY2VydGFpbiBIVE1MXG4gKiBlbGVtZW50cyB3aXRoaW4gdGhlIERPTTogYSBcInNsaWRlclwiIGVsZW1lbnQ7IGEgY29udGFpbmVyIGVsZW1lbnQgZm9yIHRoZVxuICogc2xpZGVyOyBhbmQgYSBsaXN0IG9mIHJldmlldyBlbGVtZW50cy4gKFNlZSB7QGxpbmsgUmV2aWV3U2xpZGVyI2NvbnN0cnVjdG9yfVxuICogb24gaG93IHRoZXNlIGVsZW1lbnRzIGFyZSBwcm92aWRlZCB0byB0aGUgUmV2aWV3U2xpZGVyLilcbiAqXG4gKiBUbyB1c2UgYSBSZXZpZXdTbGlkZXIsIGZpcnN0IGNvbnN0cnVjdCBhbiBpbnN0YW5jZSBvZiBpdC4gVGhlbiwgaWYgY29udHJvbHNcbiAqIGFyZSByZXF1aXJlZCwgY29uc3RydWN0IGFuIGluc3RhbmNlIG9mIG9uZSBvZiB0aGUgY29udHJvbHMgY2xhc3NlcyAoc2VlXG4gKiB7QGxpbmsgQXJyb3dDb250cm9sc30gYW5kIHtAbGluayBQYWdpbmF0aW9uQ29udHJvbHN9KSBhbmQgZm9sbG93aW5nIHRoZWlyXG4gKiBpbnN0cnVjdGlvbnMgZm9yIGluaXRpYWxpemF0aW9uLiBJZiBjb250cm9scyBhcmUgbm90IHJlcXVpcmVkLCBzaW1wbHkgY2FsbFxuICoge0BsaW5rIFJldmlld1NsaWRlciNpbml0aWFsaXplfS5cbiAqL1xuY2xhc3MgUmV2aWV3U2xpZGVyIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIFJldmlld1NsaWRlciBpbnN0YW5jZS5cbiAgICpcbiAgICogQHBhcmFtIHtPYmplY3RbXX0gcmV2aWV3cyAtIFJldmlld3MgdG8gYmUgZGlzcGxheWVkIGluIHRoZSBzbGlkZXIuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBlbGVtZW50cyAtIERPTSBlbGVtZW50cyBmb3IgdGhlIHNsaWRlci5cbiAgICogQHBhcmFtIHtIVE1MRWxlbWVudH0gZWxlbWVudHMuc2xpZGVyIC0gVGhlIHNsaWRlciBlbGVtZW50LlxuICAgKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBlbGVtZW50cy5zbGlkZXJDb250YWluZXIgLSBUaGUgY29udGFpbmVyIGZvciB0aGUgc2xpZGVyLlxuICAgKiBAcGFyYW0ge0NhbGxiYWNrfSB0ZW1wbGF0ZSAtIGZ1bmN0aW9uIHdoaWNoIGdlbmVyYXRlcyBIVE1MIGZvciBhIHJldmlldy5cbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zPXt9XSAtIE9wdGlvbnMgZm9yIHRoZSBzbGlkZXIuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy5yZXZpZXdDbGFzc10gLSBUaGUgY2xhc3MgbmFtZSBmb3IgYSByZXZpZXcgZWxlbWVudC5cbiAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRpb25zLnRyYW5zaXRpb25DbGFzc10gLSBUaGUgY2xhc3MgbmFtZSBmb3IgZWxlbWVudHNcbiAgICogd2l0aCBhIHNsaWRpbmcgYW5pbWF0aW9uL3RyYW5zaXRpb24uXG4gICAqIEBwYXJhbSB7aW50fE9iamVjdFtdfSBbb3B0aW9ucy5yZXZpZXdzUGVyUGFnZV0gLSBFaXRoZXIgdGhlIG51bWJlciBvZlxuICAgKiByZXZpZXdzIHRvIGRpc3BsYXkgcGVyIHBhZ2UsIG9yIGEgbGlzdCBvZiBvYmplY3RzIGNvbnRhaW5pbmcgYnJlYWtwb2ludHNcbiAgICogd2l0aCBhc3NvY2lhdGVkIHJldmlldyBjb3VudHMgKHNlZSB7QGxpbmsgUmV2aWV3U2xpZGVyI3NldFJldmlld3NQZXJQYWdlfSkuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihyZXZpZXdzLCBlbGVtZW50cywgdGVtcGxhdGUsIG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMucmV2aWV3cyA9IHJldmlld3M7XG4gICAgdGhpcy5lbGVtZW50cyA9IGVsZW1lbnRzO1xuICAgIHRoaXMucmV2aWV3Q291bnQgPSByZXZpZXdzLmxlbmd0aDtcbiAgICB0aGlzLnRlbXBsYXRlID0gdGVtcGxhdGU7XG4gICAgdGhpcy5yZXZpZXdDbGFzcyA9IG9wdGlvbnMucmV2aWV3Q2xhc3M7XG4gICAgdGhpcy5zZXRSZXZpZXdzUGVyUGFnZShvcHRpb25zLnJldmlld3NQZXJQYWdlKTtcbiAgICB0aGlzLmN1cnJlbnRQYWdlID0gMTtcbiAgICB0aGlzLnJlc2l6ZVRpbWVvdXQgPSBudWxsO1xuICAgIHRoaXMub2JzZXJ2ZXJzID0gW107XG4gICAgdGhpcy5pc0luaXRpYWxpemVkID0gZmFsc2U7XG5cbiAgICAvLyBUb3VjaCBjYWxsYmFja3NcblxuICAgIHRoaXMudG91Y2hTdGFydENhbGxiYWNrID0gKHsgdHJhbnNsYXRlWCwgb3JpZ2luUGFnZSB9KSA9PiB7XG4gICAgICB0aGlzLnNldFNsaWRlclRyYW5zaXRpb25EdXJhdGlvbigwKTtcbiAgICAgIHRoaXMuc2V0U2xpZGVyVHJhbnNsYXRlWCh0cmFuc2xhdGVYKTtcbiAgICAgIHRoaXMuY3VycmVudFBhZ2UgPSBvcmlnaW5QYWdlO1xuICAgIH07XG4gICAgdGhpcy50b3VjaE1vdmVDYWxsYmFjayA9ICh7IHRyYW5zbGF0ZVggfSkgPT4ge1xuICAgICAgdGhpcy5zZXRTbGlkZXJUcmFuc2xhdGVYKHRyYW5zbGF0ZVgpO1xuICAgIH07XG4gICAgdGhpcy50b3VjaEVuZENhbGxiYWNrID0gKHsgcGFnZXNUb1N3aXBlLCB0cmFuc2l0aW9uRHVyYXRpb24gfSkgPT4ge1xuICAgICAgdGhpcy5tb3ZlQ29udGVudChwYWdlc1RvU3dpcGUsIGNsYW1wKHRyYW5zaXRpb25EdXJhdGlvbiwgMC4yLCAxKSk7XG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHJldmlld3NQZXJQYWdlIHByb3BlcnR5LlxuICAgKlxuICAgKiBAcGFyYW0ge2ludHxPYmplY3RbXX0gcmV2aWV3c1BlclBhZ2UgLSBFaXRoZXIgdGhlIG51bWJlciBvZiByZXZpZXdzIHRvXG4gICAqIGRpc3BsYXkgcGVyIHBhZ2UsIG9yIGEgbGlzdCBvZiBvYmplY3RzIGNvbnRhaW5pbmcgYnJlYWtwb2ludHMgd2l0aFxuICAgKiBhc3NvY2lhdGVkIHJldmlldyBjb3VudHMuIEluIHRoZSBjYXNlIG9mIHRoZSBsYXR0ZXIsIGVhY2ggb2JqZWN0IG11c3RcbiAgICogY29udGFpbiBhIG1pbldpZHRoIGFuZCBhIHJldmlld3NGb3JXaWR0aCBwcm9wZXJ0eS4gVGhlIG51bWJlciBvZiByZXZpZXdzXG4gICAqIGRpc3BsYXllZCBpcyBlcXVhbCB0byB0aGUgcmV2aWV3c0ZvcldpZHRoIHZhbHVlIGFzc29jaWF0ZWQgd2l0aCB0aGUgbGFyZ2VzdFxuICAgKiBtaW5pbXVtIHdpZHRoIHZhbHVlIGxlc3MgdGhhbiB0aGUgd2lkdGggb2YgdGhlIHNsaWRlckNvbnRhaW5lci5cbiAgICovXG4gIHNldFJldmlld3NQZXJQYWdlKHJldmlld3NQZXJQYWdlKSB7XG4gICAgaWYgKHR5cGVvZiByZXZpZXdzUGVyUGFnZSA9PT0gJ251bWJlcicpIHtcbiAgICAgIHRoaXMucmV2aWV3c1BlclBhZ2UgPSBbeyBtaW5XaWR0aDogMCwgcmV2aWV3c0ZvcldpZHRoOiByZXZpZXdzUGVyUGFnZSB9XTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5yZXZpZXdzUGVyUGFnZSA9IHJldmlld3NQZXJQYWdlO1xuICAgICAgdGhpcy5yZXZpZXdzUGVyUGFnZS5zb3J0KCh7IG1pbldpZHRoOiBhIH0sIHsgbWluV2lkdGg6IGIgfSkgPT4gYiAtIGEpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQb3B1bGF0ZSB0aGUgc2xpZGVyIHdpdGggcmV2aWV3cyB1c2luZyB0aGUgdGVtcGxhdGUuXG4gICAqL1xuICBwb3B1bGF0ZVNsaWRlcigpIHtcbiAgICB0aGlzLmVsZW1lbnRzLnNsaWRlci5pbm5lckhUTUwgPSB0aGlzLnJldmlld3MubWFwKHRoaXMudGVtcGxhdGUuYmluZCh0aGlzKSkuam9pbignJyk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZSB0aGlzIFJldmlld1NsaWRlciBpbnN0YW5jZS5cbiAgICpcbiAgICogVGhpcyBtZXRob2QgYXR0YWNoZXMgdGhpcyBpbnN0YW5jZSB0byB0aGUgc2xpZGVyIGFuZCB3aW5kb3cuIEl0IGF0dGFjaGVzXG4gICAqIGEgdG91Y2ggaGFuZGxlciB0byB0aGUgc2xpZGVyIGFuZCBlbnN1cmVzIHRoZSByZXNpemUgZXZlbnRzIGFyZSBsaXN0ZW5lZFxuICAgKiB0by5cbiAgICovXG4gIGluaXRpYWxpemUoKSB7XG4gICAgaWYgKHRoaXMuaXNJbml0aWFsaXplZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMucG9wdWxhdGVTbGlkZXIoKTtcbiAgICB0aGlzLmNhbGN1bGF0ZVJldmlld3NQZXJQYWdlKCk7XG5cbiAgICB0aGlzLnRvdWNoID0gbmV3IFRydXN0Qm94ZXNUb3VjaCh7XG4gICAgICB0YXJnZXRFbGVtZW50OiB0aGlzLmVsZW1lbnRzLnNsaWRlcixcbiAgICAgIHBhZ2VXaWR0aDogdGhpcy5zbGlkZXJDb250YWluZXJXaWR0aCxcbiAgICAgIHRvdWNoU3RhcnRDYWxsYmFjazogdGhpcy50b3VjaFN0YXJ0Q2FsbGJhY2ssXG4gICAgICB0b3VjaE1vdmVDYWxsYmFjazogdGhpcy50b3VjaE1vdmVDYWxsYmFjayxcbiAgICAgIHRvdWNoRW5kQ2FsbGJhY2s6IHRoaXMudG91Y2hFbmRDYWxsYmFjayxcbiAgICB9KTtcblxuICAgIHRoaXMudG91Y2guYXR0YWNoKCk7XG4gICAgdGhpcy53aW5kb3dSZXNpemUoKTtcbiAgICB0aGlzLmF0dGFjaFJlc2l6ZUxpc3RlbmVyKCk7XG5cbiAgICB0aGlzLmlzSW5pdGlhbGl6ZWQgPSB0cnVlO1xuICB9XG5cbiAgLy8gR2V0dGVycyAmIHByb3BlcnRpZXMgLy9cblxuICBnZXQgdG90YWxQYWdlcygpIHtcbiAgICByZXR1cm4gTWF0aC5jZWlsKHRoaXMucmV2aWV3Q291bnQgLyB0aGlzLl9yZXZpZXdzUGVyUGFnZSk7XG4gIH1cblxuICBnZXQgcmV2aWV3V2lkdGgoKSB7XG4gICAgY29uc3QgeyBsZWZ0LCByaWdodCB9ID0gdGhpcy5yZXZpZXdFbGVtZW50TWFyZ2lucygpO1xuICAgIHJldHVybiB0aGlzLnJldmlld1dpZHRoV2l0aE1hcmdpbnMgLSAobGVmdCArIHJpZ2h0KTtcbiAgfVxuXG4gIGdldCByZXZpZXdXaWR0aFdpdGhNYXJnaW5zKCkge1xuICAgIHJldHVybiB0aGlzLnNsaWRlckNvbnRhaW5lcldpZHRoIC8gdGhpcy5fcmV2aWV3c1BlclBhZ2U7XG4gIH1cblxuICBnZXQgc2xpZGVyQ29udGFpbmVyV2lkdGgoKSB7XG4gICAgY29uc3Qge1xuICAgICAgcmlnaHQ6IGFkanVzdG1lbnRGb3JMYXN0UmlnaHRNYXJnaW4sXG4gICAgICBsZWZ0OiBhZGp1c3RtZW50Rm9yRmlyc3RMZWZ0TWFyZ2luLFxuICAgIH0gPSB0aGlzLnJldmlld0VsZW1lbnRNYXJnaW5zKCk7XG4gICAgcmV0dXJuIChcbiAgICAgICh0aGlzLmVsZW1lbnRzLnNsaWRlckNvbnRhaW5lci5vZmZzZXRXaWR0aCB8fCB0aGlzLl9kZWZhdWx0U2xpZGVyV2lkdGgpICtcbiAgICAgIGFkanVzdG1lbnRGb3JMYXN0UmlnaHRNYXJnaW4gK1xuICAgICAgYWRqdXN0bWVudEZvckZpcnN0TGVmdE1hcmdpblxuICAgICk7XG4gIH1cblxuICBnZXQgcmV2aWV3RWxlbWVudHMoKSB7XG4gICAgcmV0dXJuIFtdLnNsaWNlLmNhbGwodGhpcy5lbGVtZW50cy5zbGlkZXIuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSh0aGlzLnJldmlld0NsYXNzKSk7XG4gIH1cblxuICBnZXRGaXJzdFZpc2libGVSZXZpZXdJbmRleCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmV2aWV3c1BlclBhZ2UgKiAodGhpcy5jdXJyZW50UGFnZSAtIDEpO1xuICB9XG5cbiAgaXNBdEZpcnN0UGFnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5jdXJyZW50UGFnZSA9PT0gMTtcbiAgfVxuXG4gIGlzQXRMYXN0UGFnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5jdXJyZW50UGFnZSA9PT0gdGhpcy50b3RhbFBhZ2VzO1xuICB9XG5cbiAgc2V0U2xpZGVyVHJhbnNsYXRlWChwaXhlbHMpIHtcbiAgICB0aGlzLmVsZW1lbnRzLnNsaWRlci5zdHlsZS50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlWCgke3BpeGVsc31weClgO1xuICB9XG5cbiAgc2V0U2xpZGVyVHJhbnNpdGlvbkR1cmF0aW9uKHNlY29uZHMpIHtcbiAgICB0aGlzLmVsZW1lbnRzLnNsaWRlci5zdHlsZS50cmFuc2l0aW9uRHVyYXRpb24gPSBgJHtzZWNvbmRzfXNgO1xuICB9XG5cbiAgLy8gUmV2aWV3IGNhbGN1bGF0aW9ucyAvL1xuXG4gIHJldmlld0VsZW1lbnRNYXJnaW5zKCkge1xuICAgIGlmICh0aGlzLnJldmlld0VsZW1lbnRzLmxlbmd0aCA9PT0gMCB8fCAhdGhpcy5yZXZpZXdFbGVtZW50c1swXSkge1xuICAgICAgcmV0dXJuIHsgbGVmdDogMCwgcmlnaHQ6IDAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgY29tcHV0ZWRTdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHRoaXMucmV2aWV3RWxlbWVudHNbMF0pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogcGFyc2VJbnQoY29tcHV0ZWRTdHlsZS5tYXJnaW5MZWZ0KSxcbiAgICAgICAgcmlnaHQ6IHBhcnNlSW50KGNvbXB1dGVkU3R5bGUubWFyZ2luUmlnaHQpLFxuICAgICAgfTtcbiAgICB9XG4gIH1cblxuICBjYWxjdWxhdGVSZXZpZXdzUGVyUGFnZSgpIHtcbiAgICBjb25zdCBjdXJyZW50QnJlYWtwb2ludCA9IHRoaXMucmV2aWV3c1BlclBhZ2UucmVkdWNlKFxuICAgICAgKHJldmlld0NvdW50LCB7IG1pbldpZHRoLCByZXZpZXdzRm9yV2lkdGggfSkgPT5cbiAgICAgICAgIXJldmlld0NvdW50ICYmIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aCA+PSBtaW5XaWR0aFxuICAgICAgICAgID8geyBtaW5XaWR0aCwgcmV2aWV3c0ZvcldpZHRoIH1cbiAgICAgICAgICA6IHJldmlld0NvdW50LFxuICAgICAgbnVsbFxuICAgICk7XG4gICAgdGhpcy5fcmV2aWV3c1BlclBhZ2UgPSBjdXJyZW50QnJlYWtwb2ludC5yZXZpZXdzRm9yV2lkdGg7XG4gICAgdGhpcy5fZGVmYXVsdFNsaWRlcldpZHRoID0gY3VycmVudEJyZWFrcG9pbnQubWluV2lkdGg7XG4gIH1cblxuICAvLyBPYnNlcnZlciBtZXRob2RzIC8vXG5cbiAgYXR0YWNoT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcbiAgICB0aGlzLm9ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcbiAgfVxuXG4gIGRldGFjaE9ic2VydmVyKG9ic2VydmVyKSB7XG4gICAgdGhpcy5vYnNlcnZlcnMgPSB0aGlzLm9ic2VydmVycy5maWx0ZXIoKG9icykgPT4gb2JzICE9PSBvYnNlcnZlcik7XG4gIH1cblxuICAvLyBXaW5kb3cgcmVzaXplIG1ldGhvZHMgLy9cblxuICBhdHRhY2hSZXNpemVMaXN0ZW5lcigpIHtcbiAgICBhZGRFdmVudExpc3RlbmVyKHdpbmRvdywgJ3Jlc2l6ZScsICgpID0+IHtcbiAgICAgIGlmICh0aGlzLnJlc2l6ZVRpbWVvdXQgIT09IG51bGwpIHtcbiAgICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aGlzLnJlc2l6ZVRpbWVvdXQpO1xuICAgICAgfVxuICAgICAgdGhpcy5yZXNpemVUaW1lb3V0ID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLndpbmRvd1Jlc2l6ZSgpO1xuICAgICAgfSwgMjAwKTtcbiAgICB9KTtcbiAgfVxuXG4gIHdpbmRvd1Jlc2l6ZSgpIHtcbiAgICB0aGlzLnNldFBhZ2VPblJlc2l6ZSgpO1xuICAgIHRoaXMuZWxlbWVudHMuc2xpZGVyLnN0eWxlLndpZHRoID0gYCR7dGhpcy5yZXZpZXdDb3VudCAqIHRoaXMucmV2aWV3V2lkdGhXaXRoTWFyZ2luc31weGA7XG4gICAgdGhpcy5yZXZpZXdFbGVtZW50cy5mb3JFYWNoKChlbGVtKSA9PiB7XG4gICAgICBlbGVtLnN0eWxlLndpZHRoID0gYCR7dGhpcy5yZXZpZXdXaWR0aH1weGA7XG4gICAgfSk7XG4gICAgdGhpcy5vYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IG9ic2VydmVyLm9uUmVzaXplKCkpO1xuICB9XG5cbiAgc2V0UGFnZU9uUmVzaXplKCkge1xuICAgIGNvbnN0IHByZVJlc2l6ZSA9IHtcbiAgICAgIHBhZ2U6IHRoaXMuY3VycmVudFBhZ2UsXG4gICAgICBmb2N1c2VkUmV2aWV3SW5kZXg6IHRoaXMuX3Jldmlld3NQZXJQYWdlICogKHRoaXMuY3VycmVudFBhZ2UgLSAxKSxcbiAgICB9O1xuICAgIHRoaXMuY2FsY3VsYXRlUmV2aWV3c1BlclBhZ2UoKTtcbiAgICBjb25zdCBuZXdQYWdlID0gTWF0aC5mbG9vcihwcmVSZXNpemUuZm9jdXNlZFJldmlld0luZGV4IC8gdGhpcy5fcmV2aWV3c1BlclBhZ2UpICsgMTtcbiAgICB0aGlzLmp1bXBUb1BhZ2UobmV3UGFnZSwgMCk7XG4gICAgdGhpcy50b3VjaC5zZXRQYWdlV2lkdGgodGhpcy5zbGlkZXJDb250YWluZXJXaWR0aCk7XG4gIH1cblxuICAvLyBQYWdpbmF0aW9uIG1ldGhvZHMgLy9cblxuICBtb3ZlQ29udGVudChudW1QYWdlcywgdHJhbnNpdGlvbkR1cmF0aW9uID0gMSkge1xuICAgIGNvbnN0IHBhZ2VOdW1iZXIgPSBjbGFtcChudW1QYWdlcyArIHRoaXMuY3VycmVudFBhZ2UsIDEsIHRoaXMudG90YWxQYWdlcyk7XG4gICAgdGhpcy5qdW1wVG9QYWdlKHBhZ2VOdW1iZXIsIHRyYW5zaXRpb25EdXJhdGlvbik7XG4gIH1cblxuICBwYWdlT2Zmc2V0KHBhZ2VOdW1iZXIpIHtcbiAgICByZXR1cm4gdGhpcy5zbGlkZXJDb250YWluZXJXaWR0aCAqIChwYWdlTnVtYmVyIC0gMSkgKiAtMTtcbiAgfVxuXG4gIGp1bXBUb1BhZ2UocGFnZU51bWJlciwgdHJhbnNpdGlvbkR1cmF0aW9uID0gMSkge1xuICAgIGNvbnN0IG9mZnNldCA9IHRoaXMucGFnZU9mZnNldChwYWdlTnVtYmVyKTtcbiAgICB0aGlzLnNldFNsaWRlclRyYW5zbGF0ZVgob2Zmc2V0KTtcbiAgICB0aGlzLnNldFNsaWRlclRyYW5zaXRpb25EdXJhdGlvbih0cmFuc2l0aW9uRHVyYXRpb24pO1xuICAgIHRoaXMuY3VycmVudFBhZ2UgPSBwYWdlTnVtYmVyO1xuICAgIHRoaXMub2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiBvYnNlcnZlci5vblBhZ2VDaGFuZ2UoKSk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgUmV2aWV3U2xpZGVyO1xuIiwiLy8gcG9seWZpbGwgZm9yIE1hdGguc2lnbiAobm90IHN1cHBvcnRlZCBpbiBzb21lIG1vYmlsZSBicm93c2VycylcbmNvbnN0IHNpZ24gPSAoeCkgPT4gKHggPiAwKSAtICh4IDwgMCkgfHwgK3g7XG5NYXRoLnNpZ24gPSBNYXRoLnNpZ24gfHwgc2lnbjtcblxuZXhwb3J0IGNsYXNzIFRydXN0Qm94ZXNUb3VjaCB7XG4gIGNvbnN0cnVjdG9yKHtcbiAgICB0YXJnZXRFbGVtZW50ID0gbnVsbCxcbiAgICBwYWdlV2lkdGggPSBudWxsLFxuICAgIHNlbnNpdGl2aXR5ID0gMjUsXG4gICAgdG91Y2hFbmRDYWxsYmFjayA9ICgpID0+IHt9LFxuICAgIHRvdWNoTW92ZUNhbGxiYWNrID0gKCkgPT4ge30sXG4gICAgdG91Y2hTdGFydENhbGxiYWNrID0gKCkgPT4ge30sXG4gIH0pIHtcbiAgICB0aGlzLnRhcmdldEVsZW1lbnQgPSB0YXJnZXRFbGVtZW50O1xuICAgIHRoaXMucGFnZVdpZHRoID0gcGFnZVdpZHRoO1xuICAgIHRoaXMuc2Vuc2l0aXZpdHkgPSBzZW5zaXRpdml0eTtcbiAgICB0aGlzLnRvdWNoRW5kQ2FsbGJhY2sgPSB0b3VjaEVuZENhbGxiYWNrO1xuICAgIHRoaXMudG91Y2hNb3ZlQ2FsbGJhY2sgPSB0b3VjaE1vdmVDYWxsYmFjaztcbiAgICB0aGlzLnRvdWNoU3RhcnRDYWxsYmFjayA9IHRvdWNoU3RhcnRDYWxsYmFjaztcbiAgICB0aGlzLmluaXRpYWxYID0gMDtcbiAgICB0aGlzLm9mZnNldERpc3RhbmNlWCA9IDA7XG4gICAgdGhpcy5zdGFydFRvdWNoVGltZSA9IDA7XG4gICAgdGhpcy5sYXN0RHJhZ0Rpc3RhbmNlWCA9IDA7XG4gICAgdGhpcy5kaXJlY3Rpb25YID0gMDtcbiAgICB0aGlzLnNjcm9sbEF4aXMgPSAnbm9uZSc7XG4gICAgdGhpcy50b3VjaFBvc2l0aW9uID0ge1xuICAgICAgc3RhcnQ6IHtcbiAgICAgICAgeDogMCxcbiAgICAgICAgeTogMCxcbiAgICAgIH0sXG4gICAgICBzdG9wOiB7XG4gICAgICAgIHg6IDAsXG4gICAgICAgIHk6IDAsXG4gICAgICB9LFxuICAgIH07XG4gICAgdGhpcy50YXJnZXRFbGVtZW50LnN0eWxlLnVzZXJTZWxlY3QgPSAnbm9uZSc7XG4gICAgdGhpcy50YXJnZXRFbGVtZW50LnN0eWxlLnRyYW5zaXRpb25UaW1pbmdGdW5jdGlvbiA9ICdlYXNlJztcbiAgfVxuXG4gIGdldERyYWdEaXN0YW5jZSgpIHtcbiAgICByZXR1cm4ge1xuICAgICAgeDogdGhpcy50b3VjaFBvc2l0aW9uLnN0b3AueCAtIHRoaXMudG91Y2hQb3NpdGlvbi5zdGFydC54LFxuICAgICAgeTogdGhpcy50b3VjaFBvc2l0aW9uLnN0b3AueSAtIHRoaXMudG91Y2hQb3NpdGlvbi5zdGFydC55LFxuICAgIH07XG4gIH1cblxuICBnZXRQYWdlc1RvU3dpcGUodG93YXJkc0luaXRpYWxYKSB7XG4gICAgY29uc3QgZGlzdGFuY2UgPSB0aGlzLmdldERyYWdEaXN0YW5jZSgpLnggKyB0aGlzLm9mZnNldERpc3RhbmNlWDtcbiAgICBjb25zdCBkaXN0RnJvbUNsb3Nlc3RQYWdlID0gTWF0aC5hYnMoZGlzdGFuY2UpICUgdGhpcy5wYWdlV2lkdGg7XG4gICAgY29uc3QgbWF4UGFnZXNUb1N3aXBlID0gTWF0aC5jZWlsKE1hdGguYWJzKGRpc3RhbmNlIC8gdGhpcy5wYWdlV2lkdGgpKSB8fCAxO1xuICAgIGNvbnN0IGV4Y2VlZHNUaHJlc2hvbGQgPSBkaXN0RnJvbUNsb3Nlc3RQYWdlID4gdGhpcy5zZW5zaXRpdml0eTtcbiAgICByZXR1cm4gZXhjZWVkc1RocmVzaG9sZCAmJiAhdG93YXJkc0luaXRpYWxYID8gbWF4UGFnZXNUb1N3aXBlIDogbWF4UGFnZXNUb1N3aXBlIC0gMTtcbiAgfVxuXG4gIHNldFBhZ2VXaWR0aChwYWdlV2lkdGgpIHtcbiAgICB0aGlzLnBhZ2VXaWR0aCA9IHBhZ2VXaWR0aDtcbiAgfVxuXG4gIGF0dGFjaCgpIHtcbiAgICB0aGlzLnRhcmdldEVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndG91Y2hzdGFydCcsIChldnQpID0+IHtcbiAgICAgIHRoaXMuc3RhcnRUb3VjaFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICAgIHRoaXMudG91Y2hQb3NpdGlvbi5zdGFydC54ID0gZXZ0LmNoYW5nZWRUb3VjaGVzWzBdLnNjcmVlblg7XG4gICAgICB0aGlzLnRvdWNoUG9zaXRpb24uc3RhcnQueSA9IGV2dC5jaGFuZ2VkVG91Y2hlc1swXS5zY3JlZW5ZO1xuICAgICAgY29uc3Qgc3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZSh0aGlzLnRhcmdldEVsZW1lbnQpO1xuICAgICAgbGV0IHRyYW5zbGF0ZVggPSAwO1xuICAgICAgaWYgKHdpbmRvdy5ET01NYXRyaXgpIHtcbiAgICAgICAgY29uc3QgbWF0cml4ID0gbmV3IHdpbmRvdy5ET01NYXRyaXgoc3R5bGUud2Via2l0VHJhbnNmb3JtKTtcbiAgICAgICAgdHJhbnNsYXRlWCA9IG1hdHJpeC5tNDE7XG4gICAgICAgIHRoaXMuaW5pdGlhbFggPSBNYXRoLnJvdW5kKHRyYW5zbGF0ZVggLyB0aGlzLnBhZ2VXaWR0aCkgKiB0aGlzLnBhZ2VXaWR0aDtcbiAgICAgICAgdGhpcy5vZmZzZXREaXN0YW5jZVggPSB0cmFuc2xhdGVYIC0gdGhpcy5pbml0aWFsWDtcbiAgICAgIH1cbiAgICAgIHRoaXMuc2Nyb2xsQXhpcyA9ICdub25lJztcbiAgICAgIC8vIERvbid0IHByZXNzIGxpbmtzIHdoZW4gcGFnZXMgYXJlIG9mZnNldFxuICAgICAgLy8gQXNzdW1lIHVzZXIgd2FudHMgdG8gc2Nyb2xsIG9uIHggaW4gdGhpcyBjYXNlLlxuICAgICAgaWYgKE1hdGguYWJzKHRoaXMub2Zmc2V0RGlzdGFuY2VYKSA+IDUpIHtcbiAgICAgICAgZXZ0LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHRoaXMuc2Nyb2xsQXhpcyA9ICd4JztcbiAgICAgIH1cbiAgICAgIHRoaXMudG91Y2hTdGFydENhbGxiYWNrKHtcbiAgICAgICAgdHJhbnNsYXRlWCxcbiAgICAgICAgb3JpZ2luUGFnZTogTWF0aC5hYnModGhpcy5pbml0aWFsWCkgLyB0aGlzLnBhZ2VXaWR0aCArIDEsXG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIHRoaXMudGFyZ2V0RWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCd0b3VjaG1vdmUnLCAoZXZ0KSA9PiB7XG4gICAgICB0aGlzLnRvdWNoUG9zaXRpb24uc3RvcC54ID0gZXZ0LmNoYW5nZWRUb3VjaGVzWzBdLnNjcmVlblg7XG4gICAgICB0aGlzLnRvdWNoUG9zaXRpb24uc3RvcC55ID0gZXZ0LmNoYW5nZWRUb3VjaGVzWzBdLnNjcmVlblk7XG4gICAgICBjb25zdCBkcmFnRGlzdGFuY2UgPSB0aGlzLmdldERyYWdEaXN0YW5jZSgpO1xuICAgICAgaWYgKHRoaXMuc2Nyb2xsQXhpcyA9PT0gJ25vbmUnKSB7XG4gICAgICAgIHRoaXMuc2Nyb2xsQXhpcyA9IE1hdGguYWJzKGRyYWdEaXN0YW5jZS54KSA+PSBNYXRoLmFicyhkcmFnRGlzdGFuY2UueSkgPyAneCcgOiAneSc7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5zY3JvbGxBeGlzID09PSAneCcpIHtcbiAgICAgICAgZXZ0LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHRoaXMuZGlyZWN0aW9uWCA9IGRyYWdEaXN0YW5jZS54IC0gdGhpcy5sYXN0RHJhZ0Rpc3RhbmNlWDtcbiAgICAgICAgdGhpcy5sYXN0RHJhZ0Rpc3RhbmNlWCA9IGRyYWdEaXN0YW5jZS54O1xuXG4gICAgICAgIHRoaXMudG91Y2hNb3ZlQ2FsbGJhY2soe1xuICAgICAgICAgIHRyYW5zbGF0ZVg6IGRyYWdEaXN0YW5jZS54ICsgdGhpcy5vZmZzZXREaXN0YW5jZVggKyB0aGlzLmluaXRpYWxYLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHRoaXMudGFyZ2V0RWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCd0b3VjaGVuZCcsICgpID0+IHtcbiAgICAgIGNvbnN0IGVuZFRvdWNoVGltZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgY29uc3QgZGVsdGFUaW1lID0gKGVuZFRvdWNoVGltZSAtIHRoaXMuc3RhcnRUb3VjaFRpbWUpIC8gMTAwMDtcbiAgICAgIGNvbnN0IGRyYWdEaXN0YW5jZSA9IHRoaXMuZ2V0RHJhZ0Rpc3RhbmNlKCk7XG4gICAgICBjb25zdCBmaW5nZXJTcGVlZCA9IE1hdGguYWJzKGRyYWdEaXN0YW5jZS54KSAvIGRlbHRhVGltZTtcbiAgICAgIGNvbnN0IHRyYW5zaXRpb25EdXJhdGlvbiA9IHRoaXMucGFnZVdpZHRoIC8gZmluZ2VyU3BlZWQ7XG4gICAgICBjb25zdCB0cmFuc2xhdGVYID0gZHJhZ0Rpc3RhbmNlLnggKyB0aGlzLm9mZnNldERpc3RhbmNlWCArIHRoaXMuaW5pdGlhbFg7XG4gICAgICBjb25zdCBkaXJUb0luaXRpYWxYID0gTWF0aC5zaWduKHRoaXMuaW5pdGlhbFggLSB0cmFuc2xhdGVYKTtcbiAgICAgIGNvbnN0IHRvd2FyZHNJbml0aWFsWCA9IE1hdGguc2lnbih0aGlzLmRpcmVjdGlvblgpID09PSBkaXJUb0luaXRpYWxYO1xuICAgICAgY29uc3QgcGFnZXNUb1N3aXBlID0gdGhpcy5zY3JvbGxBeGlzID09PSAneCcgPyB0aGlzLmdldFBhZ2VzVG9Td2lwZSh0b3dhcmRzSW5pdGlhbFgpIDogMDtcblxuICAgICAgdGhpcy50b3VjaEVuZENhbGxiYWNrKHtcbiAgICAgICAgcGFnZXNUb1N3aXBlOiBwYWdlc1RvU3dpcGUgKiBkaXJUb0luaXRpYWxYLFxuICAgICAgICB0cmFuc2l0aW9uRHVyYXRpb24sXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgZGVmYXVsdExvY2FsZSwgZm9ybWF0TG9jYWxlLCBnZXRGcmFtZXdvcmtUcmFuc2xhdGlvbiB9IGZyb20gJy4vdHJhbnNsYXRpb25zJztcblxuY29uc3QgbWFwRGF0ZU51bWJlclRvSHVtYW4gPSB7XG4gICcwJzogJ2phbnVhcnknLFxuICAnMSc6ICdmZWJydWFyeScsXG4gICcyJzogJ21hcmNoJyxcbiAgJzMnOiAnYXByaWwnLFxuICAnNCc6ICdtYXknLFxuICAnNSc6ICdqdW5lJyxcbiAgJzYnOiAnanVseScsXG4gICc3JzogJ2F1Z3VzdCcsXG4gICc4JzogJ3NlcHRlbWJlcicsXG4gICc5JzogJ29jdG9iZXInLFxuICAnMTAnOiAnbm92ZW1iZXInLFxuICAnMTEnOiAnZGVjZW1iZXInLFxufTtcblxuY29uc3Qgc21hcnRBZ2UgPSAobG9jYWxlLCBkYXRlKSA9PiB7XG4gIGlmICghZGF0ZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgY29uc3QgZm9ybWF0dGVkTG9jYWxlID0gZm9ybWF0TG9jYWxlKGxvY2FsZSk7XG4gIGNvbnN0IHBhcnNlZERhdGUgPSBEYXRlLnBhcnNlKGRhdGUpO1xuICBjb25zdCBwYXJzZWREYXRlQXNPYmplY3QgPSBuZXcgRGF0ZShwYXJzZWREYXRlKTtcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcbiAgY29uc3Qgc2Vjb25kcyA9IE1hdGguZmxvb3IoKG5vdyAtIHBhcnNlZERhdGUpIC8gMTAwMCk7XG4gIGNvbnN0IG1pbnV0ZXMgPSByb3VuZFVwT3JEb3duKHNlY29uZHMsIDYwKTtcbiAgY29uc3QgaG91cnMgPSByb3VuZFVwT3JEb3duKG1pbnV0ZXMsIDYwKTtcbiAgY29uc3QgZGF5cyA9IHJvdW5kVXBPckRvd24oaG91cnMsIDI0KTtcblxuICBpZiAoZGF5cyA+PSA3KSB7XG4gICAgY29uc3QgbW9udGggPSBwYXJzZWREYXRlQXNPYmplY3QuZ2V0TW9udGgoKTtcbiAgICBjb25zdCBkYXkgPSBwYXJzZWREYXRlQXNPYmplY3QuZ2V0RGF0ZSgpO1xuICAgIGNvbnN0IG1vbnRoTmFtZSA9IG1hcERhdGVOdW1iZXJUb0h1bWFuW21vbnRoXTtcbiAgICBjb25zdCBtb250aE5hbWVUcmFuc2xhdGVkID0gZ2V0RnJhbWV3b3JrVHJhbnNsYXRpb24oYG1vbnRoTmFtZXMuJHttb250aE5hbWV9YCwgZm9ybWF0dGVkTG9jYWxlKTtcbiAgICBjb25zdCBqYXBhbmVzZUxvY2FsZSA9ICdqYS1KUCc7XG5cbiAgICBpZiAoZm9ybWF0dGVkTG9jYWxlID09PSBkZWZhdWx0TG9jYWxlKSB7XG4gICAgICByZXR1cm4gYCR7bW9udGhOYW1lVHJhbnNsYXRlZH0gJHtkYXl9YDtcbiAgICB9IGVsc2UgaWYgKGZvcm1hdHRlZExvY2FsZSA9PT0gamFwYW5lc2VMb2NhbGUpIHtcbiAgICAgIHJldHVybiBgJHttb250aE5hbWVUcmFuc2xhdGVkfSAke2RheX3ml6VgO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYCR7ZGF5fSAke21vbnRoTmFtZVRyYW5zbGF0ZWR9YDtcbiAgICB9XG4gIH1cblxuICBpZiAoZGF5cyA+IDApIHtcbiAgICByZXR1cm4gZ2V0RnJhbWV3b3JrVHJhbnNsYXRpb24oYHRpbWVBZ28uZGF5cy4ke3Npbmd1bGFyT3JQbHVyYWwoZGF5cyl9YCwgZm9ybWF0dGVkTG9jYWxlLCB7J1tjb3VudF0nOiBkYXlzfSk7XG4gIH1cblxuICBpZiAoaG91cnMgPiAwKSB7XG4gICAgcmV0dXJuIGdldEZyYW1ld29ya1RyYW5zbGF0aW9uKGB0aW1lQWdvLmhvdXJzLiR7c2luZ3VsYXJPclBsdXJhbChob3Vycyl9YCwgZm9ybWF0dGVkTG9jYWxlLCB7J1tjb3VudF0nOiBob3Vyc30pO1xuICB9XG5cbiAgaWYgKG1pbnV0ZXMgPiAwKSB7XG4gICAgcmV0dXJuIGdldEZyYW1ld29ya1RyYW5zbGF0aW9uKGB0aW1lQWdvLm1pbnV0ZXMuJHtzaW5ndWxhck9yUGx1cmFsKG1pbnV0ZXMpfWAsIGZvcm1hdHRlZExvY2FsZSwgeydbY291bnRdJzogbWludXRlc30pO1xuICB9XG5cbiAgaWYgKHNlY29uZHMgPj0gMCkge1xuICAgIHJldHVybiBnZXRGcmFtZXdvcmtUcmFuc2xhdGlvbihgdGltZUFnby5zZWNvbmRzLiR7c2luZ3VsYXJPclBsdXJhbChzZWNvbmRzKX1gLCBmb3JtYXR0ZWRMb2NhbGUsIHsnW2NvdW50XSc6IHNlY29uZHN9KTtcbiAgfVxufTtcblxuZnVuY3Rpb24gcm91bmRVcE9yRG93bih2YWx1ZSwgaW50ZXJ2YWwpIHtcbiAgcmV0dXJuIGluU2Vjb25kUGFydE9mVGltZUludGVydmFsKHZhbHVlLCBpbnRlcnZhbCkgPyBNYXRoLmNlaWwodmFsdWUgLyBpbnRlcnZhbCkgOiBNYXRoLmZsb29yKHZhbHVlIC8gaW50ZXJ2YWwpO1xufVxuXG5mdW5jdGlvbiBpblNlY29uZFBhcnRPZlRpbWVJbnRlcnZhbCh2YWx1ZSwgaW50ZXJ2YWwpIHtcbiAgcmV0dXJuICh2YWx1ZSA+IGludGVydmFsKSAmJiAodmFsdWUgJSBpbnRlcnZhbCA+PSBpbnRlcnZhbCAvIDIpO1xufVxuXG5mdW5jdGlvbiBzaW5ndWxhck9yUGx1cmFsKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSA9PT0gMSA/ICdzaW5ndWxhcicgOiAncGx1cmFsJztcbn1cblxuZXhwb3J0IGRlZmF1bHQgc21hcnRBZ2U7XG4iLCJmdW5jdGlvbiBlc2NhcGVIdG1sKHN0cmluZykge1xuICBjb25zdCBzcGVjaWFsQ2hhcmFjdGVycyA9IHtcbiAgICAnPCc6ICcmbHQ7JyxcbiAgICAnPic6ICcmZ3Q7JyxcbiAgICAnXCInOiAnJnF1b3Q7JyxcbiAgICAnXFwnJzogJyZhcG9zOycsXG4gICAgJy8nOiAnJnNvbDsnLFxuICAgICc9JzogJyZlcXVhbHM7JyxcbiAgICAnYCc6ICcmZ3JhdmU7JyxcbiAgfTtcbiAgcmV0dXJuIHN0cmluZy5yZXBsYWNlKC9bPD5cIidgPVxcL10vZywgZnVuY3Rpb24gKHMpIHtcbiAgICByZXR1cm4gc3BlY2lhbENoYXJhY3RlcnNbc107XG4gIH0pO1xufVxuXG5mdW5jdGlvbiB0cnVuY2F0ZVRleHQoaW5wdXQsIG1heGltdW1MZW5ndGgpIHtcbiAgaWYgKGlzTmFOKG1heGltdW1MZW5ndGgpKSB7XG4gICAgcmV0dXJuIGlucHV0O1xuICB9XG4gIGlmIChtYXhpbXVtTGVuZ3RoIDw9IDApIHtcbiAgICByZXR1cm4gJyc7XG4gIH1cbiAgaWYgKGlucHV0ICYmIGlucHV0Lmxlbmd0aCA+IG1heGltdW1MZW5ndGgpIHtcbiAgICBpbnB1dCA9IGlucHV0LnN1YnN0cmluZygwLCBtYXhpbXVtTGVuZ3RoKTtcbiAgICB2YXIgbGFzdENoYXIgPSBpbnB1dC5jaGFyQXQoaW5wdXQubGVuZ3RoIC0gMSk7XG4gICAgd2hpbGUgKGxhc3RDaGFyID09PSAnICcgfHwgbGFzdENoYXIgPT09ICcuJyB8fCBsYXN0Q2hhciA9PT0gJywnKSB7XG4gICAgICBpbnB1dCA9IGlucHV0LnN1YnN0cigwLCBpbnB1dC5sZW5ndGggLSAxKTtcbiAgICAgIGxhc3RDaGFyID0gaW5wdXQuY2hhckF0KGlucHV0Lmxlbmd0aCAtIDEpO1xuICAgIH1cbiAgICBpbnB1dCArPSAnLi4uJztcbiAgfVxuICByZXR1cm4gZXNjYXBlSHRtbChpbnB1dCk7XG59XG5cbmV4cG9ydCB7IHRydW5jYXRlVGV4dCwgZXNjYXBlSHRtbCB9O1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbi8vIHJhd0FzYXAgcHJvdmlkZXMgZXZlcnl0aGluZyB3ZSBuZWVkIGV4Y2VwdCBleGNlcHRpb24gbWFuYWdlbWVudC5cbnZhciByYXdBc2FwID0gcmVxdWlyZShcIi4vcmF3XCIpO1xuLy8gUmF3VGFza3MgYXJlIHJlY3ljbGVkIHRvIHJlZHVjZSBHQyBjaHVybi5cbnZhciBmcmVlVGFza3MgPSBbXTtcbi8vIFdlIHF1ZXVlIGVycm9ycyB0byBlbnN1cmUgdGhleSBhcmUgdGhyb3duIGluIHJpZ2h0IG9yZGVyIChGSUZPKS5cbi8vIEFycmF5LWFzLXF1ZXVlIGlzIGdvb2QgZW5vdWdoIGhlcmUsIHNpbmNlIHdlIGFyZSBqdXN0IGRlYWxpbmcgd2l0aCBleGNlcHRpb25zLlxudmFyIHBlbmRpbmdFcnJvcnMgPSBbXTtcbnZhciByZXF1ZXN0RXJyb3JUaHJvdyA9IHJhd0FzYXAubWFrZVJlcXVlc3RDYWxsRnJvbVRpbWVyKHRocm93Rmlyc3RFcnJvcik7XG5cbmZ1bmN0aW9uIHRocm93Rmlyc3RFcnJvcigpIHtcbiAgICBpZiAocGVuZGluZ0Vycm9ycy5sZW5ndGgpIHtcbiAgICAgICAgdGhyb3cgcGVuZGluZ0Vycm9ycy5zaGlmdCgpO1xuICAgIH1cbn1cblxuLyoqXG4gKiBDYWxscyBhIHRhc2sgYXMgc29vbiBhcyBwb3NzaWJsZSBhZnRlciByZXR1cm5pbmcsIGluIGl0cyBvd24gZXZlbnQsIHdpdGggcHJpb3JpdHlcbiAqIG92ZXIgb3RoZXIgZXZlbnRzIGxpa2UgYW5pbWF0aW9uLCByZWZsb3csIGFuZCByZXBhaW50LiBBbiBlcnJvciB0aHJvd24gZnJvbSBhblxuICogZXZlbnQgd2lsbCBub3QgaW50ZXJydXB0LCBub3IgZXZlbiBzdWJzdGFudGlhbGx5IHNsb3cgZG93biB0aGUgcHJvY2Vzc2luZyBvZlxuICogb3RoZXIgZXZlbnRzLCBidXQgd2lsbCBiZSByYXRoZXIgcG9zdHBvbmVkIHRvIGEgbG93ZXIgcHJpb3JpdHkgZXZlbnQuXG4gKiBAcGFyYW0ge3tjYWxsfX0gdGFzayBBIGNhbGxhYmxlIG9iamVjdCwgdHlwaWNhbGx5IGEgZnVuY3Rpb24gdGhhdCB0YWtlcyBub1xuICogYXJndW1lbnRzLlxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGFzYXA7XG5mdW5jdGlvbiBhc2FwKHRhc2spIHtcbiAgICB2YXIgcmF3VGFzaztcbiAgICBpZiAoZnJlZVRhc2tzLmxlbmd0aCkge1xuICAgICAgICByYXdUYXNrID0gZnJlZVRhc2tzLnBvcCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHJhd1Rhc2sgPSBuZXcgUmF3VGFzaygpO1xuICAgIH1cbiAgICByYXdUYXNrLnRhc2sgPSB0YXNrO1xuICAgIHJhd0FzYXAocmF3VGFzayk7XG59XG5cbi8vIFdlIHdyYXAgdGFza3Mgd2l0aCByZWN5Y2xhYmxlIHRhc2sgb2JqZWN0cy4gIEEgdGFzayBvYmplY3QgaW1wbGVtZW50c1xuLy8gYGNhbGxgLCBqdXN0IGxpa2UgYSBmdW5jdGlvbi5cbmZ1bmN0aW9uIFJhd1Rhc2soKSB7XG4gICAgdGhpcy50YXNrID0gbnVsbDtcbn1cblxuLy8gVGhlIHNvbGUgcHVycG9zZSBvZiB3cmFwcGluZyB0aGUgdGFzayBpcyB0byBjYXRjaCB0aGUgZXhjZXB0aW9uIGFuZCByZWN5Y2xlXG4vLyB0aGUgdGFzayBvYmplY3QgYWZ0ZXIgaXRzIHNpbmdsZSB1c2UuXG5SYXdUYXNrLnByb3RvdHlwZS5jYWxsID0gZnVuY3Rpb24gKCkge1xuICAgIHRyeSB7XG4gICAgICAgIHRoaXMudGFzay5jYWxsKCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKGFzYXAub25lcnJvcikge1xuICAgICAgICAgICAgLy8gVGhpcyBob29rIGV4aXN0cyBwdXJlbHkgZm9yIHRlc3RpbmcgcHVycG9zZXMuXG4gICAgICAgICAgICAvLyBJdHMgbmFtZSB3aWxsIGJlIHBlcmlvZGljYWxseSByYW5kb21pemVkIHRvIGJyZWFrIGFueSBjb2RlIHRoYXRcbiAgICAgICAgICAgIC8vIGRlcGVuZHMgb24gaXRzIGV4aXN0ZW5jZS5cbiAgICAgICAgICAgIGFzYXAub25lcnJvcihlcnJvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBJbiBhIHdlYiBicm93c2VyLCBleGNlcHRpb25zIGFyZSBub3QgZmF0YWwuIEhvd2V2ZXIsIHRvIGF2b2lkXG4gICAgICAgICAgICAvLyBzbG93aW5nIGRvd24gdGhlIHF1ZXVlIG9mIHBlbmRpbmcgdGFza3MsIHdlIHJldGhyb3cgdGhlIGVycm9yIGluIGFcbiAgICAgICAgICAgIC8vIGxvd2VyIHByaW9yaXR5IHR1cm4uXG4gICAgICAgICAgICBwZW5kaW5nRXJyb3JzLnB1c2goZXJyb3IpO1xuICAgICAgICAgICAgcmVxdWVzdEVycm9yVGhyb3coKTtcbiAgICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICAgIHRoaXMudGFzayA9IG51bGw7XG4gICAgICAgIGZyZWVUYXNrc1tmcmVlVGFza3MubGVuZ3RoXSA9IHRoaXM7XG4gICAgfVxufTtcbiIsIlwidXNlIHN0cmljdFwiO1xuXG4vLyBVc2UgdGhlIGZhc3Rlc3QgbWVhbnMgcG9zc2libGUgdG8gZXhlY3V0ZSBhIHRhc2sgaW4gaXRzIG93biB0dXJuLCB3aXRoXG4vLyBwcmlvcml0eSBvdmVyIG90aGVyIGV2ZW50cyBpbmNsdWRpbmcgSU8sIGFuaW1hdGlvbiwgcmVmbG93LCBhbmQgcmVkcmF3XG4vLyBldmVudHMgaW4gYnJvd3NlcnMuXG4vL1xuLy8gQW4gZXhjZXB0aW9uIHRocm93biBieSBhIHRhc2sgd2lsbCBwZXJtYW5lbnRseSBpbnRlcnJ1cHQgdGhlIHByb2Nlc3Npbmcgb2Zcbi8vIHN1YnNlcXVlbnQgdGFza3MuIFRoZSBoaWdoZXIgbGV2ZWwgYGFzYXBgIGZ1bmN0aW9uIGVuc3VyZXMgdGhhdCBpZiBhblxuLy8gZXhjZXB0aW9uIGlzIHRocm93biBieSBhIHRhc2ssIHRoYXQgdGhlIHRhc2sgcXVldWUgd2lsbCBjb250aW51ZSBmbHVzaGluZyBhc1xuLy8gc29vbiBhcyBwb3NzaWJsZSwgYnV0IGlmIHlvdSB1c2UgYHJhd0FzYXBgIGRpcmVjdGx5LCB5b3UgYXJlIHJlc3BvbnNpYmxlIHRvXG4vLyBlaXRoZXIgZW5zdXJlIHRoYXQgbm8gZXhjZXB0aW9ucyBhcmUgdGhyb3duIGZyb20geW91ciB0YXNrLCBvciB0byBtYW51YWxseVxuLy8gY2FsbCBgcmF3QXNhcC5yZXF1ZXN0Rmx1c2hgIGlmIGFuIGV4Y2VwdGlvbiBpcyB0aHJvd24uXG5tb2R1bGUuZXhwb3J0cyA9IHJhd0FzYXA7XG5mdW5jdGlvbiByYXdBc2FwKHRhc2spIHtcbiAgICBpZiAoIXF1ZXVlLmxlbmd0aCkge1xuICAgICAgICByZXF1ZXN0Rmx1c2goKTtcbiAgICAgICAgZmx1c2hpbmcgPSB0cnVlO1xuICAgIH1cbiAgICAvLyBFcXVpdmFsZW50IHRvIHB1c2gsIGJ1dCBhdm9pZHMgYSBmdW5jdGlvbiBjYWxsLlxuICAgIHF1ZXVlW3F1ZXVlLmxlbmd0aF0gPSB0YXNrO1xufVxuXG52YXIgcXVldWUgPSBbXTtcbi8vIE9uY2UgYSBmbHVzaCBoYXMgYmVlbiByZXF1ZXN0ZWQsIG5vIGZ1cnRoZXIgY2FsbHMgdG8gYHJlcXVlc3RGbHVzaGAgYXJlXG4vLyBuZWNlc3NhcnkgdW50aWwgdGhlIG5leHQgYGZsdXNoYCBjb21wbGV0ZXMuXG52YXIgZmx1c2hpbmcgPSBmYWxzZTtcbi8vIGByZXF1ZXN0Rmx1c2hgIGlzIGFuIGltcGxlbWVudGF0aW9uLXNwZWNpZmljIG1ldGhvZCB0aGF0IGF0dGVtcHRzIHRvIGtpY2tcbi8vIG9mZiBhIGBmbHVzaGAgZXZlbnQgYXMgcXVpY2tseSBhcyBwb3NzaWJsZS4gYGZsdXNoYCB3aWxsIGF0dGVtcHQgdG8gZXhoYXVzdFxuLy8gdGhlIGV2ZW50IHF1ZXVlIGJlZm9yZSB5aWVsZGluZyB0byB0aGUgYnJvd3NlcidzIG93biBldmVudCBsb29wLlxudmFyIHJlcXVlc3RGbHVzaDtcbi8vIFRoZSBwb3NpdGlvbiBvZiB0aGUgbmV4dCB0YXNrIHRvIGV4ZWN1dGUgaW4gdGhlIHRhc2sgcXVldWUuIFRoaXMgaXNcbi8vIHByZXNlcnZlZCBiZXR3ZWVuIGNhbGxzIHRvIGBmbHVzaGAgc28gdGhhdCBpdCBjYW4gYmUgcmVzdW1lZCBpZlxuLy8gYSB0YXNrIHRocm93cyBhbiBleGNlcHRpb24uXG52YXIgaW5kZXggPSAwO1xuLy8gSWYgYSB0YXNrIHNjaGVkdWxlcyBhZGRpdGlvbmFsIHRhc2tzIHJlY3Vyc2l2ZWx5LCB0aGUgdGFzayBxdWV1ZSBjYW4gZ3Jvd1xuLy8gdW5ib3VuZGVkLiBUbyBwcmV2ZW50IG1lbW9yeSBleGhhdXN0aW9uLCB0aGUgdGFzayBxdWV1ZSB3aWxsIHBlcmlvZGljYWxseVxuLy8gdHJ1bmNhdGUgYWxyZWFkeS1jb21wbGV0ZWQgdGFza3MuXG52YXIgY2FwYWNpdHkgPSAxMDI0O1xuXG4vLyBUaGUgZmx1c2ggZnVuY3Rpb24gcHJvY2Vzc2VzIGFsbCB0YXNrcyB0aGF0IGhhdmUgYmVlbiBzY2hlZHVsZWQgd2l0aFxuLy8gYHJhd0FzYXBgIHVubGVzcyBhbmQgdW50aWwgb25lIG9mIHRob3NlIHRhc2tzIHRocm93cyBhbiBleGNlcHRpb24uXG4vLyBJZiBhIHRhc2sgdGhyb3dzIGFuIGV4Y2VwdGlvbiwgYGZsdXNoYCBlbnN1cmVzIHRoYXQgaXRzIHN0YXRlIHdpbGwgcmVtYWluXG4vLyBjb25zaXN0ZW50IGFuZCB3aWxsIHJlc3VtZSB3aGVyZSBpdCBsZWZ0IG9mZiB3aGVuIGNhbGxlZCBhZ2Fpbi5cbi8vIEhvd2V2ZXIsIGBmbHVzaGAgZG9lcyBub3QgbWFrZSBhbnkgYXJyYW5nZW1lbnRzIHRvIGJlIGNhbGxlZCBhZ2FpbiBpZiBhblxuLy8gZXhjZXB0aW9uIGlzIHRocm93bi5cbmZ1bmN0aW9uIGZsdXNoKCkge1xuICAgIHdoaWxlIChpbmRleCA8IHF1ZXVlLmxlbmd0aCkge1xuICAgICAgICB2YXIgY3VycmVudEluZGV4ID0gaW5kZXg7XG4gICAgICAgIC8vIEFkdmFuY2UgdGhlIGluZGV4IGJlZm9yZSBjYWxsaW5nIHRoZSB0YXNrLiBUaGlzIGVuc3VyZXMgdGhhdCB3ZSB3aWxsXG4gICAgICAgIC8vIGJlZ2luIGZsdXNoaW5nIG9uIHRoZSBuZXh0IHRhc2sgdGhlIHRhc2sgdGhyb3dzIGFuIGVycm9yLlxuICAgICAgICBpbmRleCA9IGluZGV4ICsgMTtcbiAgICAgICAgcXVldWVbY3VycmVudEluZGV4XS5jYWxsKCk7XG4gICAgICAgIC8vIFByZXZlbnQgbGVha2luZyBtZW1vcnkgZm9yIGxvbmcgY2hhaW5zIG9mIHJlY3Vyc2l2ZSBjYWxscyB0byBgYXNhcGAuXG4gICAgICAgIC8vIElmIHdlIGNhbGwgYGFzYXBgIHdpdGhpbiB0YXNrcyBzY2hlZHVsZWQgYnkgYGFzYXBgLCB0aGUgcXVldWUgd2lsbFxuICAgICAgICAvLyBncm93LCBidXQgdG8gYXZvaWQgYW4gTyhuKSB3YWxrIGZvciBldmVyeSB0YXNrIHdlIGV4ZWN1dGUsIHdlIGRvbid0XG4gICAgICAgIC8vIHNoaWZ0IHRhc2tzIG9mZiB0aGUgcXVldWUgYWZ0ZXIgdGhleSBoYXZlIGJlZW4gZXhlY3V0ZWQuXG4gICAgICAgIC8vIEluc3RlYWQsIHdlIHBlcmlvZGljYWxseSBzaGlmdCAxMDI0IHRhc2tzIG9mZiB0aGUgcXVldWUuXG4gICAgICAgIGlmIChpbmRleCA+IGNhcGFjaXR5KSB7XG4gICAgICAgICAgICAvLyBNYW51YWxseSBzaGlmdCBhbGwgdmFsdWVzIHN0YXJ0aW5nIGF0IHRoZSBpbmRleCBiYWNrIHRvIHRoZVxuICAgICAgICAgICAgLy8gYmVnaW5uaW5nIG9mIHRoZSBxdWV1ZS5cbiAgICAgICAgICAgIGZvciAodmFyIHNjYW4gPSAwLCBuZXdMZW5ndGggPSBxdWV1ZS5sZW5ndGggLSBpbmRleDsgc2NhbiA8IG5ld0xlbmd0aDsgc2NhbisrKSB7XG4gICAgICAgICAgICAgICAgcXVldWVbc2Nhbl0gPSBxdWV1ZVtzY2FuICsgaW5kZXhdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcXVldWUubGVuZ3RoIC09IGluZGV4O1xuICAgICAgICAgICAgaW5kZXggPSAwO1xuICAgICAgICB9XG4gICAgfVxuICAgIHF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgaW5kZXggPSAwO1xuICAgIGZsdXNoaW5nID0gZmFsc2U7XG59XG5cbi8vIGByZXF1ZXN0Rmx1c2hgIGlzIGltcGxlbWVudGVkIHVzaW5nIGEgc3RyYXRlZ3kgYmFzZWQgb24gZGF0YSBjb2xsZWN0ZWQgZnJvbVxuLy8gZXZlcnkgYXZhaWxhYmxlIFNhdWNlTGFicyBTZWxlbml1bSB3ZWIgZHJpdmVyIHdvcmtlciBhdCB0aW1lIG9mIHdyaXRpbmcuXG4vLyBodHRwczovL2RvY3MuZ29vZ2xlLmNvbS9zcHJlYWRzaGVldHMvZC8xbUctNVVZR3VwNXF4R2RFTVdraFA2QldDejA1M05VYjJFMVFvVVRVMTZ1QS9lZGl0I2dpZD03ODM3MjQ1OTNcblxuLy8gU2FmYXJpIDYgYW5kIDYuMSBmb3IgZGVza3RvcCwgaVBhZCwgYW5kIGlQaG9uZSBhcmUgdGhlIG9ubHkgYnJvd3NlcnMgdGhhdFxuLy8gaGF2ZSBXZWJLaXRNdXRhdGlvbk9ic2VydmVyIGJ1dCBub3QgdW4tcHJlZml4ZWQgTXV0YXRpb25PYnNlcnZlci5cbi8vIE11c3QgdXNlIGBnbG9iYWxgIG9yIGBzZWxmYCBpbnN0ZWFkIG9mIGB3aW5kb3dgIHRvIHdvcmsgaW4gYm90aCBmcmFtZXMgYW5kIHdlYlxuLy8gd29ya2Vycy4gYGdsb2JhbGAgaXMgYSBwcm92aXNpb24gb2YgQnJvd3NlcmlmeSwgTXIsIE1ycywgb3IgTW9wLlxuXG4vKiBnbG9iYWxzIHNlbGYgKi9cbnZhciBzY29wZSA9IHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiBzZWxmO1xudmFyIEJyb3dzZXJNdXRhdGlvbk9ic2VydmVyID0gc2NvcGUuTXV0YXRpb25PYnNlcnZlciB8fCBzY29wZS5XZWJLaXRNdXRhdGlvbk9ic2VydmVyO1xuXG4vLyBNdXRhdGlvbk9ic2VydmVycyBhcmUgZGVzaXJhYmxlIGJlY2F1c2UgdGhleSBoYXZlIGhpZ2ggcHJpb3JpdHkgYW5kIHdvcmtcbi8vIHJlbGlhYmx5IGV2ZXJ5d2hlcmUgdGhleSBhcmUgaW1wbGVtZW50ZWQuXG4vLyBUaGV5IGFyZSBpbXBsZW1lbnRlZCBpbiBhbGwgbW9kZXJuIGJyb3dzZXJzLlxuLy9cbi8vIC0gQW5kcm9pZCA0LTQuM1xuLy8gLSBDaHJvbWUgMjYtMzRcbi8vIC0gRmlyZWZveCAxNC0yOVxuLy8gLSBJbnRlcm5ldCBFeHBsb3JlciAxMVxuLy8gLSBpUGFkIFNhZmFyaSA2LTcuMVxuLy8gLSBpUGhvbmUgU2FmYXJpIDctNy4xXG4vLyAtIFNhZmFyaSA2LTdcbmlmICh0eXBlb2YgQnJvd3Nlck11dGF0aW9uT2JzZXJ2ZXIgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJlcXVlc3RGbHVzaCA9IG1ha2VSZXF1ZXN0Q2FsbEZyb21NdXRhdGlvbk9ic2VydmVyKGZsdXNoKTtcblxuLy8gTWVzc2FnZUNoYW5uZWxzIGFyZSBkZXNpcmFibGUgYmVjYXVzZSB0aGV5IGdpdmUgZGlyZWN0IGFjY2VzcyB0byB0aGUgSFRNTFxuLy8gdGFzayBxdWV1ZSwgYXJlIGltcGxlbWVudGVkIGluIEludGVybmV0IEV4cGxvcmVyIDEwLCBTYWZhcmkgNS4wLTEsIGFuZCBPcGVyYVxuLy8gMTEtMTIsIGFuZCBpbiB3ZWIgd29ya2VycyBpbiBtYW55IGVuZ2luZXMuXG4vLyBBbHRob3VnaCBtZXNzYWdlIGNoYW5uZWxzIHlpZWxkIHRvIGFueSBxdWV1ZWQgcmVuZGVyaW5nIGFuZCBJTyB0YXNrcywgdGhleVxuLy8gd291bGQgYmUgYmV0dGVyIHRoYW4gaW1wb3NpbmcgdGhlIDRtcyBkZWxheSBvZiB0aW1lcnMuXG4vLyBIb3dldmVyLCB0aGV5IGRvIG5vdCB3b3JrIHJlbGlhYmx5IGluIEludGVybmV0IEV4cGxvcmVyIG9yIFNhZmFyaS5cblxuLy8gSW50ZXJuZXQgRXhwbG9yZXIgMTAgaXMgdGhlIG9ubHkgYnJvd3NlciB0aGF0IGhhcyBzZXRJbW1lZGlhdGUgYnV0IGRvZXNcbi8vIG5vdCBoYXZlIE11dGF0aW9uT2JzZXJ2ZXJzLlxuLy8gQWx0aG91Z2ggc2V0SW1tZWRpYXRlIHlpZWxkcyB0byB0aGUgYnJvd3NlcidzIHJlbmRlcmVyLCBpdCB3b3VsZCBiZVxuLy8gcHJlZmVycmFibGUgdG8gZmFsbGluZyBiYWNrIHRvIHNldFRpbWVvdXQgc2luY2UgaXQgZG9lcyBub3QgaGF2ZVxuLy8gdGhlIG1pbmltdW0gNG1zIHBlbmFsdHkuXG4vLyBVbmZvcnR1bmF0ZWx5IHRoZXJlIGFwcGVhcnMgdG8gYmUgYSBidWcgaW4gSW50ZXJuZXQgRXhwbG9yZXIgMTAgTW9iaWxlIChhbmRcbi8vIERlc2t0b3AgdG8gYSBsZXNzZXIgZXh0ZW50KSB0aGF0IHJlbmRlcnMgYm90aCBzZXRJbW1lZGlhdGUgYW5kXG4vLyBNZXNzYWdlQ2hhbm5lbCB1c2VsZXNzIGZvciB0aGUgcHVycG9zZXMgb2YgQVNBUC5cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9rcmlza293YWwvcS9pc3N1ZXMvMzk2XG5cbi8vIFRpbWVycyBhcmUgaW1wbGVtZW50ZWQgdW5pdmVyc2FsbHkuXG4vLyBXZSBmYWxsIGJhY2sgdG8gdGltZXJzIGluIHdvcmtlcnMgaW4gbW9zdCBlbmdpbmVzLCBhbmQgaW4gZm9yZWdyb3VuZFxuLy8gY29udGV4dHMgaW4gdGhlIGZvbGxvd2luZyBicm93c2Vycy5cbi8vIEhvd2V2ZXIsIG5vdGUgdGhhdCBldmVuIHRoaXMgc2ltcGxlIGNhc2UgcmVxdWlyZXMgbnVhbmNlcyB0byBvcGVyYXRlIGluIGFcbi8vIGJyb2FkIHNwZWN0cnVtIG9mIGJyb3dzZXJzLlxuLy9cbi8vIC0gRmlyZWZveCAzLTEzXG4vLyAtIEludGVybmV0IEV4cGxvcmVyIDYtOVxuLy8gLSBpUGFkIFNhZmFyaSA0LjNcbi8vIC0gTHlueCAyLjguN1xufSBlbHNlIHtcbiAgICByZXF1ZXN0Rmx1c2ggPSBtYWtlUmVxdWVzdENhbGxGcm9tVGltZXIoZmx1c2gpO1xufVxuXG4vLyBgcmVxdWVzdEZsdXNoYCByZXF1ZXN0cyB0aGF0IHRoZSBoaWdoIHByaW9yaXR5IGV2ZW50IHF1ZXVlIGJlIGZsdXNoZWQgYXNcbi8vIHNvb24gYXMgcG9zc2libGUuXG4vLyBUaGlzIGlzIHVzZWZ1bCB0byBwcmV2ZW50IGFuIGVycm9yIHRocm93biBpbiBhIHRhc2sgZnJvbSBzdGFsbGluZyB0aGUgZXZlbnRcbi8vIHF1ZXVlIGlmIHRoZSBleGNlcHRpb24gaGFuZGxlZCBieSBOb2RlLmpz4oCZc1xuLy8gYHByb2Nlc3Mub24oXCJ1bmNhdWdodEV4Y2VwdGlvblwiKWAgb3IgYnkgYSBkb21haW4uXG5yYXdBc2FwLnJlcXVlc3RGbHVzaCA9IHJlcXVlc3RGbHVzaDtcblxuLy8gVG8gcmVxdWVzdCBhIGhpZ2ggcHJpb3JpdHkgZXZlbnQsIHdlIGluZHVjZSBhIG11dGF0aW9uIG9ic2VydmVyIGJ5IHRvZ2dsaW5nXG4vLyB0aGUgdGV4dCBvZiBhIHRleHQgbm9kZSBiZXR3ZWVuIFwiMVwiIGFuZCBcIi0xXCIuXG5mdW5jdGlvbiBtYWtlUmVxdWVzdENhbGxGcm9tTXV0YXRpb25PYnNlcnZlcihjYWxsYmFjaykge1xuICAgIHZhciB0b2dnbGUgPSAxO1xuICAgIHZhciBvYnNlcnZlciA9IG5ldyBCcm93c2VyTXV0YXRpb25PYnNlcnZlcihjYWxsYmFjayk7XG4gICAgdmFyIG5vZGUgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShcIlwiKTtcbiAgICBvYnNlcnZlci5vYnNlcnZlKG5vZGUsIHtjaGFyYWN0ZXJEYXRhOiB0cnVlfSk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIHJlcXVlc3RDYWxsKCkge1xuICAgICAgICB0b2dnbGUgPSAtdG9nZ2xlO1xuICAgICAgICBub2RlLmRhdGEgPSB0b2dnbGU7XG4gICAgfTtcbn1cblxuLy8gVGhlIG1lc3NhZ2UgY2hhbm5lbCB0ZWNobmlxdWUgd2FzIGRpc2NvdmVyZWQgYnkgTWFsdGUgVWJsIGFuZCB3YXMgdGhlXG4vLyBvcmlnaW5hbCBmb3VuZGF0aW9uIGZvciB0aGlzIGxpYnJhcnkuXG4vLyBodHRwOi8vd3d3Lm5vbmJsb2NraW5nLmlvLzIwMTEvMDYvd2luZG93bmV4dHRpY2suaHRtbFxuXG4vLyBTYWZhcmkgNi4wLjUgKGF0IGxlYXN0KSBpbnRlcm1pdHRlbnRseSBmYWlscyB0byBjcmVhdGUgbWVzc2FnZSBwb3J0cyBvbiBhXG4vLyBwYWdlJ3MgZmlyc3QgbG9hZC4gVGhhbmtmdWxseSwgdGhpcyB2ZXJzaW9uIG9mIFNhZmFyaSBzdXBwb3J0c1xuLy8gTXV0YXRpb25PYnNlcnZlcnMsIHNvIHdlIGRvbid0IG5lZWQgdG8gZmFsbCBiYWNrIGluIHRoYXQgY2FzZS5cblxuLy8gZnVuY3Rpb24gbWFrZVJlcXVlc3RDYWxsRnJvbU1lc3NhZ2VDaGFubmVsKGNhbGxiYWNrKSB7XG4vLyAgICAgdmFyIGNoYW5uZWwgPSBuZXcgTWVzc2FnZUNoYW5uZWwoKTtcbi8vICAgICBjaGFubmVsLnBvcnQxLm9ubWVzc2FnZSA9IGNhbGxiYWNrO1xuLy8gICAgIHJldHVybiBmdW5jdGlvbiByZXF1ZXN0Q2FsbCgpIHtcbi8vICAgICAgICAgY2hhbm5lbC5wb3J0Mi5wb3N0TWVzc2FnZSgwKTtcbi8vICAgICB9O1xuLy8gfVxuXG4vLyBGb3IgcmVhc29ucyBleHBsYWluZWQgYWJvdmUsIHdlIGFyZSBhbHNvIHVuYWJsZSB0byB1c2UgYHNldEltbWVkaWF0ZWBcbi8vIHVuZGVyIGFueSBjaXJjdW1zdGFuY2VzLlxuLy8gRXZlbiBpZiB3ZSB3ZXJlLCB0aGVyZSBpcyBhbm90aGVyIGJ1ZyBpbiBJbnRlcm5ldCBFeHBsb3JlciAxMC5cbi8vIEl0IGlzIG5vdCBzdWZmaWNpZW50IHRvIGFzc2lnbiBgc2V0SW1tZWRpYXRlYCB0byBgcmVxdWVzdEZsdXNoYCBiZWNhdXNlXG4vLyBgc2V0SW1tZWRpYXRlYCBtdXN0IGJlIGNhbGxlZCAqYnkgbmFtZSogYW5kIHRoZXJlZm9yZSBtdXN0IGJlIHdyYXBwZWQgaW4gYVxuLy8gY2xvc3VyZS5cbi8vIE5ldmVyIGZvcmdldC5cblxuLy8gZnVuY3Rpb24gbWFrZVJlcXVlc3RDYWxsRnJvbVNldEltbWVkaWF0ZShjYWxsYmFjaykge1xuLy8gICAgIHJldHVybiBmdW5jdGlvbiByZXF1ZXN0Q2FsbCgpIHtcbi8vICAgICAgICAgc2V0SW1tZWRpYXRlKGNhbGxiYWNrKTtcbi8vICAgICB9O1xuLy8gfVxuXG4vLyBTYWZhcmkgNi4wIGhhcyBhIHByb2JsZW0gd2hlcmUgdGltZXJzIHdpbGwgZ2V0IGxvc3Qgd2hpbGUgdGhlIHVzZXIgaXNcbi8vIHNjcm9sbGluZy4gVGhpcyBwcm9ibGVtIGRvZXMgbm90IGltcGFjdCBBU0FQIGJlY2F1c2UgU2FmYXJpIDYuMCBzdXBwb3J0c1xuLy8gbXV0YXRpb24gb2JzZXJ2ZXJzLCBzbyB0aGF0IGltcGxlbWVudGF0aW9uIGlzIHVzZWQgaW5zdGVhZC5cbi8vIEhvd2V2ZXIsIGlmIHdlIGV2ZXIgZWxlY3QgdG8gdXNlIHRpbWVycyBpbiBTYWZhcmksIHRoZSBwcmV2YWxlbnQgd29yay1hcm91bmRcbi8vIGlzIHRvIGFkZCBhIHNjcm9sbCBldmVudCBsaXN0ZW5lciB0aGF0IGNhbGxzIGZvciBhIGZsdXNoLlxuXG4vLyBgc2V0VGltZW91dGAgZG9lcyBub3QgY2FsbCB0aGUgcGFzc2VkIGNhbGxiYWNrIGlmIHRoZSBkZWxheSBpcyBsZXNzIHRoYW5cbi8vIGFwcHJveGltYXRlbHkgNyBpbiB3ZWIgd29ya2VycyBpbiBGaXJlZm94IDggdGhyb3VnaCAxOCwgYW5kIHNvbWV0aW1lcyBub3Rcbi8vIGV2ZW4gdGhlbi5cblxuZnVuY3Rpb24gbWFrZVJlcXVlc3RDYWxsRnJvbVRpbWVyKGNhbGxiYWNrKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIHJlcXVlc3RDYWxsKCkge1xuICAgICAgICAvLyBXZSBkaXNwYXRjaCBhIHRpbWVvdXQgd2l0aCBhIHNwZWNpZmllZCBkZWxheSBvZiAwIGZvciBlbmdpbmVzIHRoYXRcbiAgICAgICAgLy8gY2FuIHJlbGlhYmx5IGFjY29tbW9kYXRlIHRoYXQgcmVxdWVzdC4gVGhpcyB3aWxsIHVzdWFsbHkgYmUgc25hcHBlZFxuICAgICAgICAvLyB0byBhIDQgbWlsaXNlY29uZCBkZWxheSwgYnV0IG9uY2Ugd2UncmUgZmx1c2hpbmcsIHRoZXJlJ3Mgbm8gZGVsYXlcbiAgICAgICAgLy8gYmV0d2VlbiBldmVudHMuXG4gICAgICAgIHZhciB0aW1lb3V0SGFuZGxlID0gc2V0VGltZW91dChoYW5kbGVUaW1lciwgMCk7XG4gICAgICAgIC8vIEhvd2V2ZXIsIHNpbmNlIHRoaXMgdGltZXIgZ2V0cyBmcmVxdWVudGx5IGRyb3BwZWQgaW4gRmlyZWZveFxuICAgICAgICAvLyB3b3JrZXJzLCB3ZSBlbmxpc3QgYW4gaW50ZXJ2YWwgaGFuZGxlIHRoYXQgd2lsbCB0cnkgdG8gZmlyZVxuICAgICAgICAvLyBhbiBldmVudCAyMCB0aW1lcyBwZXIgc2Vjb25kIHVudGlsIGl0IHN1Y2NlZWRzLlxuICAgICAgICB2YXIgaW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbChoYW5kbGVUaW1lciwgNTApO1xuXG4gICAgICAgIGZ1bmN0aW9uIGhhbmRsZVRpbWVyKCkge1xuICAgICAgICAgICAgLy8gV2hpY2hldmVyIHRpbWVyIHN1Y2NlZWRzIHdpbGwgY2FuY2VsIGJvdGggdGltZXJzIGFuZFxuICAgICAgICAgICAgLy8gZXhlY3V0ZSB0aGUgY2FsbGJhY2suXG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dEhhbmRsZSk7XG4gICAgICAgICAgICBjbGVhckludGVydmFsKGludGVydmFsSGFuZGxlKTtcbiAgICAgICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICAgIH1cbiAgICB9O1xufVxuXG4vLyBUaGlzIGlzIGZvciBgYXNhcC5qc2Agb25seS5cbi8vIEl0cyBuYW1lIHdpbGwgYmUgcGVyaW9kaWNhbGx5IHJhbmRvbWl6ZWQgdG8gYnJlYWsgYW55IGNvZGUgdGhhdCBkZXBlbmRzIG9uXG4vLyBpdHMgZXhpc3RlbmNlLlxucmF3QXNhcC5tYWtlUmVxdWVzdENhbGxGcm9tVGltZXIgPSBtYWtlUmVxdWVzdENhbGxGcm9tVGltZXI7XG5cbi8vIEFTQVAgd2FzIG9yaWdpbmFsbHkgYSBuZXh0VGljayBzaGltIGluY2x1ZGVkIGluIFEuIFRoaXMgd2FzIGZhY3RvcmVkIG91dFxuLy8gaW50byB0aGlzIEFTQVAgcGFja2FnZS4gSXQgd2FzIGxhdGVyIGFkYXB0ZWQgdG8gUlNWUCB3aGljaCBtYWRlIGZ1cnRoZXJcbi8vIGFtZW5kbWVudHMuIFRoZXNlIGRlY2lzaW9ucywgcGFydGljdWxhcmx5IHRvIG1hcmdpbmFsaXplIE1lc3NhZ2VDaGFubmVsIGFuZFxuLy8gdG8gY2FwdHVyZSB0aGUgTXV0YXRpb25PYnNlcnZlciBpbXBsZW1lbnRhdGlvbiBpbiBhIGNsb3N1cmUsIHdlcmUgaW50ZWdyYXRlZFxuLy8gYmFjayBpbnRvIEFTQVAgcHJvcGVyLlxuLy8gaHR0cHM6Ly9naXRodWIuY29tL3RpbGRlaW8vcnN2cC5qcy9ibG9iL2NkZGY3MjMyNTQ2YTljZjg1ODUyNGI3NWNkZTZmOWVkZjcyNjIwYTcvbGliL3JzdnAvYXNhcC5qc1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY29yZS5qcycpO1xucmVxdWlyZSgnLi9kb25lLmpzJyk7XG5yZXF1aXJlKCcuL2ZpbmFsbHkuanMnKTtcbnJlcXVpcmUoJy4vZXM2LWV4dGVuc2lvbnMuanMnKTtcbnJlcXVpcmUoJy4vbm9kZS1leHRlbnNpb25zLmpzJyk7XG5yZXF1aXJlKCcuL3N5bmNocm9ub3VzLmpzJyk7XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBhc2FwID0gcmVxdWlyZSgnYXNhcC9yYXcnKTtcblxuZnVuY3Rpb24gbm9vcCgpIHt9XG5cbi8vIFN0YXRlczpcbi8vXG4vLyAwIC0gcGVuZGluZ1xuLy8gMSAtIGZ1bGZpbGxlZCB3aXRoIF92YWx1ZVxuLy8gMiAtIHJlamVjdGVkIHdpdGggX3ZhbHVlXG4vLyAzIC0gYWRvcHRlZCB0aGUgc3RhdGUgb2YgYW5vdGhlciBwcm9taXNlLCBfdmFsdWVcbi8vXG4vLyBvbmNlIHRoZSBzdGF0ZSBpcyBubyBsb25nZXIgcGVuZGluZyAoMCkgaXQgaXMgaW1tdXRhYmxlXG5cbi8vIEFsbCBgX2AgcHJlZml4ZWQgcHJvcGVydGllcyB3aWxsIGJlIHJlZHVjZWQgdG8gYF97cmFuZG9tIG51bWJlcn1gXG4vLyBhdCBidWlsZCB0aW1lIHRvIG9iZnVzY2F0ZSB0aGVtIGFuZCBkaXNjb3VyYWdlIHRoZWlyIHVzZS5cbi8vIFdlIGRvbid0IHVzZSBzeW1ib2xzIG9yIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSB0byBmdWxseSBoaWRlIHRoZW1cbi8vIGJlY2F1c2UgdGhlIHBlcmZvcm1hbmNlIGlzbid0IGdvb2QgZW5vdWdoLlxuXG5cbi8vIHRvIGF2b2lkIHVzaW5nIHRyeS9jYXRjaCBpbnNpZGUgY3JpdGljYWwgZnVuY3Rpb25zLCB3ZVxuLy8gZXh0cmFjdCB0aGVtIHRvIGhlcmUuXG52YXIgTEFTVF9FUlJPUiA9IG51bGw7XG52YXIgSVNfRVJST1IgPSB7fTtcbmZ1bmN0aW9uIGdldFRoZW4ob2JqKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIG9iai50aGVuO1xuICB9IGNhdGNoIChleCkge1xuICAgIExBU1RfRVJST1IgPSBleDtcbiAgICByZXR1cm4gSVNfRVJST1I7XG4gIH1cbn1cblxuZnVuY3Rpb24gdHJ5Q2FsbE9uZShmbiwgYSkge1xuICB0cnkge1xuICAgIHJldHVybiBmbihhKTtcbiAgfSBjYXRjaCAoZXgpIHtcbiAgICBMQVNUX0VSUk9SID0gZXg7XG4gICAgcmV0dXJuIElTX0VSUk9SO1xuICB9XG59XG5mdW5jdGlvbiB0cnlDYWxsVHdvKGZuLCBhLCBiKSB7XG4gIHRyeSB7XG4gICAgZm4oYSwgYik7XG4gIH0gY2F0Y2ggKGV4KSB7XG4gICAgTEFTVF9FUlJPUiA9IGV4O1xuICAgIHJldHVybiBJU19FUlJPUjtcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IFByb21pc2U7XG5cbmZ1bmN0aW9uIFByb21pc2UoZm4pIHtcbiAgaWYgKHR5cGVvZiB0aGlzICE9PSAnb2JqZWN0Jykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1Byb21pc2VzIG11c3QgYmUgY29uc3RydWN0ZWQgdmlhIG5ldycpO1xuICB9XG4gIGlmICh0eXBlb2YgZm4gIT09ICdmdW5jdGlvbicpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdQcm9taXNlIGNvbnN0cnVjdG9yXFwncyBhcmd1bWVudCBpcyBub3QgYSBmdW5jdGlvbicpO1xuICB9XG4gIHRoaXMuXzQwID0gMDtcbiAgdGhpcy5fNjUgPSAwO1xuICB0aGlzLl81NSA9IG51bGw7XG4gIHRoaXMuXzcyID0gbnVsbDtcbiAgaWYgKGZuID09PSBub29wKSByZXR1cm47XG4gIGRvUmVzb2x2ZShmbiwgdGhpcyk7XG59XG5Qcm9taXNlLl8zNyA9IG51bGw7XG5Qcm9taXNlLl84NyA9IG51bGw7XG5Qcm9taXNlLl82MSA9IG5vb3A7XG5cblByb21pc2UucHJvdG90eXBlLnRoZW4gPSBmdW5jdGlvbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICBpZiAodGhpcy5jb25zdHJ1Y3RvciAhPT0gUHJvbWlzZSkge1xuICAgIHJldHVybiBzYWZlVGhlbih0aGlzLCBvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCk7XG4gIH1cbiAgdmFyIHJlcyA9IG5ldyBQcm9taXNlKG5vb3ApO1xuICBoYW5kbGUodGhpcywgbmV3IEhhbmRsZXIob25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQsIHJlcykpO1xuICByZXR1cm4gcmVzO1xufTtcblxuZnVuY3Rpb24gc2FmZVRoZW4oc2VsZiwgb25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQpIHtcbiAgcmV0dXJuIG5ldyBzZWxmLmNvbnN0cnVjdG9yKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICB2YXIgcmVzID0gbmV3IFByb21pc2Uobm9vcCk7XG4gICAgcmVzLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICBoYW5kbGUoc2VsZiwgbmV3IEhhbmRsZXIob25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQsIHJlcykpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGhhbmRsZShzZWxmLCBkZWZlcnJlZCkge1xuICB3aGlsZSAoc2VsZi5fNjUgPT09IDMpIHtcbiAgICBzZWxmID0gc2VsZi5fNTU7XG4gIH1cbiAgaWYgKFByb21pc2UuXzM3KSB7XG4gICAgUHJvbWlzZS5fMzcoc2VsZik7XG4gIH1cbiAgaWYgKHNlbGYuXzY1ID09PSAwKSB7XG4gICAgaWYgKHNlbGYuXzQwID09PSAwKSB7XG4gICAgICBzZWxmLl80MCA9IDE7XG4gICAgICBzZWxmLl83MiA9IGRlZmVycmVkO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoc2VsZi5fNDAgPT09IDEpIHtcbiAgICAgIHNlbGYuXzQwID0gMjtcbiAgICAgIHNlbGYuXzcyID0gW3NlbGYuXzcyLCBkZWZlcnJlZF07XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNlbGYuXzcyLnB1c2goZGVmZXJyZWQpO1xuICAgIHJldHVybjtcbiAgfVxuICBoYW5kbGVSZXNvbHZlZChzZWxmLCBkZWZlcnJlZCk7XG59XG5cbmZ1bmN0aW9uIGhhbmRsZVJlc29sdmVkKHNlbGYsIGRlZmVycmVkKSB7XG4gIGFzYXAoZnVuY3Rpb24oKSB7XG4gICAgdmFyIGNiID0gc2VsZi5fNjUgPT09IDEgPyBkZWZlcnJlZC5vbkZ1bGZpbGxlZCA6IGRlZmVycmVkLm9uUmVqZWN0ZWQ7XG4gICAgaWYgKGNiID09PSBudWxsKSB7XG4gICAgICBpZiAoc2VsZi5fNjUgPT09IDEpIHtcbiAgICAgICAgcmVzb2x2ZShkZWZlcnJlZC5wcm9taXNlLCBzZWxmLl81NSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZWplY3QoZGVmZXJyZWQucHJvbWlzZSwgc2VsZi5fNTUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgcmV0ID0gdHJ5Q2FsbE9uZShjYiwgc2VsZi5fNTUpO1xuICAgIGlmIChyZXQgPT09IElTX0VSUk9SKSB7XG4gICAgICByZWplY3QoZGVmZXJyZWQucHJvbWlzZSwgTEFTVF9FUlJPUik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc29sdmUoZGVmZXJyZWQucHJvbWlzZSwgcmV0KTtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gcmVzb2x2ZShzZWxmLCBuZXdWYWx1ZSkge1xuICAvLyBQcm9taXNlIFJlc29sdXRpb24gUHJvY2VkdXJlOiBodHRwczovL2dpdGh1Yi5jb20vcHJvbWlzZXMtYXBsdXMvcHJvbWlzZXMtc3BlYyN0aGUtcHJvbWlzZS1yZXNvbHV0aW9uLXByb2NlZHVyZVxuICBpZiAobmV3VmFsdWUgPT09IHNlbGYpIHtcbiAgICByZXR1cm4gcmVqZWN0KFxuICAgICAgc2VsZixcbiAgICAgIG5ldyBUeXBlRXJyb3IoJ0EgcHJvbWlzZSBjYW5ub3QgYmUgcmVzb2x2ZWQgd2l0aCBpdHNlbGYuJylcbiAgICApO1xuICB9XG4gIGlmIChcbiAgICBuZXdWYWx1ZSAmJlxuICAgICh0eXBlb2YgbmV3VmFsdWUgPT09ICdvYmplY3QnIHx8IHR5cGVvZiBuZXdWYWx1ZSA9PT0gJ2Z1bmN0aW9uJylcbiAgKSB7XG4gICAgdmFyIHRoZW4gPSBnZXRUaGVuKG5ld1ZhbHVlKTtcbiAgICBpZiAodGhlbiA9PT0gSVNfRVJST1IpIHtcbiAgICAgIHJldHVybiByZWplY3Qoc2VsZiwgTEFTVF9FUlJPUik7XG4gICAgfVxuICAgIGlmIChcbiAgICAgIHRoZW4gPT09IHNlbGYudGhlbiAmJlxuICAgICAgbmV3VmFsdWUgaW5zdGFuY2VvZiBQcm9taXNlXG4gICAgKSB7XG4gICAgICBzZWxmLl82NSA9IDM7XG4gICAgICBzZWxmLl81NSA9IG5ld1ZhbHVlO1xuICAgICAgZmluYWxlKHNlbGYpO1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGRvUmVzb2x2ZSh0aGVuLmJpbmQobmV3VmFsdWUpLCBzZWxmKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbiAgc2VsZi5fNjUgPSAxO1xuICBzZWxmLl81NSA9IG5ld1ZhbHVlO1xuICBmaW5hbGUoc2VsZik7XG59XG5cbmZ1bmN0aW9uIHJlamVjdChzZWxmLCBuZXdWYWx1ZSkge1xuICBzZWxmLl82NSA9IDI7XG4gIHNlbGYuXzU1ID0gbmV3VmFsdWU7XG4gIGlmIChQcm9taXNlLl84Nykge1xuICAgIFByb21pc2UuXzg3KHNlbGYsIG5ld1ZhbHVlKTtcbiAgfVxuICBmaW5hbGUoc2VsZik7XG59XG5mdW5jdGlvbiBmaW5hbGUoc2VsZikge1xuICBpZiAoc2VsZi5fNDAgPT09IDEpIHtcbiAgICBoYW5kbGUoc2VsZiwgc2VsZi5fNzIpO1xuICAgIHNlbGYuXzcyID0gbnVsbDtcbiAgfVxuICBpZiAoc2VsZi5fNDAgPT09IDIpIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlbGYuXzcyLmxlbmd0aDsgaSsrKSB7XG4gICAgICBoYW5kbGUoc2VsZiwgc2VsZi5fNzJbaV0pO1xuICAgIH1cbiAgICBzZWxmLl83MiA9IG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gSGFuZGxlcihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCwgcHJvbWlzZSl7XG4gIHRoaXMub25GdWxmaWxsZWQgPSB0eXBlb2Ygb25GdWxmaWxsZWQgPT09ICdmdW5jdGlvbicgPyBvbkZ1bGZpbGxlZCA6IG51bGw7XG4gIHRoaXMub25SZWplY3RlZCA9IHR5cGVvZiBvblJlamVjdGVkID09PSAnZnVuY3Rpb24nID8gb25SZWplY3RlZCA6IG51bGw7XG4gIHRoaXMucHJvbWlzZSA9IHByb21pc2U7XG59XG5cbi8qKlxuICogVGFrZSBhIHBvdGVudGlhbGx5IG1pc2JlaGF2aW5nIHJlc29sdmVyIGZ1bmN0aW9uIGFuZCBtYWtlIHN1cmVcbiAqIG9uRnVsZmlsbGVkIGFuZCBvblJlamVjdGVkIGFyZSBvbmx5IGNhbGxlZCBvbmNlLlxuICpcbiAqIE1ha2VzIG5vIGd1YXJhbnRlZXMgYWJvdXQgYXN5bmNocm9ueS5cbiAqL1xuZnVuY3Rpb24gZG9SZXNvbHZlKGZuLCBwcm9taXNlKSB7XG4gIHZhciBkb25lID0gZmFsc2U7XG4gIHZhciByZXMgPSB0cnlDYWxsVHdvKGZuLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICBpZiAoZG9uZSkgcmV0dXJuO1xuICAgIGRvbmUgPSB0cnVlO1xuICAgIHJlc29sdmUocHJvbWlzZSwgdmFsdWUpO1xuICB9LCBmdW5jdGlvbiAocmVhc29uKSB7XG4gICAgaWYgKGRvbmUpIHJldHVybjtcbiAgICBkb25lID0gdHJ1ZTtcbiAgICByZWplY3QocHJvbWlzZSwgcmVhc29uKTtcbiAgfSk7XG4gIGlmICghZG9uZSAmJiByZXMgPT09IElTX0VSUk9SKSB7XG4gICAgZG9uZSA9IHRydWU7XG4gICAgcmVqZWN0KHByb21pc2UsIExBU1RfRVJST1IpO1xuICB9XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBQcm9taXNlID0gcmVxdWlyZSgnLi9jb3JlLmpzJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gUHJvbWlzZTtcblByb21pc2UucHJvdG90eXBlLmRvbmUgPSBmdW5jdGlvbiAob25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQpIHtcbiAgdmFyIHNlbGYgPSBhcmd1bWVudHMubGVuZ3RoID8gdGhpcy50aGVuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykgOiB0aGlzO1xuICBzZWxmLnRoZW4obnVsbCwgZnVuY3Rpb24gKGVycikge1xuICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH0sIDApO1xuICB9KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbi8vVGhpcyBmaWxlIGNvbnRhaW5zIHRoZSBFUzYgZXh0ZW5zaW9ucyB0byB0aGUgY29yZSBQcm9taXNlcy9BKyBBUElcblxudmFyIFByb21pc2UgPSByZXF1aXJlKCcuL2NvcmUuanMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBQcm9taXNlO1xuXG4vKiBTdGF0aWMgRnVuY3Rpb25zICovXG5cbnZhciBUUlVFID0gdmFsdWVQcm9taXNlKHRydWUpO1xudmFyIEZBTFNFID0gdmFsdWVQcm9taXNlKGZhbHNlKTtcbnZhciBOVUxMID0gdmFsdWVQcm9taXNlKG51bGwpO1xudmFyIFVOREVGSU5FRCA9IHZhbHVlUHJvbWlzZSh1bmRlZmluZWQpO1xudmFyIFpFUk8gPSB2YWx1ZVByb21pc2UoMCk7XG52YXIgRU1QVFlTVFJJTkcgPSB2YWx1ZVByb21pc2UoJycpO1xuXG5mdW5jdGlvbiB2YWx1ZVByb21pc2UodmFsdWUpIHtcbiAgdmFyIHAgPSBuZXcgUHJvbWlzZShQcm9taXNlLl82MSk7XG4gIHAuXzY1ID0gMTtcbiAgcC5fNTUgPSB2YWx1ZTtcbiAgcmV0dXJuIHA7XG59XG5Qcm9taXNlLnJlc29sdmUgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgaWYgKHZhbHVlIGluc3RhbmNlb2YgUHJvbWlzZSkgcmV0dXJuIHZhbHVlO1xuXG4gIGlmICh2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIE5VTEw7XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSByZXR1cm4gVU5ERUZJTkVEO1xuICBpZiAodmFsdWUgPT09IHRydWUpIHJldHVybiBUUlVFO1xuICBpZiAodmFsdWUgPT09IGZhbHNlKSByZXR1cm4gRkFMU0U7XG4gIGlmICh2YWx1ZSA9PT0gMCkgcmV0dXJuIFpFUk87XG4gIGlmICh2YWx1ZSA9PT0gJycpIHJldHVybiBFTVBUWVNUUklORztcblxuICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyB8fCB0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbicpIHtcbiAgICB0cnkge1xuICAgICAgdmFyIHRoZW4gPSB2YWx1ZS50aGVuO1xuICAgICAgaWYgKHR5cGVvZiB0aGVuID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSh0aGVuLmJpbmQodmFsdWUpKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChleCkge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgcmVqZWN0KGV4KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdmFsdWVQcm9taXNlKHZhbHVlKTtcbn07XG5cblByb21pc2UuYWxsID0gZnVuY3Rpb24gKGFycikge1xuICB2YXIgYXJncyA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFycik7XG5cbiAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICBpZiAoYXJncy5sZW5ndGggPT09IDApIHJldHVybiByZXNvbHZlKFtdKTtcbiAgICB2YXIgcmVtYWluaW5nID0gYXJncy5sZW5ndGg7XG4gICAgZnVuY3Rpb24gcmVzKGksIHZhbCkge1xuICAgICAgaWYgKHZhbCAmJiAodHlwZW9mIHZhbCA9PT0gJ29iamVjdCcgfHwgdHlwZW9mIHZhbCA9PT0gJ2Z1bmN0aW9uJykpIHtcbiAgICAgICAgaWYgKHZhbCBpbnN0YW5jZW9mIFByb21pc2UgJiYgdmFsLnRoZW4gPT09IFByb21pc2UucHJvdG90eXBlLnRoZW4pIHtcbiAgICAgICAgICB3aGlsZSAodmFsLl82NSA9PT0gMykge1xuICAgICAgICAgICAgdmFsID0gdmFsLl81NTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHZhbC5fNjUgPT09IDEpIHJldHVybiByZXMoaSwgdmFsLl81NSk7XG4gICAgICAgICAgaWYgKHZhbC5fNjUgPT09IDIpIHJlamVjdCh2YWwuXzU1KTtcbiAgICAgICAgICB2YWwudGhlbihmdW5jdGlvbiAodmFsKSB7XG4gICAgICAgICAgICByZXMoaSwgdmFsKTtcbiAgICAgICAgICB9LCByZWplY3QpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2YXIgdGhlbiA9IHZhbC50aGVuO1xuICAgICAgICAgIGlmICh0eXBlb2YgdGhlbiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgdmFyIHAgPSBuZXcgUHJvbWlzZSh0aGVuLmJpbmQodmFsKSk7XG4gICAgICAgICAgICBwLnRoZW4oZnVuY3Rpb24gKHZhbCkge1xuICAgICAgICAgICAgICByZXMoaSwgdmFsKTtcbiAgICAgICAgICAgIH0sIHJlamVjdCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhcmdzW2ldID0gdmFsO1xuICAgICAgaWYgKC0tcmVtYWluaW5nID09PSAwKSB7XG4gICAgICAgIHJlc29sdmUoYXJncyk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJncy5sZW5ndGg7IGkrKykge1xuICAgICAgcmVzKGksIGFyZ3NbaV0pO1xuICAgIH1cbiAgfSk7XG59O1xuXG5Qcm9taXNlLnJlamVjdCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgIHJlamVjdCh2YWx1ZSk7XG4gIH0pO1xufTtcblxuUHJvbWlzZS5yYWNlID0gZnVuY3Rpb24gKHZhbHVlcykge1xuICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgIHZhbHVlcy5mb3JFYWNoKGZ1bmN0aW9uKHZhbHVlKXtcbiAgICAgIFByb21pc2UucmVzb2x2ZSh2YWx1ZSkudGhlbihyZXNvbHZlLCByZWplY3QpO1xuICAgIH0pO1xuICB9KTtcbn07XG5cbi8qIFByb3RvdHlwZSBNZXRob2RzICovXG5cblByb21pc2UucHJvdG90eXBlWydjYXRjaCddID0gZnVuY3Rpb24gKG9uUmVqZWN0ZWQpIHtcbiAgcmV0dXJuIHRoaXMudGhlbihudWxsLCBvblJlamVjdGVkKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBQcm9taXNlID0gcmVxdWlyZSgnLi9jb3JlLmpzJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gUHJvbWlzZTtcblByb21pc2UucHJvdG90eXBlWydmaW5hbGx5J10gPSBmdW5jdGlvbiAoZikge1xuICByZXR1cm4gdGhpcy50aGVuKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZigpKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9KTtcbiAgfSwgZnVuY3Rpb24gKGVycikge1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZigpKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgIHRocm93IGVycjtcbiAgICB9KTtcbiAgfSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgUHJvbWlzZSA9IHJlcXVpcmUoJy4vY29yZS5qcycpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFByb21pc2U7XG5Qcm9taXNlLmVuYWJsZVN5bmNocm9ub3VzID0gZnVuY3Rpb24gKCkge1xuICBQcm9taXNlLnByb3RvdHlwZS5pc1BlbmRpbmcgPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdGF0ZSgpID09IDA7XG4gIH07XG5cbiAgUHJvbWlzZS5wcm90b3R5cGUuaXNGdWxmaWxsZWQgPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdGF0ZSgpID09IDE7XG4gIH07XG5cbiAgUHJvbWlzZS5wcm90b3R5cGUuaXNSZWplY3RlZCA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0YXRlKCkgPT0gMjtcbiAgfTtcblxuICBQcm9taXNlLnByb3RvdHlwZS5nZXRWYWx1ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5fNjUgPT09IDMpIHtcbiAgICAgIHJldHVybiB0aGlzLl81NS5nZXRWYWx1ZSgpO1xuICAgIH1cblxuICAgIGlmICghdGhpcy5pc0Z1bGZpbGxlZCgpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBnZXQgYSB2YWx1ZSBvZiBhbiB1bmZ1bGZpbGxlZCBwcm9taXNlLicpO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl81NTtcbiAgfTtcblxuICBQcm9taXNlLnByb3RvdHlwZS5nZXRSZWFzb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHRoaXMuXzY1ID09PSAzKSB7XG4gICAgICByZXR1cm4gdGhpcy5fNTUuZ2V0UmVhc29uKCk7XG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLmlzUmVqZWN0ZWQoKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgZ2V0IGEgcmVqZWN0aW9uIHJlYXNvbiBvZiBhIG5vbi1yZWplY3RlZCBwcm9taXNlLicpO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl81NTtcbiAgfTtcblxuICBQcm9taXNlLnByb3RvdHlwZS5nZXRTdGF0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5fNjUgPT09IDMpIHtcbiAgICAgIHJldHVybiB0aGlzLl81NS5nZXRTdGF0ZSgpO1xuICAgIH1cbiAgICBpZiAodGhpcy5fNjUgPT09IC0xIHx8IHRoaXMuXzY1ID09PSAtMikge1xuICAgICAgcmV0dXJuIDA7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuXzY1O1xuICB9O1xufTtcblxuUHJvbWlzZS5kaXNhYmxlU3luY2hyb25vdXMgPSBmdW5jdGlvbigpIHtcbiAgUHJvbWlzZS5wcm90b3R5cGUuaXNQZW5kaW5nID0gdW5kZWZpbmVkO1xuICBQcm9taXNlLnByb3RvdHlwZS5pc0Z1bGZpbGxlZCA9IHVuZGVmaW5lZDtcbiAgUHJvbWlzZS5wcm90b3R5cGUuaXNSZWplY3RlZCA9IHVuZGVmaW5lZDtcbiAgUHJvbWlzZS5wcm90b3R5cGUuZ2V0VmFsdWUgPSB1bmRlZmluZWQ7XG4gIFByb21pc2UucHJvdG90eXBlLmdldFJlYXNvbiA9IHVuZGVmaW5lZDtcbiAgUHJvbWlzZS5wcm90b3R5cGUuZ2V0U3RhdGUgPSB1bmRlZmluZWQ7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vLyBUaGlzIGZpbGUgY29udGFpbnMgdGhlbi9wcm9taXNlIHNwZWNpZmljIGV4dGVuc2lvbnMgdGhhdCBhcmUgb25seSB1c2VmdWxcbi8vIGZvciBub2RlLmpzIGludGVyb3BcblxudmFyIFByb21pc2UgPSByZXF1aXJlKCcuL2NvcmUuanMnKTtcbnZhciBhc2FwID0gcmVxdWlyZSgnYXNhcCcpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFByb21pc2U7XG5cbi8qIFN0YXRpYyBGdW5jdGlvbnMgKi9cblxuUHJvbWlzZS5kZW5vZGVpZnkgPSBmdW5jdGlvbiAoZm4sIGFyZ3VtZW50Q291bnQpIHtcbiAgaWYgKFxuICAgIHR5cGVvZiBhcmd1bWVudENvdW50ID09PSAnbnVtYmVyJyAmJiBhcmd1bWVudENvdW50ICE9PSBJbmZpbml0eVxuICApIHtcbiAgICByZXR1cm4gZGVub2RlaWZ5V2l0aENvdW50KGZuLCBhcmd1bWVudENvdW50KTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gZGVub2RlaWZ5V2l0aG91dENvdW50KGZuKTtcbiAgfVxufTtcblxudmFyIGNhbGxiYWNrRm4gPSAoXG4gICdmdW5jdGlvbiAoZXJyLCByZXMpIHsnICtcbiAgJ2lmIChlcnIpIHsgcmooZXJyKTsgfSBlbHNlIHsgcnMocmVzKTsgfScgK1xuICAnfSdcbik7XG5mdW5jdGlvbiBkZW5vZGVpZnlXaXRoQ291bnQoZm4sIGFyZ3VtZW50Q291bnQpIHtcbiAgdmFyIGFyZ3MgPSBbXTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcmd1bWVudENvdW50OyBpKyspIHtcbiAgICBhcmdzLnB1c2goJ2EnICsgaSk7XG4gIH1cbiAgdmFyIGJvZHkgPSBbXG4gICAgJ3JldHVybiBmdW5jdGlvbiAoJyArIGFyZ3Muam9pbignLCcpICsgJykgeycsXG4gICAgJ3ZhciBzZWxmID0gdGhpczsnLFxuICAgICdyZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJzLCByaikgeycsXG4gICAgJ3ZhciByZXMgPSBmbi5jYWxsKCcsXG4gICAgWydzZWxmJ10uY29uY2F0KGFyZ3MpLmNvbmNhdChbY2FsbGJhY2tGbl0pLmpvaW4oJywnKSxcbiAgICAnKTsnLFxuICAgICdpZiAocmVzICYmJyxcbiAgICAnKHR5cGVvZiByZXMgPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIHJlcyA9PT0gXCJmdW5jdGlvblwiKSAmJicsXG4gICAgJ3R5cGVvZiByZXMudGhlbiA9PT0gXCJmdW5jdGlvblwiJyxcbiAgICAnKSB7cnMocmVzKTt9JyxcbiAgICAnfSk7JyxcbiAgICAnfTsnXG4gIF0uam9pbignJyk7XG4gIHJldHVybiBGdW5jdGlvbihbJ1Byb21pc2UnLCAnZm4nXSwgYm9keSkoUHJvbWlzZSwgZm4pO1xufVxuZnVuY3Rpb24gZGVub2RlaWZ5V2l0aG91dENvdW50KGZuKSB7XG4gIHZhciBmbkxlbmd0aCA9IE1hdGgubWF4KGZuLmxlbmd0aCAtIDEsIDMpO1xuICB2YXIgYXJncyA9IFtdO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGZuTGVuZ3RoOyBpKyspIHtcbiAgICBhcmdzLnB1c2goJ2EnICsgaSk7XG4gIH1cbiAgdmFyIGJvZHkgPSBbXG4gICAgJ3JldHVybiBmdW5jdGlvbiAoJyArIGFyZ3Muam9pbignLCcpICsgJykgeycsXG4gICAgJ3ZhciBzZWxmID0gdGhpczsnLFxuICAgICd2YXIgYXJnczsnLFxuICAgICd2YXIgYXJnTGVuZ3RoID0gYXJndW1lbnRzLmxlbmd0aDsnLFxuICAgICdpZiAoYXJndW1lbnRzLmxlbmd0aCA+ICcgKyBmbkxlbmd0aCArICcpIHsnLFxuICAgICdhcmdzID0gbmV3IEFycmF5KGFyZ3VtZW50cy5sZW5ndGggKyAxKTsnLFxuICAgICdmb3IgKHZhciBpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykgeycsXG4gICAgJ2FyZ3NbaV0gPSBhcmd1bWVudHNbaV07JyxcbiAgICAnfScsXG4gICAgJ30nLFxuICAgICdyZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJzLCByaikgeycsXG4gICAgJ3ZhciBjYiA9ICcgKyBjYWxsYmFja0ZuICsgJzsnLFxuICAgICd2YXIgcmVzOycsXG4gICAgJ3N3aXRjaCAoYXJnTGVuZ3RoKSB7JyxcbiAgICBhcmdzLmNvbmNhdChbJ2V4dHJhJ10pLm1hcChmdW5jdGlvbiAoXywgaW5kZXgpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgICdjYXNlICcgKyAoaW5kZXgpICsgJzonICtcbiAgICAgICAgJ3JlcyA9IGZuLmNhbGwoJyArIFsnc2VsZiddLmNvbmNhdChhcmdzLnNsaWNlKDAsIGluZGV4KSkuY29uY2F0KCdjYicpLmpvaW4oJywnKSArICcpOycgK1xuICAgICAgICAnYnJlYWs7J1xuICAgICAgKTtcbiAgICB9KS5qb2luKCcnKSxcbiAgICAnZGVmYXVsdDonLFxuICAgICdhcmdzW2FyZ0xlbmd0aF0gPSBjYjsnLFxuICAgICdyZXMgPSBmbi5hcHBseShzZWxmLCBhcmdzKTsnLFxuICAgICd9JyxcbiAgICBcbiAgICAnaWYgKHJlcyAmJicsXG4gICAgJyh0eXBlb2YgcmVzID09PSBcIm9iamVjdFwiIHx8IHR5cGVvZiByZXMgPT09IFwiZnVuY3Rpb25cIikgJiYnLFxuICAgICd0eXBlb2YgcmVzLnRoZW4gPT09IFwiZnVuY3Rpb25cIicsXG4gICAgJykge3JzKHJlcyk7fScsXG4gICAgJ30pOycsXG4gICAgJ307J1xuICBdLmpvaW4oJycpO1xuXG4gIHJldHVybiBGdW5jdGlvbihcbiAgICBbJ1Byb21pc2UnLCAnZm4nXSxcbiAgICBib2R5XG4gICkoUHJvbWlzZSwgZm4pO1xufVxuXG5Qcm9taXNlLm5vZGVpZnkgPSBmdW5jdGlvbiAoZm4pIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgYXJncyA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cyk7XG4gICAgdmFyIGNhbGxiYWNrID1cbiAgICAgIHR5cGVvZiBhcmdzW2FyZ3MubGVuZ3RoIC0gMV0gPT09ICdmdW5jdGlvbicgPyBhcmdzLnBvcCgpIDogbnVsbDtcbiAgICB2YXIgY3R4ID0gdGhpcztcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGZuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykubm9kZWlmeShjYWxsYmFjaywgY3R4KTtcbiAgICB9IGNhdGNoIChleCkge1xuICAgICAgaWYgKGNhbGxiYWNrID09PSBudWxsIHx8IHR5cGVvZiBjYWxsYmFjayA9PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgIHJlamVjdChleCk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXNhcChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgY2FsbGJhY2suY2FsbChjdHgsIGV4KTtcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG4gIH1cbn07XG5cblByb21pc2UucHJvdG90eXBlLm5vZGVpZnkgPSBmdW5jdGlvbiAoY2FsbGJhY2ssIGN0eCkge1xuICBpZiAodHlwZW9mIGNhbGxiYWNrICE9ICdmdW5jdGlvbicpIHJldHVybiB0aGlzO1xuXG4gIHRoaXMudGhlbihmdW5jdGlvbiAodmFsdWUpIHtcbiAgICBhc2FwKGZ1bmN0aW9uICgpIHtcbiAgICAgIGNhbGxiYWNrLmNhbGwoY3R4LCBudWxsLCB2YWx1ZSk7XG4gICAgfSk7XG4gIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICBhc2FwKGZ1bmN0aW9uICgpIHtcbiAgICAgIGNhbGxiYWNrLmNhbGwoY3R4LCBlcnIpO1xuICAgIH0pO1xuICB9KTtcbn07XG4iXX0=