! function n(a, i, s) {
    function o(t, e) {
        if (!i[t]) {
            if (!a[t]) {
                var r = "function" == typeof require && require;
                if (!e && r) return r(t, !0);
                if (u) return u(t, !0);
                throw (r = new Error("Cannot find module '" + t + "'")).code = "MODULE_NOT_FOUND", r
            }
            r = i[t] = {
                exports: {}
            }, a[t][0].call(r.exports, function(e) {
                return o(a[t][1][e] || e)
            }, r, r.exports, n, a, i, s)
        }
        return i[t].exports
    }
    for (var u = "function" == typeof require && require, e = 0; e < s.length; e++) o(s[e]);
    return o
}({
    1: [function(e, t, r) {
        "use strict";
        var i = e("@trustpilot/trustbox-framework-vanilla/modules/slider"),
            n = h(e("@trustpilot/trustbox-framework-vanilla/modules/impression")),
            a = e("@trustpilot/trustbox-framework-vanilla/modules/api"),
            s = e("@trustpilot/trustbox-framework-vanilla/modules/dom"),
            o = e("@trustpilot/trustbox-framework-vanilla/modules/utils"),
            u = e("@trustpilot/trustbox-framework-vanilla/modules/queryString"),
            l = h(e("@trustpilot/trustbox-framework-vanilla/modules/templates/reviews")),
            c = e("@trustpilot/trustbox-framework-vanilla/modules/templates/logo"),
            d = e("@trustpilot/trustbox-framework-vanilla/modules/templating"),
            f = e("@trustpilot/trustbox-framework-vanilla/modules/templates/summary"),
            p = h(e("@trustpilot/trustbox-framework-vanilla/modules/init")),
            v = e("./placeholder"),
            m = h(e("@trustpilot/trustbox-framework-vanilla/modules/reviewFilterText"));

        function h(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        n.default.attachImpressionHandler();

        function g(e) {
            return function() {
                return n.default.engagement({
                    source: e
                })
            }
        }

        function y(e) {
            var t, r = e.baseData,
                n = e.locale;
            0 < r.businessEntity.numberOfReviews.total ? (function(e) {
                var t = e.locale,
                    r = e.reviews,
                    n = {
                        slider: document.getElementById("tp-widget-reviews"),
                        sliderContainer: document.getElementById("tp-widget-reviews-wrapper")
                    },
                    a = {
                        prevArrow: document.getElementById("review-arrow-left"),
                        nextArrow: document.getElementById("review-arrow-right")
                    },
                    e = {
                        reviewLinkGenerator: function(e) {
                            return M(e.reviewUrl)
                        }
                    },
                    t = (0, l.default)(t.toLowerCase(), e);
                [].slice.call(document.getElementsByClassName("svg-slider-arrow")).forEach(function(e) {
                    return (0, s.populateElements)([{
                        element: e,
                        string: (0, d.mkElemWithSvgLookup)("arrowSlider")
                    }, {
                        element: e,
                        string: (0, d.mkElemWithSvgLookup)("arrowSlider")
                    }])
                });
                e = {
                    prevPage: g("Prev"),
                    nextPage: g("Next")
                }, t = new i.ReviewSlider(r, n, t, {
                    reviewClass: "tp-widget-review",
                    reviewsPerPage: [{
                        minWidth: 1200,
                        reviewsForWidth: 5
                    }, {
                        minWidth: 980,
                        reviewsForWidth: 4
                    }, {
                        minWidth: 760,
                        reviewsForWidth: 3
                    }, {
                        minWidth: 540,
                        reviewsForWidth: 2
                    }, {
                        minWidth: 0,
                        reviewsForWidth: 1
                    }]
                });
                new i.ArrowControls(t, a, {
                    callbacks: e,
                    disabledClass: "display-none"
                }).initialize()
            }({
                locale: n,
                reviews: r.reviews
            }), function(e) {
                var t = e.locale,
                    r = e.baseData,
                    n = r.businessEntity,
                    a = n.numberOfReviews.total,
                    i = n.trustScore,
                    e = r.links.profileUrl,
                    n = r.translations,
                    r = document.getElementById("rating-long");
                (0, s.populateElements)([{
                    element: r,
                    string: n.mainLong,
                    substitutions: {
                        "[RATING]": i.toFixed(1),
                        "[NOREVIEWS]": (0, o.insertNumberSeparator)(a, t)
                    }
                }]), document.querySelector("#rating-long a").href = M(e);
                r = document.getElementById("rating-short");
                (0, s.populateElements)([{
                    element: r,
                    string: n.mainShort,
                    substitutions: {
                        "[RATING]": i.toFixed(1),
                        "[NOREVIEWS]": (0, o.insertNumberSeparator)(a, t)
                    }
                }]), document.querySelector("#rating-short a").href = M(e);
                a = document.getElementById("tp-widget-reviews-filter-label"), t = (0, m.default)(t, _, S);
                (0, o.setTextContent)(a, t);
                t = document.getElementById("tp-widget-reviews-filter-dot");
                (0, s.populateElements)([{
                    element: t,
                    string: n.dot
                }]), document.getElementById("tp-widget-logo").href = M(e), (0, c.populateLogo)()
            }({
                locale: n,
                baseData: r
            })) : (t = M(r.links.evaluateUrl), e = r.translations.noReviews, e = (n = {
                title: e,
                url: t
            }).title, t = n.url, n = document.getElementById("tp-widget-wrapper"), t = {
                title: e,
                url: t,
                orientation: f.ORIENTATION.HORIZONTAL
            }, t = (0, f.makeEmptySummary)(t), (0, o.setHtmlContent)(n, t, !1)), r.settings.customStylesAllowed && (P && (0, o.setFont)(P), x && (0, o.setTextColor)(x))
        }
        var b = (0, u.getAsObject)(),
            w = b.businessunitId,
            j = b.locale,
            k = b.theme,
            e = void 0 === k ? "light" : k,
            u = b.reviewLanguages,
            _ = b.stars,
            S = b.tags,
            k = b.location,
            O = b.templateId,
            P = b.fontFamily,
            x = b.textColor,
            M = (0, o.addUtmParams)("Slider"),
            E = {
                businessUnitId: w,
                locale: j,
                reviewLanguages: u,
                reviewStars: _,
                reviewTagValue: S,
                reviewsPerPage: 15,
                theme: e,
                location: k
            };
        (0, s.populateElements)([{
            element: document.getElementById("tp-widget-loader"),
            string: (0, v.createPlaceholder)()
        }]), (0, p.default)(function() {
            (0, a.fetchServiceReviewData)(O)(E, y)
        })
    }, {
        "./placeholder": 2,
        "@trustpilot/trustbox-framework-vanilla/modules/api": 31,
        "@trustpilot/trustbox-framework-vanilla/modules/dom": 38,
        "@trustpilot/trustbox-framework-vanilla/modules/impression": 40,
        "@trustpilot/trustbox-framework-vanilla/modules/init": 41,
        "@trustpilot/trustbox-framework-vanilla/modules/queryString": 42,
        "@trustpilot/trustbox-framework-vanilla/modules/reviewFilterText": 43,
        "@trustpilot/trustbox-framework-vanilla/modules/slider": 47,
        "@trustpilot/trustbox-framework-vanilla/modules/templates/logo": 53,
        "@trustpilot/trustbox-framework-vanilla/modules/templates/reviews": 54,
        "@trustpilot/trustbox-framework-vanilla/modules/templates/summary": 56,
        "@trustpilot/trustbox-framework-vanilla/modules/templating": 57,
        "@trustpilot/trustbox-framework-vanilla/modules/utils": 61
    }],
    38: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.populateElements = r.removeClass = r.addClass = void 0;
        var n = e("./utils");

        function a(e, t) {
            if (e) {
                e = e.getAttribute("class");
                return -1 !== (e ? e.split(" ") : "").indexOf(t)
            }
            return !1
        }
        r.addClass = function(e, t) {
            var r;
            e && (r = (r = e.getAttribute("class")) ? r.split(" ") : [], a(e, t) || (t = [].concat(function(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return Array.from(e)
            }(r), [t]).join(" "), e.setAttribute("class", t)))
        }, r.removeClass = function(e, t) {
            var r;
            e && (r = e.className.split(" "), e.className = r.filter(function(e) {
                return e !== t
            }).join(" "))
        }, r.populateElements = function(e) {
            e.forEach(function(e) {
                var t = e.element,
                    r = e.string,
                    e = e.substitutions;
                r ? (0, n.setHtmlContent)(t, (0, n.makeTranslations)(void 0 === e ? {} : e, r), !1) : (0, n.removeElement)(t)
            })
        }
    }, {
        "./utils": 61
    }],
    40: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var o = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            u = e("./queryString"),
            n = e("./utils"),
            l = a(e("./rootUri")),
            c = a(e("./xhr"));

        function a(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function d(e, t) {
            var r, n = {};
            for (r in e) 0 <= t.indexOf(r) || Object.prototype.hasOwnProperty.call(e, r) && (n[r] = e[r]);
            return n
        }

        function f(e, t) {
            var r = t.session,
                n = t.testId,
                a = t.sessionExpiry,
                i = (0, u.getAsObject)(),
                t = i.group,
                i = i.businessunitId;
            t && a && (i = "TrustboxSplitTest_" + i, t = encodeURIComponent(JSON.stringify({
                group: t,
                session: r,
                testId: n
            })), r = a, n = "path=/", a = "domain=" + window.location.hostname.replace(/^.*\.([^.]+\.[^.]+)/, "$1"), document.cookie = [i + "=" + t, n, r, a, "samesite=none", "secure"].join("; "), document.cookie = [i + "-legacy=" + t, n, r, a].join("; "))
        }

        function i(e, t) {
            f(0, t);
            var r, n, a, i, s, n = (r = e, a = (n = t).anonymousId, n.sessionExpiry, i = d(n, ["anonymousId", "sessionExpiry"]), t = (e = (0, u.getAsObject)()).businessunitId, n = e.templateId, e = d(e, ["businessunitId", "templateId"]), s = o({}, e, i, e.group && a ? {
                userId: a
            } : {
                nosettings: 1
            }, {
                businessUnitId: t,
                widgetId: n
            }), n = Object.keys(s).map(function(e) {
                return e + "=" + encodeURIComponent(s[e])
            }).join("&"), (0, l.default)() + "/stats/" + r + "?" + n);
            try {
                (0, c.default)({
                    url: n
                })
            } catch (e) {}
        }
        var s;
        r.default = {
            engagement: function(e) {
                i("TrustboxEngagement", e)
            },
            attachImpressionHandler: function() {
                (0, n.addEventListener)(window, "message", function(e) {
                    if ("string" == typeof e.data) {
                        var t = void 0;
                        try {
                            t = {
                                data: JSON.parse(e.data)
                            }
                        } catch (t) {
                            return
                        }
                        if ("setId" === t.data.command) return s = t.data.widgetId, void window.parent.postMessage(JSON.stringify({
                            command: "impression",
                            widgetId: s
                        }), "*");
                        "impression-received" === t.data.command && (delete t.data.command, i("TrustboxImpression", t.data)), "trustbox-in-viewport" === t.data.command && (delete t.data.command, i("TrustboxView", t.data))
                    }
                })
            }
        }
    }, {
        "./queryString": 42,
        "./rootUri": 44,
        "./utils": 61,
        "./xhr": 62
    }],
    53: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.populateLogo = r.makeLogo = void 0;

        function n() {
            return (0, a.mkElemWithSvgLookup)("logo")
        }
        var a = e("../templating"),
            i = e("../dom");
        r.makeLogo = n, r.populateLogo = function() {
            var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "tp-widget-logo",
                e = "string" == typeof e ? document.getElementById(e) : e;
            (0, i.populateElements)([{
                element: e,
                string: n()
            }])
        }
    }, {
        "../dom": 38,
        "../templating": 57
    }],
    56: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.ORIENTATION = r.makeEmptySummary = void 0;
        var a = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            i = e("../templating"),
            s = e("./stars"),
            o = e("./logo"),
            u = e("../utils");

        function l(e) {
            return e ? {
                rel: "nofollow"
            } : {}
        }

        function c(e) {
            var t = e.subtitle,
                r = e.url,
                n = e.hasLogo,
                e = e.nofollow,
                r = [(t = t && (0, u.makeTranslations)({}, t)) && (0, i.span)({
                    class: "tp-widget-empty-vertical__subtitle"
                }, t), r && (0, i.a)(a({
                    class: "tp-widget-empty-vertical__logo",
                    href: r,
                    target: "_blank"
                }, l(e)), (0, o.makeLogo)()), n && !r && (0, i.span)({
                    class: "tp-widget-empty-vertical__logo"
                }, (0, o.makeLogo)())].filter(Boolean);
            return i.div.apply(void 0, [{
                class: "tp-widget-empty-vertical__subtitle-wrapper"
            }].concat(function(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return Array.from(e)
            }(r)))
        }
        var d = {
            HORIZONTAL: "horizontal",
            VERTICAL: "vertical"
        };
        r.makeEmptySummary = function(e) {
            return e.orientation === d.HORIZONTAL ? (r = (t = e).title, n = t.url, t = t.nofollow, r = (0, u.makeTranslations)({}, r), (0, i.div)({
                class: "tp-widget-empty-horizontal"
            }, (0, i.span)({
                class: "tp-widget-empty-horizontal__title"
            }, r), (0, i.a)(a({
                class: "tp-widget-empty-horizontal__logo",
                href: n,
                target: "_blank"
            }, l(t)), (0, o.makeLogo)()))) : (t = e, e = (0, u.makeTranslations)({}, t.title), t = c(t), (0, i.div)({
                class: "tp-widget-empty-vertical"
            }, (0, i.span)({
                class: "tp-widget-empty-vertical__title"
            }, e), (0, s.makeStars)({
                num: 0,
                wrapperClass: "tp-widget-empty-vertical__stars"
            }), t));
            var t, r, n
        }, r.ORIENTATION = d
    }, {
        "../templating": 57,
        "../utils": 61,
        "./logo": 53,
        "./stars": 55
    }],
    57: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.mkElemWithSvgLookup = r.span = r.div = r.a = void 0;

        function i(t) {
            return Object.keys(t).map(function(e) {
                return e + '="' + t[e] + '"'
            }).join(" ")
        }

        function n(a) {
            return function(e) {
                for (var t = arguments.length, r = Array(1 < t ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
                return "<" + a + " " + i(e) + ">" + (e = r, [].concat.apply([], e).join("\n")) + "</" + a + ">"
            }
        }
        var a, s = e("./assets/svg"),
            o = n("a"),
            u = n("div"),
            e = (n("img"), n("label"), n("span"));
        a = "input";
        r.a = o, r.div = u, r.span = e, r.mkElemWithSvgLookup = function(e) {
            return u({
                class: 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : ""
            }, s.svgMap[e](arguments[2]))
        }
    }, {
        "./assets/svg": 36
    }],
    41: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = e("./communication"),
            a = e("./templates/errorFallback");
        r.default = function(e) {
            var t = !1;
            (0, n.onPong)(function() {
                t = !0, "function" == typeof e && e()
            }), (0, n.ping)(), setTimeout(function() {
                t || (0, a.errorFallback)()
            }, 500)
        }
    }, {
        "./communication": 37,
        "./templates/errorFallback": 51
    }],
    2: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.createPlaceholder = void 0;
        var n = e("@trustpilot/trustbox-framework-vanilla/modules/templating"),
            a = e("@trustpilot/trustbox-framework-vanilla/modules/templates/stars"),
            i = e("@trustpilot/trustbox-framework-vanilla/modules/utils");

        function s() {
            return (0, n.div)({
                class: "tp-widget-review tp-widget-review--placeholder"
            }, [(0, a.makeStars)({
                num: 0
            }), (0, n.div)({
                class: "tp-widget-review__placeholder tp-widget-review__placeholder--small"
            })].concat(function(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r
                }
                return Array.from(e)
            }((0, i.range)(2).map(function() {
                return (0, n.div)({
                    class: "tp-widget-review__placeholder tp-widget-review__placeholder"
                })
            }))))
        }
        r.createPlaceholder = function() {
            return (0, n.div)({
                class: "tp-widget-reviews tp-widget-reviews--placeholder"
            }, (0, i.range)(5).map(s))
        }
    }, {
        "@trustpilot/trustbox-framework-vanilla/modules/templates/stars": 55,
        "@trustpilot/trustbox-framework-vanilla/modules/templating": 57,
        "@trustpilot/trustbox-framework-vanilla/modules/utils": 61
    }],
    54: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n, u = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            },
            l = e("../templating"),
            a = e("../smartAge"),
            c = (n = a) && n.__esModule ? n : {
                default: n
            },
            d = e("./stars"),
            f = e("../text"),
            p = e("../translations");
        r.default = function(s) {
            var o = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {};
            return function(e) {
                var t, r, n, a, r = (r = "function" == typeof(t = o), a = null !== t && "object" === (void 0 === t ? "undefined" : u(t)), n = a ? t : {}, {
                        reviewLinkGenerator: r ? t : a ? t.reviewLinkGenerator : null,
                        textLength: n.textLength,
                        starColor: n.starColor,
                        importedReviews: n.importedReviews,
                        showReviewSource: n.showReviewSource
                    }),
                    i = r.reviewLinkGenerator,
                    a = r.textLength,
                    t = void 0 === a ? 85 : a,
                    n = r.showReviewSource,
                    a = void 0 !== n && n,
                    n = function() {
                        return i ? (0, l.a)({
                            href: i(e),
                            target: "_blank",
                            rel: "nofollow"
                        }, l.div.apply(void 0, arguments)) : l.div.apply(void 0, arguments)
                    };
                return (0, l.div)({
                    class: "tp-widget-review" + (r.importedReviews ? " tp-widget-review--imported" : "")
                }, (0, l.div)({
                    class: "tp-widget-stars"
                }, (0, d.makeStars)({
                    num: e.stars,
                    color: r.starColor
                })), (0, l.div)({
                    class: "date secondary-text"
                }, (0, c.default)(s, e.createdAt)), e.title ? n({
                    class: "header"
                }, (0, f.escapeHtml)(e.title)) : "", n({
                    class: "text"
                }, (0, f.truncateText)(e.text || e.content, t)), n({
                    class: "name secondary-text"
                }, e.consumer.displayName), a ? (0, l.div)({
                    class: "tp-widget-review__source"
                }, [(n = s, (a = e.verifiedBy) ? (0, p.getFrameworkTranslation)("reviews.collectedVia", (0, p.formatLocale)(n), {
                    "[source]": a
                }) : (0, p.getFrameworkTranslation)("reviews.verifiedVia", (0, p.formatLocale)(n), {
                    "[source]": "Trustpilot"
                }))]) : null)
            }
        }
    }, {
        "../smartAge": 50,
        "../templating": 57,
        "../text": 58,
        "../translations": 60,
        "./stars": 55
    }],
    47: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.ArrowControls = r.ReviewSlider = void 0;
        var n = i(e("./reviewSlider")),
            a = i(e("./arrowControls")),
            e = i(e("./paginationControls"));

        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        r.ReviewSlider = n.default, r.ArrowControls = a.default, e.default
    }, {
        "./arrowControls": 45,
        "./paginationControls": 48,
        "./reviewSlider": 49
    }],
    42: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.getAsObject = void 0;
        var n = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            a = function(e, t) {
                if (Array.isArray(e)) return e;
                if (Symbol.iterator in Object(e)) return function(e, t) {
                    var r = [],
                        n = !0,
                        a = !1,
                        i = void 0;
                    try {
                        for (var s, o = e[Symbol.iterator](); !(n = (s = o.next()).done) && (r.push(s.value), !t || r.length !== t); n = !0);
                    } catch (e) {
                        a = !0, i = e
                    } finally {
                        try {
                            !n && o.return && o.return()
                        } finally {
                            if (a) throw i
                        }
                    }
                    return r
                }(e, t);
                throw new TypeError("Invalid attempt to destructure non-iterable instance")
            },
            i = e("./fn");

        function s(e) {
            var t = ["?", "#"];
            return (0, i.compose)(i.pairsToObject, function(e) {
                return e.split("&").filter(Boolean).map(function(e) {
                    var t = e.split("="),
                        e = a(t, 2),
                        t = e[0],
                        e = e[1];
                    try {
                        return [decodeURIComponent(t), decodeURIComponent(e)]
                    } catch (e) {}
                }).filter(Boolean)
            }, function(e) {
                return -1 !== t.indexOf(e[0]) ? e.substring(1) : e
            })(e)
        }

        function o() {
            var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : window.location,
                t = s(e.search),
                e = s(e.hash);
            return n({}, t, e)
        }
        r.getAsObject = o
    }, {
        "./fn": 39
    }],
    43: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var a = e("./translations"),
            i = function(e, t) {
                var r = "reviewFilters.byLatest",
                    n = {},
                    e = (0, a.formatLocale)(e);
                switch (t.length) {
                    case 4:
                        r = "reviewFilters.byStars4", n["[star1]"] = t[0], n["[star2]"] = t[1], n["[star3]"] = t[2], n["[star4]"] = t[3];
                        break;
                    case 3:
                        r = "reviewFilters.byStars3", n["[star1]"] = t[0], n["[star2]"] = t[1], n["[star3]"] = t[2];
                        break;
                    case 2:
                        r = "reviewFilters.byStars2", n["[star1]"] = t[0], n["[star2]"] = t[1];
                        break;
                    case 1:
                        r = "reviewFilters.byStars1", n["[star1]"] = t[0]
                }
                return (0, a.getFrameworkTranslation)(r, e, n)
            };
        r.default = function(e, t, r) {
            var n = (0, a.formatLocale)(e);
            return r ? (0, a.getFrameworkTranslation)("reviewFilters.byFavoriteOrTag", n) : t && !["1", "2", "3", "4", "5"].every(function(e) {
                return -1 < t.split(",").indexOf(e)
            }) ? i(e, t.split(",").sort()) : (0, a.getFrameworkTranslation)("reviewFilters.byLatest", n)
        }
    }, {
        "./translations": 60
    }],
    61: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.sanitizeColor = r.sanitizeHtml = r.setFont = r.setTextColor = r.range = r.addUtmParams = r.showTrustBox = r.removeElement = r.makeTranslations = r.getOnPageReady = r.addEventListener = r.setHtmlContent = r.setTextContent = r.insertNumberSeparator = void 0;
        var n, s = function(e, t) {
                if (Array.isArray(e)) return e;
                if (Symbol.iterator in Object(e)) return function(e, t) {
                    var r = [],
                        n = !0,
                        a = !1,
                        i = void 0;
                    try {
                        for (var s, o = e[Symbol.iterator](); !(n = (s = o.next()).done) && (r.push(s.value), !t || r.length !== t); n = !0);
                    } catch (e) {
                        a = !0, i = e
                    } finally {
                        try {
                            !n && o.return && o.return()
                        } finally {
                            if (a) throw i
                        }
                    }
                    return r
                }(e, t);
                throw new TypeError("Invalid attempt to destructure non-iterable instance")
            },
            a = e("promise"),
            i = (n = a) && n.__esModule ? n : {
                default: n
            },
            o = e("./dom");

        function u(t, e, r) {
            t && (t.addEventListener ? t.addEventListener(e, r) : t.attachEvent("on" + e, function(e) {
                (e = e || window.event).preventDefault = e.preventDefault || function() {
                    e.returnValue = !1
                }, e.stopPropagation = e.stopPropagation || function() {
                    e.cancelBubble = !0
                }, r.call(t, e)
            }))
        }

        function l(e) {
            return "string" != typeof e ? e : e.replace(/(<\/?(?:p|b|i|li|ul|a|strong)\/?>)|(?:<\/?.*?\/?>)/gi, "$1")
        }

        function c(t) {
            return function(e) {
                return (e = e) + (-1 === e.indexOf("?") ? "?" : "&") + "utm_medium=trustbox&utm_source=" + t
            }
        }

        function d(e) {
            var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1,
                e = "#" === e[0] ? parseInt(e.slice(1), 16) : parseInt(e, 16);
            return "rgba(" + (e >> 16) + "," + (e >> 8 & 255) + "," + (255 & e) + "," + t + ")"
        }
        r.insertNumberSeparator = function(t, e) {
            try {
                t.toLocaleString()
            } catch (e) {
                return t
            }
            return t.toLocaleString(e || "en-US")
        }, r.setTextContent = function(e, t) {
            e && ("innerText" in e ? e.innerText = t : e.textContent = t)
        }, r.setHtmlContent = function(e, t) {
            e && (e.innerHTML = !(2 < arguments.length && void 0 !== arguments[2]) || arguments[2] ? l(t) : t)
        }, r.addEventListener = u, r.getOnPageReady = function() {
            return new i.default(function(e) {
                function t() {
                    setTimeout(function() {
                        e()
                    }, 0)
                }
                "complete" === document.readyState ? t() : u(window, "load", function() {
                    t()
                })
            })
        }, r.makeTranslations = function(r, e) {
            return e ? Object.keys(r).reduce(function(e, t) {
                return e.split(t).join(r[t])
            }, e) : ""
        }, r.removeElement = function(e) {
            if (e && e.parentNode) return e.parentNode.removeChild(e)
        }, r.showTrustBox = function(e, t) {
            var r = document.getElementsByTagName("body")[0],
                n = document.getElementById("tp-widget-wrapper");
            (0, o.addClass)(r, e), (0, o.addClass)(n, "visible"), t || (0, o.addClass)(r, "first-reviewer")
        }, r.addUtmParams = c, r.range = function(e) {
            for (var t = []; 0 < e;) t.push(t.length), e--;
            return t
        }, r.setTextColor = function(e) {
            var t = document.createElement("style");
            t.appendChild(document.createTextNode("\n      * {\n        color: inherit !important;\n      }\n      body {\n        color: " + e + " !important;\n      }\n      .bold-underline {\n        border-bottom-color: " + e + " !important;\n      }\n      .bold-underline:hover {\n        border-color: " + function(e, t) {
                var r = function(e) {
                        return 255 < e ? 255 : e < 0 ? 0 : e
                    },
                    n = !1;
                "#" === e[0] && (e = e.slice(1), n = !0);
                var a = parseInt(e, 16);
                if (!a) return e;
                var i = (a >> 16) + t,
                    e = (a >> 8 & 255) + t,
                    t = (255 & a) + t,
                    r = [i = r(i), e = r(e), t = r(t)].map(function(e) {
                        return e <= 15 ? "0" + e.toString(16) : e.toString(16)
                    }),
                    r = s(r, 3);
                return (n ? "#" : "") + (i = r[0]) + (e = r[1]) + (t = r[2])
            }(e, -30) + " !important;\n      }\n      .secondary-text {\n        color: " + d(e, .6) + " !important;\n      }\n      .secondary-text-arrow {\n        border-color: " + d(e, .6) + " transparent transparent transparent !important;\n      }\n      .read-more {\n        color: " + e + " !important;\n      }\n    ")), document.head.appendChild(t)
        }, r.setFont = function(e) {
            var t = document.createElement("link");
            t.rel = "stylesheet", t.href = "https://fonts.googleapis.com/css?family=" + e + ":wght@400,500,700", document.head.appendChild(t);
            t = e.replace(/\+/g, " "), e = document.createElement("style");
            e.appendChild(document.createTextNode('\n    * {\n      font-family: inherit !important;\n    }\n    body {\n      font-family: "' + t + '", sans-serif !important;\n    }\n    ')), document.head.appendChild(e)
        }, r.sanitizeHtml = l, r.sanitizeColor = function(e) {
            return "string" == typeof e && /^#(?:[\da-fA-F]{3}){1,2}$/.test(e) ? e : null
        }
    }, {
        "./dom": 38,
        promise: 65
    }],
    31: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.fetchServiceReviewData = void 0;
        var a = e("./fetchData"),
            e = e("./productReviews");
        e.fetchProductData, e.fetchProductReview, a.constructTrustBoxAndComplete, r.fetchServiceReviewData = function(n) {
            return function(e, t, r) {
                (0, a.fetchData)("/trustbox-data/" + n)(e, t, r, a.hasServiceReviews)
            }
        }
    }, {
        "./fetchData": 30,
        "./productReviews": 32
    }],
    55: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.makeStars = void 0;

        function n(e) {
            var t = e.num,
                r = void 0 === (a = e.trustScore) ? null : a,
                n = void 0 === (i = e.wrapperClass) ? "" : i,
                a = e.color,
                i = Math.floor(t),
                e = t === i ? "" : " tp-stars--" + i + "--half",
                a = (0, o.sanitizeColor)(a);
            return (0, s.div)({
                class: n
            }, (0, s.mkElemWithSvgLookup)("stars", a ? "tp-stars-custom-color" : "tp-stars tp-stars--" + i + e, {
                rating: t,
                trustScore: r || t,
                color: a
            }))
        }
        var s = e("../templating"),
            o = (e("../dom"), e("../utils"));
        r.makeStars = n
    }, {
        "../dom": 38,
        "../templating": 57,
        "../utils": 61
    }],
    3: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "anmeldelse",
                plural: "anmeldelser",
                collectedVia: "Indsamlet via [source]",
                verifiedVia: "Verificeret – indsamlet via [source]"
            },
            monthNames: {
                january: "januar",
                february: "februar",
                march: "marts",
                april: "april",
                may: "maj",
                june: "juni",
                july: "juli",
                august: "august",
                september: "september",
                october: "oktober",
                november: "november",
                december: "december"
            },
            timeAgo: {
                days: {
                    singular: "For [count] dag siden",
                    plural: "For [count] dage siden"
                },
                hours: {
                    singular: "For [count] time siden",
                    plural: "For [count] timer siden"
                },
                minutes: {
                    singular: "For [count] minut siden",
                    plural: "For [count] minutter siden"
                },
                seconds: {
                    singular: "For [count] sekund siden",
                    plural: "For [count] sekunder siden"
                }
            },
            reviewFilters: {
                byStars1: "Viser vores [star1]-stjernede anmeldelser",
                byStars2: "Viser vores [star1]- og [star2]-stjernede anmeldelser",
                byStars3: "Viser vores [star1]-, [star2]- og [star3]-stjernede anmeldelser",
                byStars4: "Viser vores [star1]-, [star2]-, [star3]- og [star4]-stjernede anmeldelser",
                byLatest: "Viser vores seneste anmeldelser",
                byFavoriteOrTag: "Viser vores yndlingsanmeldelser"
            }
        }
    }, {}],
    4: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "Bewertung",
                plural: "Bewertungen",
                collectedVia: "Gesammelt über [source]",
                verifiedVia: "Verifiziert, gesammelt über [source]"
            },
            monthNames: {
                january: "Januar",
                february: "Februar",
                march: "März",
                april: "April",
                may: "Mai",
                june: "Juni",
                july: "Juli",
                august: "August",
                september: "September",
                october: "Oktober",
                november: "November",
                december: "Dezember"
            },
            timeAgo: {
                days: {
                    singular: "vor [count] Tag",
                    plural: "vor [count] Tagen"
                },
                hours: {
                    singular: "vor [count] Stunde",
                    plural: "vor [count] Stunden"
                },
                minutes: {
                    singular: "vor [count] Minute",
                    plural: "vor [count] Minuten"
                },
                seconds: {
                    singular: "vor [count] Sekunde",
                    plural: "vor [count] Sekunden"
                }
            },
            reviewFilters: {
                byStars1: "Einige unserer [star1]-Sterne-Bewertungen",
                byStars2: "Einige unserer [star1]- & [star2]-Sterne-Bewertungen",
                byStars3: "Einige unserer [star1]-, [star2]- & [star3]-Sterne-Bewertungen",
                byStars4: "Einige unserer [star1]-, [star2]-, [star3]- & [star4]-Sterne-Bewertungen",
                byLatest: "Unsere neuesten Bewertungen",
                byFavoriteOrTag: "Unsere Lieblingsbewertungen"
            }
        }
    }, {}],
    5: [function(e, t, r) {
        arguments[4][4][0].apply(r, arguments)
    }, {
        dup: 4
    }],
    6: [function(e, t, r) {
        arguments[4][4][0].apply(r, arguments)
    }, {
        dup: 4
    }],
    7: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "review",
                plural: "reviews",
                collectedVia: "Collected via [source]",
                verifiedVia: "Verified, collected via [source]"
            },
            monthNames: {
                january: "January",
                february: "February",
                march: "March",
                april: "April",
                may: "May",
                june: "June",
                july: "July",
                august: "August",
                september: "September",
                october: "October",
                november: "November",
                december: "December"
            },
            timeAgo: {
                days: {
                    singular: "[count] day ago",
                    plural: "[count] days ago"
                },
                hours: {
                    singular: "[count] hour ago",
                    plural: "[count] hours ago"
                },
                minutes: {
                    singular: "[count] minute ago",
                    plural: "[count] minutes ago"
                },
                seconds: {
                    singular: "[count] second ago",
                    plural: "[count] seconds ago"
                }
            },
            reviewFilters: {
                byStars1: "Showing our [star1] star reviews",
                byStars2: "Showing our [star1] & [star2] star reviews",
                byStars3: "Showing our [star1], [star2] & [star3] star reviews",
                byStars4: "Showing our [star1], [star2], [star3] & [star4] star reviews",
                byLatest: "Showing our latest reviews",
                byFavoriteOrTag: "Showing our favourite reviews"
            }
        }
    }, {}],
    8: [function(e, t, r) {
        arguments[4][7][0].apply(r, arguments)
    }, {
        dup: 7
    }],
    9: [function(e, t, r) {
        arguments[4][7][0].apply(r, arguments)
    }, {
        dup: 7
    }],
    10: [function(e, t, r) {
        arguments[4][7][0].apply(r, arguments)
    }, {
        dup: 7
    }],
    11: [function(e, t, r) {
        arguments[4][7][0].apply(r, arguments)
    }, {
        dup: 7
    }],
    12: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "review",
                plural: "reviews",
                collectedVia: "Collected via [source]",
                verifiedVia: "Verified, collected via [source]"
            },
            monthNames: {
                january: "January",
                february: "February",
                march: "March",
                april: "April",
                may: "May",
                june: "June",
                july: "July",
                august: "August",
                september: "September",
                october: "October",
                november: "November",
                december: "December"
            },
            timeAgo: {
                days: {
                    singular: "[count] day ago",
                    plural: "[count] days ago"
                },
                hours: {
                    singular: "[count] hour ago",
                    plural: "[count] hours ago"
                },
                minutes: {
                    singular: "[count] minute ago",
                    plural: "[count] minutes ago"
                },
                seconds: {
                    singular: "[count] second ago",
                    plural: "[count] seconds ago"
                }
            },
            reviewFilters: {
                byStars1: "Showing our [star1] star reviews",
                byStars2: "Showing our [star1] & [star2] star reviews",
                byStars3: "Showing our [star1], [star2] & [star3] star reviews",
                byStars4: "Showing our [star1], [star2], [star3] & [star4] star reviews",
                byLatest: "Showing our latest reviews",
                byFavoriteOrTag: "Showing our favorite reviews"
            }
        }
    }, {}],
    13: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "opinión",
                plural: "opiniones",
                collectedVia: "Fuente: [source]",
                verifiedVia: "Verificada, recopilada vía [source]"
            },
            monthNames: {
                january: "enero",
                february: "febrero",
                march: "marzo",
                april: "abril",
                may: "mayo",
                june: "junio",
                july: "julio",
                august: "agosto",
                september: "septiembre",
                october: "octubre",
                november: "noviembre",
                december: "diciembre"
            },
            timeAgo: {
                days: {
                    singular: "Hace [count] día",
                    plural: "Hace [count] días"
                },
                hours: {
                    singular: "Hace [count] hora",
                    plural: "Hace [count] horas"
                },
                minutes: {
                    singular: "Hace [count] minuto",
                    plural: "Hace [count] minutos"
                },
                seconds: {
                    singular: "Hace [count] segundo",
                    plural: "Hace [count] segundos"
                }
            },
            reviewFilters: {
                byStars1: "Nuestras opiniones de [star1] estrellas",
                byStars2: "Nuestras opiniones de [star1] y [star2] estrellas",
                byStars3: "Nuestras opiniones de [star1], [star2] y [star3] estrellas",
                byStars4: "Nuestras opiniones de [star1], [star2], [star3] y [star4] estrellas",
                byLatest: "Nuestras opiniones más recientes",
                byFavoriteOrTag: "Nuestras opiniones preferidas"
            }
        }
    }, {}],
    14: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "arvostelu",
                plural: "arvostelua",
                collectedVia: "Arvostelun lähde: [source]",
                verifiedVia: "Varmennettu, lähde: [source]"
            },
            monthNames: {
                january: "tammikuuta",
                february: "helmikuuta",
                march: "maaliskuuta",
                april: "huhtikuuta",
                may: "toukokuuta",
                june: "kesäkuuta",
                july: "heinäkuuta",
                august: "elokuuta",
                september: "syyskuuta",
                october: "lokakuuta",
                november: "marraskuuta",
                december: "joulukuuta"
            },
            timeAgo: {
                days: {
                    singular: "[count] päivää sitten",
                    plural: "[count] päivää sitten"
                },
                hours: {
                    singular: "[count] tuntia sitten",
                    plural: "[count] tuntia sitten"
                },
                minutes: {
                    singular: "[count] minuuttia sitten",
                    plural: "[count] minuuttia sitten"
                },
                seconds: {
                    singular: "[count] sekuntia sitten",
                    plural: "[count] sekuntia sitten"
                }
            },
            reviewFilters: {
                byStars1: "Näytetään [star1] tähden arvostelumme",
                byStars2: "Näytetään [star1] & [star2] tähden arvostelumme",
                byStars3: "Näytetään [star1], [star2] & [star3] tähden arvostelumme",
                byStars4: "Näytetään [star1], [star2], [star3] & [star4] tähden arvostelumme",
                byLatest: "Näytetään viimeisimmät arvostelumme",
                byFavoriteOrTag: "Näytetään suosikkiarvostelumme"
            }
        }
    }, {}],
    15: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "avis",
                plural: "avis",
                collectedVia: "Collecté via [source]",
                verifiedVia: "Vérifié, collecté via [source]"
            },
            monthNames: {
                january: "janvier",
                february: "février",
                march: "mars",
                april: "avril",
                may: "mai",
                june: "juin",
                july: "juillet",
                august: "août",
                september: "septembre",
                october: "octobre",
                november: "novembre",
                december: "décembre"
            },
            timeAgo: {
                days: {
                    singular: "ll y a [count] jour",
                    plural: "Il y a [count] jours"
                },
                hours: {
                    singular: "Il y a [count] heure",
                    plural: "Il y a [count] heures"
                },
                minutes: {
                    singular: "Il y a [count] minute",
                    plural: "Il y a [count] minutes"
                },
                seconds: {
                    singular: "Il y a [count] seconde",
                    plural: "Il y a [count] secondes"
                }
            },
            reviewFilters: {
                byStars1: "Nos avis [star1] étoiles",
                byStars2: "Nos avis [star1] et [star2] étoiles",
                byStars3: "Nos avis [star1], [star2] et [star3] étoiles",
                byStars4: "Nos avis [star1], [star2], [star3] et [star4] étoiles",
                byLatest: "Nos derniers avis",
                byFavoriteOrTag: "Nos avis préférés"
            }
        }
    }, {}],
    16: [function(e, t, r) {
        arguments[4][15][0].apply(r, arguments)
    }, {
        dup: 15
    }],
    17: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = x(e("./da-DK/strings.json")),
            a = x(e("./de-AT/strings.json")),
            i = x(e("./de-CH/strings.json")),
            s = x(e("./de-DE/strings.json")),
            o = x(e("./en-AU/strings.json")),
            u = x(e("./en-CA/strings.json")),
            l = x(e("./en-GB/strings.json")),
            c = x(e("./en-IE/strings.json")),
            d = x(e("./en-NZ/strings.json")),
            f = x(e("./en-US/strings.json")),
            p = x(e("./es-ES/strings.json")),
            v = x(e("./fi-FI/strings.json")),
            m = x(e("./fr-BE/strings.json")),
            h = x(e("./fr-FR/strings.json")),
            g = x(e("./it-IT/strings.json")),
            y = x(e("./ja-JP/strings.json")),
            b = x(e("./nb-NO/strings.json")),
            w = x(e("./nl-BE/strings.json")),
            j = x(e("./nl-NL/strings.json")),
            k = x(e("./pl-PL/strings.json")),
            _ = x(e("./pt-BR/strings.json")),
            S = x(e("./pt-PT/strings.json")),
            O = x(e("./ru-RU/strings.json")),
            P = x(e("./sv-SE/strings.json")),
            e = x(e("./zh-CN/strings.json"));

        function x(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e)
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t.default = e, t
        }
        r.default = {
            "da-DK": n,
            "de-AT": a,
            "de-CH": i,
            "de-DE": s,
            "en-AU": o,
            "en-CA": u,
            "en-GB": l,
            "en-IE": c,
            "en-NZ": d,
            "en-US": f,
            "es-ES": p,
            "fi-FI": v,
            "fr-BE": m,
            "fr-FR": h,
            "it-IT": g,
            "ja-JP": y,
            "nb-NO": b,
            "nl-BE": w,
            "nl-NL": j,
            "pl-PL": k,
            "pt-BR": _,
            "pt-PT": S,
            "ru-RU": O,
            "sv-SE": P,
            "zh-CN": e
        }
    }, {
        "./da-DK/strings.json": 3,
        "./de-AT/strings.json": 4,
        "./de-CH/strings.json": 5,
        "./de-DE/strings.json": 6,
        "./en-AU/strings.json": 7,
        "./en-CA/strings.json": 8,
        "./en-GB/strings.json": 9,
        "./en-IE/strings.json": 10,
        "./en-NZ/strings.json": 11,
        "./en-US/strings.json": 12,
        "./es-ES/strings.json": 13,
        "./fi-FI/strings.json": 14,
        "./fr-BE/strings.json": 15,
        "./fr-FR/strings.json": 16,
        "./it-IT/strings.json": 18,
        "./ja-JP/strings.json": 19,
        "./nb-NO/strings.json": 20,
        "./nl-BE/strings.json": 21,
        "./nl-NL/strings.json": 22,
        "./pl-PL/strings.json": 23,
        "./pt-BR/strings.json": 24,
        "./pt-PT/strings.json": 25,
        "./ru-RU/strings.json": 26,
        "./sv-SE/strings.json": 27,
        "./zh-CN/strings.json": 28
    }],
    18: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "recensione",
                plural: "recensioni",
                collectedVia: "Raccolta tramite [source]",
                verifiedVia: "Verificata, raccolta da [source]"
            },
            monthNames: {
                january: "gennaio",
                february: "febbraio",
                march: "marzo",
                april: "aprile",
                may: "maggio",
                june: "giugno",
                july: "luglio",
                august: "agosto",
                september: "settembre",
                october: "ottobre",
                november: "novembre",
                december: "dicembre"
            },
            timeAgo: {
                days: {
                    singular: "[count] giorno fa",
                    plural: "[count] giorni fa"
                },
                hours: {
                    singular: "[count] ora fa",
                    plural: "[count] ore fa"
                },
                minutes: {
                    singular: "[count] minuto fa",
                    plural: "[count] minuti fa"
                },
                seconds: {
                    singular: "[count] secondo fa",
                    plural: "[count] secondi fa"
                }
            },
            reviewFilters: {
                byStars1: "Le nostre recensioni a [star1] stelle",
                byStars2: "Le nostre recensioni a [star1] e a [star2] stelle",
                byStars3: "Le nostre recensioni a [star1], a [star2] e a [star3] stelle",
                byStars4: "Le nostre recensioni a [star1], a [star2], a [star3] e a [star4] stelle",
                byLatest: "Le nostre ultime recensioni",
                byFavoriteOrTag: "Le nostre recensioni preferite"
            }
        }
    }, {}],
    19: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "レビュー",
                plural: "レビュー",
                collectedVia: "[source] によって収集",
                verifiedVia: "[source] によって確認・収集"
            },
            monthNames: {
                january: "1月",
                february: "2月",
                march: "3月",
                april: "4月",
                may: "5月",
                june: "6月",
                july: "7月",
                august: "8月",
                september: "9月",
                october: "10月",
                november: "11月",
                december: "12月"
            },
            timeAgo: {
                days: {
                    singular: "[count]日前",
                    plural: "[count]日前"
                },
                hours: {
                    singular: "[count]時間前",
                    plural: "[count]時間前"
                },
                minutes: {
                    singular: "[count]分前",
                    plural: "[count]分前"
                },
                seconds: {
                    singular: "[count]秒前",
                    plural: "[count]秒前"
                }
            },
            reviewFilters: {
                byStars1: "[star1]つ星のレビューを表示",
                byStars2: "[star1]つ星と[star2]つ星のレビューを表示",
                byStars3: "[star1]つ星、[star2]つ星、[star3]つ星のレビューを表示",
                byStars4: "[star1]つ星、[star2]つ星、[star3]つ星、[star4]つ星のレビューを表示",
                byLatest: "最新のレビューを表示",
                byFavoriteOrTag: "お気に入りのレビューを表示"
            }
        }
    }, {}],
    20: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "anmeldelse",
                plural: "anmeldelser",
                collectedVia: "Samlet inn gjennom [source]",
                verifiedVia: "Bekreftet – samlet inn via [source]"
            },
            monthNames: {
                january: "januar",
                february: "februar",
                march: "mars",
                april: "april",
                may: "mai",
                june: "juni",
                july: "juli",
                august: "august",
                september: "september",
                october: "oktober",
                november: "november",
                december: "desember"
            },
            timeAgo: {
                days: {
                    singular: "For [count] dag siden",
                    plural: "For [count] dager siden"
                },
                hours: {
                    singular: "For [count] time siden",
                    plural: "For [count] timer siden"
                },
                minutes: {
                    singular: "For [count] minutt siden",
                    plural: "For [count] minutter siden"
                },
                seconds: {
                    singular: "For [count] sekund siden",
                    plural: "For [count] sekunder siden"
                }
            },
            reviewFilters: {
                byStars1: "Viser [star1]-stjernersanmeldelsene",
                byStars2: "Viser [star1]- og [star2]-stjernersanmeldelsene",
                byStars3: "Viser [star1]-, [star2]- og [star3]-stjernersanmeldelsene",
                byStars4: "Viser [star1]-, [star2]-, [star3]- og [star4]-stjernersanmeldelsene",
                byLatest: "Viser de nyeste anmeldelsene",
                byFavoriteOrTag: "Viser favorittene våre"
            }
        }
    }, {}],
    21: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "review",
                plural: "reviews",
                collectedVia: "Verzameld via [source]",
                verifiedVia: "Geverifieerd — verzameld via [source]"
            },
            monthNames: {
                january: "januari",
                february: "februari",
                march: "maart",
                april: "april",
                may: "mei",
                june: "juni",
                july: "juli",
                august: "augustus",
                september: "september",
                october: "oktober",
                november: "november",
                december: "December"
            },
            timeAgo: {
                days: {
                    singular: "[count] dag geleden",
                    plural: "[count] dagen geleden"
                },
                hours: {
                    singular: "[count] uur geleden",
                    plural: "[count] uur geleden"
                },
                minutes: {
                    singular: "[count] minuut geleden",
                    plural: "[count] minuten geleden"
                },
                seconds: {
                    singular: "[count] seconde geleden",
                    plural: "[count] seconden geleden"
                }
            },
            reviewFilters: {
                byStars1: "Onze reviews met [star1] sterren",
                byStars2: "Onze reviews met [star1] en [star2] sterren",
                byStars3: "Onze reviews met [star1], [star2] en [star3] sterren",
                byStars4: "Onze reviews met [star1], [star2], [star3] en [star4] sterren",
                byLatest: "Onze meest recente reviews",
                byFavoriteOrTag: "Onze favoriete reviews"
            }
        }
    }, {}],
    22: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "review",
                plural: "reviews",
                collectedVia: "Verzameld via [source]",
                verifiedVia: "Geverifieerd — verzameld via [source]"
            },
            monthNames: {
                january: "januari",
                february: "februari",
                march: "maart",
                april: "april",
                may: "mei",
                june: "juni",
                july: "juli",
                august: "augustus",
                september: "september",
                october: "oktober",
                november: "november",
                december: "december"
            },
            timeAgo: {
                days: {
                    singular: "[count] dag geleden",
                    plural: "[count] dagen geleden"
                },
                hours: {
                    singular: "[count] uur geleden",
                    plural: "[count] uur geleden"
                },
                minutes: {
                    singular: "[count] minuut geleden",
                    plural: "[count] minuten geleden"
                },
                seconds: {
                    singular: "[count] seconde geleden",
                    plural: "[count] seconden geleden"
                }
            },
            reviewFilters: {
                byStars1: "Onze reviews met [star1] sterren",
                byStars2: "Onze reviews met [star1] en [star2] sterren",
                byStars3: "Onze reviews met [star1], [star2] en [star3] sterren",
                byStars4: "Onze reviews met [star1], [star2], [star3] en [star4] sterren",
                byLatest: "Onze meest recente reviews",
                byFavoriteOrTag: "Onze favoriete reviews"
            }
        }
    }, {}],
    23: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "recenzja",
                plural: "recenzji",
                collectedVia: "Zebrane przez [source]",
                verifiedVia: "Zweryfikowano i zebrano przez [source]"
            },
            monthNames: {
                january: "stycznia",
                february: "lutego",
                march: "marca",
                april: "kwietnia",
                may: "maja",
                june: "czerwca",
                july: "lipca",
                august: "sierpnia",
                september: "września",
                october: "października",
                november: "listopada",
                december: "grudnia"
            },
            timeAgo: {
                days: {
                    singular: "[count] dzień temu",
                    plural: "[count] dni temu"
                },
                hours: {
                    singular: "[count] godzinę temu",
                    plural: "[count] godz. temu"
                },
                minutes: {
                    singular: "[count] minutę temu",
                    plural: "[count] min. temu"
                },
                seconds: {
                    singular: "[count] sekundę temu",
                    plural: "[count] sek. temu"
                }
            },
            reviewFilters: {
                byStars1: "Wyświetlamy nasze [star1]-gwiazdkowe recenzje",
                byStars2: "Wyświetlamy nasze [star1]- i [star2]-gwiazdkowe recenzje",
                byStars3: "Wyświetlamy nasze [star1]-, [star2]- i [star3]-gwiazdkowe recenzje",
                byStars4: "Wyświetlamy nasze [star1]-, [star2]-, [star3]- i [star4]-gwiazdkowe recenzje",
                byLatest: "Wyświetlamy najnowsze recenzje",
                byFavoriteOrTag: "Wyświetlamy nasze ulubione recenzje"
            }
        }
    }, {}],
    24: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "avaliação",
                plural: "avaliações",
                collectedVia: "Recolhida via [source]",
                verifiedVia: "Verificada, recolhida via [source]"
            },
            monthNames: {
                january: "Janeiro",
                february: "Fevereiro",
                march: "Março",
                april: "Abril",
                may: "Maio",
                june: "Junho",
                july: "Julho",
                august: "Agosto",
                september: "Setembro",
                october: "Outubro",
                november: "Novembro",
                december: "Dezembro"
            },
            timeAgo: {
                days: {
                    singular: "há [count] dia",
                    plural: "há [count] dias"
                },
                hours: {
                    singular: "há [count] hora",
                    plural: "há [count] horas"
                },
                minutes: {
                    singular: "há [count] minuto",
                    plural: "há [count] minutos"
                },
                seconds: {
                    singular: "há [count] segundo",
                    plural: "há [count] segundos"
                }
            },
            reviewFilters: {
                byStars1: "Nossas avaliações com [star1] estrela(s)",
                byStars2: "Nossas avaliações com [star1] & [star2] estrelas",
                byStars3: "Nossas avaliações com [star1], [star2] & [star3] estrelas",
                byStars4: "Nossas avaliações com [star1], [star2], [star3] & [star4] estrelas",
                byLatest: "Mostrando nossas avaliações mais recentes",
                byFavoriteOrTag: "Mostrando nossas avaliações favoritas"
            }
        }
    }, {}],
    25: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "opinião",
                plural: "opiniões",
                collectedVia: "Recolhida via [source]",
                verifiedVia: "Verificada, recolhida via [source]"
            },
            monthNames: {
                january: "Janeiro",
                february: "Fevereiro",
                march: "Março",
                april: "Abril",
                may: "Maio",
                june: "Junho",
                july: "Julho",
                august: "Agosto",
                september: "Setembro",
                october: "Outubro",
                november: "Novembro",
                december: "Dezembro"
            },
            timeAgo: {
                days: {
                    singular: "há [count] dia",
                    plural: "há [count] dias"
                },
                hours: {
                    singular: "há [count] hora",
                    plural: "há [count] horas"
                },
                minutes: {
                    singular: "há [count] minuto",
                    plural: "há [count] minutos"
                },
                seconds: {
                    singular: "há [count] segundo",
                    plural: "há [count] segundos"
                }
            },
            reviewFilters: {
                byStars1: "As nossas opiniões com [star1] estrela(s)",
                byStars2: "As nossas opiniões com [star1] e [star2] estrelas",
                byStars3: "As nossas opiniões com [star1], [star2] e [star3] estrelas",
                byStars4: "As nossas opiniões com [star1], [star2], [star3] e [star4] estrelas",
                byLatest: "As nossas opiniões mais recentes",
                byFavoriteOrTag: "As nossas opiniões favoritas"
            }
        }
    }, {}],
    26: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "отзыв",
                plural: "отзывов",
                collectedVia: "Собрано через [source]",
                verifiedVia: "Подтверждено, собрано через [source]"
            },
            monthNames: {
                january: "января",
                february: "февраля",
                march: "марта",
                april: "апреля",
                may: "мая",
                june: "июня",
                july: "Июль",
                august: "августа",
                september: "сентября",
                october: "Октябрь",
                november: "ноября",
                december: "Декабрь"
            },
            timeAgo: {
                days: {
                    singular: "[count] день назад",
                    plural: "[count] дней назад"
                },
                hours: {
                    singular: "[count] час назад",
                    plural: "[count] часов назад"
                },
                minutes: {
                    singular: "[count] минуту назад",
                    plural: "[count] минут назад"
                },
                seconds: {
                    singular: "[count] секунду назад",
                    plural: "[count] секунд назад"
                }
            },
            reviewFilters: {
                byStars1: "Наши отзывы [star1] звезд",
                byStars2: "Наши отзывы [star1] и [star2] звезд",
                byStars3: "Наши отзывы [star1], [star2] и [star3] звезд",
                byStars4: "Наши отзывы [star1], [star2], [star3] и [star4] звезд",
                byLatest: "Наши недавние отзывы",
                byFavoriteOrTag: "Наши любимые отзывы"
            }
        }
    }, {}],
    27: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "omdöme",
                plural: "omdömen",
                collectedVia: "Insamlat via [source]",
                verifiedVia: "Verifierat – insamlat via [source]"
            },
            monthNames: {
                january: "januari",
                february: "februari",
                march: "mars",
                april: "april",
                may: "maj",
                june: "juni",
                july: "juli",
                august: "augusti",
                september: "september",
                october: "oktober",
                november: "november",
                december: "december"
            },
            timeAgo: {
                days: {
                    singular: "[count] dag sedan",
                    plural: "[count] dagar sedan"
                },
                hours: {
                    singular: "[count] timme sedan",
                    plural: "[count] timmar sedan"
                },
                minutes: {
                    singular: "[count] minut sedan",
                    plural: "[count] minuter sedan"
                },
                seconds: {
                    singular: "[count] sekund sedan",
                    plural: "[count] sekunder sedan"
                }
            },
            reviewFilters: {
                byStars1: "Visar våra [star1]-stjärniga omdömen",
                byStars2: "Visar våra [star1]- och [star2]-stjärniga omdömen",
                byStars3: "Visar våra [star1]-, [star2]- och [star3]-stjärniga omdömen",
                byStars4: "Visar våra [star1]-, [star2]-, [star3]- och [star4]-stjärniga omdömen",
                byLatest: "Visar våra senaste omdömen",
                byFavoriteOrTag: "Visar våra favoritomdömen"
            }
        }
    }, {}],
    28: [function(e, t, r) {
        t.exports = {
            reviews: {
                singular: "条评论",
                plural: "条点评,"
            },
            monthNames: {
                january: "一月",
                february: "二月",
                march: "三月",
                april: "四月",
                may: "五月",
                june: "六月",
                july: "七月",
                august: "八月",
                september: "九月",
                october: "十月",
                november: "十一月",
                december: "十二月"
            },
            timeAgo: {
                days: {
                    singular: "[count] day ago",
                    plural: "[count] days ago"
                },
                hours: {
                    singular: "[count] hour ago",
                    plural: "[count] hours ago"
                },
                minutes: {
                    singular: "[count] minute ago",
                    plural: "[count] minutes ago"
                },
                seconds: {
                    singular: "[count] second ago",
                    plural: "[count] seconds ago"
                }
            },
            reviewFilters: {
                byStars1: "Showing our [star1] star reviews",
                byStars2: "Showing our [star1] & [star2] star reviews",
                byStars3: "Showing our [star1], [star2] & [star3] star reviews",
                byStars4: "Showing our [star1], [star2], [star3] & [star4] star reviews",
                byLatest: "Showing our latest reviews",
                byFavoriteOrTag: "Showing our favorite reviews"
            }
        }
    }, {}],
    29: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.apiCall = void 0;
        var n = a(e("promise")),
            s = a(e("../xhr")),
            o = e("../queryString"),
            u = a(e("../rootUri"));

        function a(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        r.apiCall = function(a, i) {
            return new n.default(function(e, t) {
                var r = void 0,
                    n = void 0;
                if (0 === a.indexOf("/") && (r = i || {}, (0, o.getAsObject)().token && (r.random = function(e) {
                        for (var t = "", r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", n = 0; n < e; n++) t += r.charAt(Math.floor(Math.random() * r.length));
                        return t
                    }(20))), 0 === a.indexOf("http")) n = a.replace(/^https?:/, "https:");
                else {
                    if (0 !== a.indexOf("/")) return t();
                    n = (0, u.default)() + a
                }
                return (0, s.default)({
                    url: n,
                    data: r,
                    success: e,
                    error: t
                })
            })
        }
    }, {
        "../queryString": 42,
        "../rootUri": 44,
        "../xhr": 62,
        promise: 65
    }],
    62: [function(e, t, r) {
        "use strict";

        function s() {
            var e = navigator.userAgent.toLowerCase();
            return -1 != e.indexOf("msie") && parseInt(e.split("msie")[1])
        }

        function o(t) {
            try {
                return JSON.parse(t.responseText)
            } catch (e) {
                return t.responseText
            }
        }

        function u() {}
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.default = function(e) {
            var t, r, n, a, i = {
                type: e.type || "GET",
                error: e.error || u,
                success: e.success || u,
                data: e.data,
                url: e.url || ""
            };
            "GET" === i.type && i.data && (i.url = i.url + "?" + function(e) {
                var t, r = [];
                for (t in e) e.hasOwnProperty(t) && r.push(encodeURIComponent(t) + "=" + encodeURIComponent(e[t]));
                return r.join("&")
            }(i.data), delete i.data), s() && s() <= 9 ? (n = i, a = new window.XDomainRequest, e = window.location.protocol, n.url = n.url.replace(/https?:/, e), a.open(n.type, n.url), a.onload = function() {
                n.success(o(a))
            }, a.onerror = function() {
                n.error(o(a))
            }, setTimeout(function() {
                a.send(n.data)
            }, 0)) : (t = i, (r = new(window.XMLHttpRequest || ActiveXObject)("MSXML2.XMLHTTP.3.0")).open(t.type, t.url, !0), r.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), r.onreadystatechange = function() {
                4 === r.readyState && (200 <= r.status && r.status < 300 ? t.success(o(r)) : t.error(o(r)))
            }, r.send(t.data))
        }
    }, {}],
    44: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.default = function() {
            var e = "https://widget.trustpilot.com";
            return 0 === e.indexOf("#") ? "https://widget.tp-staging.com" : e
        }
    }, {}],
    65: [function(e, t, r) {
        "use strict";
        t.exports = e("./lib")
    }, {
        "./lib": 70
    }],
    30: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.hasProductReviews = r.hasServiceReviewsMultiFetch = r.hasServiceReviews = r.multiFetchData = r.fetchData = void 0;
        var n, u = function(e, t) {
                if (Array.isArray(e)) return e;
                if (Symbol.iterator in Object(e)) return function(e, t) {
                    var r = [],
                        n = !0,
                        a = !1,
                        i = void 0;
                    try {
                        for (var s, o = e[Symbol.iterator](); !(n = (s = o.next()).done) && (r.push(s.value), !t || r.length !== t); n = !0);
                    } catch (e) {
                        a = !0, i = e
                    } finally {
                        try {
                            !n && o.return && o.return()
                        } finally {
                            if (a) throw i
                        }
                    }
                    return r
                }(e, t);
                throw new TypeError("Invalid attempt to destructure non-iterable instance")
            },
            a = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            i = e("promise"),
            l = (n = i) && n.__esModule ? n : {
                default: n
            },
            s = e("./call"),
            c = e("../utils"),
            d = e("../templates/loader"),
            f = e("../templates/errorFallback"),
            p = e("../communication"),
            v = e("../fn");

        function m(e) {
            return 0 < e.businessEntity.numberOfReviews.total
        }

        function h(n) {
            return function(e) {
                var t = e.businessUnitId,
                    r = e.locale,
                    e = function(e, t) {
                        var r, n = {};
                        for (r in e) 0 <= t.indexOf(r) || Object.prototype.hasOwnProperty.call(e, r) && (n[r] = e[r]);
                        return n
                    }(e, ["businessUnitId", "locale"]),
                    e = (0, v.rejectNullaryValues)(a({
                        businessUnitId: t,
                        locale: r
                    }, e, {
                        theme: null
                    }));
                return (0, s.apiCall)(n, e)
            }
        }

        function g(s) {
            var o = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                u = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : m;
            return function(e) {
                var t = e.baseData,
                    r = e.locale,
                    n = e.theme,
                    a = e.hasMoreReviews,
                    i = e.loadMoreReviews,
                    e = u(t);
                s({
                    baseData: t,
                    locale: r,
                    hasMoreReviews: a,
                    loadMoreReviews: i
                });
                o && (0, p.setListener)(function(e) {
                    e = e.data;
                    (0, p.isLoadedMessage)(e) && (0, p.sendAPIDataMessage)({
                        baseData: t,
                        locale: r
                    })
                }), (0, c.showTrustBox)(n, e), (0, f.removeErrorFallback)()
            }
        }

        function o(o) {
            return function(e, t, r, n) {
                var a = e[Object.keys(e)[0]],
                    i = a.locale,
                    a = a.theme,
                    s = void 0 === a ? "light" : a,
                    a = (0, v.promiseAllObject)((0, v.mapObject)(h(o), e)),
                    e = (0, c.getOnPageReady)(),
                    n = l.default.all([a, e]).then(function(e) {
                        var t = u(e, 1)[0];
                        return {
                            baseData: (e = t, t = Object.keys(e), y in e && 1 === t.length ? e[y] : e),
                            locale: i,
                            theme: s
                        }
                    }).then(g(t, r, n)).catch(function(e) {
                        if (e && e.FallbackLogo) return (0, f.errorFallback)()
                    });
                (0, d.withLoader)(n)
            }
        }
        var y = "default_singleFetch_f98ac77b";
        r.fetchData = function(s) {
            return function(e, t, r, n) {
                var a, i, e = (i = e, (a = y) in (e = {}) ? Object.defineProperty(e, a, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[a] = i, e);
                o(s)(e, t, r, n)
            }
        }, r.multiFetchData = o, r.hasServiceReviews = m, r.hasServiceReviewsMultiFetch = function(t) {
            return Object.keys(t).some(function(e) {
                return m(t[e])
            })
        }, r.hasProductReviews = function(e) {
            var t = e.productReviewsSummary,
                e = e.importedProductReviewsSummary;
            return 0 < (t ? t.numberOfReviews.total : 0) + (e ? e.numberOfReviews.total : 0)
        }
    }, {
        "../communication": 37,
        "../fn": 39,
        "../templates/errorFallback": 51,
        "../templates/loader": 52,
        "../utils": 61,
        "./call": 29,
        promise: 65
    }],
    37: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.onPong = r.ping = r.sendAPIDataMessage = r.isLoadedMessage = r.setListener = void 0;
        var n = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            e = e("./utils.js"),
            a = window.parent,
            i = [],
            s = null,
            o = [];

        function u(e) {
            s ? (e.widgetId = s, e = JSON.stringify(e), a.postMessage(e, "*")) : i.push(e)
        }

        function l(t) {
            return function(e) {
                return u(n({}, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, {
                    message: e,
                    command: "message",
                    name: t
                }))
            }
        }

        function c(e) {
            o.push(e)
        }(0, e.addEventListener)(window, "message", function(e) {
            if ("string" == typeof e.data) {
                var t = void 0;
                try {
                    t = {
                        data: JSON.parse(e.data)
                    }
                } catch (t) {
                    return
                }
                if ("setId" === t.data.command) s = t.data.widgetId,
                    function() {
                        for (; i.length;) u(i.pop())
                    }();
                else
                    for (var r = 0; r < o.length; r++)(0, o[r])(t)
            }
        }), r.setListener = c, r.isLoadedMessage = function(e) {
            return "loaded" === e
        }, r.sendAPIDataMessage = function(e) {
            l("popup")("API data", e)
        }, r.ping = function() {
            return u({
                command: "ping"
            })
        }, r.onPong = function(t) {
            c(function(e) {
                "pong" === e.data.command && t(e)
            })
        }
    }, {
        "./utils.js": 61
    }],
    39: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.rejectNullaryValues = r.propMaybe = r.prop = r.promiseAllObject = r.pipeMaybe = r.pairsToObject = r.mapObject = r.map = r.guard = r.find = r.compose = void 0;
        var n, a = function(e, t) {
                if (Array.isArray(e)) return e;
                if (Symbol.iterator in Object(e)) return function(e, t) {
                    var r = [],
                        n = !0,
                        a = !1,
                        i = void 0;
                    try {
                        for (var s, o = e[Symbol.iterator](); !(n = (s = o.next()).done) && (r.push(s.value), !t || r.length !== t); n = !0);
                    } catch (e) {
                        a = !0, i = e
                    } finally {
                        try {
                            !n && o.return && o.return()
                        } finally {
                            if (a) throw i
                        }
                    }
                    return r
                }(e, t);
                throw new TypeError("Invalid attempt to destructure non-iterable instance")
            },
            i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            s = e("promise"),
            o = (n = s) && n.__esModule ? n : {
                default: n
            };

        function u(e, t, r) {
            return t in e ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = r, e
        }

        function l(t) {
            return function(e) {
                return e.filter(t)
            }
        }

        function c(e) {
            return null == e
        }

        function d() {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            return function(e) {
                return t.reduce(function(e, t) {
                    return c(e) ? e : t(e)
                }, e)
            }
        }

        function f(e) {
            return a(e, 1)[0]
        }
        r.compose = function() {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            return function(e) {
                return t.reduceRight(function(e, t) {
                    return t(e)
                }, e)
            }
        }, r.find = function(e) {
            return d(l(e), f)
        }, r.guard = function(r) {
            return function(e) {
                return c(t = r) || !1 === t ? null : e;
                var t
            }
        }, r.map = function(t) {
            return function(e) {
                return e.map(t)
            }
        }, r.mapObject = function(r, n) {
            return Object.keys(n).reduce(function(e, t) {
                return i({}, e, u({}, t, r(n[t])))
            }, {})
        }, r.pairsToObject = function(e) {
            return e.reduce(function(e, t) {
                var r = a(t, 2),
                    t = r[0],
                    r = r[1];
                return i({}, e, u({}, t, r))
            }, {})
        }, r.pipeMaybe = d, r.promiseAllObject = function(t) {
            var n = Object.keys(t),
                e = n.map(function(e) {
                    return t[e]
                });
            return o.default.all(e).then(function(e) {
                return e.reduce(function(e, t, r) {
                    return i({}, e, u({}, n[r], t))
                }, {})
            })
        }, r.prop = function(e) {
            return function() {
                return (0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})[e]
            }
        }, r.propMaybe = function(t) {
            return function() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                return e[t] || e
            }
        }, r.rejectNullaryValues = function(r) {
            return Object.keys(r).reduce(function(e, t) {
                return i({}, e, c(r[t]) ? {} : u({}, t, r[t]))
            }, {})
        }
    }, {
        promise: 65
    }],
    51: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.removeErrorFallback = r.errorFallback = void 0;
        var n = e("../dom"),
            a = e("../templating"),
            i = e("../utils");
        r.errorFallback = function() {
            var e = document.getElementById(0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "tp-widget-fallback");
            (0, n.populateElements)([{
                element: e,
                string: (0, a.a)({
                    href: "https://www.trustpilot.com?utm_medium=trustboxfallback",
                    target: "_blank",
                    rel: "noopener noreferrer"
                }, (0, a.mkElemWithSvgLookup)("logo", "fallback-logo"))
            }])
        }, r.removeErrorFallback = function() {
            var e = document.getElementById(0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "tp-widget-fallback");
            (0, i.removeElement)(e)
        }
    }, {
        "../dom": 38,
        "../templating": 57,
        "../utils": 61
    }],
    52: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.withLoader = void 0;
        var i = e("../dom"),
            s = e("../utils"),
            o = e("../templating");
        r.withLoader = function(e) {
            var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                r = t.loaderElement,
                n = void 0 === r ? "tp-widget-loader" : r,
                t = t.delay,
                a = setTimeout(function() {
                    return function(e) {
                        e = document.getElementById(e);
                        (0, i.populateElements)([{
                            element: e,
                            string: (0, o.mkElemWithSvgLookup)("logo")
                        }])
                    }(n)
                }, void 0 === t ? 1e3 : t);
            return e.finally(function() {
                var e, t;
                clearTimeout(a), e = n, t = document.getElementById(e), (0, i.addClass)(t, e + "--loaded"), t && (t.addEventListener("animationend", function() {
                    return (0, s.removeElement)(t)
                }), t.addEventListener("webkitAnimationEnd", function() {
                    return (0, s.removeElement)(t)
                }), t.addEventListener("oanimationend", function() {
                    return (0, s.removeElement)(t)
                }))
            })
        }
    }, {
        "../dom": 38,
        "../templating": 57,
        "../utils": 61
    }],
    32: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        Object.assign, e("./fetchData"), e("./call");
        var n, a = e("./reviewFetcher");
        (n = a) && n.__esModule
    }, {
        "./call": 29,
        "./fetchData": 30,
        "./reviewFetcher": 33
    }],
    33: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            a = function(e, t, r) {
                return t && i(e.prototype, t), r && i(e, r), e
            };

        function i(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        var s = d(e("promise")),
            o = e("../../fn"),
            u = e("../call"),
            l = e("./util"),
            c = d(e("./responseProcessor"));

        function d(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var f = "No reviews available",
            a = (a(p, [{
                key: "consumeReviews",
                value: function(t) {
                    var r = this;
                    return function() {
                        return r.produceReviews().then(function(e) {
                            return t(n({}, r.wrapArgs, {
                                baseData: r.baseData,
                                reviews: e,
                                hasMoreReviews: r.hasMoreReviews,
                                loadMoreReviews: r.consumeReviews.bind(r)
                            }))
                        }).catch(function(e) {
                            if (e === f) return t(n({}, r.wrapArgs, {
                                baseData: r.baseData,
                                reviews: [],
                                hasMoreReviews: !1,
                                loadMoreReviews: r.consumeReviews.bind(r)
                            }));
                            throw e
                        })
                    }
                }
            }, {
                key: "produceReviews",
                value: function() {
                    var r = this;
                    return 0 === this.reviews.length ? s.default.reject(f) : this.reviewsPerPage >= this.reviews.length ? this._fetchReviews().then(function(e) {
                        var t = r._makeResponseProcessor(e);
                        return r.nextPage = t.getNextPageLinks(), (e = r.reviews).push.apply(e, function(e) {
                            if (Array.isArray(e)) {
                                for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                                return r
                            }
                            return Array.from(e)
                        }(t.getReviews())), r._takeReviews()
                    }) : s.default.resolve(this._takeReviews())
                }
            }, {
                key: "_takeReviews",
                value: function() {
                    return this.reviews.splice(0, this.reviewsPerPage)
                }
            }, {
                key: "_fetchReviews",
                value: function() {
                    return (0, o.promiseAllObject)((0, o.mapObject)(u.apiCall, this.nextPage))
                }
            }, {
                key: "_makeResponseProcessor",
                value: function(e) {
                    return new c.default(e, {
                        includeImportedReviews: this.includeImportedReviews,
                        displayName: this.baseData.businessEntity.displayName
                    })
                }
            }, {
                key: "hasMoreReviews",
                get: function() {
                    return 0 < this.reviews.length
                }
            }]), p);

        function p(e) {
            var t = e.reviewsPerPage,
                r = e.includeImportedReviews,
                n = e.baseData,
                a = function(e, t) {
                    var r, n = {};
                    for (r in e) 0 <= t.indexOf(r) || Object.prototype.hasOwnProperty.call(e, r) && (n[r] = e[r]);
                    return n
                }(e, ["reviewsPerPage", "includeImportedReviews", "baseData"]);
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, p);
            e = (0, l.getNextPageLinks)(function(e) {
                return (0, o.pipeMaybe)((0, o.prop)(e), (0, o.prop)("links"), (0, o.prop)("nextPage"))
            });
            this.reviewsPerPage = t, this.includeImportedReviews = r, this.baseData = n, this.nextPage = e(n, r), this.wrapArgs = a, this.reviews = this._makeResponseProcessor(n).getReviews()
        }
        r.default = a
    }, {
        "../../fn": 39,
        "../call": 29,
        "./responseProcessor": 34,
        "./util": 35,
        promise: 65
    }],
    35: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.getNextPageLinks = void 0;
        var a = e("../../fn");
        r.getNextPageLinks = function(n) {
            return function(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                    r = n("productReviews")(e),
                    e = (0, a.pipeMaybe)((0, a.guard)(t), n("importedProductReviews"))(e);
                return (0, a.rejectNullaryValues)({
                    productReviews: r,
                    importedProductReviews: e
                })
            }
        }
    }, {
        "../../fn": 39
    }],
    34: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r, n = arguments[t];
                    for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            },
            a = function(e, t, r) {
                return t && i(e.prototype, t), r && i(e, r), e
            };

        function i(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        var s = e("../../fn"),
            o = e("./util");

        function u(e) {
            if (Array.isArray(e)) {
                for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                return r
            }
            return Array.from(e)
        }
        a(l, [{
            key: "getReviews",
            value: function() {
                var t = this,
                    e = this.response,
                    r = e.productReviews,
                    e = e.importedProductReviews,
                    r = (0, s.pipeMaybe)((0, s.propMaybe)("productReviews"), (0, s.propMaybe)("reviews"))(r) || [],
                    e = (0, s.pipeMaybe)((0, s.guard)(this.includeImportedReviews), (0, s.propMaybe)("importedProductReviews"), (0, s.propMaybe)("productReviews"), (0, s.map)(function(e) {
                        return n({}, e, {
                            verifiedBy: "External" === e.type && e.source ? e.source.name : t.displayName
                        })
                    }))(e) || [];
                return [].concat(u(r), u(e)).sort(function(e, t) {
                    e = e.createdAt, t = t.createdAt;
                    return new Date(t) - new Date(e)
                })
            }
        }, {
            key: "getNextPageLinks",
            value: function() {
                var e = (0, o.getNextPageLinks)(function(e) {
                        return (0, s.pipeMaybe)((0, s.prop)(e), (0, s.prop)("links"), (0, s.find)(function(e) {
                            return "next-page" === e.rel
                        }), (0, s.prop)("href"))
                    }),
                    t = (0, o.getNextPageLinks)(function(e) {
                        return (0, s.pipeMaybe)((0, s.prop)(e), (0, s.prop)(e), (0, s.prop)("links"), (0, s.prop)("nextPage"))
                    })(this.response, this.includeImportedReviews),
                    e = e(this.response, this.includeImportedReviews);
                return n({}, e, t)
            }
        }]), a = l;

        function l(e, t) {
            var r = t.includeImportedReviews,
                t = t.displayName;
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, l), this.response = e, this.includeImportedReviews = r, this.displayName = t
        }
        r.default = a
    }, {
        "../../fn": 39,
        "./util": 35
    }],
    36: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.svgMap = void 0;

        function n(e, t) {
            var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {},
                n = Object.keys(r).reduce(function(e, t) {
                    return e[t] = (0, u.sanitizeHtml)(r[t]), "color" === t && (e[t] = (0, u.sanitizeColor)(e[t])), e
                }, {});
            return '\n    <div style="position: relative; height: 0; width: 100%; padding: 0; padding-bottom: ' + e.height / e.width * 100 + '%;">\n      ' + t(e, n) + "\n    </div>\n  "
        }

        function a(e, t) {
            var r = t.rating,
                n = t.trustScore,
                t = t.color;
            return '\n  <svg role="img" aria-labelledby="starRating" viewBox="0 0 ' + e.width + " " + e.height + '" xmlns="http://www.w3.org/2000/svg" ' + l + '>\n      <title id="starRating" lang="en">' + n + ' out of five star rating on Trustpilot</title>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (1 <= r && t ? t : c) + '" d="M0 46.330002h46.375586V0H0z"/>\n          <path class="tp-star__shape" d="M39.533936 19.711433L13.230239 38.80065l3.838216-11.797827L7.02115 19.711433h12.418975l3.837417-11.798624 3.837418 11.798624h12.418975zM23.2785 31.510075l7.183595-1.509576 2.862114 8.800152L23.2785 31.510075z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (2 <= r && t ? t : c) + '" d="M51.24816 46.330002h46.375587V0H51.248161z"/>\n          <path class="tp-star__canvas--half" fill="' + (1.5 <= r && t ? t : c) + '" d="M51.24816 46.330002h23.187793V0H51.248161z"/>\n          <path class="tp-star__shape" d="M74.990978 31.32991L81.150908 30 84 39l-9.660206-7.202786L64.30279 39l3.895636-11.840666L58 19.841466h12.605577L74.499595 8l3.895637 11.841466H91L74.990978 31.329909z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (3 <= r && t ? t : c) + '" d="M102.532209 46.330002h46.375586V0h-46.375586z"/>\n          <path class="tp-star__canvas--half" fill="' + (2.5 <= r && t ? t : c) + '" d="M102.532209 46.330002h23.187793V0h-23.187793z"/>\n          <path class="tp-star__shape" d="M142.066994 19.711433L115.763298 38.80065l3.838215-11.797827-10.047304-7.291391h12.418975l3.837418-11.798624 3.837417 11.798624h12.418975zM125.81156 31.510075l7.183595-1.509576 2.862113 8.800152-10.045708-7.290576z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (4 <= r && t ? t : c) + '" d="M153.815458 46.330002h46.375586V0h-46.375586z"/>\n          <path class="tp-star__canvas--half" fill="' + (3.5 <= r && t ? t : c) + '" d="M153.815458 46.330002h23.187793V0h-23.187793z"/>\n          <path class="tp-star__shape" d="M193.348355 19.711433L167.045457 38.80065l3.837417-11.797827-10.047303-7.291391h12.418974l3.837418-11.798624 3.837418 11.798624h12.418974zM177.09292 31.510075l7.183595-1.509576 2.862114 8.800152-10.045709-7.290576z" fill="#FFF"/>\n      </g>\n      <g class="tp-star">\n          <path class="tp-star__canvas" fill="' + (5 === r && t ? t : c) + '" d="M205.064416 46.330002h46.375587V0h-46.375587z"/>\n          <path class="tp-star__canvas--half" fill="' + (4.5 <= r && t ? t : c) + '" d="M205.064416 46.330002h23.187793V0h-23.187793z"/>\n          <path class="tp-star__shape" d="M244.597022 19.711433l-26.3029 19.089218 3.837419-11.797827-10.047304-7.291391h12.418974l3.837418-11.798624 3.837418 11.798624h12.418975zm-16.255436 11.798642l7.183595-1.509576 2.862114 8.800152-10.045709-7.290576z" fill="#FFF"/>\n      </g>\n  </svg>'
        }

        function i(e) {
            return '\n  <svg role="img" aria-labelledby="trustpilotLogo" viewBox="0 0 ' + e.width + " " + e.height + '" xmlns="http://www.w3.org/2000/svg" ' + l + '>\n      <title id="trustpilotLogo">Trustpilot</title>\n      <path class="tp-logo__text" d="M33.074774 11.07005H45.81806v2.364196h-5.010656v13.290316h-2.755306V13.434246h-4.988435V11.07005h.01111zm12.198892 4.319629h2.355341v2.187433h.04444c.077771-.309334.222203-.60762.433295-.894859.211092-.287239.466624-.56343.766597-.79543.299972-.243048.633276-.430858.999909-.585525.366633-.14362.744377-.220953 1.12212-.220953.288863 0 .499955.011047.611056.022095.1111.011048.222202.033143.344413.04419v2.408387c-.177762-.033143-.355523-.055238-.544395-.077333-.188872-.022096-.366633-.033143-.544395-.033143-.422184 0-.822148.08838-1.199891.254096-.377744.165714-.699936.41981-.977689.740192-.277753.331429-.499955.729144-.666606 1.21524-.166652.486097-.244422 1.03848-.244422 1.668195v5.39125h-2.510883V15.38968h.01111zm18.220567 11.334883H61.02779v-1.579813h-.04444c-.311083.574477-.766597 1.02743-1.377653 1.369908-.611055.342477-1.233221.51924-1.866497.51924-1.499864 0-2.588654-.364573-3.25526-1.104765-.666606-.740193-.999909-1.856005-.999909-3.347437V15.38968h2.510883v6.948968c0 .994288.188872 1.701337.577725 2.1101.377744.408763.922139.618668 1.610965.618668.533285 0 .96658-.077333 1.322102-.243048.355524-.165714.644386-.37562.855478-.65181.222202-.265144.377744-.596574.477735-.972194.09999-.37562.144431-.784382.144431-1.226288v-6.573349h2.510883v11.323836zm4.27739-3.634675c.07777.729144.355522 1.237336.833257 1.535623.488844.287238 1.06657.441905 1.744286.441905.233312 0 .499954-.022095.799927-.055238.299973-.033143.588836-.110476.844368-.209905.266642-.099429.477734-.254096.655496-.452954.166652-.198857.244422-.452953.233312-.773335-.01111-.320381-.133321-.585525-.355523-.784382-.222202-.209906-.499955-.364573-.844368-.497144-.344413-.121525-.733267-.232-1.17767-.320382-.444405-.088381-.888809-.18781-1.344323-.287239-.466624-.099429-.922138-.232-1.355432-.37562-.433294-.14362-.822148-.342477-1.166561-.596573-.344413-.243048-.622166-.56343-.822148-.950097-.211092-.386668-.311083-.861716-.311083-1.436194 0-.618668.155542-1.12686.455515-1.54667.299972-.41981.688826-.75124 1.14434-1.005336.466624-.254095.97769-.430858 1.544304-.541334.566615-.099429 1.11101-.154667 1.622075-.154667.588836 0 1.15545.066286 1.688736.18781.533285.121524 1.02213.320381 1.455423.60762.433294.276191.788817.640764 1.07768 1.08267.288863.441905.466624.98324.544395 1.612955h-2.621984c-.122211-.596572-.388854-1.005335-.822148-1.204193-.433294-.209905-.933248-.309334-1.488753-.309334-.177762 0-.388854.011048-.633276.04419-.244422.033144-.466624.088382-.688826.165715-.211092.077334-.388854.198858-.544395.353525-.144432.154667-.222203.353525-.222203.60762 0 .309335.111101.552383.322193.740193.211092.18781.488845.342477.833258.475048.344413.121524.733267.232 1.177671.320382.444404.088381.899918.18781 1.366542.287239.455515.099429.899919.232 1.344323.37562.444404.14362.833257.342477 1.17767.596573.344414.254095.622166.56343.833258.93905.211092.37562.322193.850668.322193 1.40305 0 .673906-.155541 1.237336-.466624 1.712385-.311083.464001-.711047.850669-1.199891 1.137907-.488845.28724-1.04435.508192-1.644295.640764-.599946.132572-1.199891.198857-1.788727.198857-.722156 0-1.388762-.077333-1.999818-.243048-.611056-.165714-1.14434-.408763-1.588745-.729144-.444404-.33143-.799927-.740192-1.05546-1.226289-.255532-.486096-.388853-1.071621-.411073-1.745528h2.533103v-.022095zm8.288135-7.700208h1.899828v-3.402675h2.510883v3.402675h2.26646v1.867052h-2.26646v6.054109c0 .265143.01111.486096.03333.684954.02222.18781.07777.353524.155542.486096.07777.132572.199981.232.366633.298287.166651.066285.377743.099428.666606.099428.177762 0 .355523 0 .533285-.011047.177762-.011048.355523-.033143.533285-.077334v1.933338c-.277753.033143-.555505.055238-.811038.088381-.266642.033143-.533285.04419-.811037.04419-.666606 0-1.199891-.066285-1.599855-.18781-.399963-.121523-.722156-.309333-.944358-.552381-.233313-.243049-.377744-.541335-.466625-.905907-.07777-.364573-.13332-.784383-.144431-1.248384v-6.683825h-1.899827v-1.889147h-.02222zm8.454788 0h2.377562V16.9253h.04444c.355523-.662858.844368-1.12686 1.477644-1.414098.633276-.287239 1.310992-.430858 2.055369-.430858.899918 0 1.677625.154667 2.344231.475048.666606.309335 1.222111.740193 1.666515 1.292575.444405.552382.766597 1.193145.9888 1.92229.222202.729145.333303 1.513527.333303 2.3421 0 .762288-.099991 1.50248-.299973 2.20953-.199982.718096-.499955 1.347812-.899918 1.900194-.399964.552383-.911029.98324-1.533194 1.31467-.622166.33143-1.344323.497144-2.18869.497144-.366634 0-.733267-.033143-1.0999-.099429-.366634-.066286-.722157-.176762-1.05546-.320381-.333303-.14362-.655496-.33143-.933249-.56343-.288863-.232-.522175-.497144-.722157-.79543h-.04444v5.656393h-2.510883V15.38968zm8.77698 5.67849c0-.508193-.06666-1.005337-.199981-1.491433-.133321-.486096-.333303-.905907-.599946-1.281527-.266642-.37562-.599945-.673906-.988799-.894859-.399963-.220953-.855478-.342477-1.366542-.342477-1.05546 0-1.855387.364572-2.388672 1.093717-.533285.729144-.799928 1.701337-.799928 2.916578 0 .574478.066661 1.104764.211092 1.59086.144432.486097.344414.905908.633276 1.259432.277753.353525.611056.629716.99991.828574.388853.209905.844367.309334 1.355432.309334.577725 0 1.05546-.121524 1.455423-.353525.399964-.232.722157-.541335.97769-.905907.255531-.37562.444403-.79543.555504-1.270479.099991-.475049.155542-.961145.155542-1.458289zm4.432931-9.99812h2.510883v2.364197h-2.510883V11.07005zm0 4.31963h2.510883v11.334883h-2.510883V15.389679zm4.755124-4.31963h2.510883v15.654513h-2.510883V11.07005zm10.210184 15.963847c-.911029 0-1.722066-.154667-2.433113-.452953-.711046-.298287-1.310992-.718097-1.810946-1.237337-.488845-.530287-.866588-1.160002-1.12212-1.889147-.255533-.729144-.388854-1.535622-.388854-2.408386 0-.861716.133321-1.657147.388853-2.386291.255533-.729145.633276-1.35886 1.12212-1.889148.488845-.530287 1.0999-.93905 1.810947-1.237336.711047-.298286 1.522084-.452953 2.433113-.452953.911028 0 1.722066.154667 2.433112.452953.711047.298287 1.310992.718097 1.810947 1.237336.488844.530287.866588 1.160003 1.12212 1.889148.255532.729144.388854 1.524575.388854 2.38629 0 .872765-.133322 1.679243-.388854 2.408387-.255532.729145-.633276 1.35886-1.12212 1.889147-.488845.530287-1.0999.93905-1.810947 1.237337-.711046.298286-1.522084.452953-2.433112.452953zm0-1.977528c.555505 0 1.04435-.121524 1.455423-.353525.411074-.232.744377-.541335 1.01102-.916954.266642-.37562.455513-.806478.588835-1.281527.12221-.475049.188872-.961145.188872-1.45829 0-.486096-.066661-.961144-.188872-1.44724-.122211-.486097-.322193-.905907-.588836-1.281527-.266642-.37562-.599945-.673907-1.011019-.905907-.411074-.232-.899918-.353525-1.455423-.353525-.555505 0-1.04435.121524-1.455424.353525-.411073.232-.744376.541334-1.011019.905907-.266642.37562-.455514.79543-.588835 1.281526-.122211.486097-.188872.961145-.188872 1.447242 0 .497144.06666.98324.188872 1.458289.12221.475049.322193.905907.588835 1.281527.266643.37562.599946.684954 1.01102.916954.411073.243048.899918.353525 1.455423.353525zm6.4883-9.66669h1.899827v-3.402674h2.510883v3.402675h2.26646v1.867052h-2.26646v6.054109c0 .265143.01111.486096.03333.684954.02222.18781.07777.353524.155541.486096.077771.132572.199982.232.366634.298287.166651.066285.377743.099428.666606.099428.177762 0 .355523 0 .533285-.011047.177762-.011048.355523-.033143.533285-.077334v1.933338c-.277753.033143-.555505.055238-.811038.088381-.266642.033143-.533285.04419-.811037.04419-.666606 0-1.199891-.066285-1.599855-.18781-.399963-.121523-.722156-.309333-.944358-.552381-.233313-.243049-.377744-.541335-.466625-.905907-.07777-.364573-.133321-.784383-.144431-1.248384v-6.683825h-1.899827v-1.889147h-.02222z" fill="#191919"/>\n      <path class="tp-logo__star" fill="#00B67A" d="M30.141707 11.07005H18.63164L15.076408.177071l-3.566342 10.892977L0 11.059002l9.321376 6.739063-3.566343 10.88193 9.321375-6.728016 9.310266 6.728016-3.555233-10.88193 9.310266-6.728016z"/>\n      <path class="tp-logo__star-notch" fill="#005128" d="M21.631369 20.26169l-.799928-2.463625-5.755033 4.153914z"/>\n  </svg>'
        }

        function s(e) {
            return '\n  <svg viewBox="0 0 ' + e.width + " " + e.height + '" xmlns="http://www.w3.org/2000/svg" ' + l + '>\n      <circle class="arrow-slider-circle" cx="12" cy="12" r="11.5" fill="none" stroke="#8C8C8C"/>\n      <path class="arrow-slider-shape" fill="#8C8C8C" d="M10.5088835 12l3.3080582-3.02451041c.2440777-.22315674.2440777-.5849653 0-.80812204-.2440776-.22315673-.6398058-.22315673-.8838834 0L9.18305826 11.595939c-.24407768.2231567-.24407768.5849653 0 .808122l3.75000004 3.4285714c.2440776.2231568.6398058.2231568.8838834 0 .2440777-.2231567.2440777-.5849653 0-.808122L10.5088835 12z"/>\n  </svg>\n'
        }

        function o(e, t) {
            return t = t.elementColor, '\n<svg viewBox="0 0 ' + e.width + " " + e.height + '" xmlns=“http://www.w3.org/2000/svg“ ' + l + '>\n  <path d="M5.24040526 8.60770645c0 .40275007-.25576387.51300008-.57003092.24825004L.2361338 4.98520583C.0871841 4.86986375 0 4.69208677 0 4.50370575s.0871841-.366158.2361338-.48150008L4.67037434.14470501c.31501709-.26625004.57003092-.15450003.57003092.24825004V2.9992055h.75004069c2.86515541 0 5.31553833 2.3745004 5.91257072 4.93950083a4.3385348 4.3385348 0 0 1 .09375508.5782501c.02250123.20025004-.07500406.24450004-.21826184.10350002 0 0-.0405022-.036-.07500406-.07500001C10.18673699 7.00766398 8.14655579 6.09727666 5.98894586 5.995456h-.75004068l.00150008 2.61225045z" fill="' + (t || "#00B67A") + '" fill-rule="evenodd"/>\n</svg>\n'
        }
        var u = e("../utils"),
            l = 'style="position: absolute; height: 100%; width: 100%; left: 0; top: 0;"',
            c = "#dcdce6",
            d = {
                width: 251,
                height: 46
            },
            f = {
                width: 126,
                height: 31
            },
            p = {
                width: 24,
                height: 24
            },
            v = {
                width: 12,
                height: 9
            };
        r.svgMap = {
            stars: function(e) {
                return n(d, a, e)
            },
            logo: function() {
                return n(f, i)
            },
            arrowSlider: function() {
                return n(p, s)
            },
            replyArrow: function(e) {
                return n(v, o, e)
            }
        }
    }, {
        "../utils": 61
    }],
    60: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.getFrameworkTranslation = r.formatLocale = r.defaultLocale = void 0;
        var n, a = e("../localization"),
            i = (n = a) && n.__esModule ? n : {
                default: n
            };

        function s(e) {
            var t, r = (t = e.split("-"))[0],
                e = (e = t[1]) || (u[t = r] || t);
            return r && e ? r + "-" + e.toUpperCase() : o
        }
        var o = "en-US",
            u = {
                da: "DK",
                en: "US",
                ja: "JP",
                nb: "NO",
                sv: "SE"
            };
        r.defaultLocale = o, r.formatLocale = s, r.getFrameworkTranslation = function(e) {
            var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : o,
                r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {},
                t = i.default[s(t)] || i.default[o],
                t = e.split(".").reduce(function(e, t) {
                    return e[t]
                }, t);
            return Object.keys(r).reduce(function(e, t) {
                return e.replace(t, r[t])
            }, t)
        }
    }, {
        "../localization": 17
    }],
    45: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = function(e, t, r) {
            return t && a(e.prototype, t), r && a(e, r), e
        };

        function a(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        var i, u = e("../utils"),
            s = e("../dom"),
            o = e("./controls");
        (function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        })(l, ((i = o) && i.__esModule ? i : {
            default: i
        }).default), n(l, [{
            key: "attachListeners",
            value: function() {
                function e() {}
                var t = this,
                    r = this.elements,
                    n = r.prevArrow,
                    a = r.nextArrow,
                    i = this.callbacks,
                    r = i.prevPage,
                    s = void 0 === r ? e : r,
                    i = i.nextPage,
                    o = void 0 === i ? e : i;
                (0, u.addEventListener)(n, "click", function() {
                    t.slider.moveContent(-1), s()
                }), (0, u.addEventListener)(a, "click", function() {
                    t.slider.moveContent(1), o()
                })
            }
        }, {
            key: "styleArrow",
            value: function(e, t) {
                var r = this.disabledClass;
                (t ? (0, s.addClass) : (0, s.removeClass))(e, r)
            }
        }, {
            key: "styleArrows",
            value: function() {
                var e = this.elements,
                    t = e.prevArrow,
                    e = e.nextArrow;
                this.styleArrow(t, this.slider.isAtFirstPage()), this.styleArrow(e, this.slider.isAtLastPage())
            }
        }, {
            key: "onUpdate",
            value: function() {
                this.styleArrows()
            }
        }]), n = l;

        function l(e, t) {
            var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, l);
            t = function(e, t) {
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !t || "object" != typeof t && "function" != typeof t ? e : t
            }(this, (l.__proto__ || Object.getPrototypeOf(l)).call(this, e, t));
            return t.callbacks = r.callbacks || {}, t.disabledClass = r.disabledClass, t
        }
        r.default = n
    }, {
        "../dom": 38,
        "../utils": 61,
        "./controls": 46
    }],
    46: [function(e, t, r) {
        "use strict";

        function n(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var a = (function(e, t, r) {
            return t && n(e.prototype, t), r && n(e, r), e
        }(i, [{
            key: "initialize",
            value: function() {
                this.attachListeners(), this.slider.attachObserver(this), this.slider.initialize(), this.onUpdate()
            }
        }, {
            key: "attachListeners",
            value: function() {
                throw new Error("attachListeners method not yet implemented")
            }
        }, {
            key: "onUpdate",
            value: function() {
                throw new Error("onUpdate method not yet implemented")
            }
        }, {
            key: "onPageChange",
            value: function() {
                this.onUpdate()
            }
        }, {
            key: "onResize",
            value: function() {
                this.onUpdate()
            }
        }]), i);

        function i(e, t) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, i), this.slider = e, this.elements = t
        }
        r.default = a
    }, {}],
    48: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = function(e, t, r) {
            return t && a(e.prototype, t), r && a(e, r), e
        };

        function a(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        var i, s = e("../utils"),
            o = e("../dom"),
            u = e("./controls");
        (function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        })(l, ((i = u) && i.__esModule ? i : {
            default: i
        }).default), n(l, [{
            key: "attachListeners",
            value: function() {
                function r() {}
                var n = this,
                    e = this.elements;
                e.forEach(function(e, t) {
                    0 === t && (0, o.addClass)(e, n.activeClass), (0, s.addEventListener)(e, "click", function() {
                        n.slider.jumpToPage(t + 1), (n.callbacks[t] || r)()
                    })
                })
            }
        }, {
            key: "onUpdate",
            value: function() {
                var r = this;
                this.elements.forEach(function(e, t) {
                    (r.slider.currentPage === t + 1 ? (0, o.addClass) : (0, o.removeClass))(e, r.activeClass)
                })
            }
        }]), n = l;

        function l(e, t) {
            var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, l);
            t = function(e, t) {
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !t || "object" != typeof t && "function" != typeof t ? e : t
            }(this, (l.__proto__ || Object.getPrototypeOf(l)).call(this, e, t));
            return t.callbacks = r.callbacks || [], t.activeClass = r.activeClass, t
        }
        r.default = n
    }, {
        "../dom": 38,
        "../utils": 61,
        "./controls": 46
    }],
    49: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = function(e, t, r) {
            return t && a(e.prototype, t), r && a(e, r), e
        };

        function a(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        var i = e("../utils"),
            s = e("../touch");
        var o = function(e, t, r) {
                return Math.max(Math.min(e, r), t)
            },
            n = (n(u, [{
                key: "setReviewsPerPage",
                value: function(e) {
                    "number" == typeof e ? this.reviewsPerPage = [{
                        minWidth: 0,
                        reviewsForWidth: e
                    }] : (this.reviewsPerPage = e, this.reviewsPerPage.sort(function(e, t) {
                        e = e.minWidth;
                        return t.minWidth - e
                    }))
                }
            }, {
                key: "populateSlider",
                value: function() {
                    this.elements.slider.innerHTML = this.reviews.map(this.template.bind(this)).join("")
                }
            }, {
                key: "initialize",
                value: function() {
                    this.isInitialized || (this.populateSlider(), this.calculateReviewsPerPage(), this.touch = new s.TrustBoxesTouch({
                        targetElement: this.elements.slider,
                        pageWidth: this.sliderContainerWidth,
                        touchStartCallback: this.touchStartCallback,
                        touchMoveCallback: this.touchMoveCallback,
                        touchEndCallback: this.touchEndCallback
                    }), this.touch.attach(), this.windowResize(), this.attachResizeListener(), this.isInitialized = !0)
                }
            }, {
                key: "getFirstVisibleReviewIndex",
                value: function() {
                    return this._reviewsPerPage * (this.currentPage - 1)
                }
            }, {
                key: "isAtFirstPage",
                value: function() {
                    return 1 === this.currentPage
                }
            }, {
                key: "isAtLastPage",
                value: function() {
                    return this.currentPage === this.totalPages
                }
            }, {
                key: "setSliderTranslateX",
                value: function(e) {
                    this.elements.slider.style.transform = "translateX(" + e + "px)"
                }
            }, {
                key: "setSliderTransitionDuration",
                value: function(e) {
                    this.elements.slider.style.transitionDuration = e + "s"
                }
            }, {
                key: "reviewElementMargins",
                value: function() {
                    if (0 !== this.reviewElements.length && this.reviewElements[0]) {
                        var e = window.getComputedStyle(this.reviewElements[0]);
                        return {
                            left: parseInt(e.marginLeft),
                            right: parseInt(e.marginRight)
                        }
                    }
                    return {
                        left: 0,
                        right: 0
                    }
                }
            }, {
                key: "calculateReviewsPerPage",
                value: function() {
                    var e = this.reviewsPerPage.reduce(function(e, t) {
                        var r = t.minWidth,
                            t = t.reviewsForWidth;
                        return !e && document.documentElement.clientWidth >= r ? {
                            minWidth: r,
                            reviewsForWidth: t
                        } : e
                    }, null);
                    this._reviewsPerPage = e.reviewsForWidth, this._defaultSliderWidth = e.minWidth
                }
            }, {
                key: "attachObserver",
                value: function(e) {
                    this.observers.push(e)
                }
            }, {
                key: "detachObserver",
                value: function(t) {
                    this.observers = this.observers.filter(function(e) {
                        return e !== t
                    })
                }
            }, {
                key: "attachResizeListener",
                value: function() {
                    var e = this;
                    (0, i.addEventListener)(window, "resize", function() {
                        null !== e.resizeTimeout && window.clearTimeout(e.resizeTimeout), e.resizeTimeout = window.setTimeout(function() {
                            e.windowResize()
                        }, 200)
                    })
                }
            }, {
                key: "windowResize",
                value: function() {
                    var t = this;
                    this.setPageOnResize(), this.elements.slider.style.width = this.reviewCount * this.reviewWidthWithMargins + "px", this.reviewElements.forEach(function(e) {
                        e.style.width = t.reviewWidth + "px"
                    }), this.observers.forEach(function(e) {
                        return e.onResize()
                    })
                }
            }, {
                key: "setPageOnResize",
                value: function() {
                    this.currentPage;
                    var e = this._reviewsPerPage * (this.currentPage - 1);
                    this.calculateReviewsPerPage();
                    e = Math.floor(e / this._reviewsPerPage) + 1;
                    this.jumpToPage(e, 0), this.touch.setPageWidth(this.sliderContainerWidth)
                }
            }, {
                key: "moveContent",
                value: function(e) {
                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1,
                        e = o(e + this.currentPage, 1, this.totalPages);
                    this.jumpToPage(e, t)
                }
            }, {
                key: "pageOffset",
                value: function(e) {
                    return this.sliderContainerWidth * (e - 1) * -1
                }
            }, {
                key: "jumpToPage",
                value: function(e) {
                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1,
                        r = this.pageOffset(e);
                    this.setSliderTranslateX(r), this.setSliderTransitionDuration(t), this.currentPage = e, this.observers.forEach(function(e) {
                        return e.onPageChange()
                    })
                }
            }, {
                key: "totalPages",
                get: function() {
                    return Math.ceil(this.reviewCount / this._reviewsPerPage)
                }
            }, {
                key: "reviewWidth",
                get: function() {
                    var e = this.reviewElementMargins(),
                        t = e.left,
                        e = e.right;
                    return this.reviewWidthWithMargins - (t + e)
                }
            }, {
                key: "reviewWidthWithMargins",
                get: function() {
                    return this.sliderContainerWidth / this._reviewsPerPage
                }
            }, {
                key: "sliderContainerWidth",
                get: function() {
                    var e = this.reviewElementMargins(),
                        t = e.right,
                        e = e.left;
                    return (this.elements.sliderContainer.offsetWidth || this._defaultSliderWidth) + t + e
                }
            }, {
                key: "reviewElements",
                get: function() {
                    return [].slice.call(this.elements.slider.getElementsByClassName(this.reviewClass))
                }
            }]), u);

        function u(e, t, r) {
            var n = this,
                a = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {};
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, u), this.reviews = e, this.elements = t, this.reviewCount = e.length, this.template = r, this.reviewClass = a.reviewClass, this.setReviewsPerPage(a.reviewsPerPage), this.currentPage = 1, this.resizeTimeout = null, this.observers = [], this.isInitialized = !1, this.touchStartCallback = function(e) {
                var t = e.translateX,
                    e = e.originPage;
                n.setSliderTransitionDuration(0), n.setSliderTranslateX(t), n.currentPage = e
            }, this.touchMoveCallback = function(e) {
                e = e.translateX;
                n.setSliderTranslateX(e)
            }, this.touchEndCallback = function(e) {
                var t = e.pagesToSwipe,
                    e = e.transitionDuration;
                n.moveContent(t, o(e, .2, 1))
            }
        }
        r.default = n
    }, {
        "../touch": 59,
        "../utils": 61
    }],
    59: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = function(e, t, r) {
            return t && a(e.prototype, t), r && a(e, r), e
        };

        function a(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        Math.sign = Math.sign || function(e) {
            return (0 < e) - (e < 0) || +e
        };
        r.TrustBoxesTouch = (n(s, [{
            key: "getDragDistance",
            value: function() {
                return {
                    x: this.touchPosition.stop.x - this.touchPosition.start.x,
                    y: this.touchPosition.stop.y - this.touchPosition.start.y
                }
            }
        }, {
            key: "getPagesToSwipe",
            value: function(e) {
                var t = this.getDragDistance().x + this.offsetDistanceX,
                    r = Math.abs(t) % this.pageWidth,
                    t = Math.ceil(Math.abs(t / this.pageWidth)) || 1;
                return r > this.sensitivity && !e ? t : t - 1
            }
        }, {
            key: "setPageWidth",
            value: function(e) {
                this.pageWidth = e
            }
        }, {
            key: "attach",
            value: function() {
                var n = this;
                this.targetElement.addEventListener("touchstart", function(e) {
                    n.startTouchTime = (new Date).getTime(), n.touchPosition.start.x = e.changedTouches[0].screenX, n.touchPosition.start.y = e.changedTouches[0].screenY;
                    var t = window.getComputedStyle(n.targetElement),
                        r = 0;
                    window.DOMMatrix && (r = new window.DOMMatrix(t.webkitTransform).m41, n.initialX = Math.round(r / n.pageWidth) * n.pageWidth, n.offsetDistanceX = r - n.initialX), n.scrollAxis = "none", 5 < Math.abs(n.offsetDistanceX) && (e.preventDefault(), n.scrollAxis = "x"), n.touchStartCallback({
                        translateX: r,
                        originPage: Math.abs(n.initialX) / n.pageWidth + 1
                    })
                }), this.targetElement.addEventListener("touchmove", function(e) {
                    n.touchPosition.stop.x = e.changedTouches[0].screenX, n.touchPosition.stop.y = e.changedTouches[0].screenY;
                    var t = n.getDragDistance();
                    "none" === n.scrollAxis && (n.scrollAxis = Math.abs(t.x) >= Math.abs(t.y) ? "x" : "y"), "x" === n.scrollAxis && (e.preventDefault(), n.directionX = t.x - n.lastDragDistanceX, n.lastDragDistanceX = t.x, n.touchMoveCallback({
                        translateX: t.x + n.offsetDistanceX + n.initialX
                    }))
                }), this.targetElement.addEventListener("touchend", function() {
                    var e = ((new Date).getTime() - n.startTouchTime) / 1e3,
                        t = n.getDragDistance(),
                        r = Math.abs(t.x) / e,
                        e = n.pageWidth / r,
                        r = t.x + n.offsetDistanceX + n.initialX,
                        t = Math.sign(n.initialX - r),
                        r = Math.sign(n.directionX) === t,
                        r = "x" === n.scrollAxis ? n.getPagesToSwipe(r) : 0;
                    n.touchEndCallback({
                        pagesToSwipe: r * t,
                        transitionDuration: e
                    })
                })
            }
        }]), s);

        function s(e) {
            var t = e.targetElement,
                r = void 0 === t ? null : t,
                n = e.pageWidth,
                a = void 0 === n ? null : n,
                i = e.sensitivity,
                t = void 0 === i ? 25 : i,
                n = e.touchEndCallback,
                i = void 0 === n ? function() {} : n,
                n = e.touchMoveCallback,
                n = void 0 === n ? function() {} : n,
                e = e.touchStartCallback,
                e = void 0 === e ? function() {} : e;
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, s), this.targetElement = r, this.pageWidth = a, this.sensitivity = t, this.touchEndCallback = i, this.touchMoveCallback = n, this.touchStartCallback = e, this.initialX = 0, this.offsetDistanceX = 0, this.startTouchTime = 0, this.lastDragDistanceX = 0, this.directionX = 0, this.scrollAxis = "none", this.touchPosition = {
                start: {
                    x: 0,
                    y: 0
                },
                stop: {
                    x: 0,
                    y: 0
                }
            }, this.targetElement.style.userSelect = "none", this.targetElement.style.transitionTimingFunction = "ease"
        }
    }, {}],
    50: [function(e, t, r) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var o = e("./translations"),
            u = {
                0: "january",
                1: "february",
                2: "march",
                3: "april",
                4: "may",
                5: "june",
                6: "july",
                7: "august",
                8: "september",
                9: "october",
                10: "november",
                11: "december"
            };

        function l(e, t) {
            return (n = t) < (r = e) && n / 2 <= r % n ? Math.ceil(e / t) : Math.floor(e / t);
            var r, n
        }

        function c(e) {
            return 1 === e ? "singular" : "plural"
        }
        r.default = function(e, t) {
            if (!t) return null;
            var r = (0, o.formatLocale)(e),
                n = Date.parse(t),
                a = new Date(n),
                i = new Date,
                s = Math.floor((i - n) / 1e3),
                e = l(s, 60),
                t = l(e, 60),
                i = l(t, 24);
            if (7 <= i) {
                n = a.getMonth(), a = a.getDate(), n = (0, o.getFrameworkTranslation)("monthNames." + u[n], r);
                return r === o.defaultLocale ? n + " " + a : "ja-JP" === r ? n + " " + a + "日" : a + " " + n
            }
            return 0 < i ? (0, o.getFrameworkTranslation)("timeAgo.days." + c(i), r, {
                "[count]": i
            }) : 0 < t ? (0, o.getFrameworkTranslation)("timeAgo.hours." + c(t), r, {
                "[count]": t
            }) : 0 < e ? (0, o.getFrameworkTranslation)("timeAgo.minutes." + c(e), r, {
                "[count]": e
            }) : 0 <= s ? (0, o.getFrameworkTranslation)("timeAgo.seconds." + c(s), r, {
                "[count]": s
            }) : void 0
        }
    }, {
        "./translations": 60
    }],
    58: [function(e, t, r) {
        "use strict";

        function n(e) {
            var t = {
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&apos;",
                "/": "&sol;",
                "=": "&equals;",
                "`": "&grave;"
            };
            return e.replace(/[<>"'`=\/]/g, function(e) {
                return t[e]
            })
        }
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.truncateText = function(e, t) {
            if (isNaN(t)) return e;
            if (t <= 0) return "";
            if (e && e.length > t) {
                for (var r = (e = e.substring(0, t)).charAt(e.length - 1);
                    " " === r || "." === r || "," === r;) r = (e = e.substr(0, e.length - 1)).charAt(e.length - 1);
                e += "..."
            }
            return n(e)
        }, r.escapeHtml = n
    }, {}],
    63: [function(e, t, r) {
        "use strict";
        var n = e("./raw"),
            a = [],
            i = [],
            s = n.makeRequestCallFromTimer(function() {
                if (i.length) throw i.shift()
            });

        function o(e) {
            var t = a.length ? a.pop() : new u;
            t.task = e, n(t)
        }

        function u() {
            this.task = null
        }
        t.exports = o, u.prototype.call = function() {
            try {
                this.task.call()
            } catch (e) {
                o.onerror ? o.onerror(e) : (i.push(e), s())
            } finally {
                this.task = null, a[a.length] = this
            }
        }
    }, {
        "./raw": 64
    }],
    64: [function(e, f, t) {
        ! function(d) {
            ! function() {
                "use strict";

                function e(e) {
                    n.length || (t(), 0), n[n.length] = e
                }
                f.exports = e;
                var t, n = [],
                    a = 0;

                function r() {
                    for (; a < n.length;) {
                        var e = a;
                        if (a += 1, n[e].call(), 1024 < a) {
                            for (var t = 0, r = n.length - a; t < r; t++) n[t] = n[t + a];
                            n.length -= a, a = 0
                        }
                    }
                    n.length = 0, a = 0, 0
                }
                var i, s, o, u = void 0 !== d ? d : self,
                    l = u.MutationObserver || u.WebKitMutationObserver;

                function c(n) {
                    return function() {
                        var e = setTimeout(r, 0),
                            t = setInterval(r, 50);

                        function r() {
                            clearTimeout(e), clearInterval(t), n()
                        }
                    }
                }
                t = "function" == typeof l ? (s = 1, i = new l(i = r), o = document.createTextNode(""), i.observe(o, {
                    characterData: !0
                }), function() {
                    s = -s, o.data = s
                }) : c(r), e.requestFlush = t, e.makeRequestCallFromTimer = c
            }.call(this)
        }.call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
    }, {}],
    70: [function(e, t, r) {
        "use strict";
        t.exports = e("./core.js"), e("./done.js"), e("./finally.js"), e("./es6-extensions.js"), e("./node-extensions.js"), e("./synchronous.js")
    }, {
        "./core.js": 66,
        "./done.js": 67,
        "./es6-extensions.js": 68,
        "./finally.js": 69,
        "./node-extensions.js": 71,
        "./synchronous.js": 72
    }],
    66: [function(e, t, r) {
        "use strict";
        var a = e("asap/raw");

        function s() {}
        var i = null,
            o = {};

        function u(e) {
            if ("object" != typeof this) throw new TypeError("Promises must be constructed via new");
            if ("function" != typeof e) throw new TypeError("Promise constructor's argument is not a function");
            this._40 = 0, this._65 = 0, this._55 = null, this._72 = null, e !== s && p(e, this)
        }

        function l(e, t) {
            for (; 3 === e._65;) e = e._55;
            if (u._37 && u._37(e), 0 === e._65) return 0 === e._40 ? (e._40 = 1, void(e._72 = t)) : 1 === e._40 ? (e._40 = 2, void(e._72 = [e._72, t])) : void e._72.push(t);
            var r, n;
            r = e, n = t, a(function() {
                var e = 1 === r._65 ? n.onFulfilled : n.onRejected;
                null !== e ? (e = function(e, t) {
                    try {
                        return e(t)
                    } catch (e) {
                        return i = e, o
                    }
                }(e, r._55)) === o ? d(n.promise, i) : c(n.promise, e) : (1 === r._65 ? c : d)(n.promise, r._55)
            })
        }

        function c(e, t) {
            if (t === e) return d(e, new TypeError("A promise cannot be resolved with itself.")), 0;
            if (t && ("object" == typeof t || "function" == typeof t)) {
                var r = function(e) {
                    try {
                        return e.then
                    } catch (e) {
                        return i = e, o
                    }
                }(t);
                if (r === o) return d(e, i), 0;
                if (r === e.then && t instanceof u) return e._65 = 3, e._55 = t, void n(e);
                if ("function" == typeof r) return void p(r.bind(t), e)
            }
            e._65 = 1, e._55 = t, n(e)
        }

        function d(e, t) {
            e._65 = 2, e._55 = t, u._87 && u._87(e, t), n(e)
        }

        function n(e) {
            if (1 === e._40 && (l(e, e._72), e._72 = null), 2 === e._40) {
                for (var t = 0; t < e._72.length; t++) l(e, e._72[t]);
                e._72 = null
            }
        }

        function f(e, t, r) {
            this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = r
        }

        function p(e, t) {
            var r = !1,
                e = function(e, t, r) {
                    try {
                        e(t, r)
                    } catch (e) {
                        return i = e, o
                    }
                }(e, function(e) {
                    r || (r = !0, c(t, e))
                }, function(e) {
                    r || (r = !0, d(t, e))
                });
            r || e !== o || (r = !0, d(t, i))
        }(t.exports = u)._37 = null, u._87 = null, u._61 = s, u.prototype.then = function(e, t) {
            if (this.constructor !== u) return a = e, i = t, new(n = this).constructor(function(e, t) {
                var r = new u(s);
                r.then(e, t), l(n, new f(a, i, r))
            });
            var n, a, i, r = new u(s);
            return l(this, new f(e, t, r)), r
        }
    }, {
        "asap/raw": 64
    }],
    67: [function(e, t, r) {
        "use strict";
        e = e("./core.js");
        (t.exports = e).prototype.done = function(e, t) {
            (arguments.length ? this.then.apply(this, arguments) : this).then(null, function(e) {
                setTimeout(function() {
                    throw e
                }, 0)
            })
        }
    }, {
        "./core.js": 66
    }],
    68: [function(e, t, r) {
        "use strict";
        var u = e("./core.js");
        t.exports = u;
        var n = c(!0),
            a = c(!1),
            i = c(null),
            s = c(void 0),
            o = c(0),
            l = c("");

        function c(e) {
            var t = new u(u._61);
            return t._65 = 1, t._55 = e, t
        }
        u.resolve = function(e) {
            if (e instanceof u) return e;
            if (null === e) return i;
            if (void 0 === e) return s;
            if (!0 === e) return n;
            if (!1 === e) return a;
            if (0 === e) return o;
            if ("" === e) return l;
            if ("object" == typeof e || "function" == typeof e) try {
                var t = e.then;
                if ("function" == typeof t) return new u(t.bind(e))
            } catch (r) {
                return new u(function(e, t) {
                    t(r)
                })
            }
            return c(e)
        }, u.all = function(e) {
            var o = Array.prototype.slice.call(e);
            return new u(function(a, i) {
                if (0 === o.length) return a([]);
                var s = o.length;
                for (var e = 0; e < o.length; e++) ! function t(r, e) {
                    if (e && ("object" == typeof e || "function" == typeof e)) {
                        if (e instanceof u && e.then === u.prototype.then) {
                            for (; 3 === e._65;) e = e._55;
                            return 1 === e._65 ? t(r, e._55) : (2 === e._65 && i(e._55), void e.then(function(e) {
                                t(r, e)
                            }, i))
                        }
                        var n = e.then;
                        if ("function" == typeof n) return void new u(n.bind(e)).then(function(e) {
                            t(r, e)
                        }, i)
                    }
                    o[r] = e, 0 == --s && a(o)
                }(e, o[e])
            })
        }, u.reject = function(r) {
            return new u(function(e, t) {
                t(r)
            })
        }, u.race = function(e) {
            return new u(function(t, r) {
                e.forEach(function(e) {
                    u.resolve(e).then(t, r)
                })
            })
        }, u.prototype.catch = function(e) {
            return this.then(null, e)
        }
    }, {
        "./core.js": 66
    }],
    69: [function(e, t, r) {
        "use strict";
        var n = e("./core.js");
        (t.exports = n).prototype.finally = function(t) {
            return this.then(function(e) {
                return n.resolve(t()).then(function() {
                    return e
                })
            }, function(e) {
                return n.resolve(t()).then(function() {
                    throw e
                })
            })
        }
    }, {
        "./core.js": 66
    }],
    72: [function(e, t, r) {
        "use strict";
        var n = e("./core.js");
        (t.exports = n).enableSynchronous = function() {
            n.prototype.isPending = function() {
                return 0 == this.getState()
            }, n.prototype.isFulfilled = function() {
                return 1 == this.getState()
            }, n.prototype.isRejected = function() {
                return 2 == this.getState()
            }, n.prototype.getValue = function() {
                if (3 === this._65) return this._55.getValue();
                if (!this.isFulfilled()) throw new Error("Cannot get a value of an unfulfilled promise.");
                return this._55
            }, n.prototype.getReason = function() {
                if (3 === this._65) return this._55.getReason();
                if (!this.isRejected()) throw new Error("Cannot get a rejection reason of a non-rejected promise.");
                return this._55
            }, n.prototype.getState = function() {
                return 3 === this._65 ? this._55.getState() : -1 === this._65 || -2 === this._65 ? 0 : this._65
            }
        }, n.disableSynchronous = function() {
            n.prototype.isPending = void 0, n.prototype.isFulfilled = void 0, n.prototype.isRejected = void 0, n.prototype.getValue = void 0, n.prototype.getReason = void 0, n.prototype.getState = void 0
        }
    }, {
        "./core.js": 66
    }],
    71: [function(e, t, r) {
        "use strict";
        var i = e("./core.js"),
            a = e("asap");
        (t.exports = i).denodeify = function(e, t) {
            return "number" == typeof t && t !== 1 / 0 ? function(e, t) {
                for (var r = [], n = 0; n < t; n++) r.push("a" + n);
                var a = ["return function (" + r.join(",") + ") {", "var self = this;", "return new Promise(function (rs, rj) {", "var res = fn.call(", ["self"].concat(r).concat([s]).join(","), ");", "if (res &&", '(typeof res === "object" || typeof res === "function") &&', 'typeof res.then === "function"', ") {rs(res);}", "});", "};"].join("");
                return Function(["Promise", "fn"], a)(i, e)
            }(e, t) : function(e) {
                for (var t = Math.max(e.length - 1, 3), r = [], n = 0; n < t; n++) r.push("a" + n);
                var a = ["return function (" + r.join(",") + ") {", "var self = this;", "var args;", "var argLength = arguments.length;", "if (arguments.length > " + t + ") {", "args = new Array(arguments.length + 1);", "for (var i = 0; i < arguments.length; i++) {", "args[i] = arguments[i];", "}", "}", "return new Promise(function (rs, rj) {", "var cb = " + s + ";", "var res;", "switch (argLength) {", r.concat(["extra"]).map(function(e, t) {
                    return "case " + t + ":res = fn.call(" + ["self"].concat(r.slice(0, t)).concat("cb").join(",") + ");break;"
                }).join(""), "default:", "args[argLength] = cb;", "res = fn.apply(self, args);", "}", "if (res &&", '(typeof res === "object" || typeof res === "function") &&', 'typeof res.then === "function"', ") {rs(res);}", "});", "};"].join("");
                return Function(["Promise", "fn"], a)(i, e)
            }(e)
        };
        var s = "function (err, res) {if (err) { rj(err); } else { rs(res); }}";
        i.nodeify = function(r) {
            return function() {
                var e = Array.prototype.slice.call(arguments),
                    t = "function" == typeof e[e.length - 1] ? e.pop() : null,
                    n = this;
                try {
                    return r.apply(this, arguments).nodeify(t, n)
                } catch (r) {
                    if (null == t) return new i(function(e, t) {
                        t(r)
                    });
                    a(function() {
                        t.call(n, r)
                    })
                }
            }
        }, i.prototype.nodeify = function(t, r) {
            if ("function" != typeof t) return this;
            this.then(function(e) {
                a(function() {
                    t.call(r, null, e)
                })
            }, function(e) {
                a(function() {
                    t.call(r, e)
                })
            })
        }
    }, {
        "./core.js": 66,
        asap: 63
    }]
}, {}, [1]);
//# sourceMappingURL=main.js.map