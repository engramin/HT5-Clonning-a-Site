window.hjSiteSettings = window.hjSiteSettings || {
    "site_id": 1748406,
    "r": 0.41717840443121695,
    "rec_value": 0.0,
    "state_change_listen_mode": "automatic",
    "record": false,
    "continuous_capture_enabled": true,
    "recording_capture_keystrokes": false,
    "anonymize_digits": true,
    "anonymize_emails": true,
    "suppress_all": false,
    "suppress_text": false,
    "suppress_location": true,
    "user_attributes_enabled": false,
    "legal_name": "TollFreeForwarding.com",
    "privacy_policy_url": "https://tollfreeforwarding.com/content/privacy-policy/",
    "deferred_page_contents": [],
    "record_targeting_rules": [],
    "feedback_widgets": [],
    "heatmaps": [],
    "polls": [],
    "integrations": {
        "optimizely": {
            "tag_recordings": false
        },
        "google_optimize": {
            "tag_recordings": true
        }
    },
    "features": ["feedback.widgetV2", "heatmap.continuous_capture", "settings.billing_v2", "heatmap.continuous.manual_retaker", "survey.impressions", "feedback.widget_telemetry", "client_script.safe_date"]
};

! function(e) {
    var t = {};

    function n(o) {
        if (t[o]) return t[o].exports;
        var a = t[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return e[o].call(a.exports, a, a.exports, n), a.l = !0, a.exports
    }
    n.m = e, n.c = t, n.d = function(e, t, o) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: o
        })
    }, n.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function(e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var o = Object.create(null);
        if (n.r(o), Object.defineProperty(o, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var a in e) n.d(o, a, function(t) {
                return e[t]
            }.bind(null, a));
        return o
    }, n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = 249)
}({
    249: function(e, t) {
        window.hjBootstrap = window.hjBootstrap || function(e, t, n) {
            var o = ["bot", "google", "headless", "baidu", "bing", "msn", "duckduckbot", "teoma", "slurp", "yandex", "phantomjs", "pingdom", "ahrefsbot"].join("|"),
                a = new RegExp(o, "i"),
                i = window.navigator || {
                    userAgent: "unknown"
                },
                r = i.userAgent ? i.userAgent : "unknown";
            if (a.test(r)) console.warn("Hotjar not launching due to suspicious userAgent:", r);
            else {
                var s = "http:" === window.location.protocol,
                    d = Boolean(window._hjSettings.preview);
                if (!s || d) {
                    var l = function(e, t, n) {
                        window.hjBootstrapCalled = (window.hjBootstrapCalled || []).concat(n), window.hj && window.hj._init && window.hj._init._verifyInstallation && hj._init._verifyInstallation()
                    };
                    l(0, 0, n);
                    var p, _, c, u, h = window.document,
                        j = h.head || h.getElementsByTagName("head")[0];
                    h.addEventListener && (hj.scriptDomain = e, (p = h.createElement("script")).async = 1, p.src = hj.scriptDomain + t, p.charset = "utf-8", j.appendChild(p), u = ["iframe#_hjRemoteVarsFrame {", "display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;", "}"], (_ = h.createElement("style")).type = "text/css", _.styleSheet ? _.styleSheet.cssText = u.join("") : _.appendChild(h.createTextNode(u.join(""))), j.appendChild(_), (c = h.createElement("iframe")).style.cssText = u[1], c.name = "_hjRemoteVarsFrame", c.title = "_hjRemoteVarsFrame", c.id = "_hjRemoteVarsFrame", c.src = "https://" + (window._hjSettings.varsHost || "vars.hotjar.com") + "/box-0004cb77850b00d4aa7e1e08ff61e8f0.html", c.onload = function() {
                        l.varsLoaded = !0, "undefined" != typeof hj && hj.event && hj.event.signal && hj.event.signal("varsLoaded")
                    }, l.varsJar = c, "interactive" === h.readyState || "complete" === h.readyState || "loaded" === h.readyState ? f() : h.addEventListener("DOMContentLoaded", f), l.revision = "e6cc26c7f53e", window.hjBootstrap = l)
                } else console.warn("For security reasons, Hotjar only works over HTTPS. Learn more: https://help.hotjar.com/hc/en-us/articles/115011624047")
            }

            function f() {
                setTimeout(function() {
                    h.body.appendChild(c)
                }, 50)
            }
        }, window.hjBootstrap("https://script.hotjar.com/", "modules.575e0da598e3619bac00.js", "1748406"), window.hjLazyModules = window.hjLazyModules || {
            SURVEY_V2: {
                js: "survey-v2.444fe3b9961b3a408776.js"
            },
            SURVEY_BOOTSTRAPPER: {
                js: "survey-bootstrapper.133397acdc2690799633.js"
            },
            SURVEY_ISOLATED: {
                js: "survey-isolated.a7c7bfc7b2c6bedfe4ca.js"
            },
            HEATMAP_SCREENSHOTTER: {
                js: "heatmap-screenshotter.acfa1f8b7bca47b726ab.js"
            },
            HEATMAP_VIEWER: {
                js: "heatmap-viewer.fe18c087b4237a69eff5.js"
            },
            HEATMAP_DYNAMIC_VIEW: {
                js: "heatmap-dynamic-view.f6d9b7e940894e797b26.js"
            },
            HEATMAP_RETAKER: {
                js: "heatmap-retaker.ce8c1ff2986f25bc15f3.js"
            },
            SURVEY_INVITATION: {
                js: "survey-invitation.e36020b3fa6368fb37a9.js"
            },
            NOTIFICATION: {
                js: "notification.3811201ddab7e515aff1.js"
            },
            INCOMING_FEEDBACK: {
                js: "incoming-feedback.4bd0beafc651e92622ea.js"
            },
            PREACT_INCOMING_FEEDBACK: {
                js: "preact-incoming-feedback.b60656efbceec5fd4658.js"
            },
            SENTRY: {
                js: "sentry.c6b3d2ce1b0363a86f37.js"
            }
        }
    }
});